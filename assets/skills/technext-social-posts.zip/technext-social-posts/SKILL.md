---
name: technext-social-posts
description: Design, render and deliver TechNext social media posts that showcase a TechNext service and a real Odoo process as cinematic, non-flat scenes - 3:4 portrait images (one 2160x2880 high-quality file per post) and 9:16 Reels videos (1080x1920 seamless MP4 loops), compiled in one flat folder with no duplicate versions - with the fixed TechNext + Odoo logo row, captions per platform, a layout/safe-zone QA gate and md5-verified delivery to the Marketing shared drive. Built as HTML (canvas, three.js, WebGL shaders, CSS 3D) rendered by headless Chrome. Use whenever the user asks for social media posts, FB/IG/LinkedIn creatives, a posting image, reels, a post video, carousel, post batch, "socmed" content, a post about an Odoo app, an industry or a TechNext service, or wants TechNext posts redesigned, animated or resized - even if they don't say "skill".
---

# TechNext social posts

TechNext (Odoo Ready Partner; SG HQ, PH and VN teams) sells Odoo ERP, AI, Marketing and Technology services. Every post
does three things at once: **name a TechNext service, show a real Odoo process, and look like nothing else in the feed.**

## The formats (owner rule, 2026-10-07 - enforced by the scripts)
| Kind | Ratio | Files | How |
|---|---|---|---|
| **Image post** | **3:4 portrait only** | ONE file `NN-technext-<slug>.png`, 2160x2880 high quality (Instagram shrinks it to 1080x1440) | `render.py page.html --posts N` (default `--fmt 34`) |
| **Video post** | **9:16 Reels only** | `NN-technext-<slug>-reel.mp4` 1080x1920, 8 s seamless loop, silent | `render.py page.html --posts N --fmt reel` |
No other ratios (no 4:5, 1:1 or landscape) unless the owner asks. **One folder per batch, one file per post, no
duplicates** (no second size, no overview sheet, no reel cover, no old version in the delivery folder), and **images and
videos always apart**. Owner 2026-10-10: the posting-image folder is **images only** ("dont add video in this folder") - batch folder = `Image Posts\` + `captions.md` + `source\`; reels stay in the work folder unless the owner names a video destination (`deliver.py --with-video` refuses the posting-image folder). **Every created image also gets a copy in** `02. TechNext Folder\02. TechNext Social Media Posting Image\00. All Images (2026-10-09 to 10-10)\` (deliver.py does it by default). `render.py` refuses video in 3:4. Reels are posted to TikTok, YouTube Shorts AND Instagram Reels, so all
text, logos and the CTA stay inside ONE combined **safe zone**: below y 240, above the bottom 480 px, and clear of the right
150 px from y 760 down; kit.js QA + audit.py fail anything outside it. The empty space a 9:16 frame adds gets **extended
elements** (the post's world continued, with motion) - never a blank band (formats.md). Reels go to
`02. TechNext Folder\02.5. TechNext Social Media Posting Video\` (same batch layout: `Video Posts\` + `captions.md` + `00. All Videos`).
One page serves both: `?f=34` / `?f=reel` switches the layout (see `reference/formats.md`).

## The owner's standing direction (all still in force)
- **Logo row** fixed on every post: TechNext logo top-left; **plain Odoo wordmark** top-right, no card, never the "Odoo
  Ready Partner" badge image.
- **Not flat, not a workflow of boxes**: the Odoo process lives inside a scene. Light, warm palettes preferred; no dark
  sci-fi / hologram panels (post 14 was rejected: "DONT DO THIS KIND FOR DESIGN").
- **Cinematic and unique per poster** (2026-10-07): "make it dynamic, cinematic, and unique in different poster/content,
  no similar design like what we do previously." Each poster = its own film idea, light plan, build technique, text
  placement and label style, with motion. Never repeat a look from the used table in `style-library.md`.
- Nexi (the TechNext robot) wherever a layout has space (owner 2026-10-09), in an ACTION pose with a reaction and a costume
  that fits the scene (re-render with kit/nexi-cam: hero/jump/gasp/celebrate + star/wow/love faces, low or dutch camera).
  Her attitude and reactions come from the skill `nexi-character` (offended by the mess, never by the person; a pain post =
  a rage-ladder or trouble reaction at the mess prop, a result post = a win). 46 reactions + 30 variants: vary them across a
  batch (no two posts with the same reaction + variant); render from `films/nx3sheet.js` (base) or `films/nx3vsheet.js`
  (variants + new kinds: determined, idea, starstruck, nervous, stare...). Her caption line follows nexi-character `reference/voice.md`.
- **Living backgrounds** (owner 2026-10-09: "make dinamic bacground"): every post gets themed animated layers from
  `kit/scene.js` (HB.scene) and Nexi motion (HB.act). **Short social copy only** - headline + one line, no paragraphs.
- **Proper names** for every file sent or delivered, previews included: `NN-technext-<topic>-<concept>.png`.
- **Detailed, not plain** (owner 2026-10-09: "make sure the design are more detailed"): every scene gets a detail pass with
  `kit/detail.js` (DT.*: textures laid over shapes, soft shadows, shading, 8-15 small props - shelves, plants, gears,
  skylines, fences, shells, cartons...). A big flat shape with nothing on it is unfinished.
- **Audit before render, every time** (owner 2026-10-09: "properly audit all images, there's a lot of overflowing text and
  some not properly aligned content"; 2026-10-10: "do audit all images, always check if the text are too small to read,
  overflowing text, layering, etc.. properly build this skills"): `scripts/audit.py` must report **0 errors** for 3:4 AND
  reel before rendering or delivering, and `deliver.py` re-runs it and refuses to copy anything with an error. Read every
  warning; fix the real ones. A whole-catalogue check: `scripts/audit_all.py --map <map.json>`. See "Audit" below.
- **Odoo interface posts** (owner 2026-10-09: "focus on odoo interface, dashboard and icons. no analogy"): when asked,
  show the real Odoo UI (navbar, control panel, kanban, list, form, dashboards, POS, Gantt, mobile) built crisp in HTML with
  `kit/odoo-ui.css` + `kit/odoo-ui.js` (OU.*), official app icons, SAMPLE-DATA marks; no metaphor scene.
- **TechNext brand skins** (owner 2026-10-10: "use the technext branding. background and color"): unless a scene needs its
  own world, use the two live-site skins from `kit/brand.css` + `kit/brand.js` (BR.skin): LIGHT = white paper + blue-050
  44 px grid + blue aurora, highlight #3167CA, blue CTA; DARK = the Nexi slide brand blue #3167CA -> #1E4691, white headline,
  highlight + CTA in the site yellow #FFD23F (text #101C45). No peach / mint / slate / purple backgrounds.
- **Short sub-line under the headline in Inter** (owner 2026-10-10): `<p class="sub">` inside `.hw`, one or two lines,
  key phrase in `<b>`. `kit/brand-tools/make.py` builds pages from a short spec (headline, sub, CTA, css, body, js).
- **Readable sizes** (owner 2026-10-10: "some of the content like this are too small"): labels >= 15 px, anything to be
  read >= 18 px at 1080 wide (brand.md); toasts 24/18 px. Sizes are measured ON SCREEN: a 17 px label inside a window
  tilted away from the camera, a scaled-down phone or a zoomed card reads smaller - audit.py errors under 15 px and warns
  on sentences under 18 px after every transform. Budget the tilt: set UI text larger in tilted/scaled devices.
  `scripts/upsize.py` lifts an old page's font sizes to the floor.
- **All images compiled in one folder** (owner 2026-10-09): besides each batch folder, every image of the day also goes into
  one flat `<NN>. All Posts (<date>)\` folder (images only, md5-verified).
- Facts per `content-rules.md`; sample data labelled "sample"; **never post or schedule** (Buffer/Meta are the owner's).

## Where things are
| What | Where |
|---|---|
| Skill | `~/.claude/skills/technext-social-posts/` - `kit/` (kit.css, kit.js, starter.html, three.min.js, cam.js, qtworld.js, nexi-cam/, assets/, examples/), `scripts/`, `reference/` |
| Work folder per batch | `~/ClaudeWork/social-<yyyy-mm-dd>-<slug>/` on local disk (Drive sync corrupts big binaries mid-write) |
| Deliver to | `G:\Shared drives\Marketing\02. TechNext Folder\02. TechNext Social Media Posting Image\<NN>. <name> (<date>)\` (owner reorganised 2026-10-10: the old `00. TechNext Folder` is gone - never recreate it). Owner's layout per batch: `Image Posts\` + `captions.md` + `source\` (+ `Paid Ads\` with 4x5 png + 9x16 mp4); NO Video Posts folder there (reels stay in the work folder unless the owner says where). Every image also goes into `00. All Images (<dates>)\` there. |
| Last batches (owner's numbering since 2026-10-10) | `07.` creative 29-46 + 3 FB ads · `08.` industries 47-56 · `09.` Odoo services 57-66 (detailed metaphors) · `10.` Odoo interface 67-76 (real UI, no metaphor) · `11.` Odoo interface - brand skins 77-86 · `12.` Nexi introduction 87-92 (3 comic Nexi Explains page theme + 3 TechNext brand) · `13.` Odoo + TechNext collection 93-122 (30 non-comic, mixed families) · `14.` Odoo + TechNext collection part 2, 123-172 (50 non-comic) · `00. All Images (2026-10-09 to 10-10)` = every image flat. Check: `~/ClaudeWork/qa/verify_drive.py` |
| Detail + UI kits | `kit/detail.js` (DT: textures, shadows, props), `kit/odoo-ui.css` + `kit/odoo-ui.js` (OU: navbar, control panel, kanban, cards, cursor, sparkline, bars) |
| Best working examples | `kit/examples/2026-10-07-posts-21-25-v3-cinematic/p21..p25.html` (format-aware: 3:4 + reel) |
| Tools | Chrome, Python 3 + Pillow + websocket-client, ffmpeg (WinGet `yt-dlp.FFmpeg`), network for Google Fonts |

## Read first (in this order)
1. `reference/formats.md` - the two formats, safe zones, how a page adapts (`TN.F`, `TN.H`, `TN.pick`, the DY slide).
2. `reference/cinematic.md` - how to make a poster cinematic and unique; the five v3 builds and their tricks.
3. `reference/content-rules.md` - what may be claimed (partner wording, approved figures, no cyber security, samples, CTAs).
4. `reference/brand.md` - logo row, type, colours, footer. Never improvise these.
5. `reference/lessons.md` - every mistake made so far. Don't repeat them.
6. `reference/style-library.md` - looks already used (never reuse) + technique notes. `industries.md` - per industry:
   angle, Odoo apps, process, props, URL. `camera.md` - exaggerated angles. `engine.md` - page contract + helpers.
   `captions.md` - caption formats per platform and for reels. `template.md` - legacy one-template route (only on request).

## The pipeline
1. **Brief.** Topics/industries, how many posts (default 5), image or reel (default: both - one page renders the 3:4 image
   and the 9:16 reel). Don't stall on obvious defaults; say what you assumed.
2. **Concepts.** Per post write: TechNext service + Odoo process (4 steps, real Odoo vocabulary), the film idea and its
   4 scene objects, the light plan, 3+ cinematic devices, text placement, label style, Nexi or not, CTA URL. Check the
   used table: nothing may repeat. Different looks, light and text placement across the batch.
3. **Set up.** `mkdir ~/ClaudeWork/social-<date>-<slug>`; copy `kit/kit.css`, `kit/kit.js`, `kit/assets/`, plus what the
   build needs (`three.min.js`, `cam.js`, `nexi-cam/`). One HTML per post (`pNN.html`) from `kit/starter.html` or the
   closest example. Number on from the last delivered post (25 at the time of writing).
4. **Build** for 3:4 first, then the reel layout (`formats.md`): scene in design coordinates, slide it with DY, extend
   sky/floor, move the words into the reel safe zone, keep canvases at `height:100%`. Motion: `render(t)` loops on
   `th = 2*PI*t/LOOP` (integer multiples only), poster time = the most readable frame.
5. **Measure, don't guess.** `python <skill>/scripts/dbg.py pNN.html NN --f 34|reel [--t 2.6] [--shot qa/x.png]` prints
   anchors, every text rect and the QA list, and takes a screenshot without disturbing a running render.
6. **Audit (blocking).** `python <skill>/scripts/audit.py <work folder> --f 34,reel --port 9495` loads every post at its
   poster time (reels also at t=0,2,4,6) and writes `qa/audit/report.md`, numbered red/orange boxes on screenshots and
   `audit-sheet.jpg`. **0 errors required.** Works on TN.boot pages and technext-site-posts pages (`.f` frame). Checks:
   - READABILITY: text size ON SCREEN after transforms/3D/zoom ([tiny] < 15 px error, [small] sentences < 18 px warn);
     [contrast] text colour vs the real pixels behind it from a 2x screenshot (error < 2.2:1, big text < 1.8:1; warn < 3:1).
   - OVERFLOW: [spill] text out of its box/pill, [plate] SVG text off its sign, [clip] clipped by a container, [frame] cut
     by the frame, [edge] hugging it, [pad] touching its pill edge, off-centre on its plate.
   - LAYERING: [covered] text under art/cards/Nexi, [collide] text on text, [layer] a device/window covering part of
     another one's controls, [nexi] cards on Nexi, [face] anything on her head, [busy]/[crossed] plate-less text on art,
     [pe] pointer-events:none on a wrapper that holds text (hides it from these checks - decoration only).
   - CANVAS: fillText/strokeText is hooked before the page loads, so canvas labels (comic posters, name tags, pins) get the
     same size/frame/cover/collision rules; canvas text painted over by later canvas art is ignored (pixel check).
   - LAYOUT: [align] near-miss alignment, [margin] brand edge, [cut] objects cut by the frame, TN.qa reel safe zones.
   Opt-outs only for deliberate effects: `data-audit="skip"` / `data-qa-skip` (decoration), `"overlay"` (a lens), `"layer"`
   (3D-extruded word), `window.TN_AUDIT_SKIP_CANVAS = ['...']` (decorative canvas words). Never silence a real fault.
   Whole catalogue: `scripts/map_sources.py` (delivered image -> source page, md5) then
   `scripts/audit_all.py --map ~/ClaudeWork/qa/all-posts-map.json` -> `qa/audit-all/SUMMARY.md` (parallel ports).
7. **Render.** `render.py pNN.html --posts NN` (3:4) and `render.py pNN.html --posts NN --fmt reel` (reel). Both must end
   **ALL CLEAN**. Posts of one work folder render one after another (shared Chrome profile). Then LOOK: `Read` every
   PNG; overview for yourself only (stays in the work folder): `sheet.py "out/2*.png" --out qa/overview.jpg --w 432`; reel frames
   `sheet.py out/NN-...-reel.mp4 --frames 0.1,2,4,6,7.9` (first and last frame must match: seamless loop).
8. **Verify CTAs** return 200 with a browser UA (bare curl is blocked):
   `curl -s -o /dev/null -w "%{http_code}" -A "Mozilla/5.0 ... Chrome/129.0" https://technext.asia/<path>`.
9. **Captions** in `out/captions.md` per `captions.md`: feed caption per platform + a reel caption per post.
10. **Deliver.** `python <skill>/scripts/deliver.py out "<Drive folder>" --source pNN.html ...` (images -> `Image Posts\` + a copy in `00. All Images`; no videos, one file per post, md5-verified; never copies overviews/covers/@2x). AUDIT GATE: it re-audits every image's source page first and refuses on any error, a missing page, or a page edited after its render - custom delivery scripts must call audit.py the same way. When a post is redone, the old version leaves the delivery folder
   (owner rule: no duplicates) - removal on Drive goes to the shared-drive trash. SendUserFile the images + reels.
   Never post or schedule.
11. **Log + train the skill.** Add the batch to the used table (`style-library.md`), new gotchas to `lessons.md`, any owner
   rule to the right reference the same day, copy the batch pages into `kit/examples/`, re-package the .skill.

## QA checklist (audit.py first, then by eye on the rendered files)
- Readability at phone size: open each PNG at 540 px wide - every label legible, nothing pale-on-pale, no text in a tilted
  window shrunk below the floor (audit [tiny]/[contrast] must already be 0 errors).
- Layering: no device/window covering another one's controls, nothing on Nexi, no label half under an object, the frame
  settled (no card mid-slide, nothing half-faded).
- Overflow: no word out of its pill/sign/box, nothing cut by the frame or a container.
- Format: one image per post, 2160x2880 (3:4); reels 1080x1920 MP4. Nothing else, no duplicates; images and videos in
  their own subfolders.
- Reel: all words, logos and the CTA inside the safe zone; the bottom 420 px holds only scenery.
- Logo row identical in place and size; plain Odoo wordmark (white on dark).
- Title reads in one second at phone size; subtitle 2 lines; no orphan word; labels never on top of their objects.
- The TechNext service and the Odoo process are obvious without the caption.
- Every poster looks unlike the others and unlike everything in the used table; finish quality even across the batch.
- Depth: light, texture, perspective, real shadows - never a flat stock template.
- Facts pass `content-rules.md`; sample data labelled; CTA live; loop seamless (frame 0.1 s = frame 7.9 s).
