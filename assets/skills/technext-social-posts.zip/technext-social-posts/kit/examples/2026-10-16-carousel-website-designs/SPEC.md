# Website-showcase carousel cards: 5 design variations (lead spec, 2026-10-16)

The owner wants more variety in how we present the website-scroll videos. Each design below is its OWN visual idea:
its own style, light, layout and way of showing the offer. Do not reuse the v3 layout (browser + phone + "Plus your Odoo"
card + blue pill) and do not borrow from another design in this file.

## The offer: say it outright on every card
TechNext gives a **FREE website + branding** when a business starts **Odoo with TechNext**. Every card must SAY "free website" and "branding",
and the condition is implied by "with your Odoo / when TechNext sets up your Odoo".
- Odoo itself is NEVER called free. "Free" only ever describes the website / branding / design.
- No prices, no S$ / PHP figures, no "S$0" lines, no "paid".
- Core promise where it fits: you don't need to hire your own team.
- Copy is fixed below, so use it verbatim. Short social copy only: no paragraphs.

## Fixed brand frame (all designs)
- 1080 x 1350 (4:5), root `<div class="f">` 1080x1350, `overflow:hidden`, explicit background.
- TechNext logo top-left at left 72 / top 64, height 44: `../assets/logo/technext-horizontal-blue.svg` (on dark: CSS `filter:brightness(0) invert(1)`).
  Odoo wordmark top-right, right 72 / top 64, height 42: `../assets/logo/odoo-logo.png` (dark bg: `odoo-logo-white.png`). No card behind it. Never the "Odoo Ready Partner" badge image.
- Fonts (Google Fonts link): Plus Jakarta Sans 800 (display, letter-spacing about -.04em), Inter 400-700 (body), Caveat 700 (one hand-written touch max).
- Colours: brand blue #3167CA, deep #1E4691 / #173A7C, light #6FA0F5 #A9C6FF #DDE7F8 #EAF0FB, ink #1F1F3D, body #4C4C63,
  site yellow #FFD23F (text on it #101C45), success #22A55B. Blue stays the dominant brand colour.
- Footer: a CTA (pill/button/tag, styled to the design) + `technext.asia` with a short line. Bottom edge >= 52 px from the frame bottom.
- Readable sizes ON SCREEN (after any 3D/scale): sentences >= 18 px, labels >= 15 px, nothing readable within 36 px of the edge. Side gutter 72 px for text.
- Light only (no dark mode media queries). No dark sci-fi / hologram look. Detailed, not flat: soft shadows, texture, 8-15 small props where the style allows.
- App icons: `../assets/odoo/<name>.svg` (sale, crm, website, appointment, event, account, project, ...). Nexi (TechNext's robot): `../assets/nexi/*.png` (760 px poses) or `../assets/nexi-hd/*.png` (HD).
  Never redraw her. Flip/tint is OK. A soft contact shadow under her, and nothing on her head or face.
- Odoo screens (design 08): `../assets/odoo-ui.css` + `../assets/odoo-ui.js` (OU.nav, OU.cp, OU.col, OU.card, OU.av...). Must match
  `~/.claude/skills/technext-social-posts/reference/odoo-ui-facts.md` (read it). Fake data is marked "Sample". No TechNext logo inside Odoo UI.

## The recordings (real-time, normal-speed scroll, 30 fps, 600 frames = 20 s)
`../../carousel-2026-10-15-websites/rcNN/<d|t|m>/0000.jpg .. 0599.jpg`
- d = desktop 1280x872, m = phone 390x844, t = tablet 768x1024 (rc04 only).
- rc01 Immaculate Connections (immaculateconnectionsph.com), rc02 technext.asia, rc03 HummingBeing (hummingbeing.com),
  rc04 TRE in Singapore (tre-in-singapore.com), rc05 Casa Escondida Anilao (casaescondida-anilao.com).
- Show a recording in an `<img>` whose box has the SAME aspect ratio (desktop 1.468, phone 0.462, tablet 0.75). If the box must
  differ, use `object-fit:cover; object-position:top` and say so. Never stretch.

## Page contract (frame-accurate rendering)
- `window.setFrame = async (i) => {...}`: t = i/30. Set every screen `<img>` src to frame `min(i,599)`, `await img.decode()`
  for all of them, and set every animation from t in JS (transform/opacity). **No free-running CSS animations, transitions
  or requestAnimationFrame loops.** The same i must always give the same picture.
- On load, call `setFrame(Number(new URLSearchParams(location.search).get('frame') ?? 240))`, so the static page (which the audit sees)
  shows a full, settled frame with every element visible.
- Motion: gentle and purposeful, such as a float/bob of 4-8 px, a swing of a few degrees, staggered entrances in the first ~2.5 s (ease-out-back
  springs allowed), then idle. The scroll IS the main motion; nothing may distract from it or cover the screens.

## Tools
- Render: `python ../framerender.py p<NN>.html out/<file>.mp4 --n 600 --port <your port>` (about 1-2 min). Still frame:
  `python ../framerender.py p<NN>.html --still 240 qa/s240.png --port <port>`.
- Audit (blocking, 0 errors): `python ~/.claude/skills/technext-social-posts/scripts/audit.py . --f 34 --port <audit port>`, run
  from your design folder (it audits every pNN.html there; report in `qa/audit/report.md`). Fix every ERR. Read every WARN and fix the real ones.
  An intended device overlap `[stack]` WARN is acceptable only if no UI controls are covered. Opt-outs (`data-audit="skip"`) only for pure decoration.
- LOOK at stills at t = 0.3, 2.5, 8, 14, 19.9 (frames 9, 75, 240, 420, 597) with the Read tool before you report. Check for half-faded
  elements, text collisions, a card covering text, a screen shown distorted, and a frame where something has not entered yet after 2.5 s.

## The five designs
Each designer builds ONE. Work only inside your folder `~/ClaudeWork/carousel-2026-10-16-designs/d<NN>/`.

### 06: "Gift-wrapped". Casa Escondida (rc05 desktop). Folder d06, render port 9561, audit port 9571
- Idea: the website arrives as a gift with the Odoo set-up. Style: soft papercraft / light 3D, warm cream paper (#FFF8EE to #FDF1DE)
  with brand-blue accents. No grid.
- Layout: headline block top-left (y 160-420). A big laptop in three-quarter 3D perspective (CSS 3D, about rotateY(-16deg) rotateX(6deg),
  screen about 760 px wide, 1.468 aspect) sits on a pale desk surface (y about 470-1150), with the desktop recording on its screen and a thin bezel, keyboard deck and shadow.
  A kraft-paper GIFT TAG on a string hangs from the laptop's top-right corner and swings ±4 deg (period 4 s). Tag text: "FREE" (Jakarta 800, big)
  / "website + branding" / "with your Odoo set-up". Desk props: open gift box with curled blue ribbon (bottom-left), small plant,
  coffee cup, a few paper confetti flecks drifting slowly. Nexi: `nexi-hd/nexi-present.png` at the bottom-right, presenting the laptop (small bob).
- Copy: headline "Your Odoo set-up / comes gift-wrapped." (line 2 in blue). Sub: "Start Odoo with TechNext and we design your
  website and branding free, ready for guests from day one." CTA: "Unwrap the offer →". Footer line: "Free website + brand with Odoo".
- File: `06-technext-carousel-website-casa-escondida-giftwrap.mp4`

### 07: "Thumb test". HummingBeing (rc03 PHONE). Folder d07, render port 9562, audit port 9572
- Idea: mobile-first. Style: TechNext DARK brand skin, a gradient #3167CA → #1E4691 with a subtle large soft light blob, white text, yellow
  #FFD23F highlights. Logos white.
- Layout: kinetic stacked headline on the left (x 72, y 170-560): "Looks good / on every / thumb." with "thumb." in yellow. A HUGE phone
  on the right (screen about 430x930, 0.462 aspect, x about 560-1010, y about 230-1180), tilted -5 deg, with a real phone frame (rounded,
  side buttons, soft long shadow), showing the phone recording. A translucent "thumb tap" ripple circle pulses on the screen's lower third every
  2.5 s. Stickers that pop in (staggered, t 0.8-2.4 s) then wobble lightly: a yellow starburst sticker "FREE website + branding"
  overlapping the phone's left edge (not covering the site's header), and 3 small white app chips with official icons + labels
  "Website", "Appointments", "Events". Nexi `nexi-hd/nexi-wow.png` peeks from the bottom-left behind the text column, small.
- Copy: sub under the headline: "We design your mobile-first website and brand free when you set up Odoo with TechNext."
  CTA: yellow pill "Get yours designed →" (#101C45 text). Footer: technext.asia + "Odoo by TechNext, site on us".
- File: `07-technext-carousel-website-hummingbeing-thumb.mp4`

### 08: "Front of house, back of house". Immaculate Connections (rc01 desktop). Folder d08, render port 9563, audit port 9573
- Idea: the free website is the front of house; Odoo is the back of house, and inquiries flow from one to the other. Style: clean editorial
  light. White with hairline rules, small-caps section labels, a touch of the brand light grid only behind the windows.
- Layout: headline top (y 160-330), then TWO windows. (a) A browser window (screen 1.468 aspect, about 620 px wide) at the upper-left
  with the desktop recording, labelled above "FRONT OF HOUSE · your website, designed free". (b) An Odoo CRM window lower-right (about
  640x430), built with OU kit: navbar (crm icon, "CRM", menus Sales · Leads · Reporting · Configuration), control panel "Pipeline" with
  kanban view, columns New / Qualified / Proposition / Won with realistic sample cards (fresh names, e.g. "Cebu group tour, Da Nang 5D4N",
  "Corporate outing, 24 pax"...), labelled "BACK OF HOUSE · Odoo CRM" + a small "Sample" mark. The windows may overlap at most 90 px
  and never over CRM column headers or the browser's nav bar. At t = 3.5, 8.5 and 13.5 s a small inquiry card ("New inquiry · Hanoi + Ha Long
  · 12 pax", etc.) lifts off the browser, travels along a dotted curved path (about 1.1 s) and lands as the top card of "New". The New
  column count increments (3 → 4 → 5 → 6). Expected-revenue figures must NOT appear (no prices).
- Copy: headline "Inquiries in front. / Odoo behind it." Sub: "TechNext sets up your Odoo and designs your website and branding
  free, so website inquiries can land in Odoo CRM." CTA: "See how it connects →". Footer: "Free website, wired to Odoo".
- File: `08-technext-carousel-website-immaculate-front-back.mp4`

### 09: "Every screen". TRE in Singapore (rc04 desktop + tablet + phone, synced). Folder d09, render port 9564, audit port 9574
- Idea: a gallery exhibition of one brand on every screen. Style: bright art-gallery wall (off-white #F7F7F4, faint wall texture),
  soft spotlight cones from the top, and a pale oak plinth/shelf where the devices stand.
- Layout: headline top-left (y 160-340). Three devices on the plinth (y about 500-1080): a desktop monitor on a stand (centre-left, screen about
  560 px wide, desktop recording), a tablet leaning (right, about 260x347, tablet recording), and a phone standing at the front (about 150x325, phone
  recording), with real bezels and contact shadows. Under each a small gallery placard (white card, hairline border): "Desktop",
  "Tablet", "Phone" plus a one-word note ("Bookings", "Courses", "Events"). A wall plaque (brass-edged white card) beside or under the headline:
  "FREE website + branding" / "included when TechNext sets up your Odoo". Nexi `nexi/nexi-back-over-shoulder.png` as a gallery visitor at the
  bottom-right looking at the screens (small bob). The spotlights' brightness breathes very slightly (±4 %).
- Copy: headline "One brand. / Every screen." Sub: "Desktop, tablet and phone, designed free with your Odoo set-up. No design team to hire."
  CTA: "Claim your free website →". Footer: "Website + brand on us".
- File: `09-technext-carousel-website-tre-singapore-every-screen.mp4`

### 10: "Launch checklist". technext.asia (rc02 desktop). Folder d10, render port 9565, audit port 9575
- Idea: a launch checklist where everything gets ticked. Style: TechNext light brand skin (white paper + 44 px blue-050 #EAF0FB grid + soft blue
  aurora as background radial-gradients, NOT blurred divs), with a real paper clipboard prop.
- Layout: headline top (y 160-330). A large browser window (screen about 700 px wide, 1.468 aspect) on the right/centre, slightly rotated
  (+2 deg), with the desktop recording. A CLIPBOARD (metal clip, paper with faint ruled lines, soft shadow) overlaps the browser's lower-left corner
  (about 430x520, rotated -4 deg) WITHOUT covering the browser's nav bar. Its 4 rows tick in one by one at t = 1.2, 2.2, 3.2, 4.2 s with a
  hand-drawn blue tick (stroke-dash draw, 0.4 s): "Odoo set up for your business" / "Website designed - FREE" /
  "Branding designed - FREE" / "No team to hire". The FREE words are in a yellow highlight swash. Nexi `nexi-hd/nexi-point-right.png` (or present) stands
  at the bottom-left beside the clipboard, pointing at it, with a small bob and a gentle head-tilt rotation of ±2 deg.
- Copy: headline "Ticked off / before launch." Sub: "One team sets up your Odoo and designs your website and branding free. Nothing left to hire."
  CTA: "Start your checklist →". Footer: "Odoo set-up + free website".
- File: `10-technext-carousel-website-technext-launch-list.mp4`

## Report back (short)
The video path, the audit result line (errors/warnings), the still paths you looked at, and anything you could not do. Do not deliver to Google Drive; the lead reviews first.
