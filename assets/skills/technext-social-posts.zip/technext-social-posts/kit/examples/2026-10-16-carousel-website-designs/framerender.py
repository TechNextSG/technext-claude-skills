"""Frame-by-frame renderer for the website-scroll design cards.
Page contract: the page is 1080x1350 and defines  window.setFrame = async (i) => {...}  that draws frame i
(t = i/30 s) - swaps the <img> screen frames to the recording's frame i, moves every animation to time t, and
resolves only after the images have decoded. The harness screenshots each frame and encodes an H.264 MP4.
usage: python framerender.py <page.html> <out.mp4> [--n 600] [--port 9551] [--from 0 --to 600 (preview only)]
       python framerender.py <page.html> --still 240 out.png      (one frame, for checks)"""
import sys, os, time, base64, json, pathlib, subprocess, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _cdp
FF = r'C:\Users\leuss\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1.2-full_build\bin\ffmpeg.exe'
ap = argparse.ArgumentParser()
ap.add_argument('page'); ap.add_argument('out', nargs='?')
ap.add_argument('--n', type=int, default=600); ap.add_argument('--port', type=int, default=9551)
ap.add_argument('--still', nargs=2); ap.add_argument('--scale', type=float, default=1)
a = ap.parse_args()
page = pathlib.Path(a.page).resolve()
proc, c = _cdp.session(1080, 1350, port=a.port, profile='design-%d' % a.port)
try:
    c.call('Emulation.setDeviceMetricsOverride', width=1080, height=1350, deviceScaleFactor=a.scale, mobile=False)
    c.call('Page.navigate', url=page.as_uri()); time.sleep(2.5)
    c.ev('document.fonts.ready.then(()=>1)')
    if c.ev('typeof window.setFrame') != 'function': raise SystemExit('page has no window.setFrame')
    def shot(i, path):
        r = c.ev(f'Promise.resolve(window.setFrame({i})).then(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r(1)))))')
        if isinstance(r, dict) and 'exception' in r: raise SystemExit(f'setFrame({i}) failed: {r}')
        d = c.call('Page.captureScreenshot', format='png' if path.endswith('.png') else 'jpeg', quality=95,
                   clip={'x': 0, 'y': 0, 'width': 1080, 'height': 1350, 'scale': 1})
        open(path, 'wb').write(base64.b64decode(d['data']))
    if a.still:
        shot(int(a.still[0]), a.still[1]); print('still ->', a.still[1]); raise SystemExit
    fd = pathlib.Path(a.out).with_suffix('').as_posix() + '_frames'
    pathlib.Path(fd).mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    for i in range(a.n):
        shot(i, f'{fd}/{i:04d}.jpg')
        if i % 100 == 0: print(f'frame {i}/{a.n}  {time.time()-t0:.0f}s', flush=True)
finally:
    proc.terminate()
# one I-frame (keyint 600): no keyframe 'pulse' on text and device edges every 8 s
subprocess.run([FF, '-y', '-loglevel', 'error', '-framerate', '30', '-i', f'{fd}/%04d.jpg', '-vf', 'scale=1080:1350',
                '-c:v', 'libx264', '-preset', 'slow', '-crf', '15', '-tune', 'animation', '-x264-params', 'keyint=600:min-keyint=600:scenecut=0', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', a.out], check=True)
print('video ->', a.out)
