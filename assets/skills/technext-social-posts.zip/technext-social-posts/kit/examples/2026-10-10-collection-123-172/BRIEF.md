# Brief: Odoo + TechNext collection, part 2 (posts 123-172), 2026-10-10

Lead: the main session. Builders: one helper per group, each in its OWN work folder with its OWN ports.
You build, audit and render your posts; the lead reviews, delivers to the Drive and writes captions. **Never deliver,
post or schedule anything. Never edit files outside your work folder** (the kits in ~/.claude/skills are read-only for you;
read any example page you like).

## What the owner asked (verbatim)
Today: "craete 50 more random content." - more of the previous request: "30 random collective content that connected to
odoo and technext. do random design skills (dont do comical design) use design of our previous content in this session.
make sure the design are related to the content, much detailed properly audited/designed. dont do half baked design and
background. make sure related to the content. create alot of variation."
And three "fix this" screenshots the owner sent today (learn from them - see "Today's fixes" below).

Standing owner rules that still apply (never drop one):
- Images only: ONE 3:4 PNG per post, 2160x2880 (render.py default `--fmt 34`). **No reels, no video.**
- NOT comic: no Bangers, no SFX bursts, no ink-outline comic style. The finish of posts 57-66 / 77-86 / 93-122.
- **Living, layered, detailed backgrounds** - never a flat fill. Brand colours go INTO the living background.
- **Detailed scenes**: 8-15 small story-true props per scene, textures laid over shapes, soft contact shadows, shading.
  A big flat shape with nothing on it is unfinished. "dont do half baked design and background."
- **Nexi** (TechNext's 3D robot; "she") in an ACTION pose with a reaction, in her own free zone, fully visible (whole,
  never cut by the frame/a card/a gradient band), **nothing on her face or head** (audit now errors on it: [face]).
- **Logo row fixed**: TechNext logo top-left, plain Odoo wordmark top-right (white on dark).
- **Short social copy**: a 2-line headline (5-8 words, line 2 highlighted) + ONE short Inter sub-line (<= 2 lines, key
  phrase in `<b>`). Labels in the scene short too. No paragraphs.
- **Readable sizes**: labels >= 15 px, anything to be read >= 18 px (at 1080 wide), toasts 24/18 px.
- **Facts**: TechNext = Odoo Ready Partner (exact wording; never certified/gold), Singapore HQ, Taguig City (PH, main
  development and consulting hub), Ho Chi Minh City (VN, AI engineering hub), clients in 10+ countries, 11+ enterprise
  clients; four practices ERP, AI Solution, Marketing, Technology. **Never mention Cyber Security. Never write "free".**
  Every invented name/number/document is labelled "sample" ON the image. Numbers add up (SG GST 9%; totals, unit costs,
  stock maths). No other brands' logos or real banknotes (generic shapes only). Official Odoo app icons from
  `assets/odoo/*.svg` only - never redraw or recolour them. Do not add claims beyond the brief.
- **Every poster unique**: own concept, camera, light, palette, headline placement/treatment and label style; different
  from every other post in this job AND from posts 01-122 (contact sheets below).

## Today's fixes (the owner flagged these - never repeat them)
1. **Devices/windows never overlap another device's UI content** (post 114: the middle phone hid the side phones'
   "Track order"/"Pay now" buttons). Bezels may touch; screens may not. Everything inside a device stays inside it.
2. **The poster frame is a SETTLED frame**: every animated element in its final state - no card mid-slide, nothing
   half-faded, no label hidden under something that slid over it. Look at the PNG for this.
3. **Nothing on Nexi's face or head** (FB ad 3: two cards on a giant Nexi's visor). Place Nexi first, cards in free space.
4. **No half-empty region**: every part of the frame carries designed content that SHOWS the claim (FB ad 1: a bare blue
   panel with six unlabelled icons only *said* "One database"). Labelled tiles, flows, objects - not floating icons.
5. When you fix something, fix only that thing; keep what already works.

## Look at these first (5 minutes, it sets the bar)
- Everything made so far: `C:/Users/leuss/ClaudeWork/qa/ref/all-sheet-0.jpg`, `all-sheet-1.jpg`, `all-sheet-2.jpg`
  (posts 01-86) and `all-sheet-3.jpg` (posts 87-122). Full-size PNGs (read-only):
  `G:/Shared drives/Marketing/02. TechNext Folder/02. TechNext Social Media Posting Image/00. All Images (2026-10-09 to 10-10)/`.
  Finish quality to match or beat: 93-122 (this morning's collection), 57-66 (detailed metaphor scenes), 77-86 (UI on brand skins).

## Engine - the page contract you already have in your folder
- `kit.css`/`kit.js` (TN.boot, TN.pick, TN.seg/eo/eio/back/cl/frac/rand), `hero.css`/`hero.js` (HB.bg, HB.fx icons/shapes/toasts,
  HB.nexi, HB.float, HB.th), `scene.js` (HB.scene layers: rays, rings, bokeh, sparkle, plane, shapes, clouds, waves, birds,
  bubbles, leaves, confetti, gears, light shaft + motes...; HB.act Nexi motion: bounce, sway, float, pop, lean), `detail.js`
  (DT.defs, DT.over textures, dt-gv/gh/gr shading, dt-sh shadows, DT props: tree palm bush tufts flowers cloud city lamp fence
  gear carton star5 shell potplant screw gloss, DT.t text), `odoo-ui.css`/`odoo-ui.js` (OU.nav, OU.cp, OU.col, OU.card, OU.av,
  OU.cursor, OU.spark, OU.bars, OU.ic, `.ou` windows, `.ou-toast`, `.ou-smp` sample mark, `.dev-lap/.dev-ph/.dev-tab` devices),
  `brand.css`/`brand.js` (BR.skin(post, dark, seed) living TechNext skins + BR.layers(dark)).
- `tools/make.py` builds `pNN.html` from `tools/src/pNN.txt` (sections @meta @title @l1 @l2 @sub @cta @site @css @body @js) with
  the fixed brand frame (logo row, `.hw` headline + `.sub`, `.foot` CTA button + technext.asia). Example specs from this
  morning (copy their shape and finish): `C:/Users/.../ClaudeWork/social-2026-10-10-collection-c1 ... c5/tools/src/p93.txt ... p122.txt`
  (i.e. `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection-c<1-5>/tools/src/`), and `C:/Users/leuss/ClaudeWork/social-2026-10-10-brand-ui/tools/src/p77-p86.txt`.
  Hand-built pages are fine too (`C:/Users/leuss/ClaudeWork/social-2026-10-09-odoo-services/p57-p66.html`).
  You may move/realign the `.hw` headline per post via @css (top-left, centred, lower third, right) - the logo row and the
  footer stay where they are. Paint a themed living background (HB.bg + HB.scene + DT textures) when the concept has its
  own world; otherwise BR.skin light or dark.
- Skill docs: `C:/Users/leuss/.claude/skills/technext-social-posts/SKILL.md` and `reference/lessons.md` (must-read: every
  mistake already made, incl. today's), `reference/engine.md`, `reference/brand.md`.
- Nexi poses: render new ones with nexi-cam (unique names `n<post>`, YOUR ports):
  `NEXICAM_PORT=<yours> NEXICAM_CDP=<yours> python C:/Users/leuss/.claude/skills/technext-social-posts/kit/nexi-cam/nexi_cam.py n123 '{"hold":"present","face":"star","wear":"cap","yaw":0.3,"cam":{"pos":[0,-3,24],"look":[0,0,0],"fov":32}}'`
  -> `kit/nexi-cam/out/nexi-n123.png`; copy it to your `assets/nexi-hd/` and use `HB.nexi(post,{pose:'n123',...})`.
  Holds: idle hi present point pointL celebrate gasp think cute clap knock kiss shrug jump reach hero heroL. Faces: idle happy
  star content wow love dizzy. Wear: hardhat conductor pilot glasses strawhat beret chef cap knight bowtie goggles bellhop
  beanie tophat boppers helmet astro (sheet: `C:/Users/leuss/.claude/skills/technext-social-posts/kit/assets/nexi/costumes/_wear_sheet.jpg`).
  Look at each render before using it; the render must show her WHOLE (no flat-cropped bottom).
- After your last render, delete YOUR Chrome profiles: `C:/Users/leuss/ClaudeWork/qa/social-posts-profiles/{audit,dbg}-<your ports>`,
  `nexi-cam-<your cdp>`, `render-<your folder name>` (they are 50-500 MB each).

## Commands (run from YOUR work folder; use YOUR ports everywhere)
- Build: `python tools/make.py 123 124` (or hand-write `p123.html`).
- Look: `python C:/Users/leuss/.claude/skills/technext-social-posts/scripts/dbg.py p123.html 123 --t 3 --port <dbg> --shot qa/123.png`
  then Read the PNG (also make a 540 px copy with PIL to judge phone size).
- Audit (blocking): `python C:/Users/leuss/.claude/skills/technext-social-posts/scripts/audit.py p123.html p124.html --f 34 --port <audit>`
  -> 0 errors for every post; read `qa/audit/report.md` + boxed screenshots; fix real warnings too (a [margin] warning
  for a deliberately centred/right headline is acceptable).
- Render: `python C:/Users/leuss/.claude/skills/technext-social-posts/scripts/render.py p123.html --posts 123 --port <render>`
  -> `out/123-technext-<slug>.png`, must end ALL CLEAN. Never `--force`. One post after another.
- Copy each final to `preview/` with the same name.
- Write files with Write/Edit, not Bash heredocs (Bash halves backslashes). Kill orphan headless Chrome on your port if
  you stop a run. Never `// comment` at the end of a JS line you splice; never name a global `top`/`name`/`status`;
  prefix one-off CSS classes per post (`.p123-xxx`) - hero.css/kit.css own `.hd .pl .grid .pg .h .pn .ci .chip .sub .pm .card
  .tag` and more (grep before inventing a class).

## Slugs and numbering
File = `NN-technext-<slug>.png` from the slug in @meta / TN.boot. **Slugs never start with "technext"** (render.py adds it).
Posts are numbered 123-172 exactly as listed below.

## Definition of done (per post) - the lead will reject anything short of it
1. The topic is obvious at a glance without the caption; the visual SHOWS the claim.
2. Background alive and themed: base gradient/skin + 3-5 fitting scene layers + texture + depth FX.
3. Detail pass done: 8-15 props, textures, shading, contact shadows, small labels where they help; no empty flat areas.
4. Headline readable in one second at phone size; balanced vertical budget (visual not crammed at the bottom, no dead
   band); text never on busy art without a plate; no device overlapping another device's content.
5. Nexi whole, action pose fitting the story, own zone, nothing on her face/head.
6. audit.py 0 errors; render.py ALL CLEAN; you looked at the final PNG at full size AND 540 px wide, and the frame is settled.
7. "sample" on invented data; official Odoo icons; facts exactly as in the brief; maths checked.

## Report back (max 15 lines)
One line per post: number, slug, out PNG path, audit result, one phrase on the concept. Then anything unresolved.

---------------------------------------------------------------------------------------------------------------------------
## THE 50 POSTS
Families: [M] detailed metaphor scene, [U] crisp Odoo UI on a living background, [T] typographic/editorial/data-viz,
[I] isometric, [S] still life / bird's-eye / macro, [R] scene/room. LIGHT = BR.skin light, DARK = BR.skin dark,
THEMED = your own living world in on-brand colours. Facts for Odoo 20 items come from technext.asia/blog/odoo-20-whats-new.

### G1 - `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection2-g1` - ports render 9711, dbg 9712, audit 9713, NEXICAM 3711/9714
123 `odoo-20-website-ai-assistant` [U+M, LIGHT] "Describe the page." / "Odoo 20 builds it." Sub: "The new Website Assistant
    builds and edits pages **by chat.**" CTA "See Website Builder" (/odoo/apps/website-builder). A chat prompt ("A homepage
    for a bakery with an order button · sample") streams into a browser frame where real page blocks (hero, menu cards,
    order button, footer) snap into place mid-air; AI sparkles; chips "Structured data on by default", "llms.txt".
    Icons: website, ai_app. Nexi: present, star.
124 `odoo-20-accounting-assistant` [R, THEMED morning finance desk] "Ask your books." / "Get the answer." Sub: "Odoo 20's
    Accounting Assistant answers finance questions and **audits reconciliations.**" CTA "See Odoo Accounting"
    (/odoo/apps/accounting). Monitor with an Odoo Accounting dashboard + assistant panel (Q "Which invoices are over 30 days
    late?" -> answer card listing 3 sample invoices that add up); a clipboard reconciliation audit (2 green checks, 1 amber
    "Duplicate bank line · sample"); ledger, calculator, coffee, plant, window light. Nexi: pointL, happy.
125 `odoo-20-bill-line-prediction` [S macro, THEMED paper desk] "New vendor bill?" / "Odoo suggests the account." Sub: "Bill
    line prediction codes new bills **from your history.** You confirm." CTA (/odoo/apps/accounting). Macro of a vendor bill
    on a clipboard; each line gets a ghost "suggested" account chip sliding in like autocomplete (6100 Office supplies, 6230
    Freight, 5000 Cost of goods); a big physical Tab keycap; a confirm tick. Nexi small, clap.
126 `odoo-20-pos-snooze-sold-out` [R, THEMED warm cafe counter] "Sold out?" / "Snooze it till tomorrow." Sub: "Odoo 20 POS
    can **snooze products** and turn lines into combos." CTA "See Odoo Point of Sale" (/odoo/apps/point-of-sale). Front-on cafe
    counter: pastry case with one empty tray, a POS tablet product grid with the croissant tile greyed + a sleeping-moon
    badge "Snoozed till 7:00 AM · sample", a "Coffee + croissant combo" chip; chalk menu, espresso machine, cups.
    Icon: point_of_sale. Nexi: cap, present.
127 `odoo-20-stock-aging-report` [T data-viz, DARK] "How old" / "is your stock?" Sub: "Odoo 20 adds a **stock aging report**
    and inventory at any past date." CTA "See Odoo Inventory" (/odoo/apps/inventory). Front-on shelving where every carton is
    colour-coded by age bucket (0-30, 31-60, 61-90, 90+ days) = a heat map, legend + aging bars; a vintage time dial
    "Inventory at 30 Sep 2026 · sample"; dust on the 90+ cartons. Icon: stock. Nexi: gasp.
128 `odoo-20-bom-comparison` [M, LIGHT blueprint] "Two BOMs." / "Spot the difference." Sub: "Odoo 20 Manufacturing
    **compares bills of materials** side by side." CTA "See Odoo Manufacturing" (/odoo/apps/manufacturing). Two exploded-view
    drawings of a desk lamp (v1 vs v2) on blueprint paper with component callouts; differences circled in red marker; a
    BOM comparison card (Component | v1 | v2). Icon: mrp. Nexi: point, hardhat.

### G2 - `...-collection2-g2` - ports render 9721, dbg 9722, audit 9723, NEXICAM 3721/9724
129 `odoo-20-spreadsheet-locked-sheets` [U, LIGHT] "Lock the sheet." / "Share the numbers." Sub: "Odoo 20 Spreadsheet adds
    **locked sheets**, named ranges and bubble charts." CTA (/odoo/apps/spreadsheet). A crisp Odoo spreadsheet window; a tab
    "Budget 2027 · locked" with a padlock; a bubble chart rising out of the sheet as glossy spheres; chip "Named range:
    Q4_Revenue". Icon: spreadsheet_dashboard. Nexi: present.
130 `odoo-20-mobile-one-thumb` [U device, THEMED train platform] "Odoo 20" / "fits in one thumb." Sub: "Swipe down for the
    command palette, **pick dates in a bottom sheet.**" CTA "What's new in Odoo 20" (/blog/odoo-20-whats-new). An illustrated
    hand holding a big phone (low angle, soft motion-blurred platform behind): the swipe-down command palette (Search menus,
    records... / Create quotation / Log time) with a thumb arc; a bottom-sheet date picker. Nexi: hi.
131 `bank-reconciliation-zipper` [M, THEMED stitched textile] "Zip your bank" / "to your books." Sub: "Odoo matches **bank lines
    to invoices**; you confirm the rest." CTA (/odoo/apps/accounting). A giant zipper: left teeth = bank lines, right teeth =
    invoices (amounts that match, sample), the pull (accountant icon) closing them into matched pairs; unmatched lines splay
    open above; "Matched 12 of 14 · sample"; stitching, buttons, fabric texture. Nexi: reach (pulling the zipper).
132 `invoice-follow-up-reminders` [S, THEMED desk] "Overdue?" / "Odoo sends the reminder." Sub: "Follow-up reminders go out
    **on schedule, level by level.**" CTA (/odoo/apps/invoicing). Three envelopes on a timeline (Day 7 friendly, Day 15 second
    notice, Day 30 final) with wax-seal-like stamps; a PAID receipt stamped at the end; calendar strip; follow-up report card.
    Icon: account. Nexi: present.
133 `analytic-accounting-profit-per-project` [M food still life, THEMED pastry] "Profit per project," / "not just per company."
    Sub: "Analytic accounting splits costs and revenue **by project, branch or team.**" CTA (/odoo/apps/accounting). A layered
    cake on a stand cut into labelled slices (Project A · Branch East · Team Retail · sample) with flags showing margin %; a
    cake knife; an analytic report card whose numbers match the flags. Nexi: present, bowtie.
134 `asset-depreciation-van` [M, THEMED road] "The van loses value." / "Your books keep up." Sub: "Odoo posts **depreciation
    every month**, on the schedule you set." CTA (/odoo/apps/accounting). A delivery van driving down a road shaped like a
    straight-line depreciation chart, monthly milestone posts with book values (S$48,000 -> ... sample, consistent maths); an
    asset card (cost, life, monthly amount). Nexi: cap, hi.

### G3 - `...-collection2-g3` - ports render 9731, dbg 9732, audit 9733, NEXICAM 3731/9734
135 `multi-currency-one-ledger` [S, THEMED marble] "SGD, PHP, VND." / "One set of books." Sub: "Odoo records each currency
    and **converts at the day's rate.**" CTA (/odoo/apps/accounting). Three stacks of GENERIC coins labelled SGD / PHP / VND
    (no real banknotes) streaming into one ledger; an exchange-rate board (rates marked sample); a globe. Nexi: clap.
136 `invoice-pay-online-link` [U, LIGHT] "Pay this invoice" / "in one tap." Sub: "Customers pay from the invoice link;
    **Odoo marks it paid.**" CTA (/odoo/apps/invoicing). An invoice email on a phone with "Pay now", a generic checkout
    screen (no payment brand logos), then the Odoo invoice with a PAID ribbon; flow arrows. Icon: account. Nexi: celebrate.
137 `quotation-optional-products` [U, DARK] "Upsell" / "without a hard sell." Sub: "Quotation templates offer **optional
    add-ons** the customer can tick." CTA (/odoo/apps/sales). The customer's quotation page with an optional products section
    (Extended warranty, Installation, Training · sample) and Add buttons; one being added by the cursor; total updates
    correctly; signature line. Icon: sale. Nexi: point.
138 `product-variants-grid` [T kinetic, LIGHT] "One t-shirt." / "Twenty-four variants." Sub: "Odoo builds **every size and
    colour** from one product." CTA (/odoo/apps/ecommerce). A rail wall of 24 t-shirts (6 colours x 4 sizes S M L XL) as a
    matrix, tiny tags; attribute panel (Colour 6 x Size 4 = 24 variants). Icon: website_sale. Nexi: present, cap.
139 `loyalty-gift-cards` [S, THEMED cafe table] "Points that" / "bring them back." Sub: "Loyalty cards, gift cards and
    eWallets **in Odoo POS and eCommerce.**" CTA (/odoo/apps/point-of-sale). A stamp card with 8 of 10 coffee stamps, a gift
    card, a phone with a points balance, a POS receipt "Points earned: 24 · sample". Nexi: love face.
140 `sms-marketing-text-offer` [U, DARK] "A text" / "they actually read." Sub: "Odoo SMS Marketing sends **short offers** to the
    right list." CTA (/odoo/apps/sms-marketing). A phone lock screen with an SMS "Bayside Cafe: 2-for-1 coffee till 3 PM ·
    sample"; the SMS campaign composer (character counter 98/160, audience chip); floating message bubbles.
    Icon: mass_mailing_sms. Nexi: hi.

### G4 - `...-collection2-g4` - ports render 9741, dbg 9742, audit 9743, NEXICAM 3741/9744
141 `crm-lead-scoring-hot-leads` [T data-viz, LIGHT] "Hot leads first." / "Odoo scores the rest." Sub: "Predictive lead
    scoring shows each lead's **chance to win.**" CTA (/odoo/apps/crm). Lead cards on a heat column from cool blue to hot
    orange with probability badges (82%, 64%, 31%, 12% · sample); a rep's queue sorted by score. Icon: crm. Nexi: point.
142 `customer-portal-self-service` [R, THEMED daylight lobby] "Customers help themselves." / "Orders, invoices, tickets."
    Sub: "The Odoo customer portal **opens any time** with their own records." CTA (/odoo/apps/sales). A bright lobby with a
    self-service screen (tabs: My orders, Invoices, Tickets, Documents · sample); a customer using it; plants, glass, light.
    Nexi: bowtie, present (concierge).
143 `pick-pack-ship-routes` [S bird's-eye, THEMED warehouse] "Pick. Pack. Ship." / "Three steps, one order." Sub: "Odoo
    routes each order through **pick, pack and ship.**" CTA (/odoo/apps/inventory). Bird's-eye warehouse: three coloured
    zones (shelves, packing tables, dock + van) and one order tote's dashed path with step badges; workers; pallets.
    Nexi from above, cap.
144 `dropshipping-vendor-ships` [I, LIGHT] "Sell it." / "Never touch it." Sub: "With dropshipping, **your vendor ships**
    straight to your customer." CTA (/odoo/apps/purchase). Isometric mini-world: your shop (no box, a ghost box outline "no
    stock needed") -> a purchase order flies to the vendor's warehouse -> a van drives straight to the customer's house;
    labelled route. Icons: sale, purchase. Nexi: present.
145 `landed-costs-shipping-container` [M cutaway, THEMED port] "Freight, duty, insurance:" / "in the product cost." Sub:
    "Landed costs add **shipping and duties** to your stock value." CTA (/odoo/apps/inventory). Container cutaway at a port,
    1,000 crates; cost chips Freight S$1,200 + Duty S$380 + Insurance S$95 = S$1,675 (sample) flow into a price tag
    "Unit cost S$12.40 -> S$14.08" (12.40 + 1.675); crane, sea. Nexi: helmet, point.
146 `repairs-workbench-order` [R, THEMED workshop] "Broken?" / "Track the repair." Sub: "Odoo Repairs logs parts, labour and
    **the customer's quote.**" CTA "See all Odoo apps" (/odoo/apps). Workbench with an opened generic laptop, tools, parts
    bins; repair order ticket "RO/0042 · Screen replacement · Quote S$180 · sample"; status steps Received -> Quoted ->
    Repaired -> Returned. Nexi: goggles, reach.

### G5 - `...-collection2-g5` - ports render 9751, dbg 9752, audit 9753, NEXICAM 3751/9754
147 `quality-check-before-it-ships` [M macro, LIGHT] "Check it" / "before it ships." Sub: "Odoo Quality adds **control points**
    to receipts and production." CTA (/odoo/apps/quality). Macro: a digital caliper measuring a machined part on a line;
    tablet "Diameter 25.00 +/- 0.05 mm: 25.02 · Pass · sample"; pass/fail lamps; reject bin. Icon: quality_control. Nexi: think.
148 `maintenance-before-it-breaks` [R, THEMED warm factory] "Fix it" / "before it breaks." Sub: "Odoo Maintenance plans
    **preventive checks** for every machine." CTA (/odoo/apps/maintenance). A machine with gauges, a technician cart; a wall
    calendar with recurring check stickers every 30 days; maintenance request cards New / In progress / Repaired.
    Icon: maintenance. Nexi: hardhat, present.
149 `fleet-key-cabinet` [S, THEMED office wall] "Every vehicle," / "every service date." Sub: "Odoo Fleet tracks
    **contracts, services and odometers.**" CTA (/odoo/apps/fleet). A wall key cabinet with labelled hooks (VAN-01, VAN-02,
    CAR-03 · sample), key tags with service-due chips and odometer readings; a fleet card on a tablet. Icon: fleet.
    Nexi: present.
150 `recruitment-applicant-to-first-day` [M, LIGHT] "From applicant" / "to first day." Sub: "Odoo Recruitment moves candidates
    **stage by stage**, notes included." CTA (/odoo/apps/recruitment). A glass elevator shaft with floors New -> Interview ->
    Offer -> Hired; candidate cards riding up; floor indicator; a "Welcome" door at the top. Icon: hr_recruitment. Nexi: hi.
151 `appraisals-feedback-garden` [M, THEMED garden] "Feedback" / "on a schedule." Sub: "Odoo Appraisals sets **goals and
    check-ins** for every employee." CTA (/odoo/apps/appraisals). Potted plants labelled with goals growing to different
    heights; a watering can = feedback; a check-in calendar; an appraisal card with ratings. Icon: hr_appraisal.
    Nexi: strawhat, reach.
152 `employees-org-chart-mobile` [M art, THEMED gallery] "Who reports" / "to whom?" Sub: "The Employees app **draws your org
    chart** from each profile." CTA (/odoo/apps/employees). An elegant hanging mobile sculpture with employee avatar discs
    balanced by role (sample names) in a light gallery; an org-chart card. Icon: hr. Nexi: think, looking up.

### G6 - `...-collection2-g6` - ports render 9761, dbg 9762, audit 9763, NEXICAM 3761/9764
153 `ph-payroll-bir-forms` [S, THEMED office desk] "Payslips and BIR forms," / "in one run." Sub: "Odoo 20's Philippine
    payroll covers **1601-C, 2316 and 1604-C.**" CTA (/odoo/apps/payroll). Payslip envelopes on a desk tray with form chips
    (BIR 1601-C, 2316, 1604-C, SSS and Pag-IBIG loan deductions); a payroll run card "October run · 24 employees · sample".
    Icon: hr_payroll. Nexi: present.
154 `lunch-orders-by-noon` [S top-down, THEMED pantry] "Lunch orders," / "sorted by noon." Sub: "Odoo Lunch collects orders
    and **sends them to the vendor.**" CTA "See all Odoo apps" (/odoo/apps). Top-down pantry table: named lunch boxes (sample
    names), a vendor order summary "Kopi & Co. · 14 orders · sample", a phone with the lunch order, a clock at 11:30.
    Nexi: chef.
155 `knowledge-company-wiki` [M, THEMED library] "Your company wiki," / "inside Odoo." Sub: "Odoo Knowledge keeps **how-tos
    and policies** one search away." CTA (/odoo/apps/knowledge). A wooden card catalogue with a drawer out; cards lift into
    nested article pages (Onboarding > IT setup > Wi-Fi); a search bar; reading lamp. Icon: knowledge. Nexi: think, glasses.
156 `discuss-chat-beside-the-record` [M split, LIGHT] "Chat beside the record," / "not in ten group chats." Sub: "Odoo
    Discuss and the chatter keep **every message on its document.**" CTA (/odoo/apps/discuss). Left: a knot of generic group-chat
    bubbles (no app logos); right: a clean sales order with its chatter thread pinned to it, messages stacked neatly.
    Icon: mail. Nexi: reach (untangling).
157 `activities-never-forget-a-follow-up` [S, THEMED desk wall] "Never forget" / "a follow-up." Sub: "Schedule an activity and
    **Odoo reminds you** on the day." CTA "Watch the Quick Tips" (/nexi-explains). A wall of messy sticky notes giving way to
    a tidy activity list (Call · Email · Meeting · To-do) with due dates coloured (today orange, overdue red, planned green);
    an alarm clock. Nexi: point.
158 `surveys-feedback-kiosk` [R, THEMED shop exit] "Ask customers." / "Count the answers." Sub: "Odoo Surveys collects answers
    and **charts them live.**" CTA (/odoo/apps/surveys). A feedback kiosk with four big face buttons at a shop exit, a live
    results bar chart above it (sample counts that add up), a QR poster, people tapping. Icon: survey. Nexi: celebrate.

### G7 - `...-collection2-g7` - ports render 9771, dbg 9772, audit 9773, NEXICAM 3771/9774
159 `email-alias-becomes-a-record` [M, THEMED office door] "Email it to Odoo." / "It becomes a record." Sub: "Mail aliases
    turn emails into **bills, tickets and leads.**" CTA "See Odoo Integration" (/odoo/integration). A brass three-slot mail box
    in a blue door (bills@ / support@ / sales@ yourcompany · sample); envelopes flying in; on the other side they become a
    vendor bill, a helpdesk ticket and a CRM lead card. Icons: accountant, helpdesk, crm. Nexi: cap, present.
160 `voip-call-from-the-record` [M, LIGHT] "Call from the record." / "Log it automatically." Sub: "Odoo VoIP calls from the
    customer and **logs every call.**" CTA (/odoo/apps/voip). A retro handset whose coiled cord becomes a data line into a CRM
    contact card with call-log entries (Call 4:12 · outgoing · sample); a softphone dialer; sound waves. Icon: voip. Nexi: hi.
161 `tip-save-your-search` [U macro, DARK] "Same filter every day?" / "Save it once." Sub: "Add your search to **Favorites**
    and reuse it in one click." CTA "Watch the Quick Tips" (/nexi-explains). A big tilted Odoo search panel (Filters / Group By /
    Favorites columns); a star being clicked; a bookmark ribbon dropping into Favorites "My open quotes · sample".
    Icon: crm. Nexi: celebrate.
162 `tip-ctrl-k-go-anywhere` [S macro, THEMED desk] "Press Ctrl + K." / "Go anywhere." Sub: "The command palette jumps to
    **any menu or record.**" CTA (/nexi-explains). Photo-real-ish macro of a keyboard with Ctrl and K keycaps glowing, the
    command palette floating above with results (Deliveries, Invoices, Lumen Goods · sample). NOT comic. Nexi small, pointL.
163 `tip-edit-many-records-dominoes` [M, LIGHT] "Change twenty records" / "in one go." Sub: "Select them, **edit one field**,
    and Odoo updates them all." CTA (/nexi-explains). A curving row of domino-shaped record tiles toppling, each flipping from
    "Salesperson: -" to "Salesperson: Mei · sample"; a cursor pushes the first; list header "20 selected". Nexi: gasp.
164 `tip-group-by-in-one-click` [M, THEMED glass jars] "Messy list?" / "Group By in one click." Sub: "Group records by
    **stage, salesperson or date** instantly." CTA (/nexi-explains). A messy pile of coloured marbles pouring into labelled
    glass jars (New / Qualified / Proposition / Won) with counts on the lids that add up; a Group By chip. Nexi: clap.
165 `tip-import-the-spreadsheet` [M, THEMED loading dock] "Typing it all in?" / "Import the spreadsheet." Sub: "Odoo maps your
    columns and **loads every row** at once." CTA (/nexi-explains). Spreadsheet rows as crates rolling up a ramp into an Odoo
    list; a column-mapping card (Name -> Customer, Phone -> Phone); "248 rows imported · sample". Nexi: hardhat, point.

### G8 - `...-collection2-g8` - ports render 9781, dbg 9782, audit 9783, NEXICAM 3781/9784
166 `tip-log-note-or-send-message` [M split, LIGHT] "Log note" / "or send message?" Sub: "Notes stay **inside the team**;
    messages go to the customer." CTA (/nexi-explains). Left: an internal note on yellow paper pinned inside the office
    (padlock, team avatars); right: an envelope flying out a window to the customer; the chatter buttons "Send message" /
    "Log note" at the top. Nexi between, holding both.
167 `odoo-takes-tasks-not-people` [M editorial, THEMED office] "Odoo takes the tasks," / "not the people." Sub: "Automation lifts
    **repetitive work**, so your team does the thinking." CTA (/odoo/ai-integration). A smiling employee at a desk; a soft
    overhead conveyor lifts away repetitive task cards (re-key invoice x3, chase reminders, match bank lines) into an Odoo
    box; her desk keeps the people work (client call, plan Q4). Not the S2 comic claw. Nexi: assisting, present.
168 `practise-on-a-test-database` [R flight simulator, THEMED] "Practise on a copy" / "before the real thing." Sub: "Training
    runs on a **test database**, so nobody fears the wrong click." CTA "See Odoo Training" (/odoo/training). A flight
    simulator cockpit whose screens show Odoo (sales order, inventory) with a "TEST DATABASE" banner; trainee hands on the
    controls; instructor tablet. Nexi: pilot, present (instructor).
169 `fix-the-process-first` [M map, LIGHT] "Fix the process first," / "then automate it." Sub: "Map how orders really flow,
    **remove the detours**, then switch Odoo on." CTA "See Odoo Discovery" (/odoo/discovery). A road map with a tangled old
    route (loops, dead ends) being redrawn by a highlighter into a clean road; a car waiting at the start; milestones =
    process steps. Nexi: point, with a pen.
170 `the-log-is-for-fixing` [U, DARK] "The log is for fixing," / "not for blaming." Sub: "Odoo's history shows **what changed
    and when**, so mistakes get fixed fast." CTA (/odoo/training). A crisp chatter/history timeline on a record ("Price
    12.40 -> 14.20 · by Mei · 10:42 · sample"), a magnifier on the change, an undo arrow restoring it. Nexi: present.
171 `ask-the-policy-manual` [M, THEMED office library] "Ask the policy manual." / "Get the page it came from." Sub: "AI
    knowledge assistants answer from **your own documents**, with sources." CTA "See AI Knowledge" (/solutions/ai-knowledge).
    A thick handbook open and glowing; chat Q "How many days of annual leave in year 2? · sample" -> answer card with a
    citation chip "Handbook p.14, 3.2" and the matching paragraph highlighted on the page; bookmarks. Nexi: point.
172 `get-a-written-quotation` [U, LIGHT] "Pick your apps." / "Get a written quote." Sub: "Apps, users, hosting, services:
    **we turn it into a quotation.**" CTA "Get a quotation" (/quotation). The five quotation-builder steps as stacked cards
    (1 Apps: Accounting, Sales, Inventory selected · 2 Users: 10 · 3 Hosting · 4 Services · 5 Timeline) fanning into a printed
    "TechNext · written quotation · sample" document; note "Nothing here commits you". Nexi: present.
