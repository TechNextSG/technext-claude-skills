/* hero.js - builders + deterministic motion for the hero-language posts (needs kit.js first).
   Every motion input is an integer multiple of th = 2*PI*t/LOOP (or frac(t/LOOP)), so the 8 s loop is seamless.
   HB.bg(post, o)        aurora + grid + spotlight + twinkling particles           -> render(t)
   HB.rot(span, words)   slide-1 rotating word inside a headline                    -> render(t, per, i0)
   HB.dash(parent, o)    slide-1 product card (KPIs, chart, live feed)               -> {el, render(t)}
   HB.orbit(post, o)     slide-1 Odoo apps on tilted rings around a core              -> render(t)
   HB.map(post, o)       slide-2 process map: lanes, nodes, gates, edges, tokens      -> render(t)
   HB.float(el, o)       gentle bob for Nexi / cards                                  -> render(t) */
(function () {
  var TAU = Math.PI * 2, HB = window.HB = {};
  function el(tag, cls, parent, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; if (parent) parent.appendChild(e); return e; }
  function L() { return window.LOOP || 8; }
  HB.el = el;
  HB.ic = function (n) { return 'assets/odoo/' + n + '.svg'; };
  HB.th = function (t) { return TAU * t / L(); };

  /* ---------- background ---------- */
  HB.bg = function (post, o) {
    var b = el('div', 'hb'); post.insertBefore(b, post.firstChild);
    if (o.base) b.style.setProperty('--hb-base', o.base);
    var au = (o.au || []).map(function (a) {
      var d = el('div', 'au', b);
      d.style.cssText = 'left:' + (a[0] - a[2] / 2) + 'px;top:' + (a[1] - a[2] / 2) + 'px;width:' + a[2] + 'px;height:' + a[2] + 'px;--au:' + a[3] + ';opacity:' + (a[4] == null ? .9 : a[4]);
      return d;
    });
    if (o.grid !== false) {
      var g = el('div', 'grid', b);
      ['gl', 'gm', 'gx', 'gy'].forEach(function (k) { if (o[k]) g.style.setProperty('--' + k, o[k]); });
    }
    var sp = null; if (o.spot) { sp = el('div', 'spot', b); if (o.sp) sp.style.setProperty('--sp', o.sp); }
    var cv = el('canvas', '', b), dpr = window.devicePixelRatio || 1; cv.width = TN.W * dpr; cv.height = TN.H * dpr;
    var g2 = cv.getContext('2d'), R = TN.rand(o.seed || 7), N = o.parts == null ? 50 : o.parts, P = [], avoid = o.avoid || [];
    for (var i = 0; i < N; i++) {
      var p = { x: R() * TN.W, y: R() * TN.H, r: 1.6 + R() * 3.4, k: 1 + Math.floor(R() * 3), a: .22 + R() * .5, ph: R() * TAU };
      if (avoid.some(function (z) { return p.x > z[0] && p.x < z[2] && p.y > z[1] && p.y < z[3]; })) continue;
      P.push(p);
    }
    var pc = o.pc || '79,134,232';
    return function (t) {
      var th = HB.th(t);
      au.forEach(function (d, i) { d.style.transform = 'translate(' + (38 * Math.sin(th + i * 2.1)).toFixed(1) + 'px,' + (28 * Math.cos(th + i * 1.3)).toFixed(1) + 'px) scale(' + (1 + .05 * Math.sin(th + i)).toFixed(3) + ')'; });
      if (sp) { sp.style.left = (o.spot[0] + 70 * Math.sin(th)).toFixed(1) + 'px'; sp.style.top = (o.spot[1] + 46 * Math.sin(2 * th)).toFixed(1) + 'px'; }
      g2.setTransform(dpr, 0, 0, dpr, 0, 0); g2.clearRect(0, 0, TN.W, TN.H);
      P.forEach(function (p) {
        var x = p.x + 18 * Math.sin(th + p.ph), y = p.y + 26 * Math.cos(th * p.k + p.ph), a = p.a * (.55 + .45 * Math.sin(2 * th * p.k + p.ph));
        g2.fillStyle = 'rgba(' + pc + ',' + a.toFixed(3) + ')'; g2.beginPath(); g2.arc(x, y, p.r, 0, TAU); g2.fill();
      });
    };
  };

  /* ---------- rotating word ---------- */
  HB.rot = function (span, words) {
    // the gradient (.hl) must sit on each word: background-clip:text on the container paints hidden children too
    var hl = span.classList.contains('hl'); span.classList.remove('hl'); span.classList.add('rot'); span.innerHTML = '';
    var bs = words.map(function (w) { return el('b', hl ? 'hl' : '', span, w); });
    var ws = bs.map(function (b) { return b.offsetWidth; });
    span.style.width = Math.max.apply(null, ws) + 'px';
    return function (t, per, i0) {
      var n = words.length, k = Math.floor(t / per + 1e-6), cur = ((i0 || 0) + k) % n, prev = (cur - 1 + n) % n;
      var e = TN.eo(TN.seg(t - k * per, 0, .55));
      bs.forEach(function (b, i) {
        var y = 120, op = 0;
        if (i === cur) { y = (1 - e) * 105; op = e; }
        else if (i === prev && e < 1) { y = -e * 105; op = 1 - e; }
        b.style.transform = 'translateY(' + y.toFixed(2) + '%)'; b.style.opacity = op.toFixed(3);
      });
      span.style.width = (ws[prev] + (ws[cur] - ws[prev]) * e).toFixed(1) + 'px';
    };
  };

  /* ---------- product card ---------- */
  // o = {x, y, w, title, kpis: [[icon, label, value, note]], chart: [heights %], chartT, feed: [[icon, html, time]], tf}
  HB.dash = function (parent, o) {
    var d = el('div', 'hd', parent);
    d.style.left = o.x + 'px'; d.style.top = o.y + 'px'; if (o.w) d.style.setProperty('--dw', o.w + 'px'); if (o.tf) d.style.transform = o.tf;
    el('div', 'hd-bar', d, '<i></i><i></i><i></i> ' + (o.title || 'Odoo &middot; one database') + ' <span><i class="live"></i> sample data</span>');
    var body = el('div', 'hd-body', d);
    if (o.kpis) el('div', 'kpis', body, o.kpis.map(function (k) { return '<div class="kpi"><img src="' + HB.ic(k[0]) + '" alt=""><small>' + k[1] + '</small><b>' + k[2] + '</b><em>' + k[3] + '</em></div>'; }).join(''));
    var bars = [];
    if (o.chart) { var c = el('div', 'hchart', body); c.setAttribute('data-t', o.chartT || 'Cash forecast · 12 weeks'); bars = o.chart.map(function (h) { var i = el('i', '', c); i.style.setProperty('--h', h + '%'); return i; }); }
    var rows = [], fh = 0, feed;
    if (o.feed) {
      feed = el('ol', 'hfeed', body);
      rows = o.feed.map(function (f) { return el('li', '', feed, '<img src="' + HB.ic(f[0]) + '" alt=""><span>' + f[1] + '</span><time>' + f[2] + '</time>'); });
      fh = rows[0].offsetHeight + 7; var show = o.feedShow || 3; feed.style.height = (show * fh - 7) + 'px';
      rows.forEach(function (r) { r.style.position = 'absolute'; r.style.left = '0'; r.style.right = '0'; r.style.top = '0'; });
    }
    var live = d.querySelector('.live');
    return {
      el: d, render: function (t) {
        var th = HB.th(t);
        d.style.setProperty('--sw', (-130 + 260 * TN.eio(TN.seg(t % L(), .3, 1.6))).toFixed(1) + '%');
        live.style.setProperty('--lp', (8 * TN.frac(2 * t / L() * 2)).toFixed(1) + 'px');
        bars.forEach(function (b, i) { b.style.transform = 'scaleY(' + (1 + .07 * Math.sin(th * 2 + i * .7)).toFixed(3) + ')'; });
        if (rows.length) {
          var m = rows.length, per = L() / m, k = Math.floor(t / per + 1e-6), e = TN.back(TN.seg(t - k * per, 0, .6)), show = o.feedShow || 3;
          rows.forEach(function (r, i) {
            var pos = ((k - i) % m + m) % m;       // 0 = newest (top)
            var y, op;
            if (pos === 0) { y = (-1 + e) * fh; op = TN.cl(e * 1.4, 0, 1); }
            else if (pos < show) { y = (pos - 1 + e) * fh; op = 1; }
            else if (pos === show) { y = (show - 1 + e) * fh; op = 1 - TN.cl(e * 1.6, 0, 1); }
            else { y = show * fh; op = 0; }
            r.style.transform = 'translateY(' + y.toFixed(1) + 'px)'; r.style.opacity = op.toFixed(3);
            r.style.background = pos === 0 ? 'rgba(234,240,251,' + (1 - e * .6).toFixed(3) + ')' : '';
          });
        }
      }
    };
  };

  /* ---------- orbit ---------- */
  // o = {cx, cy, zBack, zFront, rings: [{R, k, roll (deg), turns (int, signed), s (px), ph (deg), apps: [], tags: {app: [b, small, 'up']},
  //       line: 'rgba()', dash: [a,b], comet: true, depth: .22}]}
  HB.orbit = function (post, o) {
    var dpr = window.devicePixelRatio || 1, Hh = TN.H;
    function cvs(z) { var c = el('canvas', '', post); c.style.cssText = 'position:absolute;left:0;top:0;width:1080px;height:100%;pointer-events:none;z-index:' + z; c.width = TN.W * dpr; c.height = Hh * dpr; return c.getContext('2d'); }
    var gb = cvs(o.zBack || 9), gf = cvs(o.zFront || 24);
    var items = [];
    o.rings.forEach(function (r, ri) {
      r.apps.forEach(function (a, j) {
        var d = el('div', 'oa', post); d.style.setProperty('--s', r.s + 'px');
        var img = el('img', '', d); img.src = /\//.test(a) ? a : HB.ic(a); img.alt = '';
        var tg = r.tags && r.tags[a];   // labels live in their own top layer so icons on other rings never slide over them
        var tag = tg ? el('span', 'otag free' + (tg[2] === 'up' ? ' up' : ''), post, '<b>' + tg[0] + '</b>' + (tg[1] ? '<small>' + tg[1] + '</small>' : '')) : null;
        if (tag) { tag.setAttribute('data-qa', 'text'); tag.style.zIndex = o.zTag || 34; }
        items.push({ d: d, r: r, ri: ri, j: j, n: r.apps.length, tag: tag, name: a });
      });
    });
    function P(r, phi) {   // ring-local angle -> screen point + depth
      var ex = r.R * Math.cos(phi), ey = r.R * r.k * Math.sin(phi), ro = (r.roll || 0) * Math.PI / 180;
      return [o.cx + ex * Math.cos(ro) - ey * Math.sin(ro), o.cy + ex * Math.sin(ro) + ey * Math.cos(ro), Math.sin(phi)];
    }
    function arc(g, r, a0, a1, style, w, dash) {
      g.save(); g.translate(o.cx, o.cy); g.rotate((r.roll || 0) * Math.PI / 180);
      g.beginPath(); g.ellipse(0, 0, r.R, r.R * r.k, 0, a0, a1); g.strokeStyle = style; g.lineWidth = w; g.setLineDash(dash || []); g.stroke(); g.restore();
    }
    return function (t) {
      var th = HB.th(t), out = {};
      [gb, gf].forEach(function (g) { g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, TN.W, Hh); });
      o.rings.forEach(function (r) {
        var dk = post.classList.contains('dark'), line = r.line || (dk ? 'rgba(255,255,255,.5)' : 'rgba(49,103,202,.32)'); if (dk && !r.cc) r.cc = '255,255,255';
        arc(gb, r, Math.PI, TAU, line.replace(/[\d.]+\)$/, function (m) { return (parseFloat(m) * .6).toFixed(3) + ')'; }), r.w || 2.4, r.dash);
        arc(gf, r, 0, Math.PI, line, (r.w || 2.4) + .6, r.dash);
        if (r.comet !== false) {                                       // a bright comet running the ring
          var head = (r.cph || 0) * Math.PI / 180 + (r.cturns || 2 * (r.turns || 1)) * th, N = 26, span = 1.25;
          for (var i = 0; i < N; i++) {
            var a0 = head - span + span * i / N, a1 = head - span + span * (i + 1) / N, mid = (a0 + a1) / 2, f = (i + 1) / N;
            var g = Math.sin(mid) >= 0 ? gf : gb;
            arc(g, r, a0, a1 + .004, 'rgba(' + (r.cc || '49,103,202') + ',' + (f * f * .95).toFixed(3) + ')', 1.5 + f * (r.cw || 5));
          }
          var hp = P(r, head), gg = Math.sin(head) >= 0 ? gf : gb;
          var rg = gg.createRadialGradient(hp[0], hp[1], 0, hp[0], hp[1], 26); rg.addColorStop(0, 'rgba(255,255,255,.95)'); rg.addColorStop(.25, 'rgba(' + (r.cc || '49,103,202') + ',.55)'); rg.addColorStop(1, 'rgba(' + (r.cc || '49,103,202') + ',0)');
          gg.fillStyle = rg; gg.beginPath(); gg.arc(hp[0], hp[1], 26, 0, TAU); gg.fill();
        }
      });
      items.forEach(function (it) {
        var r = it.r, phi = (r.ph || 0) * Math.PI / 180 + TAU * it.j / it.n + (r.turns || 1) * th, p = P(r, phi), dp = p[2];
        var sc = 1 + (r.depth == null ? .22 : r.depth) * dp, front = dp > -0.02;
        it.d.style.transform = 'translate(' + p[0].toFixed(1) + 'px,' + p[1].toFixed(1) + 'px) scale(' + sc.toFixed(3) + ')';
        it.d.style.zIndex = front ? (o.zFront || 24) + 1 + Math.round(dp * 5) : (o.zBack || 9) + 1;
        it.d.style.opacity = (front ? 1 : .55 + .45 * (1 + dp)).toFixed(3);
        it.d.firstChild.style.filter = dp < -.35 ? 'blur(' + ((-dp - .35) * 3.2).toFixed(2) + 'px) drop-shadow(0 12px 12px rgba(31,31,61,.16))' : '';
        if (it.tag) {
          var tv = TN.cl((dp + .05) / .3, 0, 1), half = r.s * sc / 2 + 14, up = it.tag.classList.contains('up');
          it.tag.style.opacity = tv.toFixed(3);
          it.tag.style.transform = 'translate(' + p[0].toFixed(1) + 'px,' + (up ? p[1] - half : p[1] + half).toFixed(1) + 'px) translate(-50%,' + (up ? '-100%' : '0') + ')';
        }
        out[it.name] = [Math.round(p[0]), Math.round(p[1]), +dp.toFixed(2)];
      });
      return out;
    };
  };

  /* ---------- process map ---------- */
  // o = {x, y, w, h, tf, origin, ns, lanes: {dir: 'rows'|'cols', head, items: [[icon, label]], alt: true},
  //      nodes: [{id, x, y, icon | gate:true, label, sub, pos: 'b'|'t'|'l'|'r', n (badge)}],
  //      edges: [{a, b, via: [[x,y]], dash, label, lt, ldx, ldy}],
  //      routes: [{path: [ids], c: colour, n: tokens, laps: int, off}], kpis: {x, y, items: [[dt, dd, ok]]},
  //      scen: {x, y, items: [[label, colour, on]]}, hint: {x, y, text}}
  HB.map = function (post, o) {
    var NS = 'http://www.w3.org/2000/svg';
    if (TN.F === 'reel' && o.reelFit !== false) { o.x = Math.max(o.x, 98); if (o.tf) o.tf = o.tf.replace('scale(.9)', 'scale(.85)'); }   // reel safe zone: left 60, right 140 below y 1000
    var wrap = el('div', 'pmw', post); wrap.style.cssText = 'left:' + o.x + 'px;top:' + o.y + 'px;width:' + o.w + 'px;height:' + o.h + 'px;' + (o.z ? 'z-index:' + o.z + ';' : '');
    if (o.glow !== false) { var gw = el('div', 'pmglow', wrap); gw.style.cssText = 'left:6%;right:6%;top:14%;bottom:-4%;background:' + (o.glow || 'linear-gradient(120deg,#6FA0F5,#A9C6FF 50%,#F3B9D3)'); if (o.tf) gw.style.transform = o.tf; if (o.origin) gw.style.transformOrigin = o.origin; }
    var pm = el('div', 'pm', wrap); if (o.tf) pm.style.transform = o.tf; if (o.origin) pm.style.transformOrigin = o.origin;
    if (o.ns) pm.style.setProperty('--ns', o.ns + 'px');
    var lanes = el('div', 'pm-lanes', pm), ln = o.lanes, n = ln ? ln.items.length : 0, head = ln ? ln.head : 0;
    if (ln) ln.items.forEach(function (it, i) {
      var b = el('div', 'pm-lane' + (ln.dir === 'cols' ? ' cols' : '') + (i % 2 ? ' alt' : ''), lanes);
      var lab = el('div', 'pm-ln', pm, (it[0] ? '<img src="' + (/\//.test(it[0]) ? it[0] : HB.ic(it[0])) + '" alt="">' : '') + '<b>' + it[1] + '</b>');
      lab.setAttribute('data-qa', 'text'); lab.setAttribute('data-qa-group', 'lanes');
      if (ln.dir === 'cols') {
        var cw = (o.w) / n; b.style.cssText = 'left:' + (i * cw) + 'px;top:0;width:' + cw + 'px;height:' + o.h + 'px';
        lab.style.cssText = 'left:' + (i * cw) + 'px;top:0;width:' + cw + 'px;height:' + head + 'px';
        if (i) { var dv = el('div', 'pm-div', pm); dv.style.cssText = 'left:' + (i * cw) + 'px;top:' + head + 'px;width:1.5px;bottom:0;opacity:.0'; }
      } else {
        var sz = ln.sizes || ln.items.map(function () { return o.h / n; }), top = 0, rh = sz[i];
        for (var q = 0; q < i; q++) top += sz[q];
        b.style.cssText = 'left:0;top:' + top + 'px;width:' + o.w + 'px;height:' + rh + 'px';
        lab.style.cssText = 'left:0;top:' + top + 'px;width:' + head + 'px;height:' + rh + 'px';
        if (i) { b.style.borderTop = '1.5px dashed rgba(49,103,202,.16)'; }
      }
    });
    if (ln) { var hd = el('div', 'pm-div', pm); hd.style.cssText = ln.dir === 'cols' ? 'left:0;right:0;top:' + head + 'px;height:1.5px' : 'top:0;bottom:0;left:' + head + 'px;width:1.5px'; }

    var svg = document.createElementNS(NS, 'svg'); svg.setAttribute('class', 'pm-svg'); svg.setAttribute('width', o.w); svg.setAttribute('height', o.h); pm.appendChild(svg);
    svg.innerHTML = '<defs><marker id="ar-' + TN.P + '" viewBox="0 0 10 10" refX="7.5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M1 1 L9 5 L1 9 z" fill="#BFCDEA"/></marker>' +
      '<marker id="arh-' + TN.P + '" viewBox="0 0 10 10" refX="7.5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M1 1 L9 5 L1 9 z" fill="#3167CA"/></marker></defs>';
    var gE = document.createElementNS(NS, 'g'); svg.appendChild(gE);
    var gT = document.createElementNS(NS, 'g'); svg.appendChild(gT);

    var N = {}, nodes = [];
    o.nodes.forEach(function (nd) {
      N[nd.id] = nd;
      var d = el('div', 'pm-node' + (nd.gate ? ' gate' : ''), pm); d.style.left = nd.x + 'px'; d.style.top = nd.y + 'px';
      if (nd.ns) d.style.setProperty('--ns', nd.ns + 'px');
      el('i', 'ring', d);
      el('div', 'pi', d, nd.gate ? '<i class="pm-dia"></i>' : '<img src="' + (/\//.test(nd.icon) ? nd.icon : HB.ic(nd.icon)) + '" alt="">');
      if (nd.label) { var l = el('div', 'pl ' + (nd.pos || 'b'), d, nd.label + (nd.sub ? '<small>' + nd.sub + '</small>' : '')); l.setAttribute('data-qa', 'text'); l.setAttribute('data-qa-group', 'n-' + nd.id); }
      if (nd.n != null) el('span', 'pn', d, nd.n);
      nd.el = d; nd.ring = d.querySelector('.ring'); nd.r = nd.gate ? 32 : (nd.ns || o.ns || 58) / 2 + 4; nodes.push(nd);
    });

    function poly(e) { var A = N[e.a], B = N[e.b]; return [[A.x, A.y]].concat(e.via || [], [[B.x, B.y]]); }
    function lens(p) { var c = [0]; for (var i = 1; i < p.length; i++) c.push(c[i - 1] + Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1])); return c; }
    function at(p, c, s) { s = TN.cl(s, 0, c[c.length - 1]); for (var i = 1; i < p.length; i++) if (s <= c[i] || i === p.length - 1) { var f = (s - c[i - 1]) / ((c[i] - c[i - 1]) || 1); return [p[i - 1][0] + (p[i][0] - p[i - 1][0]) * f, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * f]; } }
    function trim(p, a, b) {        // cut a px off the start, b px off the end
      var c = lens(p), Lt = c[c.length - 1], s0 = a, s1 = Lt - b, q = [at(p, c, s0)];
      for (var i = 1; i < p.length - 1; i++) if (c[i] > s0 && c[i] < s1) q.push(p[i]);
      q.push(at(p, c, s1)); return q;
    }
    function rounded(p, rad) {
      var d = 'M' + p[0][0].toFixed(1) + ' ' + p[0][1].toFixed(1);
      for (var i = 1; i < p.length - 1; i++) {
        var a = p[i - 1], b = p[i], c = p[i + 1], l1 = Math.hypot(b[0] - a[0], b[1] - a[1]), l2 = Math.hypot(c[0] - b[0], c[1] - b[1]), r = Math.min(rad, l1 / 2, l2 / 2);
        var p1 = [b[0] - (b[0] - a[0]) / l1 * r, b[1] - (b[1] - a[1]) / l1 * r], p2 = [b[0] + (c[0] - b[0]) / l2 * r, b[1] + (c[1] - b[1]) / l2 * r];
        d += ' L' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + ' Q' + b[0] + ' ' + b[1] + ' ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
      }
      return d + ' L' + p[p.length - 1][0].toFixed(1) + ' ' + p[p.length - 1][1].toFixed(1);
    }
    var E = {};
    o.edges.forEach(function (e) {
      var p = poly(e), q = trim(p, N[e.a].r, N[e.b].r + 5);
      var path = document.createElementNS(NS, 'path'); path.setAttribute('d', rounded(q, 18)); path.setAttribute('class', 'pm-e' + (e.dash ? ' dash' : ''));
      path.setAttribute('marker-end', 'url(#ar-' + TN.P + ')'); gE.appendChild(path);
      var fl = document.createElementNS(NS, 'path'); fl.setAttribute('d', path.getAttribute('d')); fl.setAttribute('class', 'pm-flow'); gE.appendChild(fl); e.fl = fl;
      e.path = path; e.p = p; e.c = lens(p); E[e.a + '>' + e.b] = e;
      if (e.label) {
        var pt = at(p, e.c, e.c[e.c.length - 1] * (e.lt == null ? .5 : e.lt));
        var lb = el('div', 'pm-el' + (e.dash ? ' dash' : ''), pm, e.label); lb.style.left = (pt[0] + (e.ldx || 0)) + 'px'; lb.style.top = (pt[1] + (e.ldy || 0)) + 'px';
        lb.setAttribute('data-qa', 'text'); lb.setAttribute('data-qa-group', 'el-' + e.a + e.b); e.lb = lb;
      }
    });
    var toks = [];
    (o.routes || []).forEach(function (rt) {
      var p = [], segs = [], hits = [];
      for (var i = 0; i < rt.path.length - 1; i++) {
        var e = E[rt.path[i] + '>' + rt.path[i + 1]]; if (!e) { console.warn('no edge', rt.path[i], rt.path[i + 1]); continue; }
        var s0 = p.length ? lens(p)[p.length - 1] : 0;
        var q = p.length ? e.p.slice(1) : e.p.slice(); p = p.concat(q);
        segs.push({ e: e, s0: s0, s1: lens(p)[p.length - 1] });
      }
      var c = lens(p), Lt = c[c.length - 1];
      segs.forEach(function (sg, i) { if (i === 0) hits.push({ nd: N[sg.e.a], s: sg.s0 }); hits.push({ nd: N[sg.e.b], s: sg.s1 }); });
      rt.p = p; rt.cum = c; rt.L = Lt; rt.segs = segs; rt.hits = hits;
      for (var k = 0; k < (rt.n || 1); k++) {
        var tr = []; for (var q = 1; q <= 7; q++) { var cc = document.createElementNS(NS, 'circle'); cc.setAttribute('r', (8.5 - q * .9).toFixed(1)); cc.setAttribute('fill', rt.c); cc.setAttribute('opacity', (.42 - q * .05).toFixed(2)); gT.appendChild(cc); tr.push(cc); }
        var g = document.createElementNS(NS, 'g'); g.setAttribute('class', 'pm-tok');
        g.innerHTML = '<circle class="h" r="17" fill="' + rt.c + '"/><circle r="9" fill="' + rt.c + '" stroke="#fff" stroke-width="3"/>';
        gT.appendChild(g); toks.push({ g: g, rt: rt, k: k, tr: tr });
      }
    });

    var kp = null;
    if (o.kpis) {
      kp = el('dl', 'pm-kpis' + (o.kpis.sm === false ? '' : ' sm'), pm, o.kpis.items.map(function (k) { return '<div' + (k[2] ? ' class="k0"' : '') + '><dt>' + k[0] + '</dt><dd>' + k[1] + '</dd></div>'; }).join(''));
      kp.style.left = o.kpis.x + 'px'; kp.style.top = o.kpis.y + 'px'; kp.setAttribute('data-qa', 'text'); kp.setAttribute('data-qa-group', 'kpis');
    }
    if (o.scen) {
      var sc = el('div', 'pm-scen', pm, o.scen.items.map(function (s) { return '<span' + (s[2] ? ' class="on"' : '') + '>' + (s[1] ? '<i style="background:' + s[1] + '"></i>' : '') + s[0] + '</span>'; }).join(''));
      sc.style.left = o.scen.x + 'px'; sc.style.top = o.scen.y + 'px'; if (o.scen.center) sc.style.transform = 'translateX(-50%)'; sc.setAttribute('data-qa', 'text');
    }
    if (o.hint) { var hn = el('div', 'pm-hint', pm, '<i></i>' + o.hint.text); hn.style.left = o.hint.x + 'px'; hn.style.top = o.hint.y + 'px'; if (o.hint.right) { hn.style.left = 'auto'; hn.style.right = o.hint.right + 'px'; } hn.setAttribute('data-qa', 'text'); }

    return function (t) {
      var u = t / L(), hot = {}, pulse = {};
      pm.style.setProperty('--sh', (180 - 260 * TN.eio(TN.seg(t % L(), .6, 2.2))).toFixed(1) + '%');
      toks.forEach(function (tk) {
        var rt = tk.rt, s = TN.frac((rt.off || 0) + tk.k / (rt.n || 1) + (rt.laps || 1) * u) * rt.L, q = at(rt.p, rt.cum, s);
        tk.g.setAttribute('transform', 'translate(' + q[0].toFixed(1) + ',' + q[1].toFixed(1) + ')');
        tk.tr.forEach(function (cc, i) { var s2 = s - (i + 1) * 13, q2 = at(rt.p, rt.cum, s2 < 0 ? s2 + rt.L : s2); cc.setAttribute('cx', q2[0].toFixed(1)); cc.setAttribute('cy', q2[1].toFixed(1)); cc.style.display = s2 < 0 ? 'none' : ''; });
        rt.segs.forEach(function (sg) { if (s >= sg.s0 && s <= sg.s1) hot[sg.e.a + '>' + sg.e.b] = 1; });
        rt.hits.forEach(function (h) { var ds = ((s - h.s) % rt.L + rt.L) % rt.L; if (ds < 90) pulse[h.nd.id] = Math.max(pulse[h.nd.id] || 0, 1 - ds / 90); });
      });
      o.edges.forEach(function (e) {
        var k = e.a + '>' + e.b, on = !!hot[k];
        e.path.setAttribute('class', 'pm-e' + (e.dash ? ' dash' : '') + (on ? ' hot' : ''));
        e.path.setAttribute('marker-end', 'url(#' + (on ? 'arh-' : 'ar-') + TN.P + ')');
        if (e.lb) e.lb.classList.toggle('hot', on);
        e.fl.style.opacity = on ? '.95' : '0'; e.fl.setAttribute('stroke-dashoffset', (-u * 18 * 8).toFixed(2));
      });
      nodes.forEach(function (nd) {
        var pv = pulse[nd.id] || 0;
        nd.ring.style.opacity = (pv * .55).toFixed(3); nd.ring.style.transform = 'scale(' + (.62 + (1 - pv) * .5).toFixed(3) + ')';
        nd.el.querySelector('.pi').style.transform = 'scale(' + (1 + pv * .1).toFixed(3) + ')';
      });
    };
  };

  /* ---------- FX layer: bokeh, foreground DOF icons, glossy 3D shapes, toasts, sparkles ----------
     o = {bokeh: [{x,y,s,c,blur,a}], icons: [{n,x,y,s,blur,a,r,z}], shapes: [{t:'sphere|ring|pill|cube|star',x,y,s,w,c1,c2,r,tilt,z}],
          toasts: [{i,b,s,e,x,y,z,ping}]}; every item floats on integer multiples of th (seamless). Returns render(t). */
  HB.fx = function (post, o) {
    var it = [], R = TN.rand(o.seed || 11);
    function fl(d, a, defz) { a.fx = a.fx == null ? 10 + R() * 14 : a.fx; a.fy = a.fy == null ? 12 + R() * 16 : a.fy; a.k = a.k || (1 + Math.floor(R() * 2)); a.ph = a.ph == null ? R() * 6.28 : a.ph; d.style.zIndex = a.z || defz; it.push({ d: d, a: a }); }
    (o.bokeh || []).forEach(function (a) { var d = el('div', 'fxb', post); d.style.cssText = 'left:' + (a.x - a.s / 2) + 'px;top:' + (a.y - a.s / 2) + 'px;width:' + a.s + 'px;height:' + a.s + 'px;background:radial-gradient(closest-side,' + (a.c || 'rgba(111,160,245,.45)') + ',transparent);filter:blur(' + (a.blur || 6) + 'px);opacity:' + (a.a || 1); fl(d, a, 38); });
    (o.icons || []).forEach(function (a) { var d = el('img', 'fxi', post); d.src = /\//.test(a.n) ? a.n : HB.ic(a.n); d.alt = ''; d.style.cssText = 'left:' + (a.x - a.s / 2) + 'px;top:' + (a.y - a.s / 2) + 'px;width:' + a.s + 'px;height:' + a.s + 'px;opacity:' + (a.a || .85) + ';filter:blur(' + (a.blur || 0) + 'px) drop-shadow(0 18px 18px rgba(31,31,61,.22))'; fl(d, a, 38); });
    (o.shapes || []).forEach(function (a) { var d = el('div', 'fxs fx-' + a.t, post); var w = a.w || a.s; d.style.cssText = 'left:' + (a.x - w / 2) + 'px;top:' + (a.y - a.s / 2) + 'px;width:' + w + 'px;height:' + a.s + 'px;' + (a.c1 ? '--c1:' + a.c1 + ';' : '') + (a.c2 ? '--c2:' + a.c2 + ';' : '') + (a.blur ? 'filter:blur(' + a.blur + 'px);' : ''); fl(d, a, 37); });
    (o.toasts || []).forEach(function (a) { var d = el('div', 'fxt', post, '<img src="' + HB.ic(a.i) + '" alt=""><span><b>' + a.b + '</b>' + (a.s ? '<small>' + a.s + '</small>' : '') + '</span>' + (a.e ? '<em>' + a.e + '</em>' : '') + '<i class="pg"></i>'); d.style.left = a.x + 'px'; d.style.top = a.y + 'px'; d.setAttribute('data-qa', 'text'); a.fx = a.fx || 0; a.fy = a.fy || 7; a.rr = a.rr == null ? 1.2 : a.rr; fl(d, a, 36); a.pg = d.querySelector('.pg'); });
    return function (t) {
      var th = HB.th(t);
      it.forEach(function (o2) {
        var a = o2.a, x = a.fx * Math.sin(a.k * th + a.ph), y = a.fy * Math.cos(a.k * th + a.ph * 1.3), r = (a.r || 0) + (a.rr == null ? 6 : a.rr) * Math.sin(th + a.ph);
        o2.d.style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px)' + (a.tilt ? ' perspective(600px) rotateX(' + a.tilt + 'deg)' : '') + ' rotate(' + r.toFixed(2) + 'deg)';
        if (a.pg) { var f = TN.frac(t / L() * 2 + (a.ph || 0) / 6.28); a.pg.style.opacity = (f < .35 ? .8 * (1 - f / .35) : 0).toFixed(3); a.pg.style.transform = 'scale(' + (1 + f * .9).toFixed(3) + ')'; }
        if (a.t === 'star') o2.d.style.opacity = (.55 + .45 * Math.sin(2 * th + a.ph)).toFixed(3);
      });
    };
  };

  /* ---------- Nexi (HD pose PNG, feet anchored, contact shadow, bob) ---------- */
  // o = {pose: 'present', x: centre x, y: feet y, h: height px, flip, z, bob (px), k (bobs per loop), ph, shadow: false, parent}
  HB.nexi = function (post, o) {
    var par = o.parent || post, w = el('div', 'nx', par), img = el('img', '', w);
    img.src = 'assets/nexi-hd/nexi-' + (o.pose || 'present') + '.png'; img.alt = 'Nexi';
    var sh = o.shadow === false ? null : el('div', 'nxs', par);
    var ready = img.decode ? img.decode().catch(function () {}) : Promise.resolve();
    var api = { el: w, img: img, ready: ready };
    ready.then(function () {
      var ww = o.h * img.naturalWidth / img.naturalHeight; api.w = ww;
      w.style.cssText = 'left:' + (o.x - ww / 2) + 'px;top:' + (o.y - o.h) + 'px;width:' + ww + 'px;z-index:' + (o.z || 32) + (o.flip ? ';' : '');
      if (o.flip) img.style.transform = 'scaleX(-1)';
      if (sh) sh.style.cssText = 'left:' + (o.x - ww * .36) + 'px;top:' + (o.y - 16) + 'px;width:' + (ww * .72) + 'px;height:34px;z-index:' + ((o.z || 32) - 1);
    });
    api.render = function (t) {
      var th = HB.th(t), b = (o.bob == null ? 12 : o.bob) * Math.sin((o.k || 2) * th + (o.ph || 0));
      w.style.transform = 'translateY(' + (b - Math.abs(o.bob == null ? 12 : o.bob)).toFixed(2) + 'px) rotate(' + ((o.rot || 1.2) * Math.sin((o.k || 2) * th + (o.ph || 0) + 1.2)).toFixed(3) + 'deg)';
      if (sh) { var f = 1 - (b + Math.abs(o.bob || 12)) / (4 * Math.abs(o.bob || 12) + 1); sh.style.transform = 'scaleX(' + (.85 + .15 * f).toFixed(3) + ')'; sh.style.opacity = (.55 + .45 * f).toFixed(3); }
    };
    return api;
  };

  /* ---------- float (bob) ---------- */
  HB.float = function (e, o) {
    o = o || {};
    return function (t) { var th = HB.th(t); e.style.transform = (o.base || '') + ' translateY(' + ((o.a || 10) * Math.sin((o.k || 2) * th + (o.ph || 0))).toFixed(2) + 'px) rotate(' + ((o.rot || 0) * Math.sin((o.k || 2) * th + (o.ph || 0) + 1)).toFixed(3) + 'deg)'; };
  };
})();
