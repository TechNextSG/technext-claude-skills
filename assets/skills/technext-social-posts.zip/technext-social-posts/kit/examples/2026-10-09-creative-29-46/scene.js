/* scene.js - LIVING BACKGROUNDS + REACTIONS for the 2026-10-09 TechNext posts (owner: "make it alive, dynamic background",
   "Nexi in dynamic posing and reaction"). Needs kit.js + hero.js. Everything is periodic in th = 2*PI*t/LOOP (integer
   multiples) or frac(t/LOOP*k) with integer k, so reels loop seamlessly.

   var sc = HB.scene(post, { seed, z: 4 (back canvas), fz: 37 (front canvas), avoid: [[x0,y0,x1,y1]], layers: [...] });
   sc.render(t)  (call every frame)        - layer {type, fg: true -> drawn on the front canvas, ...options}
   Types: blobs, rays, rings, bokeh, sparkle, confetti, float (icons/images), clouds, waves, streaks, leaves, bubbles,
          birds, stars, shapes (heart|plus|check|coin|pill|note|bolt|pin|dot), shaft (light beam + motes), gears,
          plane (TechNext paper plane with dashed trail), burst (comic action lines), speed (motion lines),
          hearts (rising from a point), exclaim ("!" pop), pop (sparkle pop at a time) */
(function () {
  var TAU = Math.PI * 2, HB = window.HB;
  HB._pending = HB._pending || [];
  function L() { return window.LOOP || 8; }
  function rgba(c, a) {               // '#RRGGBB' or 'r,g,b' -> rgba string
    if (c[0] === '#') { var n = parseInt(c.slice(1), 16); c = (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255); }
    return 'rgba(' + c + ',' + Math.max(0, Math.min(1, a)).toFixed(3) + ')';
  }
  var SHAPES = {
    heart: function (g, s) { g.beginPath(); g.moveTo(0, s * .35); g.bezierCurveTo(-s * .9, -s * .25, -s * .45, -s * .95, 0, -s * .45); g.bezierCurveTo(s * .45, -s * .95, s * .9, -s * .25, 0, s * .35); g.fill(); },
    plus: function (g, s) { var w = s * .32; g.fillRect(-w / 2, -s / 2, w, s); g.fillRect(-s / 2, -w / 2, s, w); },
    check: function (g, s, c) { g.beginPath(); g.arc(0, 0, s / 2, 0, TAU); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = s * .13; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); g.moveTo(-s * .22, 0); g.lineTo(-s * .05, s * .17); g.lineTo(s * .24, -s * .16); g.stroke(); },
    coin: function (g, s) { g.beginPath(); g.arc(0, 0, s / 2, 0, TAU); g.fill(); g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.arc(-s * .12, -s * .12, s * .16, 0, TAU); g.fill(); g.strokeStyle = 'rgba(150,100,0,.55)'; g.lineWidth = s * .07; g.beginPath(); g.arc(0, 0, s * .34, 0, TAU); g.stroke(); },
    pill: function (g, s, c) { var w = s, h = s * .42; g.beginPath(); g.roundRect(-w / 2, -h / 2, w, h, h / 2); g.fill(); g.fillStyle = 'rgba(255,255,255,.9)'; g.beginPath(); g.roundRect(0, -h / 2, w / 2, h, [0, h / 2, h / 2, 0]); g.fill(); },
    note: function (g, s) { g.beginPath(); g.ellipse(-s * .18, s * .28, s * .2, s * .15, -.4, 0, TAU); g.fill(); g.fillRect(-s * .02, -s * .45, s * .08, s * .74); g.beginPath(); g.moveTo(s * .06, -s * .45); g.quadraticCurveTo(s * .4, -s * .3, s * .3, -s * .05); g.lineTo(s * .06, -s * .2); g.fill(); },
    bolt: function (g, s) { var r = s / 2; g.beginPath(); for (var i = 0; i < 6; i++) { var a = i * TAU / 6; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.fill(); g.fillStyle = 'rgba(255,255,255,.75)'; g.beginPath(); g.arc(0, 0, r * .42, 0, TAU); g.fill(); },
    pin: function (g, s) { g.beginPath(); g.arc(0, -s * .15, s * .32, Math.PI, 0); g.quadraticCurveTo(s * .32, s * .12, 0, s * .5); g.quadraticCurveTo(-s * .32, s * .12, -s * .32, -s * .15); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(0, -s * .15, s * .12, 0, TAU); g.fill(); },
    dot: function (g, s) { g.beginPath(); g.arc(0, 0, s / 2, 0, TAU); g.fill(); },
    leaf: function (g, s) { g.beginPath(); g.moveTo(-s / 2, 0); g.quadraticCurveTo(0, -s * .38, s / 2, 0); g.quadraticCurveTo(0, s * .38, -s / 2, 0); g.fill(); g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(-s * .45, 0); g.lineTo(s * .45, 0); g.stroke(); },
    star4: function (g, s) { g.beginPath(); for (var i = 0; i < 8; i++) { var r = i % 2 ? s * .14 : s / 2, a = i * Math.PI / 4 - Math.PI / 2; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.fill(); },
    box: function (g, s) { g.fillRect(-s / 2, -s * .38, s, s * .76); g.fillStyle = 'rgba(255,255,255,.55)'; g.fillRect(-s * .08, -s * .38, s * .16, s * .76); },
    balloon: function (g, s) { g.beginPath(); g.moveTo(0, -s * .55); g.bezierCurveTo(s * .55, -s * .55, s * .5, s * .05, s * .1, s * .3); g.lineTo(-s * .1, s * .3); g.bezierCurveTo(-s * .5, s * .05, -s * .55, -s * .55, 0, -s * .55); g.fill();
      g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(-s * .14, -s * .25, s * .08, s * .18, -.3, 0, TAU); g.fill(); g.strokeStyle = 'rgba(90,70,50,.6)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(-s * .08, s * .3); g.lineTo(-s * .06, s * .48); g.moveTo(s * .08, s * .3); g.lineTo(s * .06, s * .48); g.stroke(); g.fillStyle = '#A8743F'; g.fillRect(-s * .09, s * .48, s * .18, s * .12); },
    paper: function (g, s) { g.fillRect(-s * .38, -s / 2, s * .76, s); g.fillStyle = 'rgba(150,170,200,.45)'; for (var i = 0; i < 5; i++) g.fillRect(-s * .28, -s * .32 + i * s * .14, s * (i % 2 ? .4 : .56), s * .05); },
    chili: function (g, s) { g.beginPath(); g.moveTo(-s * .45, -s * .1); g.quadraticCurveTo(-s * .1, -s * .3, s * .42, s * .1); g.quadraticCurveTo(s * .1, s * .02, -s * .45, s * .08); g.closePath(); g.fill(); g.fillStyle = '#3E9B4F'; g.beginPath(); g.ellipse(-s * .46, -s * .01, s * .08, s * .1, 0, 0, TAU); g.fill(); },
    bubble: function (g, s) { g.beginPath(); g.roundRect(-s / 2, -s * .34, s, s * .6, s * .18); g.fill(); g.beginPath(); g.moveTo(-s * .2, s * .24); g.lineTo(-s * .34, s * .44); g.lineTo(-s * .02, s * .26); g.fill(); g.fillStyle = 'rgba(255,255,255,.85)'; [-.22, 0, .22].forEach(function (x) { g.beginPath(); g.arc(x * s, -s * .04, s * .06, 0, TAU); g.fill(); }); }
  };
  HB.SHAPES = SHAPES;

  HB.scene = function (post, o) {
    var dpr = window.devicePixelRatio || 1, W = TN.W, H = TN.H, R = TN.rand(o.seed || 5);
    function mk(z) { var c = HB.el('canvas', '', post); c.style.cssText = 'position:absolute;left:0;top:0;width:1080px;height:100%;pointer-events:none;z-index:' + z; c.width = W * dpr; c.height = H * dpr; return c.getContext('2d'); }
    var gb = mk(o.z == null ? 4 : o.z), gf = null, avoid = o.avoid || [];
    function av(x, y) { for (var i = 0; i < avoid.length; i++) { var z = avoid[i]; if (x > z[0] && x < z[2] && y > z[1] && y < z[3]) return o.avoidA == null ? .18 : o.avoidA; } return 1; }
    function rr(a) { return a[0] + R() * (a[1] - a[0]); }
    var imgs = {}, waits = [];
    function img(src) { if (!imgs[src]) { var im = new Image(); im.src = src; imgs[src] = im; waits.push(im.decode ? im.decode().catch(function () {}) : 0); } return imgs[src]; }
    var LY = (o.layers || []).map(function (ly) {
      ly = Object.assign({}, ly);
      if (ly.fg && !gf) gf = mk(o.fz || 37);
      var area = ly.area || [0, 0, W, H], n = ly.n || 20, P = [];
      for (var i = 0; i < n; i++) P.push({ x: rr([area[0], area[2]]), y: rr([area[1], area[3]]), s: rr(ly.size || [6, 14]), ph: R() * TAU, k: 1 + Math.floor(R() * (ly.kmax || 2)), c: (ly.cols || ['#3167CA'])[i % (ly.cols || ['#3167CA']).length], d: R(), r: R() * TAU, src: ly.icons ? ly.icons[i % ly.icons.length] : null });
      ly.P = P; ly.area = area;
      if (ly.icons) ly.icons.forEach(function (s) { img(/\//.test(s) ? s : HB.ic(s)); });
      return ly;
    });
    var ready = Promise.all(waits); HB._pending.push(ready);

    var DRAW = {
      blobs: function (g, ly, th) { g.save(); g.globalCompositeOperation = ly.blend || 'source-over'; ly.P.forEach(function (p, i) {
        var x = p.x + (ly.amp || 120) * Math.sin(th * p.k + p.ph), y = p.y + (ly.amp || 120) * .7 * Math.cos(th + p.ph * 1.3), r = p.s * (1 + .12 * Math.sin(2 * th + p.ph));
        var gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, rgba(p.c, ly.a || .5)); gr.addColorStop(1, rgba(p.c, 0)); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); }); g.restore(); },
      rays: function (g, ly, th) { var n = ly.n || 16, rot = (ly.spin || 1) * (TAU / n) * (window.TNt / L()) + (ly.rot0 || 0); g.save(); g.translate(ly.x, ly.y); g.rotate(rot);
        var len = ly.len || 900, w = (ly.w || .5) * TAU / n; for (var i = 0; i < n; i++) { var a = i * TAU / n; var gr = g.createRadialGradient(0, 0, ly.r0 || 0, 0, 0, len); gr.addColorStop(0, rgba(ly.col || '#FFFFFF', ly.a || .25)); gr.addColorStop(1, rgba(ly.col || '#FFFFFF', 0));
          g.fillStyle = gr; g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, len, a - w / 2, a + w / 2); g.closePath(); g.fill(); } g.restore(); },
      rings: function (g, ly) { for (var i = 0; i < (ly.n || 3); i++) { var f = TN.frac(window.TNt / L() * (ly.k || 1) + i / (ly.n || 3)), r = (ly.r0 || 20) + f * (ly.max || 300);
        g.strokeStyle = rgba(ly.col || '#FFFFFF', (ly.a || .5) * (1 - f)); g.lineWidth = ly.w || 3; g.beginPath(); g.ellipse(ly.x, ly.y, r, r * (ly.flat || 1), 0, 0, TAU); g.stroke(); } },
      bokeh: function (g, ly, th) { ly.P.forEach(function (p) { var x = p.x + 30 * Math.sin(th * p.k + p.ph), y = p.y + 22 * Math.cos(th + p.ph), a = (ly.a || .35) * (.55 + .45 * Math.sin(2 * th * p.k + p.ph)) * av(x, y);
        var gr = g.createRadialGradient(x, y, 0, x, y, p.s); gr.addColorStop(0, rgba(p.c, a)); gr.addColorStop(.7, rgba(p.c, a * .6)); gr.addColorStop(1, rgba(p.c, 0)); g.fillStyle = gr; g.beginPath(); g.arc(x, y, p.s, 0, TAU); g.fill(); }); },
      sparkle: function (g, ly, th) { ly.P.forEach(function (p) { var s = p.s * Math.max(0, Math.sin(2 * th * p.k + p.ph)), x = p.x, y = p.y; if (s < .5) return; g.save(); g.translate(x, y); g.rotate(p.r * .2); g.fillStyle = rgba(p.c, (ly.a || .95) * av(x, y)); SHAPES.star4(g, s * 2); g.restore(); }); },
      stars: function (g, ly, th) { ly.P.forEach(function (p) { var a = (ly.a || .8) * (.35 + .65 * Math.abs(Math.sin(th * p.k * 2 + p.ph))) * av(p.x, p.y); g.fillStyle = rgba(p.c, a); g.beginPath(); g.arc(p.x, p.y, p.s * .25, 0, TAU); g.fill(); }); },
      confetti: function (g, ly, th) { var a = ly.area, h = a[3] - a[1]; ly.P.forEach(function (p) { var f = TN.frac(window.TNt / L() * (ly.k || 1) + p.d), y = a[1] + f * h, x = p.x + 26 * Math.sin(th * 2 + p.ph), al = (f < .1 ? f / .1 : f > .85 ? (1 - f) / .15 : 1) * av(x, y);
        g.save(); g.translate(x, y); g.rotate(p.r + th * p.k * (p.d > .5 ? 1 : -1)); g.fillStyle = rgba(p.c, (ly.a || .9) * al); g.fillRect(-p.s / 2, -p.s * .3, p.s, p.s * .6 * Math.abs(Math.cos(th * 2 * p.k + p.ph)) + 1.5); g.restore(); }); },
      float: function (g, ly, th) { var a = ly.area, h = a[3] - a[1]; ly.P.forEach(function (p) { var f = TN.frac(window.TNt / L() * (ly.k || 1) + p.d), y = ly.down ? a[1] + f * h : a[3] - f * h, x = p.x + 24 * Math.sin(th + p.ph);
        var im = imgs[/\//.test(p.src) ? p.src : HB.ic(p.src)], al = (f < .12 ? f / .12 : f > .82 ? (1 - f) / .18 : 1) * (ly.a || .5) * av(x, y); if (!im || !im.complete) return;
        g.save(); g.globalAlpha = al; if (ly.blur) g.filter = 'blur(' + (ly.blur * (1 - p.d * .6)).toFixed(1) + 'px)'; g.translate(x, y); g.rotate(.3 * Math.sin(th + p.ph)); g.drawImage(im, -p.s / 2, -p.s / 2, p.s, p.s); g.restore(); }); },
      shapes: function (g, ly, th) { var a = ly.area, h = a[3] - a[1]; ly.P.forEach(function (p) { var f = ly.still ? 0 : TN.frac(window.TNt / L() * (ly.k || 1) + p.d), y = ly.still ? p.y + 14 * Math.sin(th * p.k + p.ph) : (ly.down ? a[1] + f * h : a[3] - f * h), x = p.x + (ly.sway || 26) * Math.sin(th + p.ph);
        var al = (ly.still ? 1 : (f < .12 ? f / .12 : f > .82 ? (1 - f) / .18 : 1)) * (ly.a || .7) * av(x, y); g.save(); g.translate(x, y); g.rotate((ly.spin == null ? .4 : ly.spin) * Math.sin(th * p.k + p.ph)); if (ly.blur) g.filter = 'blur(' + ly.blur + 'px)';
        g.fillStyle = rgba(p.c, al); SHAPES[ly.shape](g, p.s, p.c); g.restore(); }); },
      clouds: function (g, ly) { var a = ly.area, span = a[2] - a[0] + 500; ly.P.forEach(function (p) { var x = a[0] - 250 + TN.frac(window.TNt / L() * (ly.k || 1) * (ly.dir || 1) + p.d) * span, y = p.y, s = p.s / 60;
        g.fillStyle = rgba(ly.col || '#FFFFFF', (ly.a || .85)); [[0, 0, 44], [46, -16, 36], [86, 4, 30], [-40, 6, 30], [30, 14, 40]].forEach(function (b) { g.beginPath(); g.arc(x + b[0] * s, y + b[1] * s, b[2] * s, 0, TAU); g.fill(); }); }); },
      waves: function (g, ly, th) { for (var i = 0; i < (ly.n || 3); i++) { var y0 = ly.y + i * (ly.gap || 26); g.strokeStyle = rgba(ly.col || '#FFFFFF', (ly.a || .4) * (1 - i * .18)); g.lineWidth = ly.w || 3; g.beginPath();
        for (var x = (ly.x0 || 0); x <= (ly.x1 || W); x += 8) { var y = y0 + (ly.amp || 10) * Math.sin(x / (ly.len || 90) + th * (ly.k || 1) + i * 1.3); x === (ly.x0 || 0) ? g.moveTo(x, y) : g.lineTo(x, y); } g.stroke(); } },
      streaks: function (g, ly) { var a = ly.area, ang = (ly.ang || 0) * Math.PI / 180, span = a[2] - a[0] + (ly.len || 160) * 2; ly.P.forEach(function (p) { var f = TN.frac(window.TNt / L() * (ly.k || 2) + p.d), x = a[0] - (ly.len || 160) + f * span, y = p.y;
        g.save(); g.translate(x, y); g.rotate(ang); var gr = g.createLinearGradient(-(ly.len || 160), 0, 0, 0); gr.addColorStop(0, rgba(p.c, 0)); gr.addColorStop(1, rgba(p.c, (ly.a || .6) * av(x, y))); g.strokeStyle = gr; g.lineWidth = ly.w || 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(-(ly.len || 160), 0); g.lineTo(0, 0); g.stroke(); g.restore(); }); },
      leaves: function (g, ly, th) { ly.shape = 'leaf'; ly.down = true; ly.spin = 1.2; DRAW.shapes(g, ly, th); },
      bubbles: function (g, ly, th) { var a = ly.area, h = a[3] - a[1]; ly.P.forEach(function (p) { var f = TN.frac(window.TNt / L() * (ly.k || 1) + p.d), y = a[3] - f * h, x = p.x + 18 * Math.sin(th * 2 + p.ph), al = (f > .85 ? (1 - f) / .15 : Math.min(1, f / .1)) * (ly.a || .7) * av(x, y);
        g.strokeStyle = rgba(ly.col || '#FFFFFF', al); g.lineWidth = 2.5; g.fillStyle = rgba(ly.col || '#FFFFFF', al * .18); g.beginPath(); g.arc(x, y, p.s, 0, TAU); g.fill(); g.stroke(); g.fillStyle = rgba('#FFFFFF', al * .8); g.beginPath(); g.arc(x - p.s * .35, y - p.s * .35, p.s * .22, 0, TAU); g.fill(); }); },
      birds: function (g, ly, th) { var a = ly.area, span = a[2] - a[0] + 200; ly.P.forEach(function (p) { var fb = TN.frac(window.TNt / L() * (ly.k || 1) + p.d), x = ly.dir === -1 ? a[2] + 100 - fb * span : a[0] - 100 + fb * span, y = p.y + 14 * Math.sin(th * 2 + p.ph), fl = Math.sin(th * 8 * p.k + p.ph) * p.s * .45;
        g.strokeStyle = rgba(ly.col || '#2B2B40', (ly.a || .7) * av(x, y)); g.lineWidth = 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(x - p.s, y - fl); g.quadraticCurveTo(x - p.s * .4, y - p.s * .2, x, y); g.quadraticCurveTo(x + p.s * .4, y - p.s * .2, x + p.s, y - fl); g.stroke(); }); },
      shaft: function (g, ly, th) { g.save(); g.translate(ly.x, ly.y); g.rotate((ly.ang || 20) * Math.PI / 180); var gr = g.createLinearGradient(-(ly.w || 260) / 2, 0, (ly.w || 260) / 2, 0); gr.addColorStop(0, rgba(ly.col || '#FFFFFF', 0)); gr.addColorStop(.5, rgba(ly.col || '#FFFFFF', (ly.a || .35) * (.8 + .2 * Math.sin(2 * th)))); gr.addColorStop(1, rgba(ly.col || '#FFFFFF', 0));
        g.fillStyle = gr; g.fillRect(-(ly.w || 260) / 2, 0, ly.w || 260, ly.len || 1400); ly.P.forEach(function (p) { var my = TN.frac(window.TNt / L() + p.d) * (ly.len || 1400), mx = (p.x / W - .5) * (ly.w || 260) * .8 + 10 * Math.sin(th * p.k + p.ph); g.fillStyle = rgba('#FFFFFF', .75 * Math.sin(Math.PI * my / (ly.len || 1400))); g.beginPath(); g.arc(mx, my, p.s * .2, 0, TAU); g.fill(); }); g.restore(); },
      gears: function (g, ly) { (ly.list || []).forEach(function (q, i) { g.save(); g.translate(q[0], q[1]); g.rotate((q[4] || 1) * (i % 2 ? -1 : 1) * TAU / (q[3] || 10) * (window.TNt / L())); g.strokeStyle = rgba(ly.col || '#FFFFFF', ly.a || .3); g.lineWidth = ly.w || 3; g.beginPath();
        var n = q[3] || 10, R1 = q[2], r1 = R1 * .82; for (var k = 0; k < n; k++) { var a0 = k * TAU / n, st = TAU / n; [[r1, a0], [r1, a0 + st * .2], [R1, a0 + st * .3], [R1, a0 + st * .6], [r1, a0 + st * .7]].forEach(function (pp, j) { var X = pp[0] * Math.cos(pp[1]), Y = pp[0] * Math.sin(pp[1]); (k === 0 && j === 0) ? g.moveTo(X, Y) : g.lineTo(X, Y); }); }
        g.closePath(); g.stroke(); g.beginPath(); g.arc(0, 0, R1 * .3, 0, TAU); g.stroke(); g.restore(); }); },
      plane: function (g, ly) { var f = TN.frac(window.TNt / L() * (ly.k || 1) + (ly.ph || 0)), x0 = ly.from[0], y0 = ly.from[1], x1 = ly.to[0], y1 = ly.to[1], bend = ly.bend || -120;
        function pt(u) { var mx = (x0 + x1) / 2, my = (y0 + y1) / 2 + bend; return [(1 - u) * (1 - u) * x0 + 2 * (1 - u) * u * mx + u * u * x1, (1 - u) * (1 - u) * y0 + 2 * (1 - u) * u * my + u * u * y1]; }
        var al = f < .08 ? f / .08 : f > .9 ? (1 - f) / .1 : 1; g.strokeStyle = rgba(ly.col || '#3167CA', .5 * al); g.lineWidth = 3; g.setLineDash([2, 12]); g.lineCap = 'round'; g.beginPath(); for (var u = Math.max(0, f - .35); u <= f; u += .01) { var q = pt(u); u === Math.max(0, f - .35) ? g.moveTo(q[0], q[1]) : g.lineTo(q[0], q[1]); } g.stroke(); g.setLineDash([]);
        var p = pt(f), p2 = pt(Math.min(1, f + .01)), ang = Math.atan2(p2[1] - p[1], p2[0] - p[0]), s = ly.s || 30; g.save(); g.translate(p[0], p[1]); g.rotate(ang); g.globalAlpha = al;
        g.fillStyle = ly.fill || '#3167CA'; g.beginPath(); g.moveTo(s, 0); g.lineTo(-s * .8, -s * .55); g.lineTo(-s * .35, 0); g.lineTo(-s * .8, s * .55); g.closePath(); g.fill(); g.fillStyle = 'rgba(0,0,0,.18)'; g.beginPath(); g.moveTo(s, 0); g.lineTo(-s * .35, 0); g.lineTo(-s * .8, s * .55); g.closePath(); g.fill(); g.restore(); },
      burst: function (g, ly) { var n = ly.n || 14, f = ly.at == null ? TN.frac(window.TNt / L() * (ly.k || 2)) : TN.seg(window.TNt, ly.at, ly.at + (ly.dur || .6)), e = TN.eo(f), al = Math.sin(Math.PI * f);
        if (al <= 0) return; g.save(); g.translate(ly.x, ly.y); g.strokeStyle = rgba(ly.col || '#FFC93C', (ly.a || .95) * al); g.lineWidth = ly.w || 6; g.lineCap = 'round';
        for (var i = 0; i < n; i++) { var a = i * TAU / n + (i % 2) * .12, r0 = (ly.r0 || 60) + e * 40, r1 = r0 + (ly.len || 46) * (i % 2 ? .6 : 1) * (1 - e * .4); g.beginPath(); g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0 * (ly.flat || 1)); g.lineTo(Math.cos(a) * r1, Math.sin(a) * r1 * (ly.flat || 1)); g.stroke(); } g.restore(); },
      speed: function (g, ly, th) { g.save(); g.translate(ly.x, ly.y); g.rotate((ly.ang || 0) * Math.PI / 180); for (var i = 0; i < (ly.n || 5); i++) { var y = (i - (ly.n || 5) / 2) * (ly.gap || 22), f = TN.frac(window.TNt / L() * (ly.k || 4) + i * .37), x = -f * (ly.len || 120), l = (ly.len || 120) * (.4 + .6 * Math.sin(Math.PI * f));
        g.strokeStyle = rgba(ly.col || '#FFFFFF', (ly.a || .8) * Math.sin(Math.PI * f)); g.lineWidth = ly.w || 5; g.lineCap = 'round'; g.beginPath(); g.moveTo(x, y); g.lineTo(x - l, y); g.stroke(); } g.restore(); },
      hearts: function (g, ly, th) { for (var i = 0; i < (ly.n || 5); i++) { var f = TN.frac(window.TNt / L() * (ly.k || 2) + i / (ly.n || 5)), x = ly.x + (ly.spread || 60) * Math.sin(th * 2 + i * 2.1) * f, y = ly.y - f * (ly.rise || 220), s = (ly.s || 30) * (.6 + .6 * Math.sin(Math.PI * Math.min(1, f * 1.4)));
        g.save(); g.translate(x, y); g.rotate(.3 * Math.sin(th * 2 + i)); g.fillStyle = rgba(ly.col || '#F0537A', Math.sin(Math.PI * f)); SHAPES[ly.shape || 'heart'](g, s); g.restore(); } },
      exclaim: function (g, ly) { var f = ly.at == null ? TN.frac(window.TNt / L() * (ly.k || 1)) : TN.seg(window.TNt, ly.at, ly.at + 1.6), p = TN.back(TN.cl(f * 4, 0, 1)), al = f < .85 ? 1 : (1 - f) / .15; if (f <= 0 || f >= 1) return;
        g.save(); g.translate(ly.x, ly.y); g.rotate((ly.rot || 12) * Math.PI / 180); g.scale(p, p); g.globalAlpha = al; g.fillStyle = ly.bg || '#FFC93C'; g.strokeStyle = '#1F1F3D'; g.lineWidth = 5; g.beginPath(); g.arc(0, 0, ly.s || 38, 0, TAU); g.fill(); g.stroke();
        g.fillStyle = '#1F1F3D'; g.font = '800 ' + Math.round((ly.s || 38) * 1.35) + 'px "Plus Jakarta Sans"'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(ly.text || '!', 0, 3); g.restore(); },
      pop: function (g, ly) { var f = TN.seg(window.TNt, ly.at, ly.at + .9); if (f <= 0 || f >= 1) return; for (var i = 0; i < (ly.n || 8); i++) { var a = i * TAU / (ly.n || 8), r = (ly.r || 70) * TN.eo(f); g.save(); g.translate(ly.x + Math.cos(a) * r, ly.y + Math.sin(a) * r); g.fillStyle = rgba((ly.cols || ['#FFC93C'])[i % (ly.cols || ['#FFC93C']).length], 1 - f); SHAPES.star4(g, (ly.s || 22) * (1 - f * .5)); g.restore(); } }
    };
    return {
      ready: ready,
      render: function (t) {
        window.TNt = t; var th = TAU * t / L();
        [gb, gf].forEach(function (g) { if (!g) return; g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H); });
        LY.forEach(function (ly) { var g = ly.fg ? gf : gb; g.save(); if (ly.layerBlur) g.filter = 'blur(' + ly.layerBlur + 'px)'; DRAW[ly.type](g, ly, th); g.restore(); });
      }
    };
  };

  /* Nexi motion: act = bounce (squash/stretch hop) | sway | float | pop (sync to a beat) | lean */
  HB.act = function (nx, o) {
    var e = nx.img, flip = /scaleX\(-1\)/.test(e.style.transform) ? ' scaleX(-1)' : ''; e.style.transformOrigin = '50% 100%';
    return function (t) {
      var th = TAU * t / L(), k = o.k || 2, tr = '';
      if (o.act === 'bounce') { var s = Math.abs(Math.sin(k * th / 2 + (o.ph || 0))), sq = Math.pow(1 - s, 6); tr = 'translateY(' + (-(o.h || 60) * s).toFixed(1) + 'px) scale(' + (1 + .07 * sq).toFixed(3) + ',' + (1 - .08 * sq + .03 * s).toFixed(3) + ') rotate(' + ((o.rot || 4) * Math.sin(k * th / 2 + 1)).toFixed(2) + 'deg)'; }
      else if (o.act === 'sway') tr = 'rotate(' + ((o.rot || 6) * Math.sin(k * th / 2 + (o.ph || 0))).toFixed(2) + 'deg) translateY(' + (-(o.h || 8) * Math.abs(Math.sin(k * th / 2))).toFixed(1) + 'px)';
      else if (o.act === 'float') tr = 'translateY(' + ((o.h || 18) * Math.sin(th * (o.k || 1) + (o.ph || 0))).toFixed(1) + 'px) rotate(' + ((o.rot || 3) * Math.sin(th + 1)).toFixed(2) + 'deg)';
      else if (o.act === 'pop') { var f = TN.seg(t, o.at || 1.4, (o.at || 1.4) + .5), b = Math.sin(Math.PI * f); tr = 'translateY(' + (-(o.h || 40) * b).toFixed(1) + 'px) scale(' + (1 + .08 * b).toFixed(3) + ',' + (1 + .12 * b).toFixed(3) + ') rotate(' + ((o.rot || -6) * b + 2 * Math.sin(th)).toFixed(2) + 'deg)'; }
      else if (o.act === 'lean') tr = 'rotate(' + ((o.rot || 10) * (.6 + .4 * Math.sin(k * th / 2))).toFixed(2) + 'deg) translateX(' + (10 * Math.sin(k * th / 2)).toFixed(1) + 'px)';
      e.style.transform = tr + flip;
    };
  };
})();
