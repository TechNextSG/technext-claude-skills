Worked examples (reference only). Files dated before 2026-10-07 are 4:5: render them with --fmt 45 (legacy); new
posts are 3:4 images + 9:16 reels only. Each file links kit.css/kit.js/assets relative to a work folder, so to render one,
copy it into a work folder set up from kit/ (see SKILL.md step 3). Search a post by its class (.p12, .p13 ...).
- 2026-10-06-posts-01-05-clean.html   site-style cards (owner later called this flat: technique reference only)
- 2026-10-06-posts-06-08-depth.html   isometric conveyor, exploded glass stack, 3D studio with Nexi
- 2026-10-06-posts-09-11-motion.html  window.R(t) motion: burst, chaos->device, receipt ribbon (MP4 loops)
- 2026-10-06-posts-12-14-industries.html  blueprint (construction), globe + stamps (travel), hologram (clinics) - uses kit.js
- 2026-10-06-posts-15-17-playful.html  light + playful: Nexi coaster (sky, confetti), giant 3D zero, gumball machine - uses kit.js
Note: post 14 (hologram) in the industries file was REJECTED by the owner - technique reference only.
- 2026-10-07-posts-18-20-camera.html  exaggerated cameras: worm's-eye Nexi (nexi-cam render), drone city, dutch-angle dominoes - uses cam.js
- 2026-10-07-posts-21-25-five-cameras.html  top-down kitchen, fisheye Nexi + tiny planet, macro card, tilt-shift office, over-the-shoulder Nexi
- 2026-10-07-posts-21-25-v2-nexi-world.html  HOUSE TEMPLATE (= kit/template-nexi-world.html): Nexi video world, needs qtworld.js + assets/nexi/costumes
- 2026-10-07-posts-21-25-v3-cinematic/  DEFAULT LOOK: p21 three.js bullet time, p22 lighthouse, p23 WebGL pool shader, p24 3D paper planes, p25 split-flap board (one HTML per post; need kit/three.min.js for p21, assets/nexi/costumes for p22/p25)
- 2026-10-07-posts-26-28-angles/  p26 three.js aisle + dolly zoom (Nexi billboard in-scene), p27 inside-out air-con (canvas), p28 tabletop ant's-eye (canvas + CSS 3D phone); all format-aware
