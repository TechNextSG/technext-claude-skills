# Brief: Nexi introductions + Odoo/TechNext collection (posts 87-122), 2026-10-10

Lead: the main session. Builders: one helper per group, each in its OWN work folder with its OWN ports.
You build, audit and render your posts; the lead reviews, delivers to the Drive and writes captions. **Never deliver,
post or schedule anything. Never edit files outside your work folder** (the kits in ~/.claude/skills are read-only for you;
read any example page you like).

## What the owner asked (verbatim)
"create 3 images for nexi introduction about showcasing odoo and technext. use https://technext.asia/nexi-explains skills
for designing the content, comical but follow the website page theme nexi explain. also 3 design for nexi introduction
focus on technext branding. use technext website branding skills. then create 30 random collective content that connected
to odoo and technext. do random design skills (dont do comical design) use design of our previous content in this session.
make sure the design are related to the content, much detailed properly audited/designed. dont do half baked design and
background. make sure related to the content. create alot of variation."

Standing owner rules that still apply (from earlier batches; never drop one):
- Images only: ONE 3:4 PNG per post, 2160x2880 (render.py default `--fmt 34`). **No reels, no video** this time.
- **Living, layered, detailed backgrounds** - never a flat fill. Brand colours go INTO the living background.
- **Detailed scenes**: 8-15 small story-true props per scene, textures laid over shapes, soft contact shadows, shading.
  A big flat shape with nothing on it is unfinished. "dont do half baked design and background."
- **Nexi** (TechNext's 3D robot; "she" in the series) in an ACTION pose with a reaction, placed in her own free zone,
  fully visible (whole body, never cut by the frame/a card/a gradient band, nothing stacked on her), wherever a layout has space.
- **Logo row fixed** on every non-comic post: TechNext logo top-left, plain Odoo wordmark top-right (white on dark).
- **Short social copy**: a 2-line headline (5-8 words, line 2 highlighted) + ONE short Inter sub-line (<= 2 lines, key
  phrase in `<b>`). Labels in the scene are short too. No paragraphs.
- **Readable sizes**: labels >= 15 px, anything meant to be read >= 18 px (at 1080 wide), toasts 24/18 px. audit.py errors
  under 12 px and warns under 15 px - treat its <15 px warnings as errors for real labels.
- **Facts**: TechNext = Odoo Ready Partner (exact wording; never certified/gold), Singapore HQ, Taguig City (PH, main
  development and consulting hub), Ho Chi Minh City (VN, AI engineering hub), clients in 10+ countries, 11+ enterprise
  clients; four practices ERP, AI Solution, Marketing, Technology. **Never mention Cyber Security. Never write "free".**
  Every invented name/number/document is labelled "sample" ON the image. Numbers add up; SG GST is 9%. No other brands'
  logos (no Excel/WhatsApp/Google logos; generic shapes only). Official Odoo app icons from `assets/odoo/*.svg` only - never
  redraw or recolour them. Odoo facts below come from technext.asia blog articles (2026-09-27) - do not add claims.
- **Every poster unique**: its own concept, camera, light, palette, headline placement/treatment and label style; different
  from every other post in this job AND from posts 01-86 (see the contact sheets below).
- AI copy: "the AI prepares, a person approves."

## Look at these first (5 minutes, it sets the bar)
- Everything made so far: `C:/Users/leuss/ClaudeWork/qa/ref/all-sheet-0.jpg`, `all-sheet-1.jpg`, `all-sheet-2.jpg`
  (posts 01-86). Full-size PNGs: `G:/Shared drives/Marketing/02. TechNext Folder/02. TechNext Social Media Posting Image/00. All Images (2026-10-09 to 10-10)/`
  (read-only). Finish quality to match or beat: 57-66 (detailed metaphor scenes), 67-76 and 77-86 (crisp Odoo UI on living
  backgrounds), 29-36 (creative/typographic/map posts).
- Comic group only: `C:/Users/leuss/ClaudeWork/qa/ref/s2-pagestyle-sheet.jpg` and `s1-sheet.jpg` (the approved Nexi Explains
  v4 posters).

## Engine (non-comic groups) - the page contract you already have in your folder
- `kit.css`/`kit.js` (TN.boot, TN.pick, TN.seg/eo/eio/back/cl/frac/rand), `hero.css`/`hero.js` (HB.bg, HB.fx icons/shapes/toasts,
  HB.nexi, HB.float, HB.th), `scene.js` (HB.scene layers: rays, rings, bokeh, sparkle, plane, shapes, clouds, waves, birds,
  bubbles, leaves, confetti, gears, light shaft + motes...; HB.act Nexi motion: bounce, sway, float, pop, lean), `detail.js`
  (DT.defs, DT.over textures, dt-gv/gh/gr shading, dt-sh shadows, DT props: tree palm bush tufts flowers cloud city lamp fence
  gear carton star5 shell potplant screw gloss, DT.t text), `odoo-ui.css`/`odoo-ui.js` (OU.nav, OU.cp, OU.col, OU.card, OU.av,
  OU.cursor, OU.spark, OU.bars, OU.ic, `.ou` windows, `.ou-toast`, `.ou-smp` sample mark, `.dev-lap/.dev-ph/.dev-tab` devices),
  `brand.css`/`brand.js` (BR.skin(post, dark, seed) living TechNext skins + BR.layers(dark)).
- `tools/make.py` builds `pNN.html` from `tools/src/pNN.txt` (sections @meta @title @l1 @l2 @sub @cta @site @css @body @js) with
  the fixed brand frame (logo row, `.hw` headline + `.sub`, `.foot` CTA button + technext.asia). Example specs (copy their
  shape): `C:/Users/leuss/ClaudeWork/social-2026-10-10-brand-ui/tools/src/p77.txt ... p86.txt`. Hand-built pages are fine too
  (examples: `C:/Users/leuss/ClaudeWork/social-2026-10-09-odoo-services/p57.html ... p66.html`,
  `C:/Users/leuss/ClaudeWork/social-2026-10-09-odoo-ui/p67.html ... p76.html`, `C:/Users/leuss/ClaudeWork/social-2026-10-09-hero/p29.html ... p46.html`).
  You may move/realign the `.hw` headline per post via @css (top-left, centred, lower third, right) - the logo row and
  the footer stay where they are. You may skip BR.skin and paint a themed living background (HB.bg + HB.scene layers +
  DT textures) when the concept has its own world; otherwise use BR.skin light or dark.
- Skill docs: `C:/Users/leuss/.claude/skills/technext-social-posts/SKILL.md` and `reference/` (lessons.md is a must-read:
  every mistake already made), `reference/engine.md`, `reference/brand.md`.
- Nexi poses: render new ones with nexi-cam (unique names, YOUR ports):
  `NEXICAM_PORT=<yours> NEXICAM_CDP=<yours> python C:/Users/leuss/.claude/skills/technext-social-posts/kit/nexi-cam/nexi_cam.py <name> '{"hold":"jump","face":"star","wear":"pilot","yaw":0.3,"cam":{"pos":[0,-3,24],"look":[0,0,0],"fov":32}}'`
  -> `kit/nexi-cam/out/nexi-<name>.png`; copy it to your `assets/nexi-hd/nexi-<name>.png` and use `HB.nexi(post,{pose:'<name>',...})`.
  Holds: idle hi present point pointL celebrate gasp think cute clap knock kiss shrug jump reach hero heroL. Faces: idle happy
  star content wow love dizzy. Wear: hardhat conductor pilot glasses strawhat beret chef cap knight bowtie goggles bellhop
  beanie tophat boppers helmet astro (look at the sheet first:
  `C:/Users/leuss/.claude/skills/technext-social-posts/kit/assets/nexi/costumes/_wear_sheet.jpg`). Name poses `n<post>` e.g. `n93` so nobody collides. Look at each render before using it.

## Engine (comic group A1) - see the A1 section.

## Commands (run from YOUR work folder; use YOUR ports everywhere)
- Build from spec: `python tools/make.py 93 94` (or hand-write `p93.html`).
- Look: `python C:/Users/leuss/.claude/skills/technext-social-posts/scripts/dbg.py p93.html 93 --t 3 --port <dbg> --shot qa/93.png`
  then Read the PNG (it is 1080x1440 or 2160x2880; also make a 540 px copy with PIL to judge phone size).
- Audit (blocking): `python C:/Users/leuss/.claude/skills/technext-social-posts/scripts/audit.py p93.html p94.html --f 34 --port <audit>`
  -> must print 0 errors for every post; read `qa/audit/report.md` + the boxed screenshots; fix real warnings too.
- Render: `python C:/Users/leuss/.claude/skills/technext-social-posts/scripts/render.py p93.html --posts 93 --port <render>`
  -> `out/93-technext-<slug>.png` and must end ALL CLEAN. Never `--force`. Render posts one after another.
- Preview name for the lead: copy each final to `preview/NN-technext-<slug>.png` too (same name as out/).
- Write files with the Write/Edit tools, not Bash heredocs (Bash halves backslashes).
- If you stop a command mid-render, kill the orphan headless Chrome on that port before re-running.
- Script gotchas: never `// comment` at the end of a JS line you splice (comments on their own line); never name a global
  `top`/`name`/`status`; prefix one-off CSS classes per post (e.g. `.p93-feed`) - hero.css/kit.css own `.hd .pl .grid .pg .h
  .pn .ci .chip .sub .pm .card .tag` and more; grep before inventing a class: `grep -o "\.myclass[ {:.,]" hero.css kit.css brand.css odoo-ui.css`.

## Slugs and numbering
File = `NN-technext-<topic>-<concept>.png` from the slug in TN.boot / @meta (e.g. `odoo-20-ai-agents-pdf-to-bill`).
Posts are numbered 87-122 exactly as listed below.

## Definition of done (per post) - the lead will reject anything short of it
1. The concept below is visible at a glance: someone sees the topic without reading the caption.
2. Background is alive and themed: base gradient/skin + 3-5 scene layers that fit the metaphor + texture + depth FX.
3. Detail pass done: 8-15 props, textures, shading, contact shadows, small labels where they help; no empty flat areas.
4. Headline readable in one second at phone size; sub-line Inter, short; nothing collides; balanced vertical budget (the visual
   is not crammed into the bottom; no dead band in the middle). Text never on top of busy art without a plate.
5. Nexi whole, in an action pose that fits the story, in her own zone, nothing stacked on her.
6. audit.py 0 errors (and the real warnings fixed); render.py ALL CLEAN; you looked at the final PNG at full size AND at
   540 px wide and fixed what looked off (alignment, crowding, cramped text, odd crops).
7. "sample" marks on invented data; official Odoo icons; facts exactly as in the brief.

## Report back (max 15 lines)
One line per post: number, slug, out PNG path, audit result, one phrase on the concept. Then anything unresolved.

---------------------------------------------------------------------------------------------------------------------------

## A1 - Nexi introduction, COMIC, Nexi Explains page theme (posts 87, 88, 89) - work folder `C:/Users/leuss/ClaudeWork/nexi-intro-2026-10-10-comic`
Ports: render 9601, dbg 9602, audit 9603, nexi-cam NEXICAM_PORT=3601 NEXICAM_CDP=9604.
Style = the approved Nexi Explains v4 posters (see s2-pagestyle-sheet.jpg / s1-sheet.jpg). Read
`C:/Users/leuss/.claude/skills/nexi-explains-posters/SKILL.md`, `reference/cinematography.md` (section 10 = the exaggerated
comic recipe), `reference/design-rules.md`, `reference/lessons.md`; page code `C:/Users/leuss/.claude/skills/nexi-explains-posters/examples/s2-v4/s2ep01v4.html`
(+ s2ep00v4, s2ep03v4, s2ep05v4) and `C:/Users/leuss/ClaudeWork/nxe-posters/s1ep00v4.html ... s1ep03v4.html` (read-only).
Kit in your folder: kit.css/js, nxe-page.css/js (NXP), nxe-x.css/js (NXX: `.xe` badge, `.boom` SFX, `.xbal` balloon +
NXX.balloon, `.xans` answer line, `.xapps` Odoo apps row, `.tag` chips, `.xft` footer, NXX.sheet/tile/glow/speed/flash/foam/
person/keystone), nxe-bg.js (NXB backgrounds - paint your OWN background per poster, each different), s2cast-f3.js (F3 cast).
Each poster: ONE exaggerated frozen moment, huge white + yellow ink-outlined title, one SFX burst, a speech balloon, the
`.xans` answer line, the `.xapps` "ODOO APPS" row with official icons + names AND at least one icon in the scene (NXX.tile),
`.tag` chips, red `.ytb` "Subscribe on YouTube" button + `technext.asia` / "All episodes: /nexi-explains" footer
(copy the `.ytb` CSS from s2ep01v4.html). No logo row (page-style exception). Comic but NOT messy: few big elements, clear
focal point, bright/warm (no night scene: S1 EP00 already owns the night city). Nexi from nexi-cam renders (whole, sticker
outline like the examples). Badge `.xe`: `NEXI EXPLAINS <b>MEET NEXI</b>` (vary the second part per poster).
Facts you may use (technext.asia/nexi-explains + /nexi): Nexi = TechNext's AI companion; "Odoo, AI and tech, made simple";
short animated episodes, one idea per episode, told as a little story; 2 seasons, 37 episodes, 34 Quick Tips, 3 holiday
specials; Season 1: 23 episodes, every episode gives Nexi a new sidekick and a new costume (23 sidekicks, 21 costumes);
EP00 "Meet Nexi" premieres **TUE 13 OCT · 6 PM SGT** on YouTube @TechNextAsia; Nexi also answers questions on
technext.asia ("Ask Nexi": about Odoo, AI or websites, from TechNext's own pages). TechNext = Odoo Ready Partner, SG HQ,
Taguig City, Ho Chi Minh City, clients in 10+ countries.

87 `nexi-explains-meet-nexi-hero-launch` - "HI, I'M NEXI!" Superhero SPLASH, daytime. Nexi (hold hero, face star, low
   worm's-eye camera) blasts UP out of a giant laptop whose screen shows the Odoo app home grid; the app tiles (CRM, Sales,
   Inventory, Accounting, Project, Website) burst out with her like fireworks with speed lines; one SFX "WHOOSH!".
   Background: bright comic sky - sunburst rays, halftone, puffy clouds, a far city skyline in the sun (NOT night).
   Title (2 lines): white "HI, I'M" + yellow "NEXI!" (huge). Balloon: "ODOO, AI & TECH, MADE SIMPLE!".
   `.xans`: "TechNext's AI companion. **New episodes on YouTube.**" Apps row: CRM, Sales, Inventory, Accounting.
   Tags: "SERIES PILOT · EP00" + red "PREMIERES TUE 13 OCT · 6 PM SGT".
88 `nexi-explains-meet-nexi-odoo-magic-show` - "SHOWING YOU ODOO!" Stage MAGIC SHOW: Nexi in a top hat (wear tophat,
   hold present or celebrate) on a theatre stage with red curtains and a spotlight, pulling a long chain of Odoo app tiles
   out of a giant top hat (Sales -> Inventory -> Accounting -> Purchase -> Project -> Website, linked like magician scarves),
   SFX "TA-DA!", a small audience of F3 cast heads in the foreground silhouettes cheering (the Bluebay Trading team, sample).
   Title: white "EVERY APP," + yellow "ONE ODOO!". Balloon: "SALES, STOCK & BOOKS, ONE DATABASE!".
   `.xans`: "Nexi explains the Odoo apps **one short episode at a time.**" Apps row: Sales, Inventory, Accounting, Project.
   Tags: "37 EPISODES · 34 QUICK TIPS" + "S1 · NOW PREMIERING".
89 `nexi-explains-meet-nexi-technext-crew` - "MEET MY CREW!" Nexi as a PILOT (wear pilot, hold jump or heroL) riding/flying
   the TechNext paper plane (the logo plane shape, big, white with blue) in a golden-hour sky over a stylised comic map of
   Southeast Asia (sea with halftone waves, islands); three big comic map pins/stickers: SINGAPORE · HQ, TAGUIG CITY · PH,
   HO CHI MINH CITY · VN, dashed flight path linking them; SFX "ZOOM!". Small TechNext people waving from the pins are
   optional (F3 cast, TechNext blue ID lanyard).
   Title: white "BUILT BY" + yellow "TECHNEXT!". Balloon: "MY TEAM SETS UP YOUR ODOO!".
   `.xans`: "**Odoo Ready Partner.** Clients in 10+ countries." Apps row: Accounting, Sales, Inventory (+ CRM).
   Tags: "SINGAPORE · PHILIPPINES · VIETNAM" + "ASK NEXI ON TECHNEXT.ASIA".

## A2 - Nexi introduction, TECHNEXT BRANDING, website craft (posts 90, 91, 92) - work folder `C:/Users/leuss/ClaudeWork/nexi-intro-2026-10-10-brand`
Ports: render 9611, dbg 9612, audit 9613, nexi-cam NEXICAM_PORT=3611 NEXICAM_CDP=9614.
"use technext website branding skills": read `C:/Users/leuss/.claude/skills/technext-site-posts/SKILL.md` (Brand fixed vs
free, poster style) and its craft file `site-brand.css` (copied into your folder) + `C:/Users/leuss/.claude/skills/technext-site-posts/examples/2026-10-08-erp-v2/p01.html ... p03.html`.
Brand fixed: Plus Jakarta Sans 800 headline, Inter body, Caveat hand notes; TechNext blue #3167CA, ink #1F1F3D, site yellow
#FFD23F (dark skin), Odoo plum #714B67 as a small accent; the website's **ink outline + hard lip** craft (3 px ink border,
5-8 px offset hard shadow) on cards, chips and stickers; headline treatments from the site (underline swash, highlight slab,
marker) - a different one per post. Frame: the social-posts brand frame (make.py: logo row top, `.hw` headline + Inter
`.sub`, `.foot` CTA + technext.asia) on a LIVING brand skin (BR.skin + BR.layers, or your own living layers in brand colours).
Nexi is the hero of all three posts, big, in action poses rendered for each post. Not comic (no SFX bursts, no Bangers).
Facts: as in A1 + /nexi page: "Meet Nexi, TechNext's AI companion. Ask about Odoo, AI or websites. Nexi answers from
TechNext's own pages and takes you to a quotation, a meeting or the team."

90 `nexi-introduction-technext-staff-id` (LIGHT skin) - "Say hi to Nexi." / "TechNext's AI companion." Concept: Nexi's
   TechNext staff ID. A big tilted ID card on a blue TechNext lanyard (ink outline + lip): photo window with Nexi's face,
   "NEXI", role "AI companion · Nexi Explains host", "Team: ERP · AI · Marketing · Technology", "Offices: SG · PH · VN",
   a barcode, the TechNext plane mark, card number "TN-0000 · sample". Nexi herself (hold hi, face happy) pops out from
   behind the card waving. Caveat hand notes with drawn arrows: "speaks fluent Odoo", "answers on technext.asia".
   Sub: "Ask about Odoo, AI or websites. **Nexi answers from our own pages.**" CTA "Ask Nexi" (technext.asia/nexi).
91 `nexi-introduction-four-practices-cards` (DARK skin: brand blue + yellow) - "Four practices." / "One guide." Concept:
   Nexi (hold present, face star) fans out four big playing-card-like service cards (ink outline + lip, slight 3D fan):
   ERP (Odoo app icons: Accounting, Sales, Inventory), AI Solution (assistants, Odoo + AI, automation, chatbots),
   Marketing (websites, social, brand assets), Technology (IoT, apps, networks). Each card: big glyph, title, 3 short items.
   Sub: "Season 1 explains **every TechNext service**, one episode at a time." CTA "Watch Nexi Explains" (/nexi-explains).
92 `nexi-introduction-ask-nexi-chat` (LIGHT skin, different composition from 90) - "Ask Nexi" / "anything Odoo." Concept:
   a big phone (ink outline + lip) showing the Ask Nexi chat: user "What is Odoo?" -> Nexi "One system for sales, stock and
   your books." -> user "Where do we start?" -> Nexi "Accounting, Sales and Inventory. Then grow." + quick-reply chips
   ("Get a quotation", "Book a meeting", "Talk to the team"). Chat bubbles also float out of the phone into the scene.
   Nexi (hold jump or cute, face love/happy) beside the phone. Caveat note: "replies from TechNext's own pages".
   Sub: "Quotation, meeting or the team: **Nexi takes you there.**" CTA "Ask Nexi" (technext.asia/nexi).

---------------------------------------------------------------------------------------------------------------------------
## The COLLECTION (posts 93-122): NOT comic. Varied design families from this session.
Families: [M] detailed metaphor scene (like 37-46, 57-66), [U] crisp Odoo UI on a living background (67-86), [T] typographic/
editorial/data-viz, [I] isometric diagram, [S] still life / bird's-eye desk, [R] scene/room (like 47-56). Brand frame from
make.py unless stated. LIGHT = BR.skin light, DARK = BR.skin dark, THEMED = your own living world in on-brand colours.

### C1 - work folder `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection-c1` - ports render 9621, dbg 9622, audit 9623, NEXICAM 3621/9624
93 `odoo-20-ai-agents-pdf-to-bill` [M+U, LIGHT] "Drop the PDF." / "Odoo 20 drafts the bill." Sub: "AI agents create records
   from uploaded files. **You review and approve.**" CTA "See Odoo + AI" (/odoo/ai-integration). A sleek intake machine:
   PDF vendor bills (red PDF corner, "Harbour Trading · sample") feed into a glowing slot, a scan beam; out the other side an
   Odoo Vendor Bill form fills itself (vendor, bill date, 3 lines, GST 9%, total that adds up), AI sparkle marks on the
   filled fields; an "Approve" button with the cursor and "Approved by Mei · sample". Sticker "NEW IN ODOO 20". Icons:
   accountant, ai_app. Nexi: present, happy.
94 `odoo-20-offline-mode-warehouse` [R, THEMED warm basement warehouse] "No signal?" / "Keep working." Sub: "Odoo 20 saves
   changes offline and **syncs when you're back.**" CTA "What's new in Odoo 20" (/blog/odoo-20-whats-new). Perspective
   aisle of racks, cartons, a pallet jack, hanging lamps; a big rugged tablet in the foreground showing an Odoo Inventory
   receipt with an "Offline · 3 changes waiting to sync" bar and a crossed-out signal icon; at the loading-dock door in the
   back, daylight and full signal bars with a sync arc and a "Synced · 3 records" toast. Nexi: wear hardhat, hold reach.
95 `odoo-20-mcp-connector-access-rights` [I, DARK] "Bring your own AI." / "Keep your access rules." Sub: "Odoo 20's MCP
   connector lets outside AI tools work **within each user's access rights.**" CTA "See Odoo + AI" (/odoo/ai-integration).
   Isometric diagram: an Odoo database "vault" block (app icons on its roof: sale, accountant, stock, hr_payroll), three
   generic external AI assistant terminals ("Your AI assistant", "Team copilot", "Report bot" - no brand logos) cabled into ONE
   MCP gateway with turnstiles; badges at the turnstiles: "Sales · quotes", "Finance · bills" open (green), "Payroll ·
   no access" locked (red padlock). Iso labels on planes. Nexi: wear knight, hold present (guarding the gate).
96 `odoo-20-field-service-in-planning` [U, THEMED map-paper living background] "Field Service" / "now lives in Planning."
   Sub: "Odoo 20 moves the live map, routes and worksheets **into the Planning app.**" CTA "What's new in Odoo 20"
   (/blog/odoo-20-whats-new). A crisp Odoo Planning Gantt (technicians Arif/Bea/Chen · sample, coloured jobs "Aircon service ·
   Bedok" etc.) with a docked live-map pane (streets, route line, van pins moving); a small card flies from the Field
   Service icon into the Planning icon with a "Moved in Odoo 20" sticker. Icons: planning, industry_fsm. Nexi: wear cap,
   hold point.
97 `odoo-20-pay-bills-one-signature` [S, bird's-eye warm desk] "Six bills." / "One signature." Sub: "Odoo 20 pays approved
   vendor bills in a batch, **where your bank supports it.**" CTA "See Odoo Accounting" (/odoo/apps/accounting). Top-down
   wood desk (grain texture): six vendor bills fanned in an arc (vendor names + S$ amounts · sample), ONE long fountain-pen ink
   signature stroke sweeping across all six, the pen; a laptop corner with an Odoo "Pay 6 bills · S$ total · sample" batch
   button; coffee, glasses, calculator, plant, sticky note. Nexi seen from above (camera high), hold celebrate or clap,
   wear glasses. Icon: accountant.
98 `odoo-20-reorder-levels-30-days` [T data-viz, LIGHT] "Reorder levels," / "from your last 30 days." Sub: "Odoo 20
   suggests min and max stock **from the last 30 days of sales.**" CTA "See Odoo Inventory" (/odoo/apps/inventory).
   30 daily sales bars (a skyline, dated) flow through an arrow into a tall shelf/stock gauge with Min 40 / Max 120 markers
   (suggested, sparkle), product "Cold brew 1L · sample"; an Odoo reordering-rule card (Product, Location WH/Stock, Min, Max,
   Route Buy); a purchase RFQ toast. Icons: stock, purchase. Nexi: hold celebrate on top of the gauge.

### C2 - work folder `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection-c2` - ports render 9631, dbg 9632, audit 9633, NEXICAM 3631/9634
99 `seven-signs-outgrown-spreadsheets` [T editorial checklist, THEMED desk] "Seven signs" / "you've outgrown spreadsheets."
   Sub: "If **three or more** sound familiar, it's time for one system." CTA "Read the 7 signs"
   (/blog/signs-you-have-outgrown-spreadsheets). A clipboard (paper texture, metal clip) with the 7 signs: Same data typed
   twice · Nobody trusts the stock number · Month-end takes a week · Reports mean staying late · One person holds the key
   file · Growth adds people, not output · Customers wait for answers. Three ticked with a red marker + a "3 of 7" stamp;
   curling spreadsheet sheets, a pencil, sticky notes, a mug. Nexi: hold pointL, face wow.
100 `odoo-go-live-gate-balances` [R, THEMED airport gate] "Nothing goes live" / "until it balances." Sub: "Balances
   reconcile and your team practises on its own data. **Then the gate opens.**" CTA "How we implement"
   (/blog/how-an-odoo-implementation-works). One-point perspective boarding gate: split-flap sign "GO-LIVE · GATE 4",
   two lit checks on the gate pillar "Balances reconcile" and "Team practised on its own data", a scanner reading a
   "Trial balance · old system = Odoo · sample" boarding pass; through the window a TechNext-blue plane; a "Staging copy"
   lounge on the left. Nexi: wear pilot, hold hi.
101 `standard-first-customisation-iceberg` [M cross-section, THEMED ocean] "The build is the tip." / "Upgrades are the
   rest." Sub: "Custom code is ported and retested **every Odoo version.** We go standard first." CTA "Standard first"
   (/blog/standard-first-odoo-customisation). Sea cross-section: a small iceberg tip "Build" above water, a huge mass below
   in strata "Upgrade 2027", "Upgrade 2028", "Upgrade 2029"; at the side a depth gauge with the three levels:
   Configuration - low upgrade cost, Studio - medium, Custom modules - high; a little boat "Standard Odoo" sails easily;
   light rays, bubbles, fish, waves. Icon: web_studio. Nexi: wear strawhat, hold point (on the boat).
102 `invoicenow-singapore-departures-board` [T signage, THEMED terminal hall] "InvoiceNow:" / "when's your date?" Sub:
   "Every GST-registered business in Singapore joins **by 1 April 2031.**" CTA "Check the timeline"
   (/blog/invoicenow-singapore-gst-timeline). A split-flap DEPARTURES board, rows: 1 NOV 2025 Voluntary GST within 6 months
   of incorporation - DEPARTED; 1 APR 2026 New voluntary registrants - DEPARTED; 1 APR 2028 Supplies up to S$200,000 -
   SCHEDULED; 1 APR 2029 up to S$1 million; 1 APR 2030 up to S$4 million; 1 APR 2031 above S$4 million. (Existing GST-
   registered businesses, by 2025 total supplies; source IRAS.) Terminal hall, ceiling lights, a traveller with an invoice
   suitcase. Icons: accountant. Nexi: wear bellhop, hold present.
103 `odoo-20-country-packages-sg-ph-vn` [S, THEMED travel desk] "One Odoo 20." / "Three country packages." Sub: "New
   tax reports for **Singapore, the Philippines and Vietnam.**" CTA "Country changes" (/blog/odoo-20-singapore-philippines-vietnam).
   Three passports open with stamps: SG "GST · IRAS tax invoice · SFRS", PH "BIR 2306 · 2307 · 1601-C", VN "Circular 99 ·
   01/GTGT · SInvoice"; boarding passes, luggage tags, small flags, a globe, a coffee. Icons: accountant, hr_payroll,
   point_of_sale. Nexi: hold hi, face happy.
104 `accounting-vs-erp-one-database` [M split, LIGHT] "Accounting keeps the books." / "ERP runs the business." Sub:
   "Sales, stock, purchasing and money on **one shared database.**" CTA "What is ERP?" (/blog/what-is-erp). Diagonal split:
   left muted - one ledger under a desk lamp, separate files (spreadsheet, email, CRM) scattered, label "after it happens";
   right bright - the same ledger at the core of a living machine: one database with app rings (sale, stock, purchase,
   accountant, mrp, hr) and one order card travelling Quotation -> Sales order -> Delivery -> Invoice -> Payment. Nexi on
   the seam, hold point.

### C3 - work folder `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection-c3` - ports render 9641, dbg 9642, audit 9643, NEXICAM 3641/9644
105 `odoo-phase-one-three-gears` [M 3D, DARK blueprint] "Start where money" / "and stock move." Sub: "Phase one:
   **Accounting, Sales and Inventory.** The rest joins later." CTA "Plan your phase one" (/solutions/odoo-erp). Three big
   glossy interlocking gears with the official icons on their hubs (accountant, sale, stock), motion arcs; behind, smaller
   greyed "phase two" gears (project, website, mrp, helpdesk); a "Go live" lever; blueprint grid, measurements, bolts.
   Nexi: wear goggles, hold reach (turning a gear).
106 `odoo-experience-2026-in-numbers` [T editorial stats, THEMED conference hall] "Odoo Experience 2026," / "in numbers."
   Sub: "Our takeaways: **AI agents, MCP, new prices, a PH subsidiary.**" CTA "Read the takeaways"
   (/blog/odoo-experience-2026-takeaways). Conference hall: a stage screen "Odoo 20", audience silhouettes, hanging banner
   stats: "~45,000 attendees" · "450+ talks" · "400+ exhibitors" · "€900M expected 2026 billing, up 45%"; a "Custom +20% ·
   Standard unchanged" card; lanyards. (Facts as Odoo reported them; do not imply TechNext attended.) Nexi in the front row
   taking notes, hold think.
107 `technext-three-offices-one-team` [I map, LIGHT] "Three offices." / "One Odoo team." Sub: "Singapore HQ, Taguig City
   and Ho Chi Minh City, **for clients in 10+ countries.**" CTA "About TechNext" (/company). Isometric tilted tile of a
   stylised Southeast Asia (sea with wave texture, islands) with three iso buildings: Singapore · HQ, Taguig City ·
   development & consulting hub, Ho Chi Minh City · AI engineering hub; TechNext paper planes on dashed arcs between them;
   labels on iso planes. Nexi: hold jump (flying between), face star.
108 `ai-chatbot-2am-still-answering` [R night, THEMED (warm lamp-lit night, not sci-fi)] "2:00 AM." / "Still answering."
   Sub: "A chatbot on your site and chat apps, **handing over to your team** when needed." CTA "See AI Chatbots"
   (/solutions/ai-chatbots). A closed shopfront at night (half-down shutter, CLOSED sign, street lamp, moon, a cat), a
   wall clock at 2:00, and a big phone in front with the chat: "Is the blue sofa in stock?" -> "Yes, 3 left at Bedok.
   Shall I reserve one? · sample" + "Reserve" chip. Icons: im_livechat. Nexi: wear beanie, hold cute, face content.
109 `iot-freezer-temperature-alert` [M cutaway, THEMED cold room] "Freezer too warm?" / "Know before it spoils." Sub:
   "IoT sensors watch the temperature and **alert your team first.**" CTA "See IoT Solutions" (/solutions/iot). Walk-in
   freezer cutaway (frost, ice crystals, shelves, cartons, door ajar with mist), a wireless sensor on the wall, a live line
   chart crossing a red limit line, a phone alert "Freezer 2 · -12°C · above -15°C limit · sample". Icons: iot.
   Nexi: hold gasp, face wow.
110 `networks-office-wifi-coverage` [I, THEMED blueprint-light] "Every desk," / "full signal." Sub: "Office networks, Wi-Fi
   and IT infrastructure, **planned and installed.**" CTA "See Networks" (/solutions/networks). Isometric office floor cut
   away: desks, meeting room, pantry, reception; ceiling access points with blue coverage rings; a network rack with
   patch cables; signal bars on laptops; a legend "Coverage · sample floor". Nexi: hold reach (plugging a cable).

### C4 - work folder `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection-c4` - ports render 9651, dbg 9652, audit 9653, NEXICAM 3651/9654
111 `website-design-front-door` [M, THEMED street] "Your website" / "is your front door." Sub: "Fast, clear sites that
   **explain what you do.**" CTA "See Web Design" (/solutions/website). A giant browser window built as a shopfront
   (awning, door = the "Get a quote" button, URL bar "yourcompany.com · sample"), small visitors walking in through the
   door and coming out as an Odoo CRM card "New lead from website · sample"; pavement, planters, a lamp. Icons: website,
   crm. Nexi: wear tophat, hold present (the doorman).
112 `social-media-content-calendar` [S front-on wall, THEMED studio] "Steady posting," / "with a plan behind it." Sub:
   "We plan, design and post **your social media, every week.**" CTA "See Social Media" (/solutions/social-media). A cork
   board wall planner "October · sample": a month grid with pinned post cards (photo post, reel, carousel), coloured
   strings, polaroids, push pins, tape; a phone with a feed preview; a reach card "sample". Icons: social. Nexi: wear beret,
   hold reach (pinning a card).
113 `brand-assets-one-brand-everywhere` [S three-quarter desk] "One brand," / "everywhere it shows." Sub: "Logos, decks,
   collateral and templates **that match.**" CTA "See Brand Assets" (/solutions/brand-assets). Desk flat lay at a
   three-quarter angle: an open brand guidelines book for a sample brand "Bayside F&B · sample" (logo lockups, colour
   swatches), a swatch fan, business cards, a deck on a tablet, a tote and cup with the logo, pencils, a cutting mat grid.
   Nexi: wear bowtie, hold present.
114 `app-development-three-apps` [U devices, DARK] "Apps for customers," / "staff and portals." Sub: "Mobile and web apps
   **connected to your Odoo.**" CTA "See App Development" (/solutions/app-development). Three phones fanned in low-angle
   perspective: a customer ordering/tracking app (map), a staff checklist app (photo proof), a customer portal (invoices);
   data lines into an Odoo database below; floating UI parts being assembled (wireframe -> final). Icons: sale, project,
   account. Nexi: hold clap.
115 `odoo-pos-restaurant-floor-plan` [S bird's-eye, THEMED restaurant] "Every table," / "one screen." Sub: "Odoo POS
   Restaurant: floor plan, orders **and kitchen tickets in sync.**" CTA "See Odoo for F&B" (/industries/fnb). Bird's-eye
   restaurant: wood floor, round and square tables with chairs and plates, status rings (ordering / eating / bill),
   servers with tablets; a POS tablet showing the floor-plan UI "T7 · 4 guests · S$86.40 · sample"; the kitchen pass with a
   ticket printer "T7 -> kitchen". Icons: pos_restaurant, point_of_sale. Nexi: wear chef, camera from above.
116 `odoo-planning-shifts-fit-together` [T kinetic grid, DARK] "Shifts that" / "fit together." Sub: "Odoo Planning shows
   **who works when, and every gap.**" CTA "See Odoo Planning" (/odoo/apps/planning). A week roster grid (Mon-Sun x 6 staff ·
   sample) built from rounded shift blocks falling into place like a puzzle; one dashed red gap "Sat · Cashier · open
   shift"; the Odoo Planning header; a "Shift published" toast. Icon: planning. Nexi: hold reach (pushing a block in).

### C5 - work folder `C:/Users/leuss/ClaudeWork/social-2026-10-10-collection-c5` - ports render 9661, dbg 9662, audit 9663, NEXICAM 3661/9664
117 `odoo-marketing-automation-marble-run` [M, THEMED pegboard workshop] "Every click picks" / "the next email." Sub:
   "Odoo Marketing Automation sends **the right follow-up, on its own.**" CTA "See Marketing Automation"
   (/odoo/apps/marketing-automation). A wooden marble run on a pegboard: envelope marbles drop from a "New sign-up" funnel; a
   switch gate "Opened?" sends them down "Yes -> Send the offer" or "No -> Reminder in 3 days"; they end in a "Lead -> CRM"
   basket; wooden blocks, pegs, tools. Icons: marketing_automation, mass_mailing, crm. Nexi: hold reach or gasp, face wow.
118 `odoo-documents-every-file-filed` [M machine, LIGHT] "Every file," / "in its folder." Sub: "Odoo Documents sorts PDFs and
   scans into **Finance, HR and Projects.**" CTA "See Odoo Documents" (/odoo/apps/documents). A mailroom sorting machine: a
   conveyor with PDFs, scans and contracts; diverter arms push them into labelled cubbies (Finance, HR, Legal, Projects) with
   tag chips ("Invoice", "Contract", "Payslip"); an Odoo Documents window card. Icons: documents, sign, accountant.
   Nexi: wear conductor, hold point.
119 `odoo-expenses-snap-the-receipt` [S macro, THEMED cafe table] "Snap the receipt." / "Claim it in Odoo." Sub: "Odoo
   Expenses reads the receipt and **sends it for approval.**" CTA "See Odoo Expenses" (/odoo/apps/expenses). Cafe table top:
   a crumpled receipt, a phone above it in camera mode with scan corners and detected fields popping (Merchant, Date, Total
   S$24.50 incl. 9% GST · sample); an Odoo expense card "Client lunch · S$24.50 · To approve"; coffee, keys, pen, napkin.
   Icons: hr_expense, approvals. Nexi: hold hi, face happy.
120 `odoo-studio-add-a-field` [U macro, LIGHT dutch angle] "Add a field." / "No code." Sub: "Odoo Studio adds fields, views
   and automations **on the Custom plan.**" CTA "See Odoo Customization" (/odoo/erp-system). A big tilted close-up of the
   Studio editor: the components sidebar (Text, Date, Selection, Many2one...) and a "Sales order S00042 · sample" form; a
   giant cursor dragging a "Delivery window" field into a glowing drop zone, motion trail. Icons: web_studio, sale.
   Nexi: hold point, wear glasses.
121 `odoo-tip-archive-dont-delete` [M, THEMED records room] "Don't delete it." / "Archive it." Sub: "Archived records leave
   your lists but **keep their history.**" CTA "Watch the Quick Tips" (/nexi-explains). A big filing-cabinet drawer pulled
   out (three-quarter view) with record cards ("Lumen Goods · sample", an old product) going in, tab "Archived"; a waste bin
   with a red cross; an Odoo list filter chip "Archived" + a "Restore" action card. Icons: contacts, stock. Nexi: hold think.
122 `odoo-tip-four-views-one-click` [M 3D object, DARK] "Same data," / "four views." Sub: "Switch between **Kanban, List,
   Calendar and Graph** in one click." CTA "Watch the Quick Tips" (/nexi-explains). A big glossy 3D cube (CSS 3D) floating in
   light rays; each visible face shows the SAME CRM pipeline data as a different Odoo view (Kanban, List, Calendar, Graph);
   the view-switcher icon bar above it with the active view highlighted. Icon: crm. Nexi: hold celebrate on/next to the cube.
