/* brand.js - the technext.asia skins for posts 77-86, LIVING (pairs with brand.css). Needs kit.js + hero.js + scene.js.
   Owner 2026-10-10: "use the technext branding. background and color" and then "why the last batch of image background
   are not dynamic but technext branding?" -> brand colours ON a living background, never instead of it.
   BR.skin(post, dark, seed)  -> render(t): site paper + 44 px grid + light sweep + drifting blue aurora (light) or the Nexi
                                 slide blue (dark), plus depth FX behind the UI: blurred Odoo app icons, glossy shapes
   BR.layers(dark)            -> scene layers in brand colours: pulsing rings, the TechNext paper plane with its trail,
                                 rays (dark), bokeh, sparkles. Everything sits under the UI windows (z <= 6). */
(function () {
  var BR = window.BR = {};
  var POOL = ['crm', 'sale', 'stock', 'accountant', 'project', 'website', 'helpdesk', 'point_of_sale', 'purchase', 'mrp', 'hr_timesheet', 'mass_mailing', 'sign', 'appointment', 'im_livechat'];
  BR.skin = function (post, dark, seed) {
    var DY = TN.pick({ 34: 0, reel: 170 }), R = TN.rand(seed * 7 + 3);
    var bg = HB.bg(post, dark
      ? { base: 'radial-gradient(120% 85% at 50% 28%,#4377D8 0%,#3167CA 42%,#1E4691 100%)', au: [[540, 820 + DY, 1100, '#5B8BE6', .6], [980, 360, 760, '#6FA0F5', .5], [80, 1180 + DY, 760, '#4377D8', .55]], spot: [620, 760 + DY], sp: 'rgba(255,255,255,.16)', grid: false, pc: '255,255,255', parts: 34, seed: seed }
      : { base: 'linear-gradient(180deg,#FFFFFF 0%,#F5F8FF 52%,#EAF0FB 100%)', au: [[180, 330, 840, '#DDE7F8', .95], [940, 980 + DY, 920, '#A9C6FF', .6], [120, 1160 + DY, 760, '#C9DAFB', .7]], spot: [620, 760 + DY], sp: 'rgba(169,198,255,.38)', grid: false, parts: 30, seed: seed });
    var hb = post.querySelector('.hb');
    var g = document.createElement('div'); g.className = 'sk-grid'; hb.parentNode.insertBefore(g, hb.nextSibling);
    var sw = document.createElement('div'); sw.className = 'sk-sweep'; g.parentNode.insertBefore(sw, g.nextSibling);
    // depth FX: four blurred app icons on the margins + three glossy shapes, all behind the windows (z 5)
    var ic = [], k0 = Math.floor(R() * POOL.length);
    [[70, 600, 66, 3, .55], [1018, 640, 54, 2, .6], [1030, 1170, 76, 4, .5], [52, 1210, 52, 2, .6]].forEach(function (p, i) { ic.push({ n: POOL[(k0 + i * 4) % POOL.length], x: p[0], y: p[1] + DY, s: p[2], blur: p[3], a: p[4], z: 5 }); });
    var sh = dark
      ? [{ t: 'sphere', x: 1000, y: 486 + DY, s: 52, c1: '#FFE07A', c2: '#FFB800', z: 5 }, { t: 'ring', x: 70, y: 1020 + DY, s: 92, c1: '#BFD4FF', c2: '#FFFFFF', z: 5 }, { t: 'pill', x: 1010, y: 930 + DY, s: 30, w: 86, c1: '#BFD4FF', c2: '#6FA0F5', z: 5, r: -24 }]
      : [{ t: 'sphere', x: 1000, y: 486 + DY, s: 52, c1: '#6FA0F5', c2: '#3167CA', z: 5 }, { t: 'ring', x: 70, y: 1020 + DY, s: 92, c1: '#A9C6FF', c2: '#3167CA', z: 5 }, { t: 'pill', x: 1010, y: 930 + DY, s: 30, w: 86, c1: '#FFD23F', c2: '#F2B33D', z: 5, r: -24 }];
    var fx = HB.fx(post, { seed: seed, icons: ic, shapes: sh });
    return function (t) {
      bg(t); fx(t);
      var u = TN.frac(t / (window.LOOP || 8));
      sw.style.transform = 'translateX(' + (-900 + 2200 * u).toFixed(1) + 'px) rotate(18deg)';
    };
  };
  BR.layers = function (dark) {
    var DY = TN.pick({ 34: 0, reel: 170 });
    return dark
      ? [{ type: 'rays', x: 990, y: 260, n: 12, len: 1500, col: '#FFFFFF', a: .1, spin: 1 },
         { type: 'rings', x: 540, y: 880 + DY, n: 3, max: 660, r0: 340, col: '#BFD4FF', a: .3, k: 2, flat: .34 },
         { type: 'plane', from: [-80, 1250 + DY], to: [1160, 1090 + DY], bend: -90, k: 1, ph: .15, s: 26, col: '#FFFFFF', fill: '#FFFFFF' },
         { type: 'bokeh', n: 18, size: [10, 28], cols: ['#FFFFFF', '#BFD4FF'], a: .38, area: [0, 540, 1080, 1300] },
         { type: 'sparkle', n: 12, size: [10, 18], cols: ['#FFD23F', '#FFFFFF'], area: [60, 540, 1020, 1250] }]
      : [{ type: 'rings', x: 540, y: 880 + DY, n: 3, max: 660, r0: 340, col: '#A9C6FF', a: .45, k: 2, flat: .34 },
         { type: 'plane', from: [-80, 1250 + DY], to: [1160, 1090 + DY], bend: -90, k: 1, ph: .15, s: 26, col: '#3167CA', fill: '#3167CA' },
         { type: 'bokeh', n: 16, size: [10, 28], cols: ['#A9C6FF', '#DDE7F8'], a: .6, area: [0, 540, 1080, 1300] },
         { type: 'shapes', shape: 'star4', n: 6, size: [12, 20], cols: ['#6FA0F5', '#FFD23F'], area: [60, 540, 1020, 1260], a: .8 },
         { type: 'sparkle', n: 10, size: [10, 18], cols: ['#3167CA', '#A9C6FF'], area: [60, 540, 1020, 1250] }];
  };
})();
