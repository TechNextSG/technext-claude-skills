/* odoo-ui.js - HTML builders for the Odoo-interface posts (pairs with odoo-ui.css). Each returns an HTML string.
   OU.nav(icon, app, menus, {n})   OU.cp(title, {pre, btn, facets, view})   OU.col({t, n, sum, pb, w, cards})
   OU.card({b, s, amt, tags, stars, act, av})   OU.av(initials, colour)   OU.cursor()   OU.spark(w, h, pts, col, fill)
   OU.bars(w, h, vals, col, {gap, hi})   OU.ic(name)  (app icon path)   OU.svg.*  (tiny UI glyphs) */
(function () {
  var OU = window.OU = {};
  OU.ic = function (n) { return 'assets/odoo/' + n + '.svg'; };
  var G = OU.svg = {
    search: '<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="#6B7280" stroke-width="2.4"/><path d="M15.5 15.5L21 21" stroke="#6B7280" stroke-width="2.4" stroke-linecap="round"/></svg>',
    star: function (on) { return '<svg viewBox="0 0 24 24"><path d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2l-5.7 3.1 1.2-6.4L2.8 9.5l6.4-.8z" fill="' + (on ? '#F3C623' : 'none') + '" stroke="' + (on ? '#E0AE0B' : '#C3C8D2') + '" stroke-width="1.8" stroke-linejoin="round"/></svg>'; },
    clock: function (c) { return '<svg viewBox="0 0 24 24" width="20" height="20"><circle cx="12" cy="12" r="10" fill="' + c + '"/><path d="M12 7v5.5l3.5 2" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round"/></svg>'; },
    kanban: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="5" height="16" rx="1.5" fill="#714B67"/><rect x="10" y="4" width="5" height="11" rx="1.5" fill="#714B67"/><rect x="17" y="4" width="4" height="7" rx="1.5" fill="#714B67"/></svg>',
    list: '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" stroke="#6B7280" stroke-width="2.4" stroke-linecap="round"/></svg>',
    graph: '<svg viewBox="0 0 24 24"><path d="M5 20V12M11 20V6M17 20V14" stroke="#6B7280" stroke-width="3" stroke-linecap="round"/></svg>',
    pivot: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" fill="none" stroke="#6B7280" stroke-width="2.2"/><path d="M3 9h18M9 3v18" stroke="#6B7280" stroke-width="2.2"/></svg>',
    cal: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2" fill="none" stroke="#6B7280" stroke-width="2.2"/><path d="M3 10h18M8 3v4M16 3v4" stroke="#6B7280" stroke-width="2.2" stroke-linecap="round"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    gear: '<svg viewBox="0 0 24 24" width="18" height="18"><circle cx="12" cy="12" r="3.2" fill="none" stroke="#6B7280" stroke-width="2.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="#6B7280" stroke-width="2.2" stroke-linecap="round"/></svg>'
  };
  OU.av = function (t, c) { return '<span class="ou-av" style="background:' + c + '">' + t + '</span>'; };
  OU.nav = function (icon, app, menus, o) {
    o = o || {};
    return '<div class="ou-nav"><span class="gr">' + '<i></i>'.repeat(9) + '</span><span class="app"><img src="' + OU.ic(icon) + '" alt="">' + app + '</span>' +
      (menus || []).map(function (m) { return '<span class="m">' + m + '</span>'; }).join('') +
      '<span class="r"><b data-n="' + (o.n || 3) + '"></b><i></i>' + OU.av(o.me || 'JL', o.mc || '#017E84') + '</span></div>';
  };
  OU.cp = function (title, o) {
    o = o || {};
    var v = o.view || 'kanban', vs = ['kanban', 'list', 'graph', 'pivot', 'cal'].slice(0, o.nv || 4);
    return '<div class="ou-cp">' + (o.btn === false ? '' : '<span class="ou-btn">' + (o.btn || 'New') + '</span>') + '<span class="ou-bc">' + (o.pre ? '<small>' + o.pre + ' /</small>' : '') + title + '</span>' + (o.gear === false ? '' : G.gear) +
      '<span class="ou-search">' + G.search + (o.facets || []).map(function (f) { return '<span class="ou-facet">' + f + '</span>'; }).join('') + '</span>' +
      (o.views === false ? '' : '<span class="ou-views">' + vs.map(function (k) { return '<i class="' + (k === v ? 'on' : '') + '">' + G[k] + '</i>'; }).join('') + '</span>') + '</div>';
  };
  OU.card = function (c) {
    var st = c.stars == null ? '' : '<span class="st">' + [0, 1, 2].map(function (k) { return G.star(k < c.stars); }).join('') + '</span>';
    return '<div class="ou-card' + (c.cls ? ' ' + c.cls : '') + '"' + (c.id ? ' id="' + c.id + '"' : '') + '><b>' + c.b + '</b>' + (c.s ? '<span class="s">' + c.s + '</span>' : '') + (c.amt ? '<span class="amt">' + c.amt + '</span>' : '') +
      (c.tags ? '<div class="ou-tags">' + c.tags.map(function (t) { return '<span class="ou-tag" style="background:' + t[1] + ';color:' + t[2] + '">' + t[0] + '</span>'; }).join('') + '</div>' : '') +
      '<div class="ou-ft">' + st + (c.act ? '<span class="ac">' + G.clock(c.act) + '</span>' : '') + (c.extra || '') + (c.av ? OU.av(c.av[0], c.av[1]) : '') + '</div></div>';
  };
  OU.col = function (o) {
    return '<div class="ou-col" style="width:' + o.w + 'px"><div class="ou-ch">' + o.t + ' <small>' + (o.n != null ? '(' + o.n + ')' : '') + '</small><small style="margin-left:auto">' + (o.sum || '') + '</small></div>' +
      '<div class="ou-pb">' + (o.pb || []).map(function (p) { return '<i style="width:' + p[0] + '%;background:' + p[1] + '"></i>'; }).join('') + '</div>' + (o.cards || []).map(OU.card).join('') + '</div>';
  };
  OU.cursor = function () { return '<svg class="ou-cur" viewBox="0 0 34 40"><path d="M3 2 L3 32 L11 25 L16.5 37 L22 34.5 L16.5 23 L27 23 Z" fill="#1F1F3D" stroke="#fff" stroke-width="2.4" stroke-linejoin="round"/></svg>'; };
  OU.spark = function (w, h, pts, col, fill) {
    var mx = Math.max.apply(null, pts), mn = Math.min.apply(null, pts), d = pts.map(function (v, i) { return (i ? 'L' : 'M') + (i * w / (pts.length - 1)).toFixed(1) + ' ' + (h - 4 - (v - mn) / (mx - mn || 1) * (h - 8)).toFixed(1); }).join(' ');
    return '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">' + (fill ? '<path d="' + d + ' L' + w + ' ' + h + ' L0 ' + h + ' Z" fill="' + fill + '"/>' : '') + '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/></svg>';
  };
  OU.bars = function (w, h, vals, col, o) {
    o = o || {}; var n = vals.length, gap = o.gap || 8, bw = (w - gap * (n - 1)) / n, mx = Math.max.apply(null, vals), s = '';
    vals.forEach(function (v, i) { var bh = v / mx * (h - 4); s += '<rect class="bar" data-h="' + bh.toFixed(1) + '" x="' + (i * (bw + gap)).toFixed(1) + '" y="' + (h - bh).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + bh.toFixed(1) + '" rx="4" fill="' + (o.hi === i ? (o.hc || col) : col) + '"/>'; });
    return '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" style="overflow:visible">' + s + '</svg>';
  };
})();
