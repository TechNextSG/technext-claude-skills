/* TechNext social posts kit - helpers + the page contract render.py relies on.
   TN.boot({ setup: {12: fn}, render: {12: fn(t)}, poster: {12: 4}, loop: 8, slugs: {12: 'construction-blueprint'}, waitFor: [promise] })
   - ?p=N shows <section class="post" data-p="N">; &play loops the timeline live in a browser
   - sets window.SLUGS, window.R(t) (if render given), window.POSTER, window.LOOP, window.__layout, then data-ready="1"
   QA marks: data-qa="text" (must stay inside the frame and clear of other text/blocks), data-qa="block" (visual block text must
   not sit on). Same data-qa-group = allowed to overlap (e.g. stamps on a passport). */
(function () {
  var NS = 'http://www.w3.org/2000/svg', C = Math.cos(Math.PI / 6), S = 0.5;
  var TN = window.TN = {
    NS: NS, C: C, S: S,
    el: function (tag, a, parent) { var e = document.createElementNS(NS, tag); for (var k in a) e.setAttribute(k, a[k]); if (parent) parent.appendChild(e); return e; },
    html: function (parent, s) { parent.insertAdjacentHTML('beforeend', s); return parent.lastElementChild; },
    cl: function (x, a, b) { return Math.max(a, Math.min(b, x)); },
    seg: function (t, a, b) { return TN.cl((t - a) / (b - a), 0, 1); },
    eo: function (x) { return 1 - Math.pow(1 - x, 3); },
    ei: function (x) { return x * x * x; },
    eio: function (x) { return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; },
    back: function (x) { var c1 = 1.70158, c3 = c1 + 1; return x <= 0 ? 0 : 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); },
    frac: function (x) { return x - Math.floor(x); },
    rand: function (seed) { var s = seed >>> 0 || 1; return function () { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 100000) / 100000; }; },
    // isometric: o = {x, y, k} screen origin of world (0,0,0); +x runs right-down, +y left-down, +z up
    iso: function (o, x, y, z) { var k = o.k || 1; return [o.x + (x - y) * C * k, o.y + ((x + y) * S - (z || 0)) * k]; },
    pts: function (o, arr) { return arr.map(function (p) { var q = TN.iso(o, p[0], p[1], p[2]); return q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' '); },
    // box with left (y+d) / right (x+w) / top faces; f = {top,left,right,stroke,sw,opacity}
    box: function (g, o, x, y, z, w, d, h, f) {
      var a = { stroke: f.stroke || 'none', 'stroke-width': f.sw || 1, 'stroke-linejoin': 'round' }; if (f.dash) a['stroke-dasharray'] = f.dash;
      function poly(arr, fill) { var o2 = { points: TN.pts(o, arr), fill: fill }; for (var k in a) o2[k] = a[k]; return TN.el('polygon', o2, g); }
      var L = poly([[x, y + d, z], [x + w, y + d, z], [x + w, y + d, z + h], [x, y + d, z + h]], f.left);
      var Rt = poly([[x + w, y, z], [x + w, y + d, z], [x + w, y + d, z + h], [x + w, y, z + h]], f.right);
      var T = poly([[x, y, z + h], [x + w, y, z + h], [x + w, y + d, z + h], [x, y + d, z + h]], f.top);
      return { left: L, right: Rt, top: T };
    },
    // a <g> whose local (u, v) plane is the iso floor at height z: draw rects/circles/images in it and they lie flat in 3D
    face: function (g, o, z) { var k = o.k || 1; return TN.el('g', { transform: 'matrix(' + C * k + ' ' + S * k + ' ' + (-C * k) + ' ' + S * k + ' ' + o.x + ' ' + (o.y - (z || 0) * k) + ')' }, g); },
    // same, for the right wall (x = const): local (v, z) -> v runs along y, z up
    wallX: function (g, o, x) { var k = o.k || 1, p = TN.iso(o, x, 0, 0); return TN.el('g', { transform: 'matrix(' + (-C * k) + ' ' + S * k + ' 0 ' + (-k) + ' ' + p[0] + ' ' + p[1] + ')' }, g); },
    // and the left wall (y = const): local (u, z) -> u runs along x
    wallY: function (g, o, y) { var k = o.k || 1, p = TN.iso(o, 0, y, 0); return TN.el('g', { transform: 'matrix(' + (C * k) + ' ' + S * k + ' 0 ' + (-k) + ' ' + p[0] + ' ' + p[1] + ')' }, g); },
    filters: function (svg) {   // common SVG filters: blur3/6/12/24, glow, ink (rough stamp edges), noise
      var d = TN.el('defs', {}, svg);
      d.innerHTML = [3, 6, 12, 24].map(function (b) { return '<filter id="blur' + b + '" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="' + b + '"/></filter>'; }).join('') +
        '<filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5" result="g"/><feMerge><feMergeNode in="g"/><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge></filter>' +
        '<filter id="ink" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="3.2" result="d"/>' +
        '<feTurbulence type="fractalNoise" baseFrequency="1.6" numOctaves="1" seed="3" result="s"/><feColorMatrix in="s" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -1.3 1.55" result="m"/><feComposite in="d" in2="m" operator="in"/></filter>';
      return d;
    }
  };

  /* FORMATS (owner rule 2026-10-07): images are 3:4 only (1080x1440, HQ master 2160x2880); video is 9:16 Reels only
     (1080x1920). ?f=34 (default) | ?f=reel | ?f=45 (legacy 4:5, old examples only). Pages read TN.W / TN.H / TN.F / TN.SAFE. */
  var FM = /[?&]f=(34|reel|45)/.exec(location.search);
  TN.F = FM ? FM[1] : '34';
  TN.FMT = { '34': { h: 1440, safe: [36, 36, 36, 36] }, reel: { h: 1920, safe: [240, 150, 480, 60] }, '45': { h: 1350, safe: [36, 36, 36, 36] } };  // safe = top, right, bottom, left
  TN.W = 1080; TN.H = TN.FMT[TN.F].h; TN.SAFE = TN.FMT[TN.F].safe;
  TN.pick = function (o) { return o[TN.F] !== undefined ? o[TN.F] : o['34']; };   // per-format value: TN.pick({34: 172, reel: 330})

  TN.boot = function (cfg) {
    var m = /[?&]p=(\d+)/.exec(location.search), first = document.querySelector('.post');
    var P = m ? +m[1] : +(first && first.getAttribute('data-p')), PLAY = /[?&]play/.test(location.search);
    var post = document.querySelector('.post[data-p="' + P + '"]'); post.classList.add('on'); post.classList.add('f-' + TN.F); document.body.classList.add('f-' + TN.F); window.FMT = TN.F;
    TN.P = P; TN.post = post;
    window.SLUGS = cfg.slugs || {}; window.LOOP = cfg.render && cfg.render[P] ? (cfg.loop || 8) : 0; window.POSTER = (cfg.poster || {})[P] || 0;
    var imgs = [].slice.call(post.querySelectorAll('img')).map(function (i) { return i.decode ? i.decode().catch(function () {}) : 0; });
    Promise.all([document.fonts.ready].concat(imgs, cfg.waitFor || [])).then(function () {
      return Promise.resolve(cfg.setup && cfg.setup[P] ? cfg.setup[P](post) : 0);   // setup may return a promise (data, maps)
    }).then(function () {
      return Promise.all((window.HB && window.HB._pending) || []);              // scene.js image layers
    }).then(function () {
      if (cfg.render && cfg.render[P]) { window.R = function (t) { cfg.render[P](t, post); }; window.R(window.POSTER); }
      return document.fonts.ready;
    }).then(function () {
      window.__layout = TN.qa(post);
      document.documentElement.setAttribute('data-ready', '1');
      if (PLAY && window.R) { var t0 = performance.now(); (function f(now) { window.R(((now - t0) / 1000) % window.LOOP); requestAnimationFrame(f); })(t0); }
    }).catch(function (e) { window.__layout = ['boot error: ' + e + (e && e.stack ? ' @ ' + String(e.stack).split(/\n/).slice(1, 3).join(' | ') : '')]; document.documentElement.setAttribute('data-ready', '1'); });
  };

  TN.qa = function (post) {
    var bad = [], pr = post.getBoundingClientRect(), SF = TN.SAFE || [36, 36, 36, 36];
    var marks = [].slice.call(post.querySelectorAll('[data-qa]')).filter(function (e) { return getComputedStyle(e).opacity !== '0' && e.getBoundingClientRect().width; });
    function nm(e) { return (e.id ? '#' + e.id : '') + '.' + String(e.className.baseVal !== undefined ? e.className.baseVal : e.className).split(' ')[0]; }
    marks.forEach(function (e) {
      if (e.getAttribute('data-qa') !== 'text') return;
      var r = e.getBoundingClientRect();
      var RM = TN.F === 'reel' && r.bottom < pr.top + 760 ? 36 : SF[1];   // TikTok/Shorts/Reels action buttons run down the lower right from y ~760
      if (r.left < pr.left + SF[3] || r.right > pr.right - RM || r.top < pr.top + SF[0] || r.bottom > pr.bottom - SF[2]) bad.push((TN.F === 'reel' ? 'outside reel safe zone: ' : 'outside frame: ') + nm(e) + ' ' + [r.left, r.top, r.right, r.bottom].map(Math.round));
      [].forEach.call(e.querySelectorAll('*'), function (k) { if (!k.children.length && k.scrollWidth > k.clientWidth + 1 && k.clientWidth && getComputedStyle(k).overflow === 'visible' && k.textContent.trim()) bad.push('text clipped: ' + k.textContent.trim().slice(0, 30)); });
    });
    marks.forEach(function (a, i) { marks.slice(i + 1).forEach(function (b) {
      if (a.getAttribute('data-qa') !== 'text' && b.getAttribute('data-qa') !== 'text') return;
      if (a.contains(b) || b.contains(a)) return;
      var ga = a.getAttribute('data-qa-group'), gb = b.getAttribute('data-qa-group'); if (ga && ga === gb) return;
      var x = a.getBoundingClientRect(), y = b.getBoundingClientRect();
      if (x.left < y.right - 2 && y.left < x.right - 2 && x.top < y.bottom - 2 && y.top < x.bottom - 2) bad.push('overlap: ' + nm(a) + ' / ' + nm(b));
    }); });
    return bad;
  };
})();
