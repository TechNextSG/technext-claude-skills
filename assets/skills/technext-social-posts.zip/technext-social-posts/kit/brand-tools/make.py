"""Assemble pNN.html from a short spec (tools/src/pNN.txt) so every post shares the same brand frame:
logo row, headline (2 lines, line 2 highlighted), Inter sub-line, scene, CTA footer, site skin.
Spec sections: @meta (key=value ...), @title, @l1, @l2, @sub, @cta, @site, @css, @body, @js (setup + render, uses S, DY, LOOP).
usage: python tools/make.py 77 78 ...   (or no args = all specs)"""
import pathlib, re, sys
HERE = pathlib.Path(__file__).resolve().parent.parent
SRC = HERE / 'tools' / 'src'

PAGE = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=1080">
<title>{n} - {title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@700&family=Inter:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=block" rel="stylesheet">
<link rel="stylesheet" href="kit.css">
<link rel="stylesheet" href="hero.css">
<link rel="stylesheet" href="odoo-ui.css">
<link rel="stylesheet" href="brand.css">
<style>
.p{n} .hh{{--hs:{hs}px}}
{css}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute"><defs>
  <symbol id="i-arrow" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></symbol>
  <symbol id="i-ok" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></symbol>
</defs></svg>

<section class="post p{n}{dk} grain" data-p="{n}">
  <div class="brand" data-qa="text"><img class="tn" src="assets/logo/technext-horizontal-blue.svg" alt="TechNext"><img class="odoo" src="assets/logo/{odoo}" alt="Odoo"></div>
  <div class="hw"><h1 class="hh" data-qa="text"><span class="ln">{l1}</span><span class="ln"><span class="hl">{l2}</span></span></h1><p class="sub" data-qa="text">{sub}</p></div>
{body}
  <div class="foot" data-qa="text"><span class="btn">{cta}<svg><use href="#i-arrow"/></svg></span><span class="site"><b>technext.asia</b><small>{site}</small></span></div>
</section>

<script src="kit.js"></script>
<script src="hero.js"></script>
<script src="scene.js"></script>
<script src="detail.js"></script>
<script src="odoo-ui.js"></script>
<script src="brand.js"></script>
<script>
(function () {{
  var LOOP = 8, DY = TN.pick({{ 34: 0, reel: 170 }}), S = {{}}, NS = 'http://www.w3.org/2000/svg', DARK = {dark};
  function el(t, a, p) {{ var e = document.createElementNS(NS, t); for (var k in a) if (a[k] != null) e.setAttribute(k, a[k]); if (p) p.appendChild(e); return e; }}
{js}
  TN.boot({{ slugs: {{ {n}: '{slug}' }}, setup: {{ {n}: setup }}, render: {{ {n}: render }}, poster: {{ {n}: {poster} }}, loop: LOOP }});
}})();
</script>
</body>
</html>
'''


def build(spec):
    txt = spec.read_text(encoding='utf-8')
    parts = dict((m.group(1), m.group(2).strip('\n')) for m in re.finditer(r'^@(\w+)[ \t]*\n?(.*?)(?=^@\w+|\Z)', txt, re.S | re.M))
    meta = dict(kv.split('=', 1) for kv in parts['meta'].split())
    n = meta['n']; dark = meta.get('dark', '0') == '1'
    html = PAGE.format(n=n, title=parts['title'].strip(), hs=meta.get('hs', '100'), css=parts.get('css', ''), dk=' dark' if dark else '',
                       odoo='odoo-logo-white.png' if dark else 'odoo-logo.png', l1=parts['l1'].strip(), l2=parts['l2'].strip(), sub=parts['sub'].strip(),
                       body=parts.get('body', ''), cta=parts['cta'].strip(), site=parts.get('site', 'Odoo, set up by TechNext').strip(),
                       dark='true' if dark else 'false', js=parts['js'], slug=meta['slug'], poster=meta.get('poster', '3'))
    out = HERE / f'p{n}.html'; out.write_text(html, encoding='utf-8'); print('built', out.name)


specs = [SRC / f'p{a}.txt' for a in sys.argv[1:]] or sorted(SRC.glob('p*.txt'))
for s in specs: build(s)
