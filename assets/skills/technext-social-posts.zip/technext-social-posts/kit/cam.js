/* TechNext social posts kit - TN.Cam: a real perspective camera for exaggerated angles (load after kit.js).
   World: z is UP, ground = z 0. Units are free (keep a scene in one scale).
     var cam = TN.Cam({ pos: [0, -400, 60], target: [0, 200, 20], fov: 70, roll: -0.2, cx: 540, cy: 700, view: 1350 });
     cam.p([x, y, z])            -> { x, y, d (depth), s (px per unit at that depth) } or null if behind the lens
     cam.faces(box)              -> visible faces of a box {x (centre), y (front), z (base), w, d, h, rz (yaw), rx (tip toward +y)}
     cam.draw(g, faces, paint)   -> painter's sort (far first) then paint(face, poly) for each; returns the polygons
     cam.quad(face, lw, lh)      -> SVG matrix mapping a local lw x lh box onto that face (affine, for icons/text)
     cam.dof(d)                  -> blur px for a depth (set cam.focus + cam.aperture), for depth-of-field
     cam.disc(g,x,y,z,r,h,top,side) -> a cylinder (plate, bowl, cup, a person's body); draw objects back to front
   Angles that work: worm's-eye (camera low, target high, fov 80-95), bird's-eye (camera high, target straight below,
   fov 70-85: verticals lean outwards), dutch tilt (roll 0.15-0.3 rad), macro foreground (an object 2-3x nearer than the
   rest + dof). Shading: TN.shade(hex, k) lightens (k>0) or darkens (k<0) a colour by face normal. */
(function () {
  function sub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function norm(a) { var l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  TN.v3 = { sub: sub, dot: dot, cross: cross, norm: norm };
  TN.shade = function (hex, k) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    function m(c) { return Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k)); }
    return 'rgb(' + m(r) + ',' + m(g) + ',' + m(b) + ')';
  };
  TN.Cam = function (o) {
    var pos = o.pos, f = norm(sub(o.target, pos)), up = o.up || [0, 0, 1];
    var r = norm(cross(f, up)), u = cross(r, f), ro = o.roll || 0;
    if (ro) { var r2 = [r[0] * Math.cos(ro) + u[0] * Math.sin(ro), r[1] * Math.cos(ro) + u[1] * Math.sin(ro), r[2] * Math.cos(ro) + u[2] * Math.sin(ro)];
      u = [u[0] * Math.cos(ro) - r[0] * Math.sin(ro), u[1] * Math.cos(ro) - r[1] * Math.sin(ro), u[2] * Math.cos(ro) - r[2] * Math.sin(ro)]; r = r2; }
    var F = (o.view || 1350) / 2 / Math.tan((o.fov || 60) * Math.PI / 360), cx = o.cx == null ? 540 : o.cx, cy = o.cy == null ? 675 : o.cy, near = o.near || 1;
    var cam = { pos: pos, f: f, r: r, u: u, F: F, focus: o.focus || 0, aperture: o.aperture || 0, light: norm(o.light || [-.4, -.6, 1]) };
    cam.p = function (p) { var d = sub(p, pos), z = dot(d, f); if (z < near) return null; return { x: cx + F * dot(d, r) / z, y: cy - F * dot(d, u) / z, d: z, s: F / z }; };
    cam.dof = function (d) { return cam.aperture ? Math.min(14, Math.abs(d - cam.focus) / d * cam.aperture) : 0; };
    // box corners with optional yaw (rz) around the base centre and forward tip (rx) around the front-bottom edge
    cam.corners = function (b) {
      var c = [], cz = Math.cos(b.rz || 0), sz = Math.sin(b.rz || 0), cx2 = Math.cos(b.rx || 0), sx2 = Math.sin(b.rx || 0);
      [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]].forEach(function (k) {
        var lx = (k[0] - .5) * b.w, ly = k[1] * b.d, lz = k[2] * b.h;          // local: x across, y along (front at 0), z up
        if (b.rx) { var y2 = ly * cx2 + lz * sx2, z2 = -ly * sx2 + lz * cx2; ly = y2; lz = z2; }   // tip forward about the front-bottom edge
        ly -= b.d / 2;
        c.push([b.x + lx * cz - ly * sz, b.y + lx * sz + ly * cz + b.d / 2, b.z + lz]);
      });
      return c;
    };
    var FACES = { bottom: [0, 3, 2, 1], top: [4, 5, 6, 7], front: [0, 1, 5, 4], back: [2, 3, 7, 6], left: [3, 0, 4, 7], right: [1, 2, 6, 5] };
    cam.faces = function (b) {
      var c = cam.corners(b), out = [];
      Object.keys(FACES).forEach(function (k) {
        var idx = FACES[k], P = idx.map(function (i) { return c[i]; });
        var n = norm(cross(sub(P[1], P[0]), sub(P[3], P[0]))), ctr = [0, 1, 2].map(function (a) { return (P[0][a] + P[1][a] + P[2][a] + P[3][a]) / 4; });
        if (dot(n, sub(pos, ctr)) <= 0) return;                                  // back-face cull
        var S = P.map(cam.p); if (S.some(function (s) { return !s; })) return;
        out.push({ key: k, box: b, P: P, S: S, n: n, d: dot(sub(ctr, pos), f), lit: dot(n, cam.light) });
      });
      return out;
    };
    cam.draw = function (g, faces, paint) {
      faces.sort(function (a, b) { return b.d - a.d; });
      return faces.map(function (fc) {
        var poly = TN.el('polygon', { points: fc.S.map(function (s) { return s.x.toFixed(1) + ',' + s.y.toFixed(1); }).join(' ') }, g);
        if (paint) paint(fc, poly); return poly;
      });
    };
    // affine map of a local lw x lh box (0,0 = top-left as seen from outside, x right, y down) onto a projected face;
    // for upright faces top-left is the upper corner, for the top face it is the far-left corner. Keep lw:lh = face w:h.
    cam.quad = function (fc, lw, lh) { lw = lw || 100; lh = lh || 100; var a = fc.S[3], b = fc.S[2], d = fc.S[0];
      return 'matrix(' + [(b.x - a.x) / lw, (b.y - a.y) / lw, (d.x - a.x) / lh, (d.y - a.y) / lh, a.x, a.y].map(function (v) { return v.toFixed(4); }).join(' ') + ')'; };
    // cylinder seen through the camera (plate, bowl, cup, a person's body): side colour under, top colour over
    cam.disc = function (g, x, y, z, r, h, top, side, n) {
      n = n || 40; var T = [], B = [];
      for (var i = 0; i < n; i++) { var a = i / n * Math.PI * 2; T.push(cam.p([x + r * Math.cos(a), y + r * Math.sin(a), z + h])); B.push(cam.p([x + r * Math.cos(a), y + r * Math.sin(a), z])); }
      if (T.concat(B).some(function (s) { return !s; })) return null;
      function pp(S) { return S.map(function (s) { return s.x.toFixed(1) + ',' + s.y.toFixed(1); }).join(' '); }
      if (h > 0) TN.el('polygon', { points: pp(B), fill: side }, g);
      return TN.el('polygon', { points: pp(T), fill: top }, g);
    };
    return cam;
  };
})();
