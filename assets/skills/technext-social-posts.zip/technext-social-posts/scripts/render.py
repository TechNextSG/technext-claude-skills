# -*- coding: utf-8 -*-
"""Render TechNext social posts from an HTML page (see reference/engine.md for the page contract).

    python render.py <page.html> --posts 21,22 [--fmt 34|reel] [--out DIR] [--fps 30] [--port 9411]

FORMATS (owner rule, 2026-10-07 - enforced here):
  --fmt 34    (default) the IMAGE format, 3:4 portrait, high quality. Writes ONE file per post (owner: no duplicates):
                 NN-technext-<slug>.png      2160 x 2880 (drawn at 2x; Instagram shrinks it to 1080 x 1440 itself,
                                             Facebook/LinkedIn keep the extra sharpness)
              No video in this format.
  --fmt reel  the VIDEO format, 9:16 Reels. The page must define motion (window.R + window.LOOP). Writes
                 NN-technext-<slug>-reel.mp4        1080 x 1920, H.264 crf 16, 30 fps, silent, seamless loop
              --cover also writes NN-technext-<slug>-reel-cover.png (only if the owner wants a separate cover file).
  --fmt 45    legacy 4:5 (only to re-render pre-2026-10-07 examples). Old names, optional --mp4.

For every post it opens <page>?p=N&f=<fmt>, waits for data-ready="1", prints the page's own QA list (window.__layout,
which checks the reel safe zone in reel format), broken images and missing fonts. Exit code 1 if any post has QA issues."""
import argparse, base64, glob, io, json, os, shutil, subprocess, sys, time, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import _cdp
from PIL import Image

ap = argparse.ArgumentParser()
ap.add_argument('page'); ap.add_argument('--posts', required=True); ap.add_argument('--out')
ap.add_argument('--fmt', choices=['34', 'reel', '45'], default='34')
ap.add_argument('--mp4', action='store_true', help='legacy 4:5 only; reels always render video')
ap.add_argument('--fps', type=int, default=30); ap.add_argument('--port', default=None)
ap.add_argument('--cover', action='store_true', help='reel: also write the cover PNG')
a = ap.parse_args()
if a.mp4 and a.fmt == '34':
    raise SystemExit('Video is 9:16 only (owner rule). Use --fmt reel for the MP4; --fmt 34 makes the 3:4 image.')
page = pathlib.Path(a.page).resolve()
out = pathlib.Path(a.out).resolve() if a.out else page.parent / 'out'
out.mkdir(parents=True, exist_ok=True)
FFMPEG = shutil.which('ffmpeg') or next(iter(glob.glob(os.path.expanduser(
    '~/AppData/Local/Microsoft/WinGet/Packages/*FFmpeg*/ffmpeg-*/bin/ffmpeg.exe'))), None)
SIZE = {'34': (1080, 1440), 'reel': (1080, 1920), '45': (1080, 1350)}[a.fmt]

proc, c = _cdp.session(SIZE[0], SIZE[1], port=a.port, profile=os.environ.get('RENDER_PROFILE') or 'render-' + page.parent.name[:40])   # RENDER_PROFILE: parallel renders in one folder
bad_any = False


def load(p, dpr, w, h):
    c.call('Emulation.setDeviceMetricsOverride', width=w, height=h, deviceScaleFactor=dpr, mobile=False)
    c.call('Page.navigate', url=f'{page.as_uri()}?p={p}&f={a.fmt}')
    for _ in range(240):
        time.sleep(.25)
        if c.ev("document.documentElement.getAttribute('data-ready')") == '1':
            break
    else:
        print(f'  post {p}: page never set data-ready="1" (JS error? missing CDN?)')
    time.sleep(.5)


def size():
    r = c.ev("(function(){var e=document.querySelector('.post.on');if(!e)return null;var b=e.getBoundingClientRect();return [Math.round(b.width),Math.round(b.height)]})()")
    return tuple(r) if r else SIZE


def shot(w, h):
    d = c.call('Page.captureScreenshot', format='png', clip={'x': 0, 'y': 0, 'width': w, 'height': h, 'scale': 1}, captureBeyondViewport=False)['data']
    return base64.b64decode(d)


try:
    for p in [int(x) for x in a.posts.split(',')]:
        load(p, 2, *SIZE)
        w, h = size()
        if (w, h) != SIZE:
            print(f'post {p}: page is {w}x{h}, format {a.fmt} needs {SIZE[0]}x{SIZE[1]} - does the page use kit.css/kit.js formats?')
            bad_any = True; continue
        slug = (c.ev('window.SLUGS') or {}).get(str(p)) or f'post-{p}'
        base = f'{p:02d}-technext-{slug}'
        name = {'34': base, 'reel': base + '-reel', '45': base}[a.fmt]
        lay = c.ev('window.__layout')
        broken = c.ev("[...document.querySelectorAll('.post.on img, .post.on image')].filter(i=>i.tagName==='IMG'?!i.naturalWidth:false).map(i=>i.getAttribute('src'))")
        fonts = c.ev("[...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family).filter((v,i,a)=>a.indexOf(v)===i)") or []
        missing = [f for f in ('Plus Jakarta Sans', 'Inter') if f not in fonts]
        issues = (lay or []) + [f'broken image {b}' for b in broken or []] + [f'font not loaded: {f}' for f in missing]
        print(f'post {p} [{w}x{h} {a.fmt}] {name}: ' + ('CLEAN' if not issues else 'ISSUES ' + json.dumps(issues)))
        bad_any |= bool(issues)
        im = Image.open(io.BytesIO(shot(w, h))).convert('RGB')
        if a.fmt == '34':
            im.save(out / f'{name}.png', optimize=True)                         # the one image: 2160 x 2880
        elif a.fmt == 'reel':
            if a.cover: im.resize((w, h), Image.LANCZOS).save(out / f'{name}-cover.png', optimize=True)
        else:
            im.save(out / f'{name}@2x.png', optimize=True); im.resize((w, h), Image.LANCZOS).save(out / f'{name}.png', optimize=True)
        if a.fmt == 'reel' or a.mp4:
            if not c.ev('typeof window.R === "function" && !!window.LOOP'):
                print('  no window.R / window.LOOP: a reel needs motion (see engine.md)'); bad_any = True; continue
            if not FFMPEG:
                raise SystemExit('ffmpeg not found (winget install yt-dlp.FFmpeg, or put ffmpeg on PATH)')
            load(p, 1, w, h)
            fr = out / f'_frames_{p}_{a.fmt}'
            shutil.rmtree(fr, ignore_errors=True); fr.mkdir()
            n = int(round(c.ev('window.LOOP') * a.fps)); t0 = time.time()
            for i in range(n):
                c.ev(f'window.R({i / a.fps:.5f}); 0')
                (fr / f'{i:04d}.png').write_bytes(shot(w, h))
            subprocess.run([FFMPEG, '-y', '-loglevel', 'error', '-framerate', str(a.fps), '-i', str(fr / '%04d.png'),
                            '-c:v', 'libx264', '-preset', 'slow', '-crf', '16', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
                            str(out / f'{name}.mp4')], check=True)
            shutil.rmtree(fr)
            print(f'  mp4: {n} frames in {time.time() - t0:.0f}s -> {name}.mp4 ({(out / f"{name}.mp4").stat().st_size / 1e6:.2f} MB)')
finally:
    proc.terminate()
print('ALL CLEAN' if not bad_any else 'ISSUES FOUND - fix them before delivering')
sys.exit(1 if bad_any else 0)
