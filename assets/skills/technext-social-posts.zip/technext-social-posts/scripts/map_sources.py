"""Map every delivered post image (Drive) to the local render that produced it (md5) and to its source page.
Writes qa/all-posts-map.json: [{n, name, drive, local, page, kind}] where kind = 'tn' (TN.boot social page) or 'site'."""
import hashlib, json, pathlib, re
H = pathlib.Path.home() / 'ClaudeWork'
NEW = pathlib.Path(r'G:/Shared drives/Marketing/02. TechNext Folder/02. TechNext Social Media Posting Image')
md5 = lambda p: hashlib.md5(pathlib.Path(p).read_bytes()).hexdigest()
drive = {}
for f in NEW.glob('[0-9][0-9]. */Image Posts/*.png'):
    m = re.match(r'(\d+)-technext-', f.name)
    if m: drive[int(m.group(1))] = f
for f in NEW.glob('07. */Paid Ads/*-4x5.png'):
    drive['ad' + re.search(r'fb-ad(\d)', f.name).group(1)] = f
# local renders (latest first by mtime)
local = {}
roots = [H / d for d in ['social-2026-10-07-angles'] + [p.name for p in H.glob('site-posts-2026-10-08-*')] +
         [p.name for p in H.glob('social-2026-10-*')] + [p.name for p in H.glob('nexi-intro-2026-10-10-*')]]
for r in roots:
    for f in list(r.glob('out*/*.png')) + list(r.glob('qa/*.png')):
        try: local.setdefault(md5(f), []).append(f)
        except OSError: pass
rows = []
for k, f in sorted(drive.items(), key=lambda kv: (isinstance(kv[0], str), str(kv[0]).zfill(4))):
    hit = local.get(md5(f), [])
    loc = hit[0] if hit else None
    page = kind = None
    if loc:
        w = loc.parent.parent
        if isinstance(k, str): page = w / f'{k}.html'
        else:
            for cand in [w / f'p{k}.html', w / 'v3' / f'p{k:02d}.html', w / 'v2' / f'p{k:02d}.html', w / f'p{k:02d}.html']:
                if cand.exists(): page = cand; break
        if page: kind = 'tn' if 'TN.boot' in page.read_text(encoding='utf-8', errors='ignore') else 'site'
    rows.append({'n': k, 'name': f.name, 'drive': str(f), 'local': str(loc) if loc else None, 'page': str(page) if page else None, 'kind': kind})
(H / 'qa' / 'all-posts-map.json').write_text(json.dumps(rows, indent=1), encoding='utf-8')
miss = [r for r in rows if not r['page']]
print(len(rows), 'delivered images;', sum(1 for r in rows if r['kind'] == 'tn'), 'TN pages,', sum(1 for r in rows if r['kind'] == 'site'), 'site pages; unmatched:', [(r['n'], r['name']) for r in miss])
