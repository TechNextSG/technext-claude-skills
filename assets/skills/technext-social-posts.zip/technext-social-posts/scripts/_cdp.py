# -*- coding: utf-8 -*-
"""Minimal headless-Chrome driver over the DevTools protocol (needs: pip install websocket-client).
Used by render.py. Each caller picks its own CDP_PORT / CDP_PROFILE so parallel chats don't collide."""
import json, os, pathlib, subprocess, time, urllib.request
import websocket

CHROME = os.environ.get('CHROME_PATH', r'C:\Program Files\Google\Chrome\Application\chrome.exe')
PROFILES = pathlib.Path(os.path.expanduser('~/ClaudeWork/qa/social-posts-profiles'))


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, max_size=None, timeout=120, suppress_origin=True)
        self.i = 0

    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({'id': self.i, 'method': method, 'params': params}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get('id') == self.i:
                if 'error' in m:
                    raise RuntimeError(m['error'])
                return m.get('result', {})

    def ev(self, js):
        r = self.call('Runtime.evaluate', expression=js, returnByValue=True, awaitPromise=True)
        if r.get('exceptionDetails'):
            return {'exception': r['exceptionDetails'].get('exception', {}).get('description', str(r['exceptionDetails']))}
        return r.get('result', {}).get('value')


def session(w, h, port=None, profile=None):
    """Start headless Chrome on about:blank. Returns (proc, cdp); call proc.terminate() when done."""
    port = int(port or os.environ.get('CDP_PORT', '9411'))
    prof = PROFILES / (profile or os.environ.get('CDP_PROFILE', 'default'))
    prof.mkdir(parents=True, exist_ok=True)
    # Guard (2026-10-10, reel 52 bug): if another Chrome already listens on this port, the new Chrome cannot bind it and
    # we would silently attach to the OTHER session's tab - its own page (a TechNext web form) then filled the reel frames.
    import socket
    for _ in range(20):                                    # allow ~4 s for our own previous Chrome on this port to exit
        with socket.socket() as s:
            s.settimeout(.5)
            busy = s.connect_ex(('127.0.0.1', port)) == 0
        if not busy: break
        time.sleep(.2)
    else:
        raise RuntimeError('port %d is already in use (another render/dbg/audit Chrome?) - pick a free --port' % port)
    proc = subprocess.Popen([CHROME, '--headless=new', f'--remote-debugging-port={port}', f'--user-data-dir={prof}',
                             f'--window-size={w},{h}', '--hide-scrollbars', '--no-first-run', '--allow-file-access-from-files',
                             f'--remote-allow-origins=http://127.0.0.1:{port}', 'about:blank'],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ws = None
    for _ in range(160):
        try:
            ws = [t for t in json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/json')) if t['type'] == 'page'][0]['webSocketDebuggerUrl']
            break
        except Exception:
            time.sleep(.15)
    if not ws:
        proc.terminate()
        raise RuntimeError('Chrome did not start (is another render using port %d?)' % port)
    c = CDP(ws)
    c.call('Page.enable'); c.call('Runtime.enable')
    return proc, c
