# -*- coding: utf-8 -*-
"""Audit EVERY delivered post in one go (owner 2026-10-10: "do audit all images, always check if the text are too small to
read, overflowing text, layering, etc.."). Reads a map of delivered images -> source pages (built by map_sources.py:
[{n, name, drive, page, kind}]), groups the pages by work folder, runs audit.py on each group in parallel (one Chrome per
port) and writes one consolidated report:
    <out>/SUMMARY.md     every post: errors / warnings / kinds, worst first, with links to the per-group reports
    <out>/summary.json   machine-readable
    <out>/<group>/...    audit.py's report.md, report.json, boxed screenshots and audit-sheet.jpg per work folder
usage: python audit_all.py --map ~/ClaudeWork/qa/all-posts-map.json [--out ~/ClaudeWork/qa/audit-all] [--workers 6] [--base-port 9800]
Exit code 1 if any post has an error."""
import argparse, collections, json, pathlib, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ap = argparse.ArgumentParser()
ap.add_argument('--map', required=True); ap.add_argument('--out', default=str(pathlib.Path.home() / 'ClaudeWork/qa/audit-all'))
ap.add_argument('--workers', type=int, default=6); ap.add_argument('--base-port', type=int, default=9800)
ap.add_argument('--only', nargs='*', help='post numbers to audit (default all)')
ap.add_argument('--summary-only', action='store_true', help='rebuild SUMMARY.md from existing group reports')
a = ap.parse_args()
AUDIT = pathlib.Path(__file__).resolve().parent / 'audit.py'
rows = json.loads(pathlib.Path(a.map).expanduser().read_text(encoding='utf-8'))
if a.only: rows = [r for r in rows if str(r['n']) in a.only]
groups = collections.OrderedDict()
for r in rows:
    if not r.get('page'): continue
    pg = pathlib.Path(r['page']); w = pg.parent if pg.parent.name not in ('v2', 'v3') else pg.parent.parent
    groups.setdefault(w.name + ('-' + pg.parent.name if pg.parent.name in ('v2', 'v3') else ''), []).append(str(pg))
out = pathlib.Path(a.out).expanduser().resolve(); out.mkdir(parents=True, exist_ok=True)   # absolute: each audit runs in its page folder


def run(job):
    i, (g, pages) = job
    port = a.base_port + i * 3
    o = out / g
    p = subprocess.run([sys.executable, str(AUDIT), *sorted(set(pages)), '--f', '34', '--port', str(port), '--out', str(o)],
                       capture_output=True, text=True, encoding='utf-8', errors='replace', cwd=str(pathlib.Path(pages[0]).parent))
    print(f'[{g}] ' + (p.stdout.strip().splitlines() or ['(no output)'])[-1], flush=True)
    if p.returncode not in (0, 1): print(p.stderr[-800:], flush=True)
    return g


if not a.summary_only:
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        list(ex.map(run, enumerate(groups.items())))

summ = []
for g in groups:
    f = out / g / 'report.json'
    if not f.exists(): summ.append({'group': g, 'post': '?', 'slug': 'AUDIT FAILED', 'err': 1, 'warn': 0, 'kinds': {}}); continue
    for r in json.loads(f.read_text(encoding='utf-8')):
        ne = sum(x['lvl'] == 'err' for x in r['items']); nw = len(r['items']) - ne
        kinds = collections.Counter(x['kind'] for x in r['items'] if x['lvl'] == 'err')
        summ.append({'group': g, 'post': r['post'], 'slug': r['slug'], 'err': ne, 'warn': nw, 'kinds': dict(kinds), 'page': r['page']})
summ.sort(key=lambda s: (-s['err'], -s['warn'], str(s['post']).zfill(4)))
tot = collections.Counter(); [tot.update(s['kinds']) for s in summ]
md = ['# Audit of every delivered post', '', f'{len(summ)} posts - {sum(1 for s in summ if s["err"])} with errors, '
      f'{sum(1 for s in summ if not s["err"] and s["warn"])} with warnings only, {sum(1 for s in summ if not s["err"] and not s["warn"])} clean.', '',
      'Errors by kind: ' + (', '.join(f'{k} {v}' for k, v in tot.most_common()) or 'none'), '',
      '| post | slug | errors | warnings | error kinds | report |', '|---|---|---|---|---|---|']
md += [f'| {s["post"]} | {s["slug"][:46]} | {s["err"]} | {s["warn"]} | {", ".join(f"{k} {v}" for k, v in s["kinds"].items())} | {s["group"]}/report.md |' for s in summ]
(out / 'SUMMARY.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
(out / 'summary.json').write_text(json.dumps(summ, indent=1), encoding='utf-8')
print(f'ALL POSTS: {sum(1 for s in summ if s["err"])} of {len(summ)} with errors; kinds: {dict(tot)} -> {out / "SUMMARY.md"}')
sys.exit(1 if any(s['err'] for s in summ) else 0)
