/* audit.js - deep layout audit for a rendered post (injected by audit.py after window.R(t)).
   window.TN_AUDIT(post) -> [{lvl:'err'|'warn', kind, msg, r:[x,y,w,h]}]
   Catches what TN.qa misses: SVG <text> spilling off its plate, text off-centre on its plate, text covered by art or
   Nexi, text-on-text collisions (HTML + SVG), text cut by the frame, HTML text spilling its pill, text sitting on busy
   art without a plate, sibling labels that nearly-but-not-quite line up, and icons/objects cut by the frame edge.
   v3 (2026-10-11, checks 12-19 in layering3): object layering - [deco] [edge-cut] [face] [cursor] [contain] [float] [stack]
   [line] - and the [odoo-facts] warning lint (facts in reference/odoo-ui-facts.md).
   Opt-outs (use sparingly, each one is a design decision, not a way to silence a real fault):
     data-audit="skip"     element + subtree ignored (pure decoration: tape numbers, watermarks)
     data-audit="overlay"  a deliberate cover (magnifier lens): never counts as covering, its own text skips collisions
     data-audit="layer"    stacked copies of one word (3D extrusion): no collisions inside it */
(function () {
  function vis(e) {   // effective visibility (display, visibility, opacity chain incl. SVG opacity attrs)
    var a = 1;
    for (var n = e; n && n.nodeType === 1; n = n.parentNode) {
      if (n.getAttribute && n.getAttribute('data-audit') === 'skip') return 0;
      var cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
      a *= parseFloat(cs.opacity || 1);
      if (n.tagName === 'section') break;
    }
    return a;
  }
  function R(r) { return { l: r.left, t: r.top, r: r.right, b: r.bottom, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 }; }
  function inter(a, b, pad) { pad = pad || 0; return a.l < b.r - pad && b.l < a.r - pad && a.t < b.b - pad && b.t < a.b - pad; }
  function nm(e) { var c = e.getAttribute('class') || ''; return e.tagName.toLowerCase() + (c ? '.' + c.split(' ').slice(0, 2).join('.') : ''); }
  function ink(o) { var h = Math.min(o.r.h, o.fs * .74), c = o.r.cy + (o.svg ? 0 : 0); return { l: o.r.l, r: o.r.r, t: c - h / 2, b: c + h / 2, w: o.r.w, h: h, cx: o.r.cx, cy: c }; }
  function txt(e) { return (e.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 34); }
  // on-screen scale of an element's text: a thin 1 x 100 px probe inside it picks up every CSS transform, 3D tilt,
  // perspective and zoom of its ancestors (owner 2026-10-10: "always check if the text are too small to read" - a
  // 17 px label in a window tilted away from the camera reads at 12 px; computed font-size never saw that)
  function effScale(host) {
    if (!host.appendChild || host.namespaceURI === 'http://www.w3.org/2000/svg') return 1;
    var p = document.createElement('i');
    // measure AT the text, not at the containing block's corner: on a face tilted in 3D the scale changes across it
    var st = getComputedStyle(host).position === 'static', L = st ? host.offsetLeft || 0 : 0, Tp = st ? host.offsetTop || 0 : 0;
    p.style.cssText = 'position:absolute;left:' + L + 'px;top:' + Tp + 'px;width:1px;height:100px;display:block;visibility:hidden;pointer-events:none;margin:0;padding:0;border:0;transform:none;zoom:1';
    try { host.appendChild(p); var q = p.getBoundingClientRect(); p.remove(); var s = Math.hypot(q.width, q.height) / 100; return s > 0.05 ? s : 1; } catch (x) { if (p.parentNode) p.remove(); return 1; }
  }
  function words(s) { s = (s || '').trim(); return s ? s.split(/\s+/).filter(function (w) { return /[A-Za-z0-9]/.test(w); }).length : 0; }
  function ownText(e) { return [].filter.call(e.childNodes, function (z) { return z.nodeType === 3; }).map(function (z) { return z.nodeValue; }).join(' ').replace(/\s+/g, ' ').trim(); }
  function isSentence(s) { s = (s || '').trim(); if (!s || (s === s.toUpperCase() && /[A-Z]/.test(s))) return false; return words(s) >= 5 || words(s) >= 3 && s.replace(/[\s\u00b7|\/-]+/g, ' ').length >= 30; }
  function paintedFill(e) {
    var cs = getComputedStyle(e), f = cs.fill, fo = parseFloat(cs.fillOpacity || 1);
    if (!f || f === 'none' || /rgba\([^)]*,\s*0\)$/.test(f) || f === 'transparent') return 0;
    if (/^url/.test(f)) { var id = (f.match(/#([^"')]+)/) || [])[1] || ''; if (/^dt-(speck|speckw|weave|grain|planks|stripe|dots|tile|grass|circuit|hatch|ripple|brick|gv|gh|gr|sh|glow)/.test(id)) return 0; }
    var m = f.match(/rgba\([^,]+,[^,]+,[^,]+,\s*([\d.]+)\)/); if (m) fo *= parseFloat(m[1]);
    return fo;
  }

  window.TN_AUDIT = function (post) {
    // elementsFromPoint skips anything with pointer-events:none: text inside such a wrapper is never tested for being
    // covered, and the wrapper never counts as covering (fine for glass/glare/selection overlays, wrong for a phone or
    // window that holds UI - post 114, 2026-10-10). Forcing pointer-events on everything turned decorative overlays into
    // false errors, so instead WARN when a click-transparent wrapper holds readable text (check 9 below).
    return audit(post);
  };
  function audit(post) {
    var out = [], pr = R(post.getBoundingClientRect()), PA = pr.w * pr.h;
    function add(lvl, kind, msg, r, col) { out.push({ lvl: lvl, kind: kind, msg: msg, r: r ? [Math.round(r.l - pr.l), Math.round(r.t - pr.t), Math.round(r.w), Math.round(r.h)] : null, col: col || null }); }

    // ---------- text inventory ----------
    var T = [];
    var walker = document.createTreeWalker(post, NodeFilter.SHOW_TEXT, null);
    var byEl = new Map();
    for (var n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!n.nodeValue.trim()) continue;
      var host = n.parentNode; if (host.closest && host.closest('svg')) continue;
      var rg = document.createRange(); rg.selectNodeContents(n);
      var rs = [].slice.call(rg.getClientRects()).filter(function (q) { return q.width > 1 && q.height > 1; });
      if (!rs.length) continue;
      var u = { left: 1e9, top: 1e9, right: -1e9, bottom: -1e9 };
      rs.forEach(function (q) { u.left = Math.min(u.left, q.left); u.top = Math.min(u.top, q.top); u.right = Math.max(u.right, q.right); u.bottom = Math.max(u.bottom, q.bottom); });
      var prev = byEl.get(host); if (prev) { prev.left = Math.min(prev.left, u.left); prev.top = Math.min(prev.top, u.top); prev.right = Math.max(prev.right, u.right); prev.bottom = Math.max(prev.bottom, u.bottom); } else byEl.set(host, u);
    }
    byEl.forEach(function (u, host) { if (vis(host) < .08) return; u.width = u.right - u.left; u.height = u.bottom - u.top; var f0 = parseFloat(getComputedStyle(host).fontSize); T.push({ e: host, svg: false, r: R(u), fs: f0 * effScale(host), fs0: f0 }); });
    [].forEach.call(post.querySelectorAll('svg text'), function (e) {
      if (e.querySelector('textPath') || vis(e) < .08 || !txt(e)) return;
      var r = R(e.getBoundingClientRect()); if (r.w < 1) return;
      var m = e.getScreenCTM(), sc = m ? Math.sqrt(m.a * m.a + m.b * m.b) : 1;
      T.push({ e: e, svg: true, r: r, fs: parseFloat(getComputedStyle(e).fontSize) * sc });
    });

    // ---------- per-text checks ----------
    var shapes = [].slice.call(post.querySelectorAll('svg rect, svg path, svg circle, svg ellipse, svg polygon')).filter(function (s) { if (vis(s) < .35 || paintedFill(s) < .35) return false; try { var bb = s.getBBox(); return bb.width >= 3 && bb.height >= 3; } catch (x) { return false; } });
    T.forEach(function (o) {
      var r = o.r, e = o.e, label = '"' + txt(e) + '"';
      // 1. cut by frame / hugging the frame edge (only the part its overflow-hidden containers let through counts)
      var vr = { l: r.l, t: r.t, r: r.r, b: r.b };
      for (var a0 = e.parentElement; a0 && a0 !== post; a0 = a0.parentElement) { if (getComputedStyle(a0).overflow !== 'visible') { var cr = a0.getBoundingClientRect(); vr.l = Math.max(vr.l, cr.left); vr.t = Math.max(vr.t, cr.top); vr.r = Math.min(vr.r, cr.right); vr.b = Math.min(vr.b, cr.bottom); } }
      if (vr.r <= vr.l || vr.b <= vr.t) return;   // fully hidden by its container (e.g. the far side of a magnifier lens)
      if (vr.l < pr.l - 1 || vr.r > pr.r + 1 || vr.t < pr.t - 1 || vr.b > pr.b + 1) add('err', 'frame', 'text cut by the frame: ' + label, r);
      else if (o.svg && (vr.l < pr.l + 14 || vr.r > pr.r - 14)) add('warn', 'edge', 'text hugs the frame edge: ' + label, r);
      // 2. too small to read, measured ON SCREEN (after transforms/3D/zoom): the brand floor is 15 px for any label and
      //    18 px for anything meant to be read as a sentence (owner 2026-10-10, twice: "too small", "too small to read")
      if (!(e.closest && e.closest('[data-qa-skip]'))) {
        var tilt = o.fs0 && o.fs < o.fs0 - .5 ? ' (' + o.fs0.toFixed(0) + ' px set, shrunk by a transform/tilt)' : '';
        if (o.fs < 14.5) add('err', 'tiny', 'text ' + o.fs.toFixed(1) + 'px on screen - below the 15 px floor' + tilt + ': ' + label, r);
        else if (o.fs < 17.5 && isSentence(o.svg ? e.textContent : ownText(e))) add('warn', 'small', 'reading text ' + o.fs.toFixed(1) + 'px on screen - sentences need >= 18 px' + tilt + ': ' + label, r);
      }
      // 3. SVG text vs its plate (smallest filled shape drawn before it that holds its centre)
      if (o.svg) {
        var best = null, ba = 1e12, ta = r.w * r.h;
        shapes.forEach(function (s) {
          if (!(s.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) return;
          if (s.closest('svg') !== e.closest('svg')) return;
          var tp = e.parentNode, tg = tp && tp.parentNode; if (s.parentNode !== tp && s.parentNode !== tg) return;   // a plate belongs to the text's own object (same group), not passing smoke or confetti
          var q = R(s.getBoundingClientRect()), a = q.w * q.h;
          if (q.l > r.cx || q.r < r.cx || q.t > r.cy || q.b < r.cy) return;
          if (a < ta * .9 || a > ta * 40 || a > PA * .08) return;
          var ox = Math.max(0, Math.min(q.r, r.r) - Math.max(q.l, r.l)), oy = Math.max(0, Math.min(q.b, r.b) - Math.max(q.t, r.t)); if (ox * oy < ta * .6) return;   // a shading patch under part of the word is not its plate
          if (a < ba) { ba = a; best = { s: s, q: q }; }
        });
        if (best) {
          var q = best.q, vt = o.fs * .14 + 1;
          var ov = Math.max(q.l - r.l, r.r - q.r, 0), ovv = Math.max(q.t - r.t - vt, r.b - q.b - vt, 0);
          if (ov > 1.5 || ovv > 1.5) add('err', 'plate', 'text spills off its plate by ' + Math.round(Math.max(ov, ovv)) + 'px: ' + label, r);
          else {
            var anc = getComputedStyle(e).textAnchor;
            if (anc === 'middle' && q.w < r.w * 3 && Math.abs(r.cx - q.cx) > Math.max(3, q.w * .04)) add('warn', 'centre', 'text off-centre on its plate by ' + Math.round(r.cx - q.cx) + 'px: ' + label, r);
            if (q.h < r.h * 2.6 && Math.abs(r.cy - q.cy) > q.h * .16 + 2) add('warn', 'vcentre', 'text not vertically centred on its plate (' + Math.round(r.cy - q.cy) + 'px): ' + label, r);
            if (anc !== 'middle' && q.w < r.w * 3 && Math.min(r.l - q.l, q.r - r.r) < 4) add('warn', 'pad', 'text touches its plate edge: ' + label, r);
          }
        }
      } else {
        // HTML text vs its own box / clipping ancestors
        var b = R(e.getBoundingClientRect());
        if (r.r > b.r + 3 || r.l < b.l - 3) add('err', 'spill', 'text spills out of its box: ' + label, r);
        for (var a2 = e; a2 && a2 !== post; a2 = a2.parentElement) {
          var cs = getComputedStyle(a2);
          if (cs.overflow !== 'visible' || cs.clipPath !== 'none') {
            var cb = R(a2.getBoundingClientRect()), ins = cs.clipPath !== 'none' ? Math.min(cb.w, cb.h) * .04 : 0;
            if (r.l < cb.l + ins - 1 || r.r > cb.r - ins + 1 || r.t < cb.t + ins - 1 || r.b > cb.b - ins + 1) { add('err', 'clip', 'text clipped by ' + nm(a2) + ': ' + label, r); break; }
          }
          var bg = cs.backgroundColor, hasBg = (bg && bg !== 'transparent' && !/,\s*0\)$/.test(bg)) || cs.backgroundImage !== 'none';
          if (hasBg && a2 !== e) {   // pill / card: text should sit inside the padding box with some air
            var pb = R(a2.getBoundingClientRect());
            if (pb.w < 700 && (r.l < pb.l + 3 || r.r > pb.r - 3) && !(r.r > pb.r + 1.5 || r.l < pb.l - 1.5)) add('warn', 'pad', 'text touches its pill edge: ' + label, r);
            break;
          }
        }
      }
      // 4. occlusion + busy art under plate-less text: sample the ink band; only points that really hit this text count
      var cov = 0, under = 0, N = 0, who = {}, uw = {}, ib = ink(o), curY = 0, cpts = [];
      function mine(h) { return h === e || e.contains(h) || (h !== post && h.contains && h.contains(e) && !o.svg); }
      function skip(h) {
        if (h === post || h === document.body || h === document.documentElement || h.tagName === 'svg' || h.tagName === 'CANVAS' || (h.classList && h.classList.contains('hb')) || (h.closest && h.closest('.hb'))) return true;
        if (h.contains && h.contains(e)) return true;   // an ancestor (e.g. its ::after glare) never covers its own text
        if (vis(h) < .08) return true;   // fully transparent (faded-out ghosts, hidden toasts) covers nothing
        if (h.closest && h.closest('[data-audit="overlay"]') && !(e.closest && e.closest('[data-audit="overlay"]'))) return true;
        if (h.namespaceURI !== 'http://www.w3.org/2000/svg' && h.tagName !== 'IMG' && h.tagName !== 'CANVAS') { var hc = getComputedStyle(h); if ((hc.backgroundColor === 'transparent' || /,\s*0\)$/.test(hc.backgroundColor)) && hc.backgroundImage === 'none' && hc.borderTopWidth === '0px' && hc.boxShadow === 'none') return true; }
        var hr = R(h.getBoundingClientRect()); if (hr.w > pr.w * .9 || hr.w * hr.h > PA * .25) return true;
        if (h.tagName !== 'IMG' && h.tagName !== 'image' && h.namespaceURI === 'http://www.w3.org/2000/svg' && paintedFill(h) < .35 && getComputedStyle(h).stroke === 'none') return true;
        if (h.tagName === 'text' || h.tagName === 'tspan') { var tt = h.tagName === 'tspan' ? h.closest('text') : h, m2 = tt.getScreenCTM(), f2 = parseFloat(getComputedStyle(tt).fontSize) * (m2 ? Math.sqrt(m2.a * m2.a + m2.b * m2.b) : 1), r2 = R(tt.getBoundingClientRect()); if (Math.abs(curY - r2.cy) > f2 * .37) return true; }
        return false;
      }
      var hasPlate = o.svg; if (!o.svg) for (var a5 = e; a5 && a5 !== post; a5 = a5.parentElement) { var c5 = getComputedStyle(a5), b5 = c5.backgroundColor; if ((b5 && b5 !== 'transparent' && !/,\s*0\)$/.test(b5)) || c5.backgroundImage !== 'none') { hasPlate = true; break; } }
      var NX = hasPlate ? 9 : Math.max(12, Math.round(ib.w / 5)), NY = hasPlate ? 3 : 4;   // plate-less text: dense grid so thin poles/ropes are caught
      // a click-transparent wrapper (pointer-events:none) hides this text AND its siblings from elementsFromPoint, so a
      // business card sliding over a swatch label inside the same desk passed (113, 2026-10-10). Make only this text's own
      // ancestor chain hittable while it is sampled: things inside that wrapper count again, decorative overlays elsewhere don't.
      var peFix = [];
      for (var a6 = e; a6 && a6 !== post.parentNode; a6 = a6.parentElement || a6.parentNode) {
        if (a6.style && a6.nodeType === 1 && getComputedStyle(a6).pointerEvents === 'none') { peFix.push([a6, a6.style.getPropertyValue('pointer-events'), a6.style.getPropertyPriority('pointer-events')]); a6.style.setProperty('pointer-events', 'auto', 'important'); }
      }
      for (var iy = 0; iy < NY; iy++) for (var ix = 0; ix < NX; ix++) {
        var x = ib.l + ib.w * (ix + .5) / NX, y = ib.t + ib.h * (.15 + iy * .7 / (NY - 1));
        if (x < pr.l || x > pr.r || y < pr.t || y > pr.b) continue;
        var st = document.elementsFromPoint(x, y), at = -1; curY = y;
        for (var k = 0; k < st.length; k++) if (mine(st[k])) { at = k; break; }
        if (at < 0) continue;
        N++;
        for (k = 0; k < at; k++) if (!skip(st[k]) && !mine(st[k])) { var hz = st[k].closest && st[k].closest('.nx') ? 'Nexi' : nm(st[k]); cov++; who[hz] = (who[hz] || 0) + 1; cpts.push([Math.round(x - pr.l), Math.round(y - pr.t)]); break; }
        for (k = at + 1; k < st.length; k++) if (!skip(st[k]) && !mine(st[k])) { uw[st[k].closest && st[k].closest('.nx') ? 'Nexi' : nm(st[k])] = 1; under++; break; }
      }
      peFix.forEach(function (q) { if (q[1]) q[0].style.setProperty('pointer-events', q[1], q[2]); else q[0].style.removeProperty('pointer-events'); });
      if (N && cov / N > .18) { add(cov / N > .4 ? 'err' : 'warn', 'covered', 'text ' + Math.round(cov / N * 100) + '% covered by ' + Object.keys(who).join(', ') + ': ' + label, r);
        var lastC = out[out.length - 1], tcs = getComputedStyle(e); lastC.pts = cpts; lastC.cell = [Math.max(4, ib.w / NX), Math.max(4, ib.h * .7)]; lastC.tcol = o.svg ? tcs.fill : tcs.color; }
      if (!hasPlate && N && (cov + under) / N > .03 && (cov + under) / N <= .25) add('warn', 'crossed', 'plate-less text crossed by art (' + Object.keys(who).concat(Object.keys(uw)).join(', ') + '): ' + label, r);
      if (!o.svg && N && under / N > .25) {
        var plate = false; for (var a3 = e; a3 && a3 !== post; a3 = a3.parentElement) { var c3 = getComputedStyle(a3), bg3 = c3.backgroundColor; if ((bg3 && bg3 !== 'transparent' && !/,\s*0\)$/.test(bg3)) || c3.backgroundImage !== 'none') { plate = true; break; } }
        if (!plate) add('warn', 'busy', 'plate-less text sits on artwork (' + Object.keys(uw).join(', ') + '): ' + label, r);
      }
    });
    // 5. text-on-text collisions (HTML and SVG together)
    for (var i = 0; i < T.length; i++) for (var j = i + 1; j < T.length; j++) {
      var A = T[i], B = T[j]; if (A.e.contains(B.e) || B.e.contains(A.e)) continue;
      var ga = A.e.closest('[data-qa-group]'), gb = B.e.closest('[data-qa-group]'); if (ga && ga === gb) continue;
      if (A.e.closest('[data-audit="overlay"]') || B.e.closest('[data-audit="overlay"]')) continue;
      var la = A.e.closest('[data-audit="layer"]'), lb = B.e.closest('[data-audit="layer"]'); if (la && la === lb) continue;
      if (inter(ink(A), ink(B), 1)) add('err', 'collide', 'text collides: "' + txt(A.e) + '" / "' + txt(B.e) + '"', { l: Math.min(A.r.l, B.r.l), t: Math.min(A.r.t, B.r.t), w: Math.max(A.r.r, B.r.r) - Math.min(A.r.l, B.r.l), h: Math.max(A.r.b, B.r.b) - Math.min(A.r.t, B.r.t) });
    }
    // 6. near-miss alignment between sibling labels of the same kind (stacked or in a row)
    var groups = {};
    [].forEach.call(post.querySelectorAll('[data-qa="text"]'), function (e) { if (vis(e) < .08) return; var k = (e.parentNode === post ? 'post' : nm(e.parentNode)) + '|' + (String(e.className.baseVal !== undefined ? e.className.baseVal : e.className).split(' ')[0]); (groups[k] = groups[k] || []).push(e); });
    Object.keys(groups).forEach(function (k) {
      var g = groups[k]; if (g.length < 2) return;
      for (var i2 = 0; i2 < g.length; i2++) for (var j2 = i2 + 1; j2 < g.length; j2++) {
        var a = R(g[i2].getBoundingClientRect()), b = R(g[j2].getBoundingClientRect());
        var stacked = a.l < b.r && b.l < a.r && !(a.t < b.b && b.t < a.b), row = a.t < b.b && b.t < a.b && !(a.l < b.r && b.l < a.r);
        var dl = Math.min(Math.abs(a.l - b.l), Math.abs(a.r - b.r)), dc = Math.abs(a.cx - b.cx), dt = Math.min(Math.abs(a.t - b.t), Math.abs(a.b - b.b)), dm = Math.abs(a.cy - b.cy);   // left, right or centre aligned all count
        if (stacked && Math.min(dl, dc) > 2.5 && Math.min(dl, dc) < 16) add('warn', 'align', 'stacked labels miss alignment by ' + Math.round(Math.min(dl, dc)) + 'px: "' + txt(g[i2]) + '" / "' + txt(g[j2]) + '"', { l: Math.min(a.l, b.l), t: Math.min(a.t, b.t), w: Math.max(a.r, b.r) - Math.min(a.l, b.l), h: Math.max(a.b, b.b) - Math.min(a.t, b.t) });
        if (row && Math.min(dt, dm) > 2.5 && Math.min(dt, dm) < 12) add('warn', 'align', 'labels in a row miss alignment by ' + Math.round(Math.min(dt, dm)) + 'px: "' + txt(g[i2]) + '" / "' + txt(g[j2]) + '"', { l: Math.min(a.l, b.l), t: Math.min(a.t, b.t), w: Math.max(a.r, b.r) - Math.min(a.l, b.l), h: Math.max(a.b, b.b) - Math.min(a.t, b.t) });
      }
    });
    // 6b. Nexi must stay visible (owner 2026-10-10 pointed at a toast sitting on Nexi): sample his body (box shrunk to the
    //     mascot) and flag any text box / card / window stacked on top of him
    [].forEach.call(post.querySelectorAll('.nx img'), function (im) {
      if (vis(im) < .3) return;
      var q = R(im.getBoundingClientRect()), l = q.l + q.w * .2, r2 = q.r - q.w * .2, t2 = q.t + q.h * .06, b2 = q.b - q.h * .04, hit = 0, n = 0, who = {};
      for (var iy = 0; iy < 6; iy++) for (var ix = 0; ix < 5; ix++) {
        var x = l + (r2 - l) * (ix + .5) / 5, y = t2 + (b2 - t2) * (iy + .5) / 6; if (x < pr.l || x > pr.r || y < pr.t || y > pr.b) continue; n++;
        var st = document.elementsFromPoint(x, y);
        for (var k = 0; k < st.length; k++) { var h = st[k]; if (h === im) break; var qa = h.closest && h.closest('[data-qa]'); if (qa && qa !== post && vis(qa) > .3 && !(h.closest('.hb'))) { var cs = getComputedStyle(h), own = [].some.call(h.childNodes, function (c) { return c.nodeType === 3 && c.nodeValue.trim(); }); if (h.namespaceURI !== 'http://www.w3.org/2000/svg' && !own && h.tagName !== 'IMG' && (cs.backgroundColor === 'transparent' || /,\s*0\)$/.test(cs.backgroundColor)) && cs.backgroundImage === 'none' && cs.borderTopWidth === '0px' && cs.boxShadow === 'none') continue; hit++; who[nm(h.closest('[data-qa]'))] = 1; break; } }
      }
      if (n && hit / n > .08) add(hit / n > .2 ? 'err' : 'warn', 'nexi', 'Nexi ' + Math.round(hit / n * 100) + '% covered by ' + Object.keys(who).join(', '), q);
      // 6c. her FACE must be clear (owner 2026-10-10, FB ad 3: two cards sat on a giant Nexi's visor while only a small
      //     share of her whole body was covered, so 6b stayed quiet). Dense samples on the head zone; 1 in 10 = error.
      var fl = q.l + q.w * .25, fr = q.r - q.w * .25, ft = q.t + q.h * .1, fb = q.t + q.h * .45, fh = 0, fn = 0, fwho = {};
      for (var jy = 0; jy < 5; jy++) for (var jx = 0; jx < 6; jx++) {
        var x2 = fl + (fr - fl) * (jx + .5) / 6, y2 = ft + (fb - ft) * (jy + .5) / 5; if (x2 < pr.l || x2 > pr.r || y2 < pr.t || y2 > pr.b) continue; fn++;
        var st2 = document.elementsFromPoint(x2, y2);
        for (var k2 = 0; k2 < st2.length; k2++) { var h2 = st2[k2]; if (h2 === im) break; var qa2 = h2.closest && h2.closest('[data-qa]'); if (qa2 && qa2 !== post && vis(qa2) > .3 && !(h2.closest('.hb'))) { var cs2 = getComputedStyle(h2), own2 = [].some.call(h2.childNodes, function (c) { return c.nodeType === 3 && c.nodeValue.trim(); }); if (h2.namespaceURI !== 'http://www.w3.org/2000/svg' && !own2 && h2.tagName !== 'IMG' && (cs2.backgroundColor === 'transparent' || /,\s*0\)$/.test(cs2.backgroundColor)) && cs2.backgroundImage === 'none' && cs2.borderTopWidth === '0px' && cs2.boxShadow === 'none') continue; fh++; fwho[nm(h2.closest('[data-qa]'))] = 1; break; } }
      }
      if (fn && fh / fn >= .1) add('err', 'face', "card / text on Nexi's face (" + Math.round(fh / fn * 100) + '% of the head zone): ' + Object.keys(fwho).join(', '), { l: fl, t: ft, w: fr - fl, h: fb - ft });
    });
    // 7. brand margin: logo row, headline and CTA share one left edge
    var lg = post.querySelector('.brand'), hh = post.querySelector('.hh'), bt = post.querySelector('.foot .btn');
    if (lg && hh && bt) { var xs = [lg, hh, bt].map(function (e) { return e.getBoundingClientRect().left; }); if (Math.max.apply(null, xs) - Math.min.apply(null, xs) > 2) add('warn', 'margin', 'logo / headline / CTA left edges differ: ' + xs.map(Math.round).join(', '), null); }
    // 8. icons + images cut by the frame edge (blurred depth props are exempt)
    [].forEach.call(post.querySelectorAll('img, svg image'), function (e) {
      if (vis(e) < .3) return; for (var a4 = e; a4 && a4 !== post; a4 = a4.parentNode) { var f = a4.style && a4.style.filter || ''; if (/blur/.test(f) || /blur/.test(getComputedStyle(a4).filter)) return; }
      if (e.closest('.hb')) return;
      var q = R(e.getBoundingClientRect()); if (q.w < 8) return;
      var vx = Math.max(0, Math.min(q.r, pr.r) - Math.max(q.l, pr.l)), vy = Math.max(0, Math.min(q.b, pr.b) - Math.max(q.t, pr.t)), f2 = vx * vy / (q.w * q.h);
      if (f2 > .05 && f2 < .9 && q.w * q.h < PA * .05) add('warn', 'cut', 'object cut by the frame edge (' + Math.round(f2 * 100) + '% visible): ' + (e.getAttribute('href') || e.getAttribute('src') || '').split('/').pop(), q);
    });
    // 9. a click-transparent wrapper (pointer-events:none) that holds readable text hides it from checks 3-6b: keep
    //    pointer-events:none for decoration only (glass, glare, sweeps, selection outlines), never on devices/windows/cards
    [].forEach.call(post.querySelectorAll('*'), function (e) {
      if (e === post || getComputedStyle(e).pointerEvents !== 'none') return;
      var pa = e.parentElement; if (pa && getComputedStyle(pa).pointerEvents === 'none') return;
      var t = [].filter.call(e.querySelectorAll('[data-qa="text"]'), function (x) { return vis(x) > .3; });
      if (t.length) add('warn', 'pe', 'pointer-events:none on ' + nm(e) + ' hides ' + t.length + ' text item(s) from the covered/collision checks - remove it unless it is pure decoration', R(e.getBoundingClientRect()));
    });
    // 10. CANVAS text (comic posters, scene labels): audit.py hooks fillText/strokeText before the page loads and clears the
    //     list right before the audited frame is drawn. Same rules as HTML text: on-screen size, frame, covered, collisions.
    var CV = (window.__cvText || []).filter(function (c) { return c.r[2] > pr.l && c.r[0] < pr.r && c.r[3] > pr.t && c.r[1] < pr.b; });
    var skipCv = window.TN_AUDIT_SKIP_CANVAS || [];   // page opt-out for pure decoration, e.g. ['!!', 'ZZZ']
    var cvFill = CV.filter(function (c) { return !c.stroke || !CV.some(function (d) { return d !== c && !d.stroke && d.t === c.t && Math.abs(d.r[0] - c.r[0]) < 3 && Math.abs(d.r[1] - c.r[1]) < 3; }); });
    cvFill.forEach(function (c) {
      if (skipCv.indexOf(c.t) >= 0 || /^[!?….\s]{1,3}$/.test(c.t)) return;   // reaction marks (! ?! ...) drawn by scene FX are decoration
      var q = R({ left: c.r[0], top: c.r[1], right: c.r[2], bottom: c.r[3], width: c.r[2] - c.r[0], height: c.r[3] - c.r[1] }), label = '"' + c.t.slice(0, 34) + '" (canvas)';
      if (c.r[0] < pr.l - 1 || c.r[2] > pr.r + 1 || c.r[1] < pr.t - 1 || c.r[3] > pr.b + 1) add('err', 'frame', 'text cut by the frame: ' + label, q, c.col || '?');
      if (c.fs < 14.5) add('err', 'tiny', 'text ' + c.fs.toFixed(1) + 'px on screen - below the 15 px floor: ' + label, q, c.col || '?');
      else if (c.fs < 17.5 && isSentence(c.t)) add('warn', 'small', 'reading text ' + c.fs.toFixed(1) + 'px on screen - sentences need >= 18 px: ' + label, q, c.col || '?');
      // covered by a DOM card / window / Nexi drawn over the canvas
      var hit = 0, n2 = 0, who2 = {};
      for (var yy = 0; yy < 2; yy++) for (var xx = 0; xx < 7; xx++) {
        var px = q.l + q.w * (xx + .5) / 7, py = q.t + q.h * (.3 + yy * .4); if (px < pr.l || px > pr.r || py < pr.t || py > pr.b) continue; n2++;
        var st3 = document.elementsFromPoint(px, py);
        for (var k3 = 0; k3 < st3.length; k3++) { var h3 = st3[k3]; if (h3.tagName === 'CANVAS') break; if (h3 === post || h3 === document.body || h3 === document.documentElement || (h3.closest && h3.closest('.hb')) || vis(h3) < .08) continue;
          var c3 = getComputedStyle(h3); if (h3.namespaceURI !== 'http://www.w3.org/2000/svg' && h3.tagName !== 'IMG' && (c3.backgroundColor === 'transparent' || /,\s*0\)$/.test(c3.backgroundColor)) && c3.backgroundImage === 'none' && c3.borderTopWidth === '0px' && !([].some.call(h3.childNodes, function (z) { return z.nodeType === 3 && z.nodeValue.trim(); }))) continue;
          if (h3.namespaceURI === 'http://www.w3.org/2000/svg' && h3.tagName !== 'image' && paintedFill(h3) < .35) continue;
          hit++; who2[h3.closest && h3.closest('.nx') ? 'Nexi' : nm(h3)] = 1; break; }
      }
      if (n2 && hit / n2 > .18) add(hit / n2 > .4 ? 'err' : 'warn', 'covered', 'text ' + Math.round(hit / n2 * 100) + '% covered by ' + Object.keys(who2).join(', ') + ': ' + label, q);
      // collides with HTML/SVG text
      T.forEach(function (o) { if (inter(ink(o), { l: q.l, r: q.r, t: q.t + q.h * .15, b: q.b - q.h * .15 }, 1)) add('err', 'collide', 'text collides: ' + label + ' / "' + txt(o.e) + '"', q); });
    });
    for (var ci = 0; ci < cvFill.length; ci++) for (var cj = ci + 1; cj < cvFill.length; cj++) {
      var A2 = cvFill[ci], B2 = cvFill[cj]; if (A2.t === B2.t && Math.abs(A2.r[0] - B2.r[0]) < 3 && Math.abs(A2.r[1] - B2.r[1]) < 3) continue;
      var ia = { l: A2.r[0], r: A2.r[2], t: A2.r[1] + (A2.r[3] - A2.r[1]) * .15, b: A2.r[3] - (A2.r[3] - A2.r[1]) * .15 }, ib2 = { l: B2.r[0], r: B2.r[2], t: B2.r[1] + (B2.r[3] - B2.r[1]) * .15, b: B2.r[3] - (B2.r[3] - B2.r[1]) * .15 };
      if (inter(ia, ib2, 1)) add('err', 'collide', 'canvas text collides: "' + A2.t.slice(0, 30) + '" / "' + B2.t.slice(0, 30) + '"', { l: Math.min(ia.l, ib2.l), t: Math.min(ia.t, ib2.t), w: Math.max(ia.r, ib2.r) - Math.min(ia.l, ib2.l), h: Math.max(ia.b, ib2.b) - Math.min(ia.t, ib2.t) });
    }
    // 11. LAYERING: a device / window / big card covering part of another one's controls (post 114, 2026-10-10: the
    //     middle phone hid the side phones' "Track order" / "Pay now" buttons while every word stayed readable, so the
    //     covered-text check passed). Containers = outermost boxes with a fill, rounded corners, >= 60k px2, holding text.
    var pe2 = document.createElement('style'); pe2.textContent = '*{pointer-events:auto!important}'; document.head.appendChild(pe2);
    try {
      var hasFill = function (cs) { var b = cs.backgroundColor; return (b && b !== 'transparent' && !/,\s*0\)$/.test(b)) || cs.backgroundImage !== 'none'; };
      var boxes = [].filter.call(post.querySelectorAll('*'), function (e) {
        if (e.closest('[data-audit="skip"],[data-audit="overlay"]') || vis(e) < .3 || e.namespaceURI === 'http://www.w3.org/2000/svg') return false;
        var cs = getComputedStyle(e); if (!hasFill(cs) || (parseFloat(cs.borderTopLeftRadius) || 0) < 8) return false;
        var q = e.getBoundingClientRect(), A = q.width * q.height; if (A < 60000 || A > PA * .55) return false;
        return (e.textContent || '').trim().length > 8;
      });
      boxes = boxes.filter(function (e) { return !boxes.some(function (o) { return o !== e && o.contains(e); }); });
      for (var bi = 0; bi < boxes.length; bi++) for (var bj = bi + 1; bj < boxes.length; bj++) {
        var BA = boxes[bi], BB = boxes[bj], qa = R(BA.getBoundingClientRect()), qb = R(BB.getBoundingClientRect());
        var ox = { l: Math.max(qa.l, qb.l), t: Math.max(qa.t, qb.t), r: Math.min(qa.r, qb.r), b: Math.min(qa.b, qb.b) };
        if (ox.r - ox.l < 6 || ox.b - ox.t < 6) continue;
        var top = null, st4 = document.elementsFromPoint((ox.l + ox.r) / 2, (ox.t + ox.b) / 2);
        for (var k4 = 0; k4 < st4.length; k4++) { if (BA.contains(st4[k4])) { top = BA; break; } if (BB.contains(st4[k4])) { top = BB; break; } }
        if (!top) continue;
        var low = top === BA ? BB : BA;
        // controls of the lower box that reach into the overlap: text hosts and filled pills/buttons
        [].forEach.call(low.querySelectorAll('*'), function (e) {
          if (vis(e) < .3) return;
          var own = [].some.call(e.childNodes, function (z) { return z.nodeType === 3 && z.nodeValue.trim(); }), cs = getComputedStyle(e);
          var pill = hasFill(cs) && (parseFloat(cs.borderTopLeftRadius) || 0) >= 4 && (e.textContent || '').trim().length > 0;
          if (!own && !pill) return;
          var q = R(e.getBoundingClientRect()); if (q.w < 4 || q.h < 4 || q.w * q.h > 60000) return;
          var ix2 = Math.min(q.r, ox.r) - Math.max(q.l, ox.l), iy2 = Math.min(q.b, ox.b) - Math.max(q.t, ox.t); if (ix2 < 6 || iy2 < 6) return;
          var vis2 = 0, n4 = 0;
          for (var sy = 0; sy < 3; sy++) for (var sx = 0; sx < 6; sx++) { var X = q.l + q.w * (sx + .5) / 6, Y = q.t + q.h * (sy + .5) / 3; if (X < pr.l || X > pr.r || Y < pr.t || Y > pr.b) continue; n4++; var s5 = document.elementsFromPoint(X, Y); for (var k5 = 0; k5 < s5.length; k5++) { if (low.contains(s5[k5])) { vis2++; break; } if (top.contains(s5[k5])) break; } }
          if (!n4) return; var f = vis2 / n4;
          if (f > .05 && f < .95) add((pill && f < .9) || (own && f < .6) ? 'err' : 'warn', 'layer', nm(top) + ' covers ' + Math.round((1 - f) * 100) + '% of a control in ' + nm(low) + ': "' + txt(e) + '"', q);
        });
      }
    } finally { pe2.remove(); }
    // 12-19. OBJECT LAYERING v3 (owner 2026-10-11 after 9 FB ads passed CLEAN: "properly audit the images, theres alot of
    //     layering and overflow text"): deco, edge-cut, face, cursor, contain, float, stack, line + the odoo-facts lint
    try { layering3(post, pr, PA, T, add); } catch (x) { add('warn', 'js', 'layering v3 checks crashed: ' + x, null); }
    // de-duplicate
    var seen2 = {}; return out.filter(function (x) { var k = x.kind + x.msg; if (seen2[k]) return false; seen2[k] = 1; return true; });
  }
  /* ---------------------------------------------------------------------------------------------------------------
     LAYERING v3 (2026-10-11). Why the old checks missed the 9 FB-ad faults:
       - workspace props (desk, plant, mouse, rug) live in SVG layers marked data-audit="skip" and decorations (.fxs orbs,
         .fxi icons, cursors) carry pointer-events:none, so elementsFromPoint and vis() never saw them;
       - scene sparkles / planes / hearts are CANVAS shapes (no DOM node at all);
       - [face] only counted elements inside [data-qa] (cards/text) in a fixed 25-75 % x 10-45 % zone of the PNG box;
       - [covered] needs > 18 % of a word covered, a pin or a cursor tip covers less; [layer] only compares boxes >= 60k px2.
     So these checks build their OWN inventory (ignoring data-audit="skip" for geometry, never for text), read Nexi's real
     silhouette from her PNG alpha, read canvas shapes from the fill/stroke hook in audit.py, and force pointer-events on
     while they hit-test. Severity: a fault on a physical device / prop / Nexi / CTA = error; on a floating UI card = warn. */
  function bgA(c) { if (!c || c === 'transparent') return 0; var m = c.match(/rgba?\(([^)]+)\)/); if (!m) return 1; var p = m[1].split(/[ ,\/]+/).filter(Boolean); return p.length > 3 ? parseFloat(p[3]) : 1; }
  function lumOf(c) { var m = (c || '').match(/rgba?\(([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)/); if (!m) return 1; var v = [m[1], m[2], m[3]].map(function (x) { x = x / 255; return x <= .03928 ? x / 12.92 : Math.pow((x + .055) / 1.055, 2.4); }); return .2126 * v[0] + .7152 * v[1] + .0722 * v[2]; }
  function vis2(e) { var a = 1; for (var n = e; n && n.nodeType === 1; n = n.parentNode) { var cs = getComputedStyle(n); if (cs.display === 'none' || cs.visibility === 'hidden') return 0; a *= parseFloat(cs.opacity || 1); if (n.tagName === 'section') break; } return a; }
  function B(l, t, r, b) { return { l: l, t: t, r: r, b: b, w: r - l, h: b - t, cx: (l + r) / 2, cy: (t + b) / 2 }; }
  function grow(b, d) { return B(b.l - d, b.t - d, b.r + d, b.b + d); }
  function ovl(a, b) { return { x: Math.min(a.r, b.r) - Math.max(a.l, b.l), y: Math.min(a.b, b.b) - Math.max(a.t, b.t) }; }
  function uni(a, b) { return a ? B(Math.min(a.l, b.l), Math.min(a.t, b.t), Math.max(a.r, b.r), Math.max(a.b, b.b)) : b; }
  var SVGNS = 'http://www.w3.org/2000/svg';
  function layering3(post, pr, PA, T, add) {
    var styleTag = document.createElement('style'); styleTag.textContent = '*{pointer-events:auto!important}'; document.head.appendChild(styleTag);
    try { return run(); } finally { styleTag.remove(); }
    function run() {
    var W = pr.w, Hh = pr.h;
    function bx(e) { return R(e.getBoundingClientRect()); }
    function inPost(b) { return b.r > pr.l && b.l < pr.r && b.b > pr.t && b.t < pr.b; }
    var DECO_RE = /(^|\s)(fxs|fxb|fxi)(\s|$)/, CUR_SEL = '.ou-cur, .cursor, [class*="cursor"], [data-cursor]';
    function isDeco(e) { return e.nodeType === 1 && DECO_RE.test(e.getAttribute('class') || ''); }
    // ink band of EVERY line of a text (ink() is one band through the middle of a multi-line block - a pin on line 1 missed it)
    function lineInks(o) {
      if (o.svg) return [ink(o)];
      var out2 = [], f = o.fs * .37;
      [].forEach.call(o.e.childNodes, function (z) { if (z.nodeType !== 3 || !z.nodeValue.trim()) return; var rg = document.createRange(); rg.selectNodeContents(z);
        [].forEach.call(rg.getClientRects(), function (q) { if (q.width < 2 || q.height < 2) return; var c = q.top + q.height / 2, h = Math.min(q.height / 2, f); out2.push(B(q.left, c - h, q.right, c + h)); }); });
      return out2.length ? out2 : [ink(o)];
    }
    // ---------- Nexi silhouettes (PNG alpha on a 4 px grid) ----------
    var NX = [];
    [].forEach.call(post.querySelectorAll('img'), function (im) {
      if (!(im.closest('.nx') || /(^|\/)nexi[-_][^\/]*\.png/i.test(im.getAttribute('src') || '') || im.getAttribute('alt') === 'Nexi')) return;   // HB.nexi or a Nexi PNG placed directly (TV-Nexi, ad5)
      if (vis2(im) < .3 || !im.naturalWidth) return;
      var q = R(im.getBoundingClientRect()); if (q.w < 24 || !inPost(q)) return;
      var C = 4, cw = Math.max(2, Math.round(q.w / C)), ch = Math.max(2, Math.round(q.h / C)), cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
      var g = cv.getContext('2d'), tf = getComputedStyle(im).transform, flip = false;
      try { flip = tf !== 'none' && new DOMMatrix(tf).a < 0; } catch (x) {}
      if (flip) { g.translate(cw, 0); g.scale(-1, 1); }
      var d; try { g.drawImage(im, 0, 0, cw, ch); d = g.getImageData(0, 0, cw, ch).data; } catch (x) { return; }
      var mask = new Uint8Array(cw * ch), lab = new Int32Array(cw * ch), n = 0;
      for (var i = 0; i < cw * ch; i++) if (d[i * 4 + 3] > 110) { mask[i] = 1; n++; }
      if (n < 20) return;
      var comps = [], id = 0;
      for (var s = 0; s < cw * ch; s++) {
        if (!mask[s] || lab[s]) continue; id++; var st = [s], cnt = 0, bb = { l: 1e9, t: 1e9, r: -1, b: -1 }; lab[s] = id;
        while (st.length) { var k = st.pop(), x = k % cw, y = (k - x) / cw; cnt++; bb.l = Math.min(bb.l, x); bb.r = Math.max(bb.r, x); bb.t = Math.min(bb.t, y); bb.b = Math.max(bb.b, y);
          for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var X = x + dx, Y = y + dy; if (X < 0 || Y < 0 || X >= cw || Y >= ch) continue; var kk = Y * cw + X; if (mask[kk] && !lab[kk]) { lab[kk] = id; st.push(kk); } } }
        comps.push({ id: id, n: cnt, cb: bb });
      }
      comps.sort(function (a, b) { return b.n - a.n; });
      var sx = q.w / cw, sy = q.h / ch;
      function scr(cb) { return B(q.l + cb.l * sx, q.t + cb.t * sy, q.l + (cb.r + 1) * sx, q.t + (cb.b + 1) * sy); }
      var main = comps[0], parts = comps.filter(function (c) { return c !== main && c.n >= n * .004 && c.n < n * .15; });
      // head = main component above the neck (narrowest row between 30 % and 70 % of its height)
      var wrow = [], y0 = main.cb.t, y1 = main.cb.b;
      for (var y = y0; y <= y1; y++) { var w = 0; for (var x = main.cb.l; x <= main.cb.r; x++) if (lab[y * cw + x] === main.id) w++; wrow.push(w); }
      var nk = y1, best = 1e9;
      for (var yy = Math.round(y0 + (y1 - y0) * .3); yy <= Math.round(y0 + (y1 - y0) * .7); yy++) { var ww = wrow[yy - y0]; if (ww < best) { best = ww; nk = yy; } }
      var hb = { l: 1e9, t: 1e9, r: -1, b: -1 };
      for (y = y0; y < nk; y++) for (x = main.cb.l; x <= main.cb.r; x++) if (lab[y * cw + x] === main.id) { hb.l = Math.min(hb.l, x); hb.r = Math.max(hb.r, x); hb.t = Math.min(hb.t, y); hb.b = Math.max(hb.b, y); }
      var all = { l: 1e9, t: 1e9, r: -1, b: -1 }; comps.forEach(function (c) { if (c.n < n * .004) return; all.l = Math.min(all.l, c.cb.l); all.r = Math.max(all.r, c.cb.r); all.t = Math.min(all.t, c.cb.t); all.b = Math.max(all.b, c.cb.b); });
      NX.push({ im: im, wrap: im.closest('.nx'), q: q, cw: cw, ch: ch, sx: sx, sy: sy, mask: mask, lab: lab, n: n, main: main, parts: parts.map(function (c) { return { c: c, b: scr(c.cb) }; }),
        head: hb.r >= 0 ? scr(hb) : null, box: scr(all),
        at: function (X, Y) { var i2 = Math.floor((X - q.l) / sx), j2 = Math.floor((Y - q.t) / sy); return i2 >= 0 && j2 >= 0 && i2 < cw && j2 < ch && mask[j2 * cw + i2] === 1; },
        near: function (X, Y, r) { for (var a = -r; a <= r; a += sx) for (var b = -r; b <= r; b += sy) if (this.at(X + a, Y + b)) return true; return false; },
        cellsIn: function (b, compId) { var c = 0, t = 0; for (var j = Math.max(0, Math.floor((b.t - q.t) / sy)); j < Math.min(ch, Math.ceil((b.b - q.t) / sy)); j++) for (var i3 = Math.max(0, Math.floor((b.l - q.l) / sx)); i3 < Math.min(cw, Math.ceil((b.r - q.l) / sx)); i3++) { var kk = j * cw + i3; if (mask[kk] && (compId == null || lab[kk] === compId)) c++; } return c; } });
    });
    function nexiOf(h) { for (var i = 0; i < NX.length; i++) if (NX[i].im === h) return NX[i]; return null; }
    // ---------- opacity / visibility at a point ----------
    function opaqueAt(h, x, y) {
      if (h === post || h === document.body || h === document.documentElement) return true;
      var nx = nexiOf(h); if (nx) return nx.at(x, y);
      if (h.tagName === 'CANVAS' || (h.closest && h.closest('.hb'))) return false;
      if (vis2(h) < .5) return false;
      if (h.namespaceURI === SVGNS) { if (h.tagName === 'svg' || h.tagName === 'g' || h.tagName === 'text' || h.tagName === 'tspan') return false; return h.tagName === 'image' || svgSolid(h); }
      if (h.tagName === 'IMG' || h.tagName === 'VIDEO') return true;
      var hr = h.getBoundingClientRect(); if (hr.width >= W * .9 && hr.height >= Hh * .5) return false;   // full-frame layers (grid, sweep, wrappers)
      var cs = getComputedStyle(h); return bgA(cs.backgroundColor) >= .5 || (gradOpaque(cs.backgroundImage) && !/blur/.test(cs.filter));
    }
    var urlOp = {};
    function urlOpaque(id) {   // is an SVG paint server solid? gradients: every stop >= .9 opaque; patterns: a full-size solid backing rect
      if (id in urlOp) return urlOp[id]; urlOp[id] = false; var el = document.getElementById(id); if (!el) return false;
      var res = false;
      if (/gradient/i.test(el.tagName)) { var g = el, stops = []; for (var k = 0; k < 4 && g && !stops.length; k++) { stops = [].slice.call(g.querySelectorAll('stop')); if (!stops.length) { var hr = g.getAttribute('href') || g.getAttribute('xlink:href'); g = hr ? document.getElementById(hr.slice(1)) : null; } }
        res = stops.length > 0 && stops.every(function (st) { var cs = getComputedStyle(st); return parseFloat(cs.stopOpacity) >= .9 && bgA(cs.stopColor) >= .9; }); }
      else if (/pattern/i.test(el.tagName)) { var pw = parseFloat(el.getAttribute('width')) || 0, ph = parseFloat(el.getAttribute('height')) || 0;
        res = [].some.call(el.querySelectorAll('rect'), function (r) { var f = r.getAttribute('fill') || ''; return (parseFloat(r.getAttribute('width')) || 0) >= pw * .99 && (parseFloat(r.getAttribute('height')) || 0) >= ph * .99 && parseFloat(r.getAttribute('opacity') || 1) >= .9 && (/^url\(#/.test(f) ? urlOpaque(f.slice(5, -1)) : !!f && f !== 'none' && bgA(getComputedStyle(r).fill) >= .9); }); }
      return (urlOp[id] = res);
    }
    function svgSolid(h) { var cs = getComputedStyle(h), f = cs.fill || ''; if (/^url/.test(f)) { var id = (f.match(/#([^"')]+)/) || [])[1]; return !!id && urlOpaque(id) && parseFloat(cs.fillOpacity || 1) >= .9; } return paintedFill(h) >= .5; }
    function gradOpaque(bi) { if (bi === 'none') return false; if (/url\(/.test(bi)) return true; if (/transparent/.test(bi)) return false; var m = bi.match(/rgba\([^)]*\)/g) || []; return !m.some(function (c) { return bgA(c) < .5; }); }
    function stackAt(x, y) { return (x < pr.l || x > pr.r || y < pr.t || y > pr.b) ? [] : document.elementsFromPoint(x, y); }
    function visibleAt(el, x, y) { var st = stackAt(x, y); for (var k = 0; k < st.length; k++) { var h = st[k]; if (h === el || (el.contains && el.contains(h))) return true; if (opaqueAt(h, x, y)) return false; } return false; }
    function grid(b, nx, ny, fn) { var c = 0; for (var j = 0; j < ny; j++) for (var i = 0; i < nx; i++) { var x = b.l + b.w * (i + .5) / nx, y = b.t + b.h * (j + .5) / ny; if (fn(x, y)) c++; } return c; }
    // ---------- inventory: DOM roots (devices, windows, notes, pins), SVG props, CTA ----------
    function painted(e, cs) { cs = cs || getComputedStyle(e); return bgA(cs.backgroundColor) >= .3 || cs.backgroundImage !== 'none' || e.tagName === 'IMG' || e.tagName === 'VIDEO' || (parseFloat(cs.borderTopWidth) >= 1 && bgA(cs.borderTopColor) > .3); }
    var SKIPROOT = /(^|\s)(hb|sk-grid|sk-sweep|brand|hw|foot|nx|nxs|fxs|fxb|fxi)(\s|$)/;
    var roots = [];
    (function walk(par) {
      [].forEach.call(par.children, function (e) {
        if (e.namespaceURI === SVGNS || /^(CANVAS|SCRIPT|STYLE|LINK)$/.test(e.tagName)) return;
        if (SKIPROOT.test(e.getAttribute('class') || '') || /^(skip|overlay)$/.test(e.getAttribute('data-audit') || '') || vis2(e) < .3) return;
        var r = e.getBoundingClientRect(); if (r.width < 4 || r.height < 4) { if (e.children.length) walk(e); return; }
        if (r.width * r.height > PA * .55 || r.width >= W * .9) { walk(e); return; }
        roots.push(e);
      });
    })(post);
    function extentOf(root) {
      var ext = null, dark = 0, text = false;
      (function rec(e, clip) {
        if (e.nodeType !== 1 || e.namespaceURI === SVGNS && e.tagName !== 'svg') return;
        if (e !== root && (isDeco(e) || e.matches('.nx, .nxs, ' + CUR_SEL) || /^(skip|overlay)$/.test(e.getAttribute('data-audit') || ''))) return;
        var cs = getComputedStyle(e); if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) < .05) return;
        var b = bx(e);
        if (clip) b = B(Math.max(b.l, clip.l), Math.max(b.t, clip.t), Math.min(b.r, clip.r), Math.min(b.b, clip.b));
        if (b.w > 1 && b.h > 1 && (painted(e, cs) || e.tagName === 'svg')) { ext = uni(ext, b); if (bgA(cs.backgroundColor) >= .9 && lumOf(cs.backgroundColor) < .1) dark = Math.max(dark, b.w * b.h); }
        if (!text && [].some.call(e.childNodes, function (z) { return z.nodeType === 3 && z.nodeValue.trim(); })) text = true;
        var nc = cs.overflow !== 'visible' ? (clip ? B(Math.max(b.l, clip.l), Math.max(b.t, clip.t), Math.min(b.r, clip.r), Math.min(b.b, clip.b)) : bx(e)) : clip;
        if (e.tagName !== 'svg') [].forEach.call(e.children, function (c) { rec(c, nc); });
      })(root, null);
      return ext ? { ext: ext, dark: dark, text: text } : null;
    }
    var DEV_RE = /(^|[\s_-])(dev|ws-mon|mon|monitor|tv|tvs|lap|laptop|phone|ph|tab|tablet|scr)\d*($|[\s_-])/;
    var OBJ = [];
    roots.forEach(function (e) {
      var x = extentOf(e); if (!x || x.ext.w * x.ext.h < 120) return;
      var A = x.ext.w * x.ext.h;
      OBJ.push({ el: e, name: nm(e), ext: x.ext, kind: 'dom', ui: x.text || !!e.querySelector('[data-qa]'), device: DEV_RE.test(e.getAttribute('class') || '') || x.dark >= A * .45, area: A });
    });
    // SVG props: outermost <g transform="translate(..)"> of a full-frame SVG layer (WS.plant/mug/mouse, DT.potplant ...)
    function shadowFill(s) { var f = getComputedStyle(s).fill || ''; var id = (f.match(/#([^"')]+)/) || [])[1] || ''; return /(^|-)(sh|shadow|light|glow|spot|lamp|sun)\d*$|-sh\d|shadow|glow/.test(id); }
    function leafExt(g) { var ext = null; [].forEach.call(g.querySelectorAll('path, rect, circle, ellipse, polygon, polyline, line, image, use'), function (s) {
      if (vis2(s) < .3) return; var cs = getComputedStyle(s), solid = paintedFill(s) >= .5 && !shadowFill(s), str = cs.stroke !== 'none' && parseFloat(cs.strokeWidth) >= 2 && parseFloat(cs.strokeOpacity || 1) >= .5;
      if (!solid && !str && s.tagName !== 'image') return; var b = bx(s); if (b.w < 1 && b.h < 1) return; ext = uni(ext, b); }); return ext; }
    var svgLayers = [].filter.call(post.querySelectorAll('svg'), function (s) { var r = s.getBoundingClientRect(); return r.width >= W * .9 && vis2(s) > .3 && !s.closest('.nx'); });
    var propGs = [];
    svgLayers.forEach(function (s) { [].forEach.call(s.querySelectorAll('g[transform]'), function (g) {
      if (g.closest('defs, symbol, pattern, mask, clipPath, marker') || !/translate/.test(g.getAttribute('transform'))) return;
      var e2 = leafExt(g); if (!e2) return; var A = e2.w * e2.h; if (A < 500 || A > PA * .06 || e2.w > W * .6) return;
      propGs.push({ el: g, ext: e2 }); }); });
    propGs = propGs.filter(function (p) { return !propGs.some(function (o) { return o !== p && o.el.contains(p.el); }); });
    propGs.forEach(function (p) { OBJ.push({ el: p.el, name: 'svg prop at ' + Math.round(p.ext.l - pr.l) + ',' + Math.round(p.ext.t - pr.t) + ' (' + Math.round(p.ext.w) + 'x' + Math.round(p.ext.h) + ')', ext: p.ext, kind: 'prop', ui: false, device: false, area: p.ext.w * p.ext.h }); });
    var cta = post.querySelector('.foot .btn'), ctaB = cta && vis2(cta) > .3 ? bx(cta) : null;
    // ---------- deco: brand-skin shapes (DOM) + solid canvas shapes from the fill hook ----------
    var DECO = [];
    [].forEach.call(post.querySelectorAll('.fxs, .fxb, .fxi'), function (e) { if (vis2(e) < .15) return; var b = bx(e); if (b.w < 6 || !inPost(b)) return;
      var c = (e.getAttribute('class') || '').match(/fx-(\w+)/); DECO.push({ el: e, hit: e, b: b, name: (e.classList.contains('fxi') ? 'blurred app icon (.fxi)' : e.classList.contains('fxb') ? 'bokeh (.fxb)' : 'brand ' + (c ? c[1] : 'shape') + ' (.fxs)') + ' at ' + Math.round(b.l - pr.l) + ',' + Math.round(b.t - pr.t) }); });
    var CVS = (window.__cvShapes || []).filter(function (s) { return s.cv && s.cv.isConnected && post.contains(s.cv) && !s.cv.closest('.hb') && vis2(s.cv) > .3; });
    CVS.forEach(function (s) {
      if (!(s.k === 'fill' || s.k === 'img') || !s.solid || s.a < .45 || s.blur) return;
      var b = B(s.r[0], s.r[1], s.r[2], s.r[3]); if (b.w * b.h < 36 || b.w * b.h > PA * .02 || !inPost(b)) return;
      DECO.push({ el: s.cv, hit: s.cv, b: b, name: 'canvas ' + (s.k === 'img' ? 'icon' : 'shape') + ' ' + Math.round(b.w) + 'x' + Math.round(b.h) + (s.col ? ' ' + s.col : ''), cv: true });
    });
    function objName(o) { return o.kind === 'prop' ? o.name : (o.device ? 'device ' : '') + o.name; }
    // ---------- 12. [deco] brand decoration overlapping / peeking out behind a device, prop, Nexi or the CTA ----------
    var targets = OBJ.slice(); if (ctaB) targets.push({ el: cta, name: 'the CTA button', ext: ctaB, kind: 'cta', device: false });
    NX.forEach(function (nx) { targets.push({ el: nx.im, name: 'Nexi', ext: nx.box, kind: 'nexi', nx: nx }); });
    function objAt(O, x, y) {
      if (O.nx) return O.nx.at(x, y);
      var st = stackAt(x, y); for (var k = 0; k < st.length; k++) { var h = st[k]; if ((O.el === h || O.el.contains(h)) && (opaqueAt(h, x, y) || (h.namespaceURI === SVGNS && /^(path|rect|circle|ellipse|polygon|polyline|line|use|image)$/.test(h.tagName)))) return true; }
      return false;
    }
    function contact(D, O) {
      var rg = B(Math.max(D.b.l, O.ext.l - 6), Math.max(D.b.t, O.ext.t - 6), Math.min(D.b.r, O.ext.r + 6), Math.min(D.b.b, O.ext.b + 6)); if (rg.w <= 0 || rg.h <= 0) return false;
      var step = Math.max(3, Math.sqrt(rg.w * rg.h / 400));
      for (var y = rg.t + step / 2; y < rg.b; y += step) for (var x = rg.l + step / 2; x < rg.r; x += step) {
        if (!visibleAt(D.hit, x, y)) continue;
        if (objAt(O, x, y) || objAt(O, x + 4, y) || objAt(O, x - 4, y) || objAt(O, x, y + 4) || objAt(O, x, y - 4)) return true;
      }
      return false;
    }
    var decoHits = {};
    DECO.forEach(function (D) {
      targets.forEach(function (O) {
        if (O.el.contains(D.el) || D.el.contains(O.el)) return;
        var isCta = O.kind === 'cta', o = ovl(D.b, isCta ? grow(O.ext, 24) : O.ext); if (o.x <= 4 || o.y <= 4) return;   // the CTA keeps 24 px of clear air
        if (O.nx && O.nx.cellsIn(grow(D.b, 2)) < 2) return;
        if (isCta) { var zone = grow(O.ext, 24), seen = grid(D.b, 7, 7, function (x, y) { return x >= zone.l && x <= zone.r && y >= zone.t && y <= zone.b && visibleAt(D.hit, x, y); }); if (seen < (D.cv ? 1 : 2)) return; }
        else if (!contact(D, O)) return;   // real contact: a visible deco pixel within 4 px of the object's painted pixels (boxes of rotated pills and round props are mostly air)
        var err = !D.cv && (O.kind === 'prop' || O.kind === 'cta' || O.device);   // canvas sprinkles and deco against Nexi or a floating UI card: warning
        var key = D.name + '|' + O.name; if (decoHits[key]) return; decoHits[key] = 1;
        var c = { x: (Math.max(D.b.l, O.ext.l) + Math.min(D.b.r, O.ext.r)) / 2, y: (Math.max(D.b.t, O.ext.t) + Math.min(D.b.b, O.ext.b)) / 2 }, st = stackAt(c.x, c.y), behind = false;
        for (var k = 0; k < st.length; k++) { if (st[k] === D.hit || D.hit.contains(st[k])) break; if (O.el === st[k] || O.el.contains(st[k])) { behind = true; break; } }
        add(err ? 'err' : 'warn', 'deco', D.name + (behind ? ' peeks out from behind ' : isCta && ovl(D.b, O.ext).x <= 0 || isCta && ovl(D.b, O.ext).y <= 0 ? ' crowds (< 24 px) ' : ' sits on ') + objName(O) + ' - brand decoration belongs in empty background, 24 px clear of devices, props, Nexi, text and the CTA', uni(D.b, B(Math.max(D.b.l, O.ext.l), Math.max(D.b.t, O.ext.t), Math.min(D.b.r, O.ext.r), Math.min(D.b.b, O.ext.b))));
      });
    });
    // ---------- 13. [edge-cut] objects cut by / touching the frame (< 8 px = error, < 24 px = warning) or by the CTA ----------
    var edgeObjs = OBJ.filter(function (o) { return o.ext.w < W * .85 && o.ext.h < Hh * .85; }).map(function (o) { return { name: objName(o), ext: o.ext, el: o.el }; });
    NX.forEach(function (nx) { edgeObjs.push({ name: 'Nexi (incl. her hands)', ext: nx.box, el: nx.im, nx: nx }); });
    edgeObjs.forEach(function (o) {
      var e = o.ext, d = Math.min(e.l - pr.l, pr.r - e.r, e.t - pr.t, pr.b - e.b);
      var side = d === e.l - pr.l ? 'left' : d === pr.r - e.r ? 'right' : d === e.t - pr.t ? 'top' : 'bottom';
      if (d < 8) add('err', 'edge-cut', o.name + (d < 0 ? ' is cut by the ' + side + ' frame edge (' + Math.round(-d) + ' px outside)' : ' touches the ' + side + ' frame edge (' + Math.round(d) + ' px)') + ' - keep objects whole, 24 px inside', e);
      else if (d < 24) add('warn', 'edge-cut', o.name + ' is only ' + Math.round(d) + ' px from the ' + side + ' frame edge (keep 24 px)', e);
      if (ctaB && !o.el.contains(cta)) {
        var ov = ovl(e, ctaB);
        if (ov.x > 3 && ov.y > 3 && (!o.nx || o.nx.cellsIn(ctaB) >= 2)) add('err', 'edge-cut', o.name + ' is cut by the CTA plate (' + Math.round(ov.x) + 'x' + Math.round(ov.y) + ' px under it) - give the CTA clear space', B(Math.max(e.l, ctaB.l), Math.max(e.t, ctaB.t), Math.min(e.r, ctaB.r), Math.min(e.b, ctaB.b)));
      }
    });
    // ---------- 14. [face] anything touching Nexi's HEAD (her real silhouette above the neck) ----------
    NX.forEach(function (nx) {
      if (!nx.head) return;
      var H = grow(nx.head, 3), HA = nx.head.w * nx.head.h, small = Math.max(3600, HA * .06), done = [];
      function touches(el, b) { var ib = B(Math.max(b.l, H.l), Math.max(b.t, H.t), Math.min(b.r, H.r), Math.min(b.b, H.b)); if (ib.w < 2 || ib.h < 2) return 0;
        return grid(ib, Math.max(3, Math.min(9, Math.round(ib.w / 4))), Math.max(3, Math.min(9, Math.round(ib.h / 4))), function (x, y) { return visibleAt(el, x, y) && nx.near(x, y, 5); }); }
      // candidates: DOM elements (painted or holding text), small stand-alone SVGs (hearts, pins, stars) and SVG props;
      // single shapes of a big full-frame backdrop (skyline windows, curtains) peeking behind her are scenery, not faults
      var cands = [];
      [].forEach.call(post.querySelectorAll('*'), function (e) {
        if (e === nx.im || e.contains(nx.im) || (e.closest && e.closest('.nx, .nxs, .hb'))) return;
        if (e.namespaceURI === SVGNS) { if (e.tagName === 'svg' && e.getBoundingClientRect().width < W * .9 && e.parentElement && e.parentElement.namespaceURI !== SVGNS) cands.push(e); return; }
        var own = [].some.call(e.childNodes, function (z) { return z.nodeType === 3 && z.nodeValue.trim(); }); if (painted(e) || own) cands.push(e);
      });
      propGs.forEach(function (p) { cands.push(p.el); });
      cands.forEach(function (e) {
        if (done.some(function (d) { return d.contains(e) || e.contains(d); })) return;
        if (vis2(e) < .2) return;
        var b = e.tagName === 'g' ? (propGs.filter(function (p) { return p.el === e; })[0] || {}).ext || bx(e) : bx(e), ov = ovl(b, H); if (ov.x < 2 || ov.y < 2) return;
        var host = e, hb2 = b, A = b.w * b.h; if (A > HA * 2.5) return;
        if (!touches(e, b)) return;
        done.push(host);
        add(A <= small ? 'err' : 'warn', 'face', (host.namespaceURI === SVGNS && host.tagName !== 'svg' ? 'svg ' : '') + nm(host) + ' at ' + Math.round(hb2.l - pr.l) + ',' + Math.round(hb2.t - pr.t) + (A <= small ? ' touches Nexi\'s head - nothing on or against her head/face (hearts, dots, pins, sparkles)' : ' (a large prop) touches Nexi\'s head - check it is intended'), hb2);
      });
      var cvHits = CVS.filter(function (s) { if (!(s.k === 'fill' || s.k === 'img') || !s.solid || s.a < .45) return false; var b = B(s.r[0], s.r[1], s.r[2], s.r[3]); return b.w * b.h <= small && touches(s.cv, b); });
      if (cvHits.length) { var u = null; cvHits.forEach(function (s) { u = uni(u, B(s.r[0], s.r[1], s.r[2], s.r[3])); }); add('warn', 'face', cvHits.length + ' canvas shape(s) (scene sparkle/heart/dot) touch Nexi\'s head - move the layer area or add an avoid zone round her head', u); }
    });
    // ---------- 15. [cursor] a cursor covering any part of a label (cursors are pointer-events:none: [covered] never saw them) ----------
    [].forEach.call(post.querySelectorAll(CUR_SEL), function (cur) {
      if (vis2(cur) < .3 || cur.closest('[data-audit="skip"]')) return;
      var b = bx(cur); if (b.w < 6 || !inPost(b)) return;
      var shape = cur.namespaceURI === SVGNS ? (cur.tagName === 'path' ? cur : cur.querySelector('path, polygon')) : null, pts = [];
      var inv = null; try { inv = shape && shape.getScreenCTM().inverse(); } catch (x) {}
      for (var j = 0; j < 16; j++) for (var i = 0; i < 14; i++) {
        var x = b.l + b.w * (i + .5) / 14, y = b.t + b.h * (j + .5) / 16;
        if (shape && inv) { var p = new DOMPoint(x, y).matrixTransform(inv); if (!(shape.isPointInFill(p) || shape.isPointInStroke(p))) continue; }
        pts.push([x, y]);
      }
      if (!pts.length) return;
      var tip = pts.reduce(function (a, p) { return p[0] + p[1] < a[0] + a[1] ? p : a; });   // arrow tip = top-left-most painted point
      T.forEach(function (o) {
        if (cur.contains(o.e) || o.e.contains(cur)) return;
        var n = 0, nb = grow(ink(o), 10);
        lineInks(o).forEach(function (li) { var ib = grow(li, 1.5); n += pts.filter(function (p) { return p[0] >= ib.l && p[0] <= ib.r && p[1] >= ib.t && p[1] <= ib.b; }).length; });
        if (n >= 2) add('err', 'cursor', 'cursor covers the label "' + txt(o.e) + '" - park the tip on the button\'s lower-right corner, the label stays fully readable', uni(b, ink(o)));
        else if (tip[0] >= nb.l && tip[0] <= nb.r && tip[1] >= nb.t && tip[1] <= nb.b) add('err', 'cursor', 'cursor tip crowds the label "' + txt(o.e) + '" (< 10 px) - park it on the button\'s lower-right corner, clear of the text', uni(b, ink(o)));
      });
    });
    // ---------- 16. [contain] child graphics spilling out of their card, small badges clipped by a screen edge ----------
    function isCard(e, cs) { if (e.namespaceURI === SVGNS || isDeco(e) || e.closest('.hb, .nx')) return false; cs = cs || getComputedStyle(e);
      if (!(bgA(cs.backgroundColor) >= .5 || cs.backgroundImage !== 'none')) return false; if ((parseFloat(cs.borderTopLeftRadius) || 0) < 3 && (parseFloat(cs.borderTopWidth) || 0) < 1) return false;
      var r = e.getBoundingClientRect(), A = r.width * r.height; return A >= 3000 && A <= PA * .55; }
    var cardCache = new Map();
    function cardOf(g) { for (var a = g.parentElement || g.parentNode; a && a !== post; a = a.parentElement || a.parentNode) { if (a.nodeType !== 1) continue; if (!cardCache.has(a)) cardCache.set(a, isCard(a)); if (cardCache.get(a)) return a; } return null; }
    function clipsBetween(g, c) { for (var a = g.parentElement || g.parentNode; a && a !== c; a = a.parentElement || a.parentNode) { if (a.nodeType !== 1) continue; var cs = getComputedStyle(a); if (a.namespaceURI !== SVGNS && (cs.overflow !== 'visible' || cs.clipPath !== 'none')) return true; } var cc = getComputedStyle(c); return cc.overflow !== 'visible' || cc.clipPath !== 'none'; }
    var spills = 0;
    [].forEach.call(post.querySelectorAll('rect, circle, ellipse, path, polygon, image, img, div, span, i, b, em'), function (g) {
      if (spills > 12 || vis2(g) < .3 || g.closest('[data-audit="skip"], [data-audit="overlay"], .hb, .nx') || isDeco(g) || g.matches(CUR_SEL) || g.closest(CUR_SEL)) return;
      if (g.namespaceURI === SVGNS) { if (paintedFill(g) < .5) return; } else if (!(g.tagName === 'IMG' || bgA(getComputedStyle(g).backgroundColor) >= .5)) return;
      var b = bx(g); if (b.w < 4 || b.h < 4) return;
      var c = cardOf(g); if (!c) return; var cb = bx(c); if (b.w * b.h >= cb.w * cb.h * .9) return;
      var o = Math.max(cb.l - b.l, b.r - cb.r, cb.t - b.t, b.b - cb.b); if (o <= 2) return;
      if (clipsBetween(g, c)) return;
      var io = ovl(b, cb), f = 1 - Math.max(0, io.x) * Math.max(0, io.y) / (b.w * b.h); if (f > .35) return;   // mostly outside = a deliberate pop-out, not a spill
      spills++; add('err', 'contain', (g.namespaceURI === SVGNS ? 'svg ' : '') + nm(g) + ' spills ' + Math.round(o) + ' px out of its card ' + nm(c) + ' - keep chart bars, badges and icons inside their container', b);
    });
    // small badges / dots / avatars partly clipped by a screen or window edge (incl. ::before/::after badges)
    function clipFrac(e, b) { var v = b; for (var a = e.parentElement; a && a !== post; a = a.parentElement) { var cs = getComputedStyle(a); if (cs.overflow !== 'visible') { var cr = bx(a); v = B(Math.max(v.l, cr.l), Math.max(v.t, cr.t), Math.min(v.r, cr.r), Math.min(v.b, cr.b)); if (v.w <= 0 || v.h <= 0) return { f: 0, a: a }; if (v.w < b.w - .5 || v.h < b.h - .5) return { f: v.w * v.h / (b.w * b.h), a: a }; } } return { f: 1 }; }
    var clipped = 0;
    [].forEach.call(post.querySelectorAll('*'), function (e) {
      if (clipped > 8 || e.namespaceURI === SVGNS || vis2(e) < .3 || e.closest('[data-audit="skip"], .hb, .nx') || isDeco(e)) return;
      var cs = getComputedStyle(e), boxes = [];
      if (bgA(cs.backgroundColor) >= .5 && (parseFloat(cs.borderTopLeftRadius) || 0) >= 3) { var b0 = bx(e); if (b0.w * b0.h >= 16 && b0.w * b0.h <= 2500) boxes.push([b0, nm(e)]); }
      if (cs.position !== 'static') ['::after', '::before'].forEach(function (ps) {
        var p = getComputedStyle(e, ps); if (!p.content || p.content === 'none' || p.content === 'normal' || p.position !== 'absolute' || p.display === 'none' || bgA(p.backgroundColor) < .5) return;
        var r = e.getBoundingClientRect(), k = e.offsetWidth ? r.width / e.offsetWidth : 1, w = parseFloat(p.width) * k, h = parseFloat(p.height) * k; if (!(w > 0 && h > 0)) return;
        var bl = parseFloat(cs.borderLeftWidth) * k, bt = parseFloat(cs.borderTopWidth) * k, L = parseFloat(p.left), Tp = parseFloat(p.top), Rr = parseFloat(p.right), Bb = parseFloat(p.bottom);
        var x = !isNaN(L) && p.left !== 'auto' ? r.left + bl + L * k : r.right - parseFloat(cs.borderRightWidth) * k - (Rr + 0) * k - w;
        var y = !isNaN(Tp) && p.top !== 'auto' ? r.top + bt + Tp * k : r.bottom - parseFloat(cs.borderBottomWidth) * k - Bb * k - h;
        if (w * h <= 2500) boxes.push([B(x, y, x + w, y + h), nm(e) + ps + (p.content && p.content.length < 12 ? ' ' + p.content : '')]);
      });
      boxes.forEach(function (q) { var cf = clipFrac(e, q[0]); if (cf.f > .05 && cf.f < .92) { clipped++; add('err', 'contain', q[1] + ' is clipped by ' + nm(cf.a) + ' (' + Math.round(cf.f * 100) + '% visible) - badges and dots must sit fully inside the screen/navbar', q[0]); } });
    });
    // an Odoo navbar wider than its screen pushes the badge / icons / avatar under the screen edge (ad1: "One database" pill)
    [].forEach.call(post.querySelectorAll('.ou-nav'), function (nav) {
      if (vis2(nav) < .3) return; var clip = null;
      for (var a = nav.parentElement; a && a !== post; a = a.parentElement) if (getComputedStyle(a).overflow !== 'visible') { clip = bx(a); break; }
      if (!clip) return; var lost = [];
      [].forEach.call(nav.querySelectorAll('.r > *, .m, .app'), function (c) { var q = bx(c); if (q.w > 0 && q.r > clip.r + 1) lost.push(nm(c) + (q.l >= clip.r ? ' (hidden)' : ' (cut)')); });
      if (lost.length) add('err', 'contain', 'the Odoo navbar is wider than its screen: ' + lost.join(', ') + ' run past the screen edge - drop a menu/pill so badge, icons and avatar fit', B(clip.r - 120, bx(nav).t, clip.r, bx(nav).b));
    });
    // ---------- 17. [float] a detached Nexi hand (separate PNG part) floating over a window, card or prop ----------
    var floatT = OBJ.slice();
    [].forEach.call(post.querySelectorAll('div, section, article, li'), function (e) { if (e.closest('.hb, .nx') || isDeco(e) || vis2(e) < .3) return; if (isCard(e) && [].some.call(e.querySelectorAll('*'), function (z) { return [].some.call(z.childNodes, function (t) { return t.nodeType === 3 && t.nodeValue.trim(); }); })) floatT.push({ el: e, name: nm(e), ext: bx(e), kind: 'card', area: bx(e).w * bx(e).h }); });
    NX.forEach(function (nx) {
      nx.parts.forEach(function (p) {
        var best = null, near = null;
        floatT.forEach(function (O) {
          if (O.el.contains(nx.im)) return;
          var c = nx.cellsIn(O.ext, p.c.id);
          if (c < p.c.n * .25) {   // not over it: a hand hovering < 6 px above a prop/card reads as "floating over it" too (ad4 plant)
            var og = ovl(p.b, O.ext); if (c === 0 && og.x > p.b.w * .3 && og.y > -6 && p.b.b <= O.ext.t + 4 && (!near || O.area < near.area)) near = O; return; }
          var ob = B(Math.max(p.b.l, O.ext.l), Math.max(p.b.t, O.ext.t), Math.min(p.b.r, O.ext.r), Math.min(p.b.b, O.ext.b)), above = 0, tot = 0;
          grid(ob, 4, 4, function (x, y) { if (!nx.at(x, y)) return; tot++; var st = stackAt(x, y); for (var k = 0; k < st.length; k++) { if (st[k] === nx.im) { above++; break; } if (O.el === st[k] || O.el.contains(st[k])) break; } });
          if (!tot || above < tot * .5) return;
          if (!best || O.area < best.area) best = O;
        });
        // over a window / card / device = error (ad5 TV-Nexi's hand on the Inventory list); over a prop it may be holding it = warning
        if (best) add(best.kind === 'prop' ? 'warn' : 'err', 'float', 'a detached Nexi hand ' + (best.kind === 'prop' ? 'sits on ' + best.name + ' - fine only if she is clearly holding it' : 'floats over ' + nm(best.el) + ' - move Nexi or pick a pose whose hands rest on empty space'), p.b);
        else if (near) add('err', 'float', 'a detached Nexi hand hovers just above ' + (near.kind === 'prop' ? near.name : nm(near.el)) + ' (< 6 px) - move Nexi or pick a pose whose hands rest on empty space', uni(p.b, near.ext));
      });
    });
    // ---------- 18. [stack] devices colliding, notes / pins / props covering text on another object ----------
    var doms = OBJ.filter(function (o) { return o.kind === 'dom'; });
    for (var i = 0; i < doms.length; i++) for (var j = i + 1; j < doms.length; j++) {
      var A1 = doms[i], B1 = doms[j]; if (A1.el.contains(B1.el) || B1.el.contains(A1.el)) continue;
      var o2 = ovl(A1.ext, B1.ext); if (o2.x <= -6 || o2.y <= -6 || (o2.x <= 3 && o2.y <= 3)) continue;
      var ca = (A1.el.getAttribute('class') || '').split(/\s+/)[0], cb2 = (B1.el.getAttribute('class') || '').split(/\s+/)[0], ratio = Math.min(A1.area, B1.area) / Math.max(A1.area, B1.area);
      var ob2 = B(Math.max(A1.ext.l, B1.ext.l), Math.max(A1.ext.t, B1.ext.t), Math.min(A1.ext.r, B1.ext.r), Math.min(A1.ext.b, B1.ext.b));
      if (ca && ca === cb2 && ratio >= .6 && A1.area >= 4000) add('err', 'stack', A1.name + ' and ' + B1.name + (o2.x > 0 && o2.y > 0 ? ' overlap each other by ' + Math.round(Math.min(o2.x, o2.y)) + ' px' : ' touch with no gap') + ' - devices in a row keep a clear gap', B(Math.min(ob2.l, ob2.r) - 4, Math.min(ob2.t, ob2.b), Math.max(ob2.l, ob2.r) + 4, Math.max(ob2.t, ob2.b)));
      else if (o2.x <= 3 || o2.y <= 3) continue;
      else if (A1.device && B1.device) add('warn', 'stack', 'devices overlap: ' + A1.name + ' / ' + B1.name + ' - only as a clean, intended stack with no UI covered', ob2);
    }
    var coverers = OBJ.filter(function (o) { return o.kind === 'dom' || o.kind === 'prop'; }), stk = {};
    T.forEach(function (o) {
      if (vis2(o.e) < .5) return;
      lineInks(o).forEach(function (ib) { coverers.forEach(function (O) {
        if (O.el.contains(o.e) || o.e.contains(O.el)) return;
        var ov = ovl(O.ext, ib); if (ov.x < 3 || ov.y < 3) return;
        var zb = B(Math.max(O.ext.l, ib.l), Math.max(O.ext.t, ib.t), Math.min(O.ext.r, ib.r), Math.min(O.ext.b, ib.b)), n = 0, cov = 0;
        grid(zb, 5, 3, function (x, y) { n++; var st = stackAt(x, y), io = -1, it = -1; for (var k = 0; k < st.length; k++) { var h = st[k]; if (it < 0 && (h === o.e || o.e.contains(h))) it = k; if (io < 0 && (O.el === h || O.el.contains(h)) && opaqueAt(h, x, y)) io = k; } if (io >= 0 && (it < 0 || io < it)) cov++; });
        if (cov >= 2 && cov / n >= .3) { var key = O.name + '|' + txt(o.e); if (stk[key]) return; stk[key] = 1; add('err', 'stack', objName(O) + ' covers text "' + txt(o.e) + '" (' + Math.round(cov / n * 100) + '% of the overlap) - pins, notes and props never sit on letters', zb); }
      }); });
    });
    // ---------- 19. [line] decorative strokes / dashed borders running behind or along the CTA and footer text ----------
    if (post.querySelector('.foot')) {
      var zones = [];
      if (ctaB) zones.push({ b: grow(ctaB, 24), hole: ctaB, name: 'the CTA' });
      [].forEach.call(post.querySelectorAll('.foot > *'), function (e) { if (e === cta || vis2(e) < .3) return; var b = bx(e); if (b.w > 4) zones.push({ b: grow(b, 12), hole: null, name: 'the footer text "' + txt(e) + '"' }); });
      var inProp = function (s) { return propGs.some(function (p) { return p.el.contains(s); }); };
      svgLayers.forEach(function (s) { [].forEach.call(s.querySelectorAll('path, rect, circle, ellipse, line, polyline, polygon'), function (el) {
        if (el.closest('defs, symbol, pattern, mask, clipPath, marker, .foot') || inProp(el)) return;
        var cs = getComputedStyle(el); if (cs.stroke === 'none' || /url/.test(cs.stroke) && false) return;
        var sw = parseFloat(cs.strokeWidth) || 0, m = el.getScreenCTM(), k = m ? Math.hypot(m.a, m.b) : 1; if (sw * k < 1.2) return;
        if (vis2(el) * parseFloat(cs.strokeOpacity || 1) * bgA(cs.stroke) < .25) return;
        var b = bx(el); if (Math.max(b.w, b.h) < 100) return;
        var inv; try { inv = m.inverse(); } catch (x) { return; }
        // test the line as if solid: a dash gap at one sample point does not make a dashed rug border any less there
        var dashed = cs.strokeDasharray !== 'none', dv = el.style.getPropertyValue('stroke-dasharray'), dp = el.style.getPropertyPriority('stroke-dasharray');
        if (dashed) el.style.setProperty('stroke-dasharray', 'none', 'important');
        try { zones.forEach(function (z) {
          var zb = z.b; if (ovl(b, grow(zb, sw * k)).x <= 0 || ovl(b, grow(zb, sw * k)).y <= 0) return;
          var hits = 0;
          for (var y = zb.t; y <= zb.b; y += 3) for (var x = zb.l; x <= zb.r; x += 3) {
            if (z.hole && x > z.hole.l && x < z.hole.r && y > z.hole.t && y < z.hole.b) continue;
            if (!el.isPointInStroke(new DOMPoint(x, y).matrixTransform(inv))) continue;
            if (visibleAt(el, x, y)) hits++;
            if (hits >= 3) break;
          }
          if (hits >= 3) add('err', 'line', 'a decorative ' + (dashed ? 'dashed ' : '') + 'line (svg ' + el.tagName + ') runs behind / along ' + z.name + ' - keep rug borders, cables and trails 24 px clear of the CTA and footer', B(Math.max(b.l, zb.l), Math.max(b.t, zb.t), Math.min(b.r, zb.r), Math.min(b.b, zb.b)));
        }); } finally { if (dashed) { if (dv) el.style.setProperty('stroke-dasharray', dv, dp); else el.style.removeProperty('stroke-dasharray'); } }
      }); });
      // plate-less footer text on a striped / dashed SVG pattern (ad5: "technext.asia" on the rug weave + its dashed border;
      // the rug lives in a data-audit="skip" SVG, so [busy]/[crossed] never looked under the text)
      T.forEach(function (o) {
        if (!o.e.closest('.foot') || (cta && cta.contains(o.e))) return;
        var plate = false; for (var a5 = o.e; a5 && a5 !== post; a5 = a5.parentElement) { var c5 = getComputedStyle(a5); if (bgA(c5.backgroundColor) >= .5 || c5.backgroundImage !== 'none') { plate = true; break; } } if (plate) return;
        var hit = 0, n = 0, who = '';
        lineInks(o).forEach(function (li) { grid(li, 10, 2, function (x, y) { n++; var st = stackAt(x, y), past = false;
          for (var k = 0; k < st.length; k++) { var h = st[k]; if (h === o.e || o.e.contains(h)) { past = true; continue; } if (!past) continue;
            if (h.namespaceURI === SVGNS && h.tagName !== 'svg' && h.tagName !== 'g') { var f = getComputedStyle(h).fill || '', id = (f.match(/url\("?#([^"')]+)/) || [])[1], pe = id && document.getElementById(id);
              // dense stripes only (period <= 12 px: weave, hatch) - wide wood planks / grain / tiles are texture, not lines through letters
              var pk = h.getScreenCTM(), ps = pk ? Math.hypot(pk.a, pk.b) : 1, pw2 = pe ? (parseFloat(pe.getAttribute('width')) || 99) * ps : 99, ph2 = pe ? (parseFloat(pe.getAttribute('height')) || 99) * ps : 99;
              if (pe && /pattern/i.test(pe.tagName) && Math.min(pw2, ph2) <= 12 && vis2(h) * parseFloat(getComputedStyle(h).fillOpacity || 1) >= .3 && pe.querySelector('path, line, rect')) { hit++; who = '#' + id; return true; } }
            if (opaqueAt(h, x, y)) return false; }
          return false; }); });
        if (n && hit / n >= .3) add('err', 'line', 'footer text "' + txt(o.e) + '" sits on a striped pattern (' + who + ') - lines run behind the letters; give the footer a calm background or a plate', o.r);
      });
      [].forEach.call(post.querySelectorAll('*'), function (e) {
        if (e.namespaceURI === SVGNS || e.closest('.foot') || vis2(e) < .3) return; var cs = getComputedStyle(e);
        var sides = [['Top', 't'], ['Bottom', 'b'], ['Left', 'l'], ['Right', 'r']].filter(function (s) { return /dashed|dotted/.test(cs['border' + s[0] + 'Style']) && parseFloat(cs['border' + s[0] + 'Width']) >= 1.5; });
        if (!sides.length) return; var b = bx(e);
        sides.forEach(function (s) {
          var w = parseFloat(cs['border' + s[0] + 'Width']), seg = s[1] === 't' ? B(b.l, b.t, b.r, b.t + w) : s[1] === 'b' ? B(b.l, b.b - w, b.r, b.b) : s[1] === 'l' ? B(b.l, b.t, b.l + w, b.b) : B(b.r - w, b.t, b.r, b.b);
          zones.forEach(function (z) { var o = ovl(seg, z.b); if (o.x > 2 && o.y > 0 && !(z.hole && ovl(seg, z.hole).x > 0 && ovl(seg, z.hole).y > 0 && o.x <= ovl(seg, z.hole).x)) add('err', 'line', 'a dashed/dotted border of ' + nm(e) + ' runs along ' + z.name + ' - keep it 24 px clear', seg); });
        });
      });
    }
    // ---------- [odoo-facts] WARNING lint for odoo-ui.js screens (facts: reference/odoo-ui-facts.md) ----------
    odooFacts(post, add);
    window.__l3 = { NX: NX, OBJ: OBJ, DECO: DECO };   // for debugging (dbg / devtools)
    }
  }
  // Odoo 17/18 web client (kept by Odoo 20). Keep in sync with reference/odoo-ui-facts.md.
  var ODOO_MENUS = {
    'Sales': ['Orders', 'To Invoice', 'Products', 'Reporting', 'Configuration'],
    'CRM': ['Sales', 'Leads', 'Reporting', 'Configuration'],
    'Inventory': ['Overview', 'Operations', 'Products', 'Reporting', 'Configuration'],
    'Accounting': ['Dashboard', 'Customers', 'Vendors', 'Accounting', 'Reporting', 'Configuration'],
    'Invoicing': ['Dashboard', 'Customers', 'Vendors', 'Reporting', 'Configuration'],
    'Purchase': ['Orders', 'Products', 'Reporting', 'Configuration'],
    'Manufacturing': ['Overview', 'Operations', 'Planning', 'Products', 'Reporting', 'Configuration'],
    'Project': ['Projects', 'My Tasks', 'All Tasks', 'Reporting', 'Configuration'],
    'Helpdesk': ['Overview', 'Tickets', 'Reporting', 'Configuration'],
    'Dashboards': ['Dashboards', 'Configuration'],
    'Apps': ['Apps', 'Updates', 'Update Apps List'],
    'Settings': ['General Settings', 'Users & Companies', 'Translations', 'Technical'],
    'Point of Sale': ['Dashboard', 'Orders', 'Products', 'Reporting', 'Configuration'],
    'Website': ['Site', 'eCommerce', 'Reporting', 'Configuration'],
    'Employees': ['Employees', 'Departments', 'Reporting', 'Configuration'],
    'Timesheets': ['Timesheets', 'Reporting', 'Configuration'],
    'Time Off': ['My Time', 'Overview', 'Management', 'Reporting', 'Configuration'],
    'Expenses': ['My Expenses', 'Expense Reports', 'Reporting', 'Configuration'],
    'Email Marketing': ['Mailings', 'Mailing Lists', 'Reporting', 'Configuration'],
    'Field Service': ['My Tasks', 'All Tasks', 'Reporting', 'Configuration'],
    'Planning': ['Schedule', 'Reporting', 'Configuration']
  };
  // invented button labels per screen context: [context test on the screen's text/app, label regex, real labels]
  var ODOO_BTN = [
    [/^(Sales|CRM)$|quotation|\bS0\d{3,}/i, /^approve(d)?$/i, 'a Sales quotation has Send by Email, Confirm, Preview, Cancel - there is no "Approve" in Odoo Sales'],
    [/bank reconciliation|statement lines|bank statement/i, /^reconcile$/i, 'bank reconciliation (Odoo 17+) validates the match with "Validate", not "Reconcile"'],
    [/^(Apps)$|\bapps\b.*\b(activate|module)|update apps list/i, /^(install|installed|update|upgrade|uninstall)$/i, 'Apps cards show "Activate" (not installed) or "Module Info" (installed) - no Install/Update pills'],
    [/^Settings$/i, /^(install|installed|update|upgrade)$/i, 'apps are activated from the Apps app ("Activate"), not Install/Update pills in Settings']
  ];
  function odooFacts(post, add) {
    if (!window.OU && !post.querySelector('[class*="ou-"]')) return;
    function R2(e) { var r = e.getBoundingClientRect(), p = post.getBoundingClientRect(); return { l: r.left, t: r.top, w: r.width, h: r.height }; }
    function own(e) { return [].filter.call(e.childNodes, function (z) { return z.nodeType === 3; }).map(function (z) { return z.nodeValue; }).join(' ').replace(/\s+/g, ' ').trim(); }
    function screenOf(e) { for (var a = e.parentElement; a && a !== post; a = a.parentElement) { var cs = getComputedStyle(a), c = a.getAttribute('class') || ''; if (/(^|\s)(ou|scr|ws-scr)(\s|$)|scr\d*|screen/.test(c) || (cs.overflow !== 'visible' && a.getBoundingClientRect().width > 220)) return a; } return post; }
    var screens = new Set();
    [].forEach.call(post.querySelectorAll('.ou-nav'), function (nav) {
      if (vis(nav) < .3) return; screens.add(screenOf(nav));
      var appEl = nav.querySelector('.app'), app = appEl ? (appEl.textContent || '').trim() : '', real = ODOO_MENUS[app];
      if (real) [].forEach.call(nav.querySelectorAll('.m'), function (m) { var t = (m.textContent || '').trim(); if (t && real.indexOf(t) < 0) add('warn', 'odoo-facts', '"' + t + '" is not a ' + app + ' menu in real Odoo (top menus: ' + real.join(' / ') + ')', R2(m)); });
      // anything else with text in the navbar is invented (e.g. a "One database" pill) - annotate outside the screen instead
      [].forEach.call(nav.querySelectorAll('*'), function (e) { if (e.closest('.app, .m, .gr, .ou-av') || !own(e) || vis(e) < .3) return; add('warn', 'odoo-facts', 'invented "' + own(e) + '" element in the Odoo navbar - real navbars hold app switcher, app name, menus, activity/chat icons, avatar', R2(e)); });
      if (app === 'Sales') { var scr = screenOf(nav); [].forEach.call(scr.querySelectorAll('.ou-bc'), function (bc) { if (/dashboard/i.test(bc.textContent)) add('warn', 'odoo-facts', 'Sales has no "Dashboard" view - use Sales > Reporting > Sales Analysis (graph/pivot)', R2(bc)); }); }
    });
    [].forEach.call(post.querySelectorAll('.ou-cp, .ou-tbl, .ou-card, .ou-kpi, .scr, [class*="scr"]'), function (e) { screens.add(e.matches('.scr, [class*="scr"]') ? e : screenOf(e)); });
    var seen = {};
    screens.forEach(function (sc) {
      if (!sc || sc === post) return;
      var nav = sc.querySelector('.ou-nav .app'), app = nav ? nav.textContent.trim() : '', text = (sc.textContent || '').replace(/\s+/g, ' ');
      [].forEach.call(sc.querySelectorAll('*'), function (e) {
        var t = own(e); if (!t || t.split(' ').length > 3 || t.length > 28 || vis(e) < .3) return;
        var cs = getComputedStyle(e), btn = e.classList.contains('ou-btn') || ((bgA(cs.backgroundColor) >= .5 || parseFloat(cs.borderTopWidth) >= 1) && (parseFloat(cs.borderTopLeftRadius) || 0) >= 3 && e.getBoundingClientRect().height <= 60);
        if (!btn && !/^(install|installed|update|upgrade|approve|reconcile)$/i.test(t)) return;
        ODOO_BTN.forEach(function (r) { if ((r[0].test(app) || r[0].test(text)) && r[1].test(t)) { var k = t + '|' + r[2]; if (seen[k]) return; seen[k] = 1; add('warn', 'odoo-facts', '"' + t + '" is not a real Odoo label here: ' + r[2], R2(e)); } });
      });
    });
  }
  // every visible text with its on-screen box, colour and size, for the pixel-based CONTRAST check in audit.py
  window.TN_AUDIT_TEXTS = function (post) {
    var pr = post.getBoundingClientRect(), res = [];
    function push(e, q, col, halo, fs, label) { res.push({ r: [q.left - pr.left, q.top - pr.top, q.width, q.height], c: col, halo: !!halo, fs: fs, t: label }); }
    var walker = document.createTreeWalker(post, NodeFilter.SHOW_TEXT, null), seen = new Set();
    for (var n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!n.nodeValue.trim()) continue; var h = n.parentNode; if (!h || seen.has(h) || (h.closest && h.closest('svg'))) continue; seen.add(h);
      if (vis(h) < .5 || h.closest('[data-audit="skip"],[data-qa-skip]')) continue;
      var cs = getComputedStyle(h); if (cs.webkitBackgroundClip === 'text' || /,\s*0\)$/.test(cs.color) || cs.color === 'transparent') continue;
      var rg = document.createRange(); rg.selectNodeContents(h); var q = rg.getBoundingClientRect(); if (q.width < 2 || q.height < 2) continue;
      push(h, q, cs.color, cs.textShadow !== 'none' || parseFloat(cs.webkitTextStrokeWidth) > 0, parseFloat(cs.fontSize) * effScale(h), txt(h));
    }
    [].forEach.call(post.querySelectorAll('svg text'), function (e) {
      if (vis(e) < .5 || e.closest('[data-audit="skip"],[data-qa-skip]') || !txt(e)) return;
      var cs = getComputedStyle(e); if (!/^rgb/.test(cs.fill)) return; var q = e.getBoundingClientRect(); if (q.width < 2) return;
      var m = e.getScreenCTM(), sc = m ? Math.hypot(m.a, m.b) : 1;
      push(e, q, cs.fill, cs.stroke !== 'none' && parseFloat(cs.strokeWidth) > 0, parseFloat(cs.fontSize) * sc, txt(e));
    });
    (window.__cvText || []).forEach(function (c) { if (c.stroke || !/^(#|rgb)/.test(c.col || '')) return; var halo = (window.__cvText || []).some(function (d) { return d.stroke && d.t === c.t && Math.abs(d.r[0] - c.r[0]) < 4; });
      push(null, { left: c.r[0], top: c.r[1], width: c.r[2] - c.r[0], height: c.r[3] - c.r[1] }, c.col, halo, c.fs, c.t.slice(0, 34) + ' (canvas)'); });
    return res;
  };

  window.TN_AUDIT_MARK = function (post, list) {   // draw red/orange boxes for the screenshot
    list.forEach(function (x, i) {
      if (!x.r) return; var d = document.createElement('div');
      d.style.cssText = 'position:absolute;z-index:9999;pointer-events:none;left:' + (x.r[0] - 4) + 'px;top:' + (x.r[1] - 4) + 'px;width:' + (x.r[2] + 8) + 'px;height:' + (x.r[3] + 8) + 'px;border:3px solid ' + (x.lvl === 'err' ? '#FF1F4B' : '#FF9F1A') + ';border-radius:6px;box-shadow:0 0 0 2px #fff';
      var b = document.createElement('b'); b.textContent = i + 1; b.style.cssText = 'position:absolute;left:-3px;top:-24px;font:800 15px/20px Inter,sans-serif;color:#fff;background:' + (x.lvl === 'err' ? '#FF1F4B' : '#FF9F1A') + ';padding:0 6px;border-radius:4px';
      d.appendChild(b); post.appendChild(d);
    });
  };
})();
