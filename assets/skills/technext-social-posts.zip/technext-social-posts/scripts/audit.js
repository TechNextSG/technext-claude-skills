/* audit.js - deep layout audit for a rendered post (injected by audit.py after window.R(t)).
   window.TN_AUDIT(post) -> [{lvl:'err'|'warn', kind, msg, r:[x,y,w,h]}]
   Catches what TN.qa misses: SVG <text> spilling off its plate, text off-centre on its plate, text covered by art or
   Nexi, text-on-text collisions (HTML + SVG), text cut by the frame, HTML text spilling its pill, text sitting on busy
   art without a plate, sibling labels that nearly-but-not-quite line up, and icons/objects cut by the frame edge.
   Opt-outs (use sparingly, each one is a design decision, not a way to silence a real fault):
     data-audit="skip"     element + subtree ignored (pure decoration: tape numbers, watermarks)
     data-audit="overlay"  a deliberate cover (magnifier lens): never counts as covering, its own text skips collisions
     data-audit="layer"    stacked copies of one word (3D extrusion): no collisions inside it */
(function () {
  function vis(e) {   // effective visibility (display, visibility, opacity chain incl. SVG opacity attrs)
    var a = 1;
    for (var n = e; n && n.nodeType === 1; n = n.parentNode) {
      if (n.getAttribute && n.getAttribute('data-audit') === 'skip') return 0;
      var cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
      a *= parseFloat(cs.opacity || 1);
      if (n.tagName === 'section') break;
    }
    return a;
  }
  function R(r) { return { l: r.left, t: r.top, r: r.right, b: r.bottom, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 }; }
  function inter(a, b, pad) { pad = pad || 0; return a.l < b.r - pad && b.l < a.r - pad && a.t < b.b - pad && b.t < a.b - pad; }
  function nm(e) { var c = e.getAttribute('class') || ''; return e.tagName.toLowerCase() + (c ? '.' + c.split(' ').slice(0, 2).join('.') : ''); }
  function ink(o) { var h = Math.min(o.r.h, o.fs * .74), c = o.r.cy + (o.svg ? 0 : 0); return { l: o.r.l, r: o.r.r, t: c - h / 2, b: c + h / 2, w: o.r.w, h: h, cx: o.r.cx, cy: c }; }
  function txt(e) { return (e.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 34); }
  // on-screen scale of an element's text: a thin 1 x 100 px probe inside it picks up every CSS transform, 3D tilt,
  // perspective and zoom of its ancestors (owner 2026-10-10: "always check if the text are too small to read" - a
  // 17 px label in a window tilted away from the camera reads at 12 px; computed font-size never saw that)
  function effScale(host) {
    if (!host.appendChild || host.namespaceURI === 'http://www.w3.org/2000/svg') return 1;
    var p = document.createElement('i');
    // measure AT the text, not at the containing block's corner: on a face tilted in 3D the scale changes across it
    var st = getComputedStyle(host).position === 'static', L = st ? host.offsetLeft || 0 : 0, Tp = st ? host.offsetTop || 0 : 0;
    p.style.cssText = 'position:absolute;left:' + L + 'px;top:' + Tp + 'px;width:1px;height:100px;display:block;visibility:hidden;pointer-events:none;margin:0;padding:0;border:0;transform:none;zoom:1';
    try { host.appendChild(p); var q = p.getBoundingClientRect(); p.remove(); var s = Math.hypot(q.width, q.height) / 100; return s > 0.05 ? s : 1; } catch (x) { if (p.parentNode) p.remove(); return 1; }
  }
  function words(s) { s = (s || '').trim(); return s ? s.split(/\s+/).filter(function (w) { return /[A-Za-z0-9]/.test(w); }).length : 0; }
  function ownText(e) { return [].filter.call(e.childNodes, function (z) { return z.nodeType === 3; }).map(function (z) { return z.nodeValue; }).join(' ').replace(/\s+/g, ' ').trim(); }
  function isSentence(s) { s = (s || '').trim(); if (!s || (s === s.toUpperCase() && /[A-Z]/.test(s))) return false; return words(s) >= 5 || words(s) >= 3 && s.replace(/[\s\u00b7|\/-]+/g, ' ').length >= 30; }
  function paintedFill(e) {
    var cs = getComputedStyle(e), f = cs.fill, fo = parseFloat(cs.fillOpacity || 1);
    if (!f || f === 'none' || /rgba\([^)]*,\s*0\)$/.test(f) || f === 'transparent') return 0;
    if (/^url/.test(f)) { var id = (f.match(/#([^"')]+)/) || [])[1] || ''; if (/^dt-(speck|speckw|weave|grain|planks|stripe|dots|tile|grass|circuit|hatch|ripple|brick|gv|gh|gr|sh|glow)/.test(id)) return 0; }
    var m = f.match(/rgba\([^,]+,[^,]+,[^,]+,\s*([\d.]+)\)/); if (m) fo *= parseFloat(m[1]);
    return fo;
  }

  window.TN_AUDIT = function (post) {
    // elementsFromPoint skips anything with pointer-events:none: text inside such a wrapper is never tested for being
    // covered, and the wrapper never counts as covering (fine for glass/glare/selection overlays, wrong for a phone or
    // window that holds UI - post 114, 2026-10-10). Forcing pointer-events on everything turned decorative overlays into
    // false errors, so instead WARN when a click-transparent wrapper holds readable text (check 9 below).
    return audit(post);
  };
  function audit(post) {
    var out = [], pr = R(post.getBoundingClientRect()), PA = pr.w * pr.h;
    function add(lvl, kind, msg, r, col) { out.push({ lvl: lvl, kind: kind, msg: msg, r: r ? [Math.round(r.l - pr.l), Math.round(r.t - pr.t), Math.round(r.w), Math.round(r.h)] : null, col: col || null }); }

    // ---------- text inventory ----------
    var T = [];
    var walker = document.createTreeWalker(post, NodeFilter.SHOW_TEXT, null);
    var byEl = new Map();
    for (var n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!n.nodeValue.trim()) continue;
      var host = n.parentNode; if (host.closest && host.closest('svg')) continue;
      var rg = document.createRange(); rg.selectNodeContents(n);
      var rs = [].slice.call(rg.getClientRects()).filter(function (q) { return q.width > 1 && q.height > 1; });
      if (!rs.length) continue;
      var u = { left: 1e9, top: 1e9, right: -1e9, bottom: -1e9 };
      rs.forEach(function (q) { u.left = Math.min(u.left, q.left); u.top = Math.min(u.top, q.top); u.right = Math.max(u.right, q.right); u.bottom = Math.max(u.bottom, q.bottom); });
      var prev = byEl.get(host); if (prev) { prev.left = Math.min(prev.left, u.left); prev.top = Math.min(prev.top, u.top); prev.right = Math.max(prev.right, u.right); prev.bottom = Math.max(prev.bottom, u.bottom); } else byEl.set(host, u);
    }
    byEl.forEach(function (u, host) { if (vis(host) < .08) return; u.width = u.right - u.left; u.height = u.bottom - u.top; var f0 = parseFloat(getComputedStyle(host).fontSize); T.push({ e: host, svg: false, r: R(u), fs: f0 * effScale(host), fs0: f0 }); });
    [].forEach.call(post.querySelectorAll('svg text'), function (e) {
      if (e.querySelector('textPath') || vis(e) < .08 || !txt(e)) return;
      var r = R(e.getBoundingClientRect()); if (r.w < 1) return;
      var m = e.getScreenCTM(), sc = m ? Math.sqrt(m.a * m.a + m.b * m.b) : 1;
      T.push({ e: e, svg: true, r: r, fs: parseFloat(getComputedStyle(e).fontSize) * sc });
    });

    // ---------- per-text checks ----------
    var shapes = [].slice.call(post.querySelectorAll('svg rect, svg path, svg circle, svg ellipse, svg polygon')).filter(function (s) { if (vis(s) < .35 || paintedFill(s) < .35) return false; try { var bb = s.getBBox(); return bb.width >= 3 && bb.height >= 3; } catch (x) { return false; } });
    T.forEach(function (o) {
      var r = o.r, e = o.e, label = '"' + txt(e) + '"';
      // 1. cut by frame / hugging the frame edge (only the part its overflow-hidden containers let through counts)
      var vr = { l: r.l, t: r.t, r: r.r, b: r.b };
      for (var a0 = e.parentElement; a0 && a0 !== post; a0 = a0.parentElement) { if (getComputedStyle(a0).overflow !== 'visible') { var cr = a0.getBoundingClientRect(); vr.l = Math.max(vr.l, cr.left); vr.t = Math.max(vr.t, cr.top); vr.r = Math.min(vr.r, cr.right); vr.b = Math.min(vr.b, cr.bottom); } }
      if (vr.r <= vr.l || vr.b <= vr.t) return;   // fully hidden by its container (e.g. the far side of a magnifier lens)
      if (vr.l < pr.l - 1 || vr.r > pr.r + 1 || vr.t < pr.t - 1 || vr.b > pr.b + 1) add('err', 'frame', 'text cut by the frame: ' + label, r);
      else if (o.svg && (vr.l < pr.l + 14 || vr.r > pr.r - 14)) add('warn', 'edge', 'text hugs the frame edge: ' + label, r);
      // 2. too small to read, measured ON SCREEN (after transforms/3D/zoom): the brand floor is 15 px for any label and
      //    18 px for anything meant to be read as a sentence (owner 2026-10-10, twice: "too small", "too small to read")
      if (!(e.closest && e.closest('[data-qa-skip]'))) {
        var tilt = o.fs0 && o.fs < o.fs0 - .5 ? ' (' + o.fs0.toFixed(0) + ' px set, shrunk by a transform/tilt)' : '';
        if (o.fs < 14.5) add('err', 'tiny', 'text ' + o.fs.toFixed(1) + 'px on screen - below the 15 px floor' + tilt + ': ' + label, r);
        else if (o.fs < 17.5 && isSentence(o.svg ? e.textContent : ownText(e))) add('warn', 'small', 'reading text ' + o.fs.toFixed(1) + 'px on screen - sentences need >= 18 px' + tilt + ': ' + label, r);
      }
      // 3. SVG text vs its plate (smallest filled shape drawn before it that holds its centre)
      if (o.svg) {
        var best = null, ba = 1e12, ta = r.w * r.h;
        shapes.forEach(function (s) {
          if (!(s.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) return;
          if (s.closest('svg') !== e.closest('svg')) return;
          var tp = e.parentNode, tg = tp && tp.parentNode; if (s.parentNode !== tp && s.parentNode !== tg) return;   // a plate belongs to the text's own object (same group), not passing smoke or confetti
          var q = R(s.getBoundingClientRect()), a = q.w * q.h;
          if (q.l > r.cx || q.r < r.cx || q.t > r.cy || q.b < r.cy) return;
          if (a < ta * .9 || a > ta * 40 || a > PA * .08) return;
          var ox = Math.max(0, Math.min(q.r, r.r) - Math.max(q.l, r.l)), oy = Math.max(0, Math.min(q.b, r.b) - Math.max(q.t, r.t)); if (ox * oy < ta * .6) return;   // a shading patch under part of the word is not its plate
          if (a < ba) { ba = a; best = { s: s, q: q }; }
        });
        if (best) {
          var q = best.q, vt = o.fs * .14 + 1;
          var ov = Math.max(q.l - r.l, r.r - q.r, 0), ovv = Math.max(q.t - r.t - vt, r.b - q.b - vt, 0);
          if (ov > 1.5 || ovv > 1.5) add('err', 'plate', 'text spills off its plate by ' + Math.round(Math.max(ov, ovv)) + 'px: ' + label, r);
          else {
            var anc = getComputedStyle(e).textAnchor;
            if (anc === 'middle' && q.w < r.w * 3 && Math.abs(r.cx - q.cx) > Math.max(3, q.w * .04)) add('warn', 'centre', 'text off-centre on its plate by ' + Math.round(r.cx - q.cx) + 'px: ' + label, r);
            if (q.h < r.h * 2.6 && Math.abs(r.cy - q.cy) > q.h * .16 + 2) add('warn', 'vcentre', 'text not vertically centred on its plate (' + Math.round(r.cy - q.cy) + 'px): ' + label, r);
            if (anc !== 'middle' && q.w < r.w * 3 && Math.min(r.l - q.l, q.r - r.r) < 4) add('warn', 'pad', 'text touches its plate edge: ' + label, r);
          }
        }
      } else {
        // HTML text vs its own box / clipping ancestors
        var b = R(e.getBoundingClientRect());
        if (r.r > b.r + 3 || r.l < b.l - 3) add('err', 'spill', 'text spills out of its box: ' + label, r);
        for (var a2 = e; a2 && a2 !== post; a2 = a2.parentElement) {
          var cs = getComputedStyle(a2);
          if (cs.overflow !== 'visible' || cs.clipPath !== 'none') {
            var cb = R(a2.getBoundingClientRect()), ins = cs.clipPath !== 'none' ? Math.min(cb.w, cb.h) * .04 : 0;
            if (r.l < cb.l + ins - 1 || r.r > cb.r - ins + 1 || r.t < cb.t + ins - 1 || r.b > cb.b - ins + 1) { add('err', 'clip', 'text clipped by ' + nm(a2) + ': ' + label, r); break; }
          }
          var bg = cs.backgroundColor, hasBg = (bg && bg !== 'transparent' && !/,\s*0\)$/.test(bg)) || cs.backgroundImage !== 'none';
          if (hasBg && a2 !== e) {   // pill / card: text should sit inside the padding box with some air
            var pb = R(a2.getBoundingClientRect());
            if (pb.w < 700 && (r.l < pb.l + 3 || r.r > pb.r - 3) && !(r.r > pb.r + 1.5 || r.l < pb.l - 1.5)) add('warn', 'pad', 'text touches its pill edge: ' + label, r);
            break;
          }
        }
      }
      // 4. occlusion + busy art under plate-less text: sample the ink band; only points that really hit this text count
      var cov = 0, under = 0, N = 0, who = {}, uw = {}, ib = ink(o), curY = 0, cpts = [];
      function mine(h) { return h === e || e.contains(h) || (h !== post && h.contains && h.contains(e) && !o.svg); }
      function skip(h) {
        if (h === post || h === document.body || h === document.documentElement || h.tagName === 'svg' || h.tagName === 'CANVAS' || (h.classList && h.classList.contains('hb')) || (h.closest && h.closest('.hb'))) return true;
        if (h.contains && h.contains(e)) return true;   // an ancestor (e.g. its ::after glare) never covers its own text
        if (vis(h) < .08) return true;   // fully transparent (faded-out ghosts, hidden toasts) covers nothing
        if (h.closest && h.closest('[data-audit="overlay"]') && !(e.closest && e.closest('[data-audit="overlay"]'))) return true;
        if (h.namespaceURI !== 'http://www.w3.org/2000/svg' && h.tagName !== 'IMG' && h.tagName !== 'CANVAS') { var hc = getComputedStyle(h); if ((hc.backgroundColor === 'transparent' || /,\s*0\)$/.test(hc.backgroundColor)) && hc.backgroundImage === 'none' && hc.borderTopWidth === '0px' && hc.boxShadow === 'none') return true; }
        var hr = R(h.getBoundingClientRect()); if (hr.w > pr.w * .9 || hr.w * hr.h > PA * .25) return true;
        if (h.tagName !== 'IMG' && h.tagName !== 'image' && h.namespaceURI === 'http://www.w3.org/2000/svg' && paintedFill(h) < .35 && getComputedStyle(h).stroke === 'none') return true;
        if (h.tagName === 'text' || h.tagName === 'tspan') { var tt = h.tagName === 'tspan' ? h.closest('text') : h, m2 = tt.getScreenCTM(), f2 = parseFloat(getComputedStyle(tt).fontSize) * (m2 ? Math.sqrt(m2.a * m2.a + m2.b * m2.b) : 1), r2 = R(tt.getBoundingClientRect()); if (Math.abs(curY - r2.cy) > f2 * .37) return true; }
        return false;
      }
      var hasPlate = o.svg; if (!o.svg) for (var a5 = e; a5 && a5 !== post; a5 = a5.parentElement) { var c5 = getComputedStyle(a5), b5 = c5.backgroundColor; if ((b5 && b5 !== 'transparent' && !/,\s*0\)$/.test(b5)) || c5.backgroundImage !== 'none') { hasPlate = true; break; } }
      var NX = hasPlate ? 9 : Math.max(12, Math.round(ib.w / 5)), NY = hasPlate ? 3 : 4;   // plate-less text: dense grid so thin poles/ropes are caught
      // a click-transparent wrapper (pointer-events:none) hides this text AND its siblings from elementsFromPoint, so a
      // business card sliding over a swatch label inside the same desk passed (113, 2026-10-10). Make only this text's own
      // ancestor chain hittable while it is sampled: things inside that wrapper count again, decorative overlays elsewhere don't.
      var peFix = [];
      for (var a6 = e; a6 && a6 !== post.parentNode; a6 = a6.parentElement || a6.parentNode) {
        if (a6.style && a6.nodeType === 1 && getComputedStyle(a6).pointerEvents === 'none') { peFix.push([a6, a6.style.getPropertyValue('pointer-events'), a6.style.getPropertyPriority('pointer-events')]); a6.style.setProperty('pointer-events', 'auto', 'important'); }
      }
      for (var iy = 0; iy < NY; iy++) for (var ix = 0; ix < NX; ix++) {
        var x = ib.l + ib.w * (ix + .5) / NX, y = ib.t + ib.h * (.15 + iy * .7 / (NY - 1));
        if (x < pr.l || x > pr.r || y < pr.t || y > pr.b) continue;
        var st = document.elementsFromPoint(x, y), at = -1; curY = y;
        for (var k = 0; k < st.length; k++) if (mine(st[k])) { at = k; break; }
        if (at < 0) continue;
        N++;
        for (k = 0; k < at; k++) if (!skip(st[k]) && !mine(st[k])) { var hz = st[k].closest && st[k].closest('.nx') ? 'Nexi' : nm(st[k]); cov++; who[hz] = (who[hz] || 0) + 1; cpts.push([Math.round(x - pr.l), Math.round(y - pr.t)]); break; }
        for (k = at + 1; k < st.length; k++) if (!skip(st[k]) && !mine(st[k])) { uw[st[k].closest && st[k].closest('.nx') ? 'Nexi' : nm(st[k])] = 1; under++; break; }
      }
      peFix.forEach(function (q) { if (q[1]) q[0].style.setProperty('pointer-events', q[1], q[2]); else q[0].style.removeProperty('pointer-events'); });
      if (N && cov / N > .18) { add(cov / N > .4 ? 'err' : 'warn', 'covered', 'text ' + Math.round(cov / N * 100) + '% covered by ' + Object.keys(who).join(', ') + ': ' + label, r);
        var lastC = out[out.length - 1], tcs = getComputedStyle(e); lastC.pts = cpts; lastC.cell = [Math.max(4, ib.w / NX), Math.max(4, ib.h * .7)]; lastC.tcol = o.svg ? tcs.fill : tcs.color; }
      if (!hasPlate && N && (cov + under) / N > .03 && (cov + under) / N <= .25) add('warn', 'crossed', 'plate-less text crossed by art (' + Object.keys(who).concat(Object.keys(uw)).join(', ') + '): ' + label, r);
      if (!o.svg && N && under / N > .25) {
        var plate = false; for (var a3 = e; a3 && a3 !== post; a3 = a3.parentElement) { var c3 = getComputedStyle(a3), bg3 = c3.backgroundColor; if ((bg3 && bg3 !== 'transparent' && !/,\s*0\)$/.test(bg3)) || c3.backgroundImage !== 'none') { plate = true; break; } }
        if (!plate) add('warn', 'busy', 'plate-less text sits on artwork (' + Object.keys(uw).join(', ') + '): ' + label, r);
      }
    });
    // 5. text-on-text collisions (HTML and SVG together)
    for (var i = 0; i < T.length; i++) for (var j = i + 1; j < T.length; j++) {
      var A = T[i], B = T[j]; if (A.e.contains(B.e) || B.e.contains(A.e)) continue;
      var ga = A.e.closest('[data-qa-group]'), gb = B.e.closest('[data-qa-group]'); if (ga && ga === gb) continue;
      if (A.e.closest('[data-audit="overlay"]') || B.e.closest('[data-audit="overlay"]')) continue;
      var la = A.e.closest('[data-audit="layer"]'), lb = B.e.closest('[data-audit="layer"]'); if (la && la === lb) continue;
      if (inter(ink(A), ink(B), 1)) add('err', 'collide', 'text collides: "' + txt(A.e) + '" / "' + txt(B.e) + '"', { l: Math.min(A.r.l, B.r.l), t: Math.min(A.r.t, B.r.t), w: Math.max(A.r.r, B.r.r) - Math.min(A.r.l, B.r.l), h: Math.max(A.r.b, B.r.b) - Math.min(A.r.t, B.r.t) });
    }
    // 6. near-miss alignment between sibling labels of the same kind (stacked or in a row)
    var groups = {};
    [].forEach.call(post.querySelectorAll('[data-qa="text"]'), function (e) { if (vis(e) < .08) return; var k = (e.parentNode === post ? 'post' : nm(e.parentNode)) + '|' + (String(e.className.baseVal !== undefined ? e.className.baseVal : e.className).split(' ')[0]); (groups[k] = groups[k] || []).push(e); });
    Object.keys(groups).forEach(function (k) {
      var g = groups[k]; if (g.length < 2) return;
      for (var i2 = 0; i2 < g.length; i2++) for (var j2 = i2 + 1; j2 < g.length; j2++) {
        var a = R(g[i2].getBoundingClientRect()), b = R(g[j2].getBoundingClientRect());
        var stacked = a.l < b.r && b.l < a.r && !(a.t < b.b && b.t < a.b), row = a.t < b.b && b.t < a.b && !(a.l < b.r && b.l < a.r);
        var dl = Math.min(Math.abs(a.l - b.l), Math.abs(a.r - b.r)), dc = Math.abs(a.cx - b.cx), dt = Math.min(Math.abs(a.t - b.t), Math.abs(a.b - b.b)), dm = Math.abs(a.cy - b.cy);   // left, right or centre aligned all count
        if (stacked && Math.min(dl, dc) > 2.5 && Math.min(dl, dc) < 16) add('warn', 'align', 'stacked labels miss alignment by ' + Math.round(Math.min(dl, dc)) + 'px: "' + txt(g[i2]) + '" / "' + txt(g[j2]) + '"', { l: Math.min(a.l, b.l), t: Math.min(a.t, b.t), w: Math.max(a.r, b.r) - Math.min(a.l, b.l), h: Math.max(a.b, b.b) - Math.min(a.t, b.t) });
        if (row && Math.min(dt, dm) > 2.5 && Math.min(dt, dm) < 12) add('warn', 'align', 'labels in a row miss alignment by ' + Math.round(Math.min(dt, dm)) + 'px: "' + txt(g[i2]) + '" / "' + txt(g[j2]) + '"', { l: Math.min(a.l, b.l), t: Math.min(a.t, b.t), w: Math.max(a.r, b.r) - Math.min(a.l, b.l), h: Math.max(a.b, b.b) - Math.min(a.t, b.t) });
      }
    });
    // 6b. Nexi must stay visible (owner 2026-10-10 pointed at a toast sitting on Nexi): sample his body (box shrunk to the
    //     mascot) and flag any text box / card / window stacked on top of him
    [].forEach.call(post.querySelectorAll('.nx img'), function (im) {
      if (vis(im) < .3) return;
      var q = R(im.getBoundingClientRect()), l = q.l + q.w * .2, r2 = q.r - q.w * .2, t2 = q.t + q.h * .06, b2 = q.b - q.h * .04, hit = 0, n = 0, who = {};
      for (var iy = 0; iy < 6; iy++) for (var ix = 0; ix < 5; ix++) {
        var x = l + (r2 - l) * (ix + .5) / 5, y = t2 + (b2 - t2) * (iy + .5) / 6; if (x < pr.l || x > pr.r || y < pr.t || y > pr.b) continue; n++;
        var st = document.elementsFromPoint(x, y);
        for (var k = 0; k < st.length; k++) { var h = st[k]; if (h === im) break; var qa = h.closest && h.closest('[data-qa]'); if (qa && qa !== post && vis(qa) > .3 && !(h.closest('.hb'))) { var cs = getComputedStyle(h), own = [].some.call(h.childNodes, function (c) { return c.nodeType === 3 && c.nodeValue.trim(); }); if (h.namespaceURI !== 'http://www.w3.org/2000/svg' && !own && h.tagName !== 'IMG' && (cs.backgroundColor === 'transparent' || /,\s*0\)$/.test(cs.backgroundColor)) && cs.backgroundImage === 'none' && cs.borderTopWidth === '0px' && cs.boxShadow === 'none') continue; hit++; who[nm(h.closest('[data-qa]'))] = 1; break; } }
      }
      if (n && hit / n > .08) add(hit / n > .2 ? 'err' : 'warn', 'nexi', 'Nexi ' + Math.round(hit / n * 100) + '% covered by ' + Object.keys(who).join(', '), q);
      // 6c. her FACE must be clear (owner 2026-10-10, FB ad 3: two cards sat on a giant Nexi's visor while only a small
      //     share of her whole body was covered, so 6b stayed quiet). Dense samples on the head zone; 1 in 10 = error.
      var fl = q.l + q.w * .25, fr = q.r - q.w * .25, ft = q.t + q.h * .1, fb = q.t + q.h * .45, fh = 0, fn = 0, fwho = {};
      for (var jy = 0; jy < 5; jy++) for (var jx = 0; jx < 6; jx++) {
        var x2 = fl + (fr - fl) * (jx + .5) / 6, y2 = ft + (fb - ft) * (jy + .5) / 5; if (x2 < pr.l || x2 > pr.r || y2 < pr.t || y2 > pr.b) continue; fn++;
        var st2 = document.elementsFromPoint(x2, y2);
        for (var k2 = 0; k2 < st2.length; k2++) { var h2 = st2[k2]; if (h2 === im) break; var qa2 = h2.closest && h2.closest('[data-qa]'); if (qa2 && qa2 !== post && vis(qa2) > .3 && !(h2.closest('.hb'))) { var cs2 = getComputedStyle(h2), own2 = [].some.call(h2.childNodes, function (c) { return c.nodeType === 3 && c.nodeValue.trim(); }); if (h2.namespaceURI !== 'http://www.w3.org/2000/svg' && !own2 && h2.tagName !== 'IMG' && (cs2.backgroundColor === 'transparent' || /,\s*0\)$/.test(cs2.backgroundColor)) && cs2.backgroundImage === 'none' && cs2.borderTopWidth === '0px' && cs2.boxShadow === 'none') continue; fh++; fwho[nm(h2.closest('[data-qa]'))] = 1; break; } }
      }
      if (fn && fh / fn >= .1) add('err', 'face', "card / text on Nexi's face (" + Math.round(fh / fn * 100) + '% of the head zone): ' + Object.keys(fwho).join(', '), { l: fl, t: ft, w: fr - fl, h: fb - ft });
    });
    // 7. brand margin: logo row, headline and CTA share one left edge
    var lg = post.querySelector('.brand'), hh = post.querySelector('.hh'), bt = post.querySelector('.foot .btn');
    if (lg && hh && bt) { var xs = [lg, hh, bt].map(function (e) { return e.getBoundingClientRect().left; }); if (Math.max.apply(null, xs) - Math.min.apply(null, xs) > 2) add('warn', 'margin', 'logo / headline / CTA left edges differ: ' + xs.map(Math.round).join(', '), null); }
    // 8. icons + images cut by the frame edge (blurred depth props are exempt)
    [].forEach.call(post.querySelectorAll('img, svg image'), function (e) {
      if (vis(e) < .3) return; for (var a4 = e; a4 && a4 !== post; a4 = a4.parentNode) { var f = a4.style && a4.style.filter || ''; if (/blur/.test(f) || /blur/.test(getComputedStyle(a4).filter)) return; }
      if (e.closest('.hb')) return;
      var q = R(e.getBoundingClientRect()); if (q.w < 8) return;
      var vx = Math.max(0, Math.min(q.r, pr.r) - Math.max(q.l, pr.l)), vy = Math.max(0, Math.min(q.b, pr.b) - Math.max(q.t, pr.t)), f2 = vx * vy / (q.w * q.h);
      if (f2 > .05 && f2 < .9 && q.w * q.h < PA * .05) add('warn', 'cut', 'object cut by the frame edge (' + Math.round(f2 * 100) + '% visible): ' + (e.getAttribute('href') || e.getAttribute('src') || '').split('/').pop(), q);
    });
    // 9. a click-transparent wrapper (pointer-events:none) that holds readable text hides it from checks 3-6b: keep
    //    pointer-events:none for decoration only (glass, glare, sweeps, selection outlines), never on devices/windows/cards
    [].forEach.call(post.querySelectorAll('*'), function (e) {
      if (e === post || getComputedStyle(e).pointerEvents !== 'none') return;
      var pa = e.parentElement; if (pa && getComputedStyle(pa).pointerEvents === 'none') return;
      var t = [].filter.call(e.querySelectorAll('[data-qa="text"]'), function (x) { return vis(x) > .3; });
      if (t.length) add('warn', 'pe', 'pointer-events:none on ' + nm(e) + ' hides ' + t.length + ' text item(s) from the covered/collision checks - remove it unless it is pure decoration', R(e.getBoundingClientRect()));
    });
    // 10. CANVAS text (comic posters, scene labels): audit.py hooks fillText/strokeText before the page loads and clears the
    //     list right before the audited frame is drawn. Same rules as HTML text: on-screen size, frame, covered, collisions.
    var CV = (window.__cvText || []).filter(function (c) { return c.r[2] > pr.l && c.r[0] < pr.r && c.r[3] > pr.t && c.r[1] < pr.b; });
    var skipCv = window.TN_AUDIT_SKIP_CANVAS || [];   // page opt-out for pure decoration, e.g. ['!!', 'ZZZ']
    var cvFill = CV.filter(function (c) { return !c.stroke || !CV.some(function (d) { return d !== c && !d.stroke && d.t === c.t && Math.abs(d.r[0] - c.r[0]) < 3 && Math.abs(d.r[1] - c.r[1]) < 3; }); });
    cvFill.forEach(function (c) {
      if (skipCv.indexOf(c.t) >= 0 || /^[!?….\s]{1,3}$/.test(c.t)) return;   // reaction marks (! ?! ...) drawn by scene FX are decoration
      var q = R({ left: c.r[0], top: c.r[1], right: c.r[2], bottom: c.r[3], width: c.r[2] - c.r[0], height: c.r[3] - c.r[1] }), label = '"' + c.t.slice(0, 34) + '" (canvas)';
      if (c.r[0] < pr.l - 1 || c.r[2] > pr.r + 1 || c.r[1] < pr.t - 1 || c.r[3] > pr.b + 1) add('err', 'frame', 'text cut by the frame: ' + label, q, c.col || '?');
      if (c.fs < 14.5) add('err', 'tiny', 'text ' + c.fs.toFixed(1) + 'px on screen - below the 15 px floor: ' + label, q, c.col || '?');
      else if (c.fs < 17.5 && isSentence(c.t)) add('warn', 'small', 'reading text ' + c.fs.toFixed(1) + 'px on screen - sentences need >= 18 px: ' + label, q, c.col || '?');
      // covered by a DOM card / window / Nexi drawn over the canvas
      var hit = 0, n2 = 0, who2 = {};
      for (var yy = 0; yy < 2; yy++) for (var xx = 0; xx < 7; xx++) {
        var px = q.l + q.w * (xx + .5) / 7, py = q.t + q.h * (.3 + yy * .4); if (px < pr.l || px > pr.r || py < pr.t || py > pr.b) continue; n2++;
        var st3 = document.elementsFromPoint(px, py);
        for (var k3 = 0; k3 < st3.length; k3++) { var h3 = st3[k3]; if (h3.tagName === 'CANVAS') break; if (h3 === post || h3 === document.body || h3 === document.documentElement || (h3.closest && h3.closest('.hb')) || vis(h3) < .08) continue;
          var c3 = getComputedStyle(h3); if (h3.namespaceURI !== 'http://www.w3.org/2000/svg' && h3.tagName !== 'IMG' && (c3.backgroundColor === 'transparent' || /,\s*0\)$/.test(c3.backgroundColor)) && c3.backgroundImage === 'none' && c3.borderTopWidth === '0px' && !([].some.call(h3.childNodes, function (z) { return z.nodeType === 3 && z.nodeValue.trim(); }))) continue;
          if (h3.namespaceURI === 'http://www.w3.org/2000/svg' && h3.tagName !== 'image' && paintedFill(h3) < .35) continue;
          hit++; who2[h3.closest && h3.closest('.nx') ? 'Nexi' : nm(h3)] = 1; break; }
      }
      if (n2 && hit / n2 > .18) add(hit / n2 > .4 ? 'err' : 'warn', 'covered', 'text ' + Math.round(hit / n2 * 100) + '% covered by ' + Object.keys(who2).join(', ') + ': ' + label, q);
      // collides with HTML/SVG text
      T.forEach(function (o) { if (inter(ink(o), { l: q.l, r: q.r, t: q.t + q.h * .15, b: q.b - q.h * .15 }, 1)) add('err', 'collide', 'text collides: ' + label + ' / "' + txt(o.e) + '"', q); });
    });
    for (var ci = 0; ci < cvFill.length; ci++) for (var cj = ci + 1; cj < cvFill.length; cj++) {
      var A2 = cvFill[ci], B2 = cvFill[cj]; if (A2.t === B2.t && Math.abs(A2.r[0] - B2.r[0]) < 3 && Math.abs(A2.r[1] - B2.r[1]) < 3) continue;
      var ia = { l: A2.r[0], r: A2.r[2], t: A2.r[1] + (A2.r[3] - A2.r[1]) * .15, b: A2.r[3] - (A2.r[3] - A2.r[1]) * .15 }, ib2 = { l: B2.r[0], r: B2.r[2], t: B2.r[1] + (B2.r[3] - B2.r[1]) * .15, b: B2.r[3] - (B2.r[3] - B2.r[1]) * .15 };
      if (inter(ia, ib2, 1)) add('err', 'collide', 'canvas text collides: "' + A2.t.slice(0, 30) + '" / "' + B2.t.slice(0, 30) + '"', { l: Math.min(ia.l, ib2.l), t: Math.min(ia.t, ib2.t), w: Math.max(ia.r, ib2.r) - Math.min(ia.l, ib2.l), h: Math.max(ia.b, ib2.b) - Math.min(ia.t, ib2.t) });
    }
    // 11. LAYERING: a device / window / big card covering part of another one's controls (post 114, 2026-10-10: the
    //     middle phone hid the side phones' "Track order" / "Pay now" buttons while every word stayed readable, so the
    //     covered-text check passed). Containers = outermost boxes with a fill, rounded corners, >= 60k px2, holding text.
    var pe2 = document.createElement('style'); pe2.textContent = '*{pointer-events:auto!important}'; document.head.appendChild(pe2);
    try {
      var hasFill = function (cs) { var b = cs.backgroundColor; return (b && b !== 'transparent' && !/,\s*0\)$/.test(b)) || cs.backgroundImage !== 'none'; };
      var boxes = [].filter.call(post.querySelectorAll('*'), function (e) {
        if (e.closest('[data-audit="skip"],[data-audit="overlay"]') || vis(e) < .3 || e.namespaceURI === 'http://www.w3.org/2000/svg') return false;
        var cs = getComputedStyle(e); if (!hasFill(cs) || (parseFloat(cs.borderTopLeftRadius) || 0) < 8) return false;
        var q = e.getBoundingClientRect(), A = q.width * q.height; if (A < 60000 || A > PA * .55) return false;
        return (e.textContent || '').trim().length > 8;
      });
      boxes = boxes.filter(function (e) { return !boxes.some(function (o) { return o !== e && o.contains(e); }); });
      for (var bi = 0; bi < boxes.length; bi++) for (var bj = bi + 1; bj < boxes.length; bj++) {
        var BA = boxes[bi], BB = boxes[bj], qa = R(BA.getBoundingClientRect()), qb = R(BB.getBoundingClientRect());
        var ox = { l: Math.max(qa.l, qb.l), t: Math.max(qa.t, qb.t), r: Math.min(qa.r, qb.r), b: Math.min(qa.b, qb.b) };
        if (ox.r - ox.l < 6 || ox.b - ox.t < 6) continue;
        var top = null, st4 = document.elementsFromPoint((ox.l + ox.r) / 2, (ox.t + ox.b) / 2);
        for (var k4 = 0; k4 < st4.length; k4++) { if (BA.contains(st4[k4])) { top = BA; break; } if (BB.contains(st4[k4])) { top = BB; break; } }
        if (!top) continue;
        var low = top === BA ? BB : BA;
        // controls of the lower box that reach into the overlap: text hosts and filled pills/buttons
        [].forEach.call(low.querySelectorAll('*'), function (e) {
          if (vis(e) < .3) return;
          var own = [].some.call(e.childNodes, function (z) { return z.nodeType === 3 && z.nodeValue.trim(); }), cs = getComputedStyle(e);
          var pill = hasFill(cs) && (parseFloat(cs.borderTopLeftRadius) || 0) >= 4 && (e.textContent || '').trim().length > 0;
          if (!own && !pill) return;
          var q = R(e.getBoundingClientRect()); if (q.w < 4 || q.h < 4 || q.w * q.h > 60000) return;
          var ix2 = Math.min(q.r, ox.r) - Math.max(q.l, ox.l), iy2 = Math.min(q.b, ox.b) - Math.max(q.t, ox.t); if (ix2 < 6 || iy2 < 6) return;
          var vis2 = 0, n4 = 0;
          for (var sy = 0; sy < 3; sy++) for (var sx = 0; sx < 6; sx++) { var X = q.l + q.w * (sx + .5) / 6, Y = q.t + q.h * (sy + .5) / 3; if (X < pr.l || X > pr.r || Y < pr.t || Y > pr.b) continue; n4++; var s5 = document.elementsFromPoint(X, Y); for (var k5 = 0; k5 < s5.length; k5++) { if (low.contains(s5[k5])) { vis2++; break; } if (top.contains(s5[k5])) break; } }
          if (!n4) return; var f = vis2 / n4;
          if (f > .05 && f < .95) add((pill && f < .9) || (own && f < .6) ? 'err' : 'warn', 'layer', nm(top) + ' covers ' + Math.round((1 - f) * 100) + '% of a control in ' + nm(low) + ': "' + txt(e) + '"', q);
        });
      }
    } finally { pe2.remove(); }
    // de-duplicate
    var seen2 = {}; return out.filter(function (x) { var k = x.kind + x.msg; if (seen2[k]) return false; seen2[k] = 1; return true; });
  }
  // every visible text with its on-screen box, colour and size, for the pixel-based CONTRAST check in audit.py
  window.TN_AUDIT_TEXTS = function (post) {
    var pr = post.getBoundingClientRect(), res = [];
    function push(e, q, col, halo, fs, label) { res.push({ r: [q.left - pr.left, q.top - pr.top, q.width, q.height], c: col, halo: !!halo, fs: fs, t: label }); }
    var walker = document.createTreeWalker(post, NodeFilter.SHOW_TEXT, null), seen = new Set();
    for (var n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!n.nodeValue.trim()) continue; var h = n.parentNode; if (!h || seen.has(h) || (h.closest && h.closest('svg'))) continue; seen.add(h);
      if (vis(h) < .5 || h.closest('[data-audit="skip"],[data-qa-skip]')) continue;
      var cs = getComputedStyle(h); if (cs.webkitBackgroundClip === 'text' || /,\s*0\)$/.test(cs.color) || cs.color === 'transparent') continue;
      var rg = document.createRange(); rg.selectNodeContents(h); var q = rg.getBoundingClientRect(); if (q.width < 2 || q.height < 2) continue;
      push(h, q, cs.color, cs.textShadow !== 'none' || parseFloat(cs.webkitTextStrokeWidth) > 0, parseFloat(cs.fontSize) * effScale(h), txt(h));
    }
    [].forEach.call(post.querySelectorAll('svg text'), function (e) {
      if (vis(e) < .5 || e.closest('[data-audit="skip"],[data-qa-skip]') || !txt(e)) return;
      var cs = getComputedStyle(e); if (!/^rgb/.test(cs.fill)) return; var q = e.getBoundingClientRect(); if (q.width < 2) return;
      var m = e.getScreenCTM(), sc = m ? Math.hypot(m.a, m.b) : 1;
      push(e, q, cs.fill, cs.stroke !== 'none' && parseFloat(cs.strokeWidth) > 0, parseFloat(cs.fontSize) * sc, txt(e));
    });
    (window.__cvText || []).forEach(function (c) { if (c.stroke || !/^(#|rgb)/.test(c.col || '')) return; var halo = (window.__cvText || []).some(function (d) { return d.stroke && d.t === c.t && Math.abs(d.r[0] - c.r[0]) < 4; });
      push(null, { left: c.r[0], top: c.r[1], width: c.r[2] - c.r[0], height: c.r[3] - c.r[1] }, c.col, halo, c.fs, c.t.slice(0, 34) + ' (canvas)'); });
    return res;
  };

  window.TN_AUDIT_MARK = function (post, list) {   // draw red/orange boxes for the screenshot
    list.forEach(function (x, i) {
      if (!x.r) return; var d = document.createElement('div');
      d.style.cssText = 'position:absolute;z-index:9999;pointer-events:none;left:' + (x.r[0] - 4) + 'px;top:' + (x.r[1] - 4) + 'px;width:' + (x.r[2] + 8) + 'px;height:' + (x.r[3] + 8) + 'px;border:3px solid ' + (x.lvl === 'err' ? '#FF1F4B' : '#FF9F1A') + ';border-radius:6px;box-shadow:0 0 0 2px #fff';
      var b = document.createElement('b'); b.textContent = i + 1; b.style.cssText = 'position:absolute;left:-3px;top:-24px;font:800 15px/20px Inter,sans-serif;color:#fff;background:' + (x.lvl === 'err' ? '#FF1F4B' : '#FF9F1A') + ';padding:0 6px;border-radius:4px';
      d.appendChild(b); post.appendChild(d);
    });
  };
})();
