# -*- coding: utf-8 -*-
"""Copy finished posts to the shared drive and prove every byte arrived (Google Drive sync can corrupt big binaries).

    python deliver.py <out_dir> "<drive folder>" [--source page.html other.py ...]

OWNER RULE 2026-10-10: the posting-image folder (Marketing\02. TechNext Folder\02. TechNext Social Media Posting Image) is
IMAGES ONLY - "dont add video in this folder" - and every created image ALSO gets a copy in its
"00. All Images (2026-10-09 to 10-10)" folder. So by default this script copies images, captions and source only, plus the
flat All Images copy. Reels are copied only with --with-video to a destination the owner named for video.
ONE FOLDER PER BATCH, ONE FILE PER POST (owner 2026-10-07: "remove duplicate images. compile all created image in one folder"):
    NN-technext-<slug>.png (3:4, 2160x2880)      -> <drive>/Image Posts/
    NN-technext-<slug>-reel.mp4 (9:16)          -> <drive>/Video Posts/
    captions.md                                 -> <drive>/
Never copies @2x files, overview sheets or reel covers (they repeat the posts). Overview sheets stay in the work folder.
--source files go to <drive>/source/. Never deletes anything on the drive. Prints OK/MISMATCH per file; exit 1 on any mismatch.
AUDIT GATE (owner 2026-10-10: "do audit all images, always check if the text are too small to read, overflowing text,
layering"): before copying, every image's source page (pNN.html next to the out folder, or v2/ v3/) is re-audited with
audit.py; ANY audit error, a missing page, or a page edited after its render refuses the whole delivery."""
import argparse, glob, hashlib, re, shutil, subprocess, sys, pathlib

ap = argparse.ArgumentParser()
ap.add_argument('src'); ap.add_argument('dest'); ap.add_argument('--source', nargs='*', default=[])
ap.add_argument('--with-video', action='store_true', help='also copy reels (never into the posting-image folder)')
ap.add_argument('--all', default=r'G:/Shared drives/Marketing/02. TechNext Folder/02. TechNext Social Media Posting Image/00. All Images (2026-10-09 to 10-10)', help='flat folder that gets a copy of every image ("" to skip)')
a = ap.parse_args()
src, dest = pathlib.Path(a.src), pathlib.Path(a.dest)
dest.mkdir(parents=True, exist_ok=True)


def where(f):
    if f.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp'): return dest / 'Image Posts' / f.name
    if f.suffix.lower() in ('.mp4', '.mov'): return dest / 'Video Posts' / f.name
    return dest / f.name


pats = ['[0-9]*-technext-*.png', 'captions.md'] + (['[0-9]*-technext-*.mp4'] if a.with_video else [])
if a.with_video and 'Posting Image' in str(dest): sys.exit('refused: the posting-image folder is images only (owner 2026-10-10)')
files = [pathlib.Path(f) for p in pats for f in sorted(glob.glob(str(src / p))) if '@2x' not in f and not re.search(r'-cover\.(png|jpg)$', f)
         and (pathlib.Path(f).name == 'captions.md' or re.match(r'\d{2,3}-technext-', pathlib.Path(f).name))]
# ---- audit gate ----
pages, why = [], []
for f in files:
    m = re.match(r'(\d+)-technext-', f.name)
    if not m or f.suffix.lower() != '.png': continue
    n = int(m.group(1)); w = src.parent
    cand = [w / f'p{n}.html', w / f'p{n:02d}.html', w / 'v3' / f'p{n:02d}.html', w / 'v2' / f'p{n:02d}.html']
    pg = next((c for c in cand if c.exists()), None)
    if not pg: why.append(f'no source page for {f.name}'); continue
    if pg.stat().st_mtime > f.stat().st_mtime + 1: why.append(f'{pg.name} was edited after {f.name} was rendered - re-render first')
    pages.append(pg)
if why: sys.exit('refused (audit gate):\n  ' + '\n  '.join(why))
if pages:
    rep = src.parent / 'qa' / 'audit-gate'
    r = subprocess.run([sys.executable, str(pathlib.Path(__file__).resolve().parent / 'audit.py'), *map(str, sorted(set(pages))), '--f', '34', '--port', '9496', '--out', str(rep)],
                       cwd=str(src.parent), capture_output=True, text=True, encoding='utf-8', errors='replace')
    print(r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-400:])
    if r.returncode != 0: sys.exit(f'refused (audit gate): audit errors - fix them first, see {rep / "report.md"}')
pairs = [(f, where(f)) for f in files]
pairs += [(pathlib.Path(s), dest / 'source' / pathlib.Path(s).name) for s in a.source]
if a.all: pairs += [(f, pathlib.Path(a.all) / f.name) for f in files if f.suffix.lower() == '.png']   # flat copy of every image
md5 = lambda p: hashlib.md5(pathlib.Path(p).read_bytes()).hexdigest()
bad = 0
for s, d in pairs:
    d.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(s, d)
    ok = md5(s) == md5(d)
    bad += not ok
    print(('OK       ' if ok else 'MISMATCH ') + (str(d.relative_to(dest)) if dest in d.parents else str(d)))
print(f'{len(pairs) - bad}/{len(pairs)} verified in {dest}')
sys.exit(1 if bad else 0)
