# -*- coding: utf-8 -*-
"""Contact sheets for review.

    python sheet.py out/12-*.png out/13-*.png --out out/00-overview.jpg      side-by-side overview of posts
    python sheet.py out/12-technext-x.mp4 --frames 0.4,1,2,4,7.8 --out qa/x.jpg   frames across a video's timeline

@2x files are skipped automatically. Read the sheet with the Read tool: it is how you check a batch by eye."""
import argparse, glob, os, shutil, subprocess, tempfile, pathlib
from PIL import Image, ImageDraw

ap = argparse.ArgumentParser()
ap.add_argument('files', nargs='+'); ap.add_argument('--out', required=True)
ap.add_argument('--frames'); ap.add_argument('--w', type=int, default=0)
a = ap.parse_args()
files = [f for g in a.files for f in sorted(glob.glob(g)) if '@2x' not in f]
labels, ims = [], []
if a.frames:
    ff = shutil.which('ffmpeg') or next(iter(glob.glob(os.path.expanduser('~/AppData/Local/Microsoft/WinGet/Packages/*FFmpeg*/ffmpeg-*/bin/ffmpeg.exe'))), None)
    tmp = pathlib.Path(tempfile.mkdtemp())
    for t in a.frames.split(','):
        o = tmp / f'{t}.png'
        subprocess.run([ff, '-v', 'error', '-y', '-ss', t, '-i', files[0], '-frames:v', '1', str(o)], check=True)
        ims.append(Image.open(o).convert('RGB')); labels.append(f't={t}s')
else:
    for f in files:
        ims.append(Image.open(f).convert('RGB')); labels.append(pathlib.Path(f).stem[:40])
w = a.w or (540 if len(ims) <= 3 else 432 if len(ims) <= 5 else 300)
th = [im.resize((w, round(im.height * w / im.width)), Image.LANCZOS) for im in ims]
h = max(t.height for t in th)
sheet = Image.new('RGB', (len(th) * (w + 24) + 24, h + 64), '#EAF0FB')
d = ImageDraw.Draw(sheet)
for i, (t, l) in enumerate(zip(th, labels)):
    sheet.paste(t, (24 + i * (w + 24), 44)); d.text((26 + i * (w + 24), 16), l, fill='#1F1F3D')
pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
sheet.save(a.out, quality=90)
print('sheet ->', a.out, f'({len(th)} images)')
