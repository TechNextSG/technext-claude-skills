"""Move the latest post images into the reorganised posting-image folder (owner 2026-10-10: "move properly all image here
G:\\Shared drives\\Marketing\\02. TechNext Folder\\02. TechNext Social Media Posting Image").
The owner's layout there: batches 07-11 hold Image Posts/ + captions.md + source/ (+ Paid Ads/ in 07), no Video Posts;
00. All Images (...) holds every image flat. Copies the LATEST local renders (they carry every fix), md5-checks each copy,
then removes the now-redundant image copies from the stray old path (00. TechNext Folder). Reels are not touched.
usage: python move_images.py A B C D [E]"""
import hashlib, pathlib, shutil, sys
HOME = pathlib.Path.home()
NEW = pathlib.Path(r'G:/Shared drives/Marketing/02. TechNext Folder/02. TechNext Social Media Posting Image')
OLD = pathlib.Path(r'G:/Shared drives/Marketing/00. TechNext Folder/02. TechNext Social Media Posting Image')
ALL = NEW / '00. All Images (2026-10-09 to 10-10)'
B = {'A': ('social-2026-10-09-hero', '07. Creative Posts + FB Ads (2026-10-09)', '10. Creative Posts + FB Ads (2026-10-09)', ['kit.css', 'kit.js', 'hero.css', 'hero.js', 'scene.js']),
     'B': ('social-2026-10-09-industries-b', '08. Industry Posts (2026-10-09)', '11. Industry Posts (2026-10-09)', ['kit.css', 'kit.js', 'hero.css', 'hero.js', 'scene.js']),
     'C': ('social-2026-10-09-odoo-services', '09. Odoo Services Posts (2026-10-09)', '12. Odoo Services Posts (2026-10-09)', ['kit.css', 'kit.js', 'hero.css', 'hero.js', 'scene.js', 'detail.js']),
     'D': ('social-2026-10-09-odoo-ui', '10. Odoo Interface Posts (2026-10-09)', '13. Odoo Interface Posts (2026-10-09)', ['kit.css', 'kit.js', 'hero.css', 'hero.js', 'scene.js', 'detail.js', 'odoo-ui.css', 'odoo-ui.js']),
     'E': ('social-2026-10-10-brand-ui', '11. Odoo Interface Posts - Brand (2026-10-10)', None, ['kit.css', 'kit.js', 'hero.css', 'hero.js', 'scene.js', 'detail.js', 'odoo-ui.css', 'odoo-ui.js', 'brand.css', 'brand.js'])}
md5 = lambda p: hashlib.md5(pathlib.Path(p).read_bytes()).hexdigest()
bad = 0


def put(src, dst):
    global bad
    dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, dst)
    if md5(src) != md5(dst): bad += 1; print('MISMATCH', dst)
    return dst


for k in sys.argv[1:]:
    work, new, old, libs = B[k]; w = HOME / 'ClaudeWork' / work; dest = NEW / new; n = 0
    for f in sorted((w / 'out').glob('[0-9][0-9]-technext-*.png')):
        if '@2x' in f.name: continue
        put(f, dest / 'Image Posts' / f.name); put(f, ALL / f.name); n += 1
    for f in sorted((w / 'out-ads').glob('*@2x.png')) if (w / 'out-ads').exists() else []:
        t = 'technext-' + f.name.split('-technext-', 1)[1].replace('@2x.png', '-4x5.png'); put(f, dest / 'Paid Ads' / t); put(f, ALL / t); n += 1
    for f in sorted((w / 'out-ads').glob('*-reel.mp4')) if (w / 'out-ads').exists() else []:
        put(f, dest / 'Paid Ads' / ('technext-' + f.name.split('-technext-', 1)[1].replace('-reel.mp4', '-9x16.mp4')))
    for name in ('captions.md', 'facebook-ads-details.md'):
        if (w / 'out' / name).exists(): put(w / 'out' / name, dest / name)
    for f in sorted(w.glob('p[0-9][0-9].html')) + sorted(w.glob('ad[1-3].html')) + [w / x for x in libs]:
        put(f, dest / 'source' / f.name)
    print(f'{k}: {n} images -> {dest.name} (+ All Images), captions + source refreshed')
    # remove the redundant image copies left at the stray old path (the reels there are kept until the owner decides)
    if old and (OLD / old).exists():
        gone = 0
        for f in list((OLD / old / 'Image Posts').glob('*.png')) + list((OLD / old / 'Paid Ads').glob('*.png')) if (OLD / old / 'Image Posts').exists() else []:
            nf = dest / ('Paid Ads' if f.parent.name == 'Paid Ads' else 'Image Posts') / f.name
            if nf.exists() and md5(nf) == md5(f): f.unlink(); gone += 1
        print(f'   removed {gone} duplicate images from the old path')
print('ALL VERIFIED' if not bad else f'{bad} MISMATCHES')
sys.exit(1 if bad else 0)
