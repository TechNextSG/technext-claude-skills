"""Readability pass (owner 2026-10-10: "some of the content like this are too small. fix this apply to all edits").
Brand rule: labels >= 15 px, anything to be read >= 18 px at 1080 wide. Rewrites font sizes in post pages / specs /
odoo-ui.css: CSS shorthand `NNpx/`, `font-size:NNpx`, SVG `font-size="NN"` and el() `'font-size': NN`.
Sizes < 9 (decorative barcode digits) and >= 25 (headings, KPIs) are left alone.
usage: python upsize.py file [file ...]"""
import re, sys

MAP = {9: 15, 10: 15, 11: 15, 11.5: 15, 12: 15, 13: 15, 14: 16, 15: 17, 16: 18, 17: 19, 18: 20, 19: 22, 20: 22, 21: 23, 22: 24, 23: 25, 24: 26}


def new(v):
    f = float(v)
    if f < 9 or f >= 25: return v
    k = min(MAP, key=lambda m: abs(m - f))
    n = MAP[k]
    return str(n)


def fix(s):
    s = re.sub(r'(?<![\w.-])(\d+(?:\.\d+)?)px/', lambda m: new(m.group(1)) + 'px/', s)
    s = re.sub(r'font-size:\s*(\d+(?:\.\d+)?)px', lambda m: 'font-size:' + new(m.group(1)) + 'px', s)
    s = re.sub(r'font-size="(\d+(?:\.\d+)?)"', lambda m: 'font-size="' + new(m.group(1)) + '"', s)
    s = re.sub(r"'font-size': (\d+(?:\.\d+)?)", lambda m: "'font-size': " + new(m.group(1)), s)
    return s


for p in sys.argv[1:]:
    s = open(p, encoding='utf-8').read(); t = fix(s)
    open(p, 'w', encoding='utf-8').write(t); print(('changed ' if t != s else 'same    ') + p)
