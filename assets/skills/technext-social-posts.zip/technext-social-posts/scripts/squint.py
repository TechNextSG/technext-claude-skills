"""Feed-size squint sheet for the fresh-eyes review (reference/fresh-eyes-review.md).

For every PNG it lays out, side by side: the post at feed-grid size (default 270 px wide,
roughly an Instagram/Facebook grid tile on a phone) and the same tile blurred, so the text
can't be read and only the composition is left. Look at each pair for 3 seconds and write
the two sentences the review asks for.

Usage:
  python squint.py out/*.png --out qa/squint.jpg [--w 270] [--blur 6]
Needs Pillow only. Reads the images; writes one JPG sheet. Never touches the delivery folder.
"""
import argparse
import glob
import os

from PIL import Image, ImageDraw, ImageFilter


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("images", nargs="+", help="PNG files or globs")
    ap.add_argument("--out", default="qa/squint.jpg")
    ap.add_argument("--w", type=int, default=270, help="tile width in px (feed size)")
    ap.add_argument("--blur", type=float, default=6.0, help="Gaussian blur radius on the tile")
    a = ap.parse_args()

    files = []
    for pat in a.images:
        files.extend(sorted(glob.glob(pat)) or [pat])
    files = [f for f in files if os.path.isfile(f)]
    if not files:
        raise SystemExit("no images found")

    gap, label_h = 16, 22
    rows = []
    for f in files:
        im = Image.open(f).convert("RGB")
        h = round(a.w * im.height / im.width)
        tile = im.resize((a.w, h), Image.LANCZOS)
        rows.append((os.path.basename(f), tile, tile.filter(ImageFilter.GaussianBlur(a.blur))))

    row_h = max(t.height for _, t, _ in rows) + label_h + gap
    sheet = Image.new("RGB", (gap + 2 * (a.w + gap), gap + row_h * len(rows)), "white")
    d = ImageDraw.Draw(sheet)
    y = gap
    for name, tile, blur in rows:
        d.text((gap, y), name, fill=(16, 28, 69))
        sheet.paste(tile, (gap, y + label_h))
        sheet.paste(blur, (2 * gap + a.w, y + label_h))
        y += row_h

    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    sheet.save(a.out, quality=88)
    print(f"squint sheet: {a.out} ({len(rows)} posts, tile {a.w}px, blur {a.blur})")


if __name__ == "__main__":
    main()
