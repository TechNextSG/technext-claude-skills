# -*- coding: utf-8 -*-
"""Measure a post instead of guessing: prints window.__dbg (projected anchors the page exposes), every data-qa rect and
the QA list, optionally at time t and as a screenshot. Uses its own Chrome profile, so it can run next to render.py.

    python dbg.py page.html 21 [--t 2.6] [--f 34|reel] [--shot qa/x.png] [--port 9479]
Parallel runs: give each its own --port (it also gets its own Chrome profile)."""
import argparse, base64, json, pathlib, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import _cdp

ap = argparse.ArgumentParser()
ap.add_argument('page'); ap.add_argument('p'); ap.add_argument('--t'); ap.add_argument('--f', default='34'); ap.add_argument('--shot')
ap.add_argument('--port', type=int, default=9479)
a = ap.parse_args()
page = pathlib.Path(a.page).resolve()
W, H = 1080, {'34': 1440, 'reel': 1920, '45': 1350}[a.f]
proc, c = _cdp.session(W, H, port=a.port, profile='dbg' if a.port == 9479 else f'dbg-{a.port}')
try:
    c.call('Emulation.setDeviceMetricsOverride', width=W, height=H, deviceScaleFactor=1, mobile=False)
    c.call('Page.navigate', url=f'{page.as_uri()}?p={a.p}&f={a.f}')
    for _ in range(200):
        time.sleep(.2)
        if c.ev("document.documentElement.getAttribute('data-ready')") == '1': break
    if a.t: c.ev(f'window.R({a.t}); 0')
    print(json.dumps({k: [round(x) for x in v] for k, v in (c.ev('window.__dbg') or {}).items() if v}))
    print(c.ev("JSON.stringify([...document.querySelectorAll('.post.on [data-qa]')].map(e=>{var r=e.getBoundingClientRect();return (e.className.baseVal!==undefined?e.className.baseVal:e.className).split(' ').slice(0,2).join('.')+' '+[r.left,r.top,r.right,r.bottom].map(Math.round)}))"))
    print(c.ev('JSON.stringify(window.__layout)'))
    if a.shot:
        d = c.call('Page.captureScreenshot', format='png', clip={'x': 0, 'y': 0, 'width': W, 'height': H, 'scale': 1})['data']
        pathlib.Path(a.shot).write_bytes(base64.b64decode(d)); print('shot ->', a.shot)
finally:
    proc.terminate()
