#!/bin/bash
# usage: bash layer_audit.sh <NN> <port>   - audits card NN at 12-27 frames (entrances, flights, idle, end); report d<NN>/qa/layaudit/report.md
N=$1; P=$2; R=~/ClaudeWork/carousel-2026-10-16-designs
python ~/ClaudeWork/qa/carousel-layer-audit/mk_frames.py $N >/dev/null
cd $R/d$N && python ~/.claude/skills/technext-social-posts/scripts/audit.py p0[0-9][0-9][0-9].html --f 34 --port $P --out qa/layaudit > qa/layaudit.log 2>&1
tail -1 qa/layaudit.log; grep -E "^## |ERR|WARN" qa/layaudit/report.md | cut -c1-200
rm -f p0[0-9][0-9][0-9].html
