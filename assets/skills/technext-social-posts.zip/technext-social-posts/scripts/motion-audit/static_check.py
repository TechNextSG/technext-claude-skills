# Pixels changing >=10 levels between consecutive frames inside regions that should be still (headline + footer), frames 180-599
import sys, subprocess, numpy as np
FF = r'C:\Users\leuss\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1.2-full_build\bin\ffmpeg.exe'
mp4 = sys.argv[1]; boxes = {'headline': (60, 150, 1000, 330), 'footer-right': (700, 1235, 1020, 1300)}
W, H = 1080, 1350
p = subprocess.Popen([FF, '-loglevel', 'error', '-i', mp4, '-f', 'rawvideo', '-pix_fmt', 'gray', '-'], stdout=subprocess.PIPE)
prev = None; i = 0; worst = {k: (0, -1) for k in boxes}
while True:
    b = p.stdout.read(W * H)
    if len(b) < W * H: break
    a = np.frombuffer(b, np.uint8).reshape(H, W).astype(np.int16)
    if prev is not None and i >= 180:
        for k, (x0, y0, x1, y1) in boxes.items():
            n = int((np.abs(a[y0:y1, x0:x1] - prev[y0:y1, x0:x1]) >= 10).sum())
            if n > worst[k][0]: worst[k] = (n, i)
    prev = a; i += 1
print(mp4.split('/')[-1][:2], {k: f'{v[0]} px (frame {v[1]})' for k, v in worst.items()})
