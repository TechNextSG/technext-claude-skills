# Make per-frame copies of each design page (the page reads ?frame= at load; we set it with history.replaceState first)
import pathlib, re, sys
root = pathlib.Path.home() / 'ClaudeWork/carousel-2026-10-16-designs'
common = [9, 45, 75, 150, 240, 330, 420, 510, 597]
extra = {'06': [30, 90, 150, 210], '07': [24, 36, 48, 60, 72, 115, 190],
         '08': [105, 112, 120, 128, 136, 140, 255, 262, 270, 278, 286, 290, 405, 412, 420, 428, 436, 440],
         '09': [15, 30, 60], '10': [36, 42, 50, 66, 80, 96, 110, 126, 140]}
for n in (sys.argv[1:] or ['06', '07', '08', '09', '10']):
    d = root / f'd{n}'; src = (d / f'p{n}.html').read_text(encoding='utf-8')
    for old in d.glob('p0[0-9][0-9][0-9].html'): old.unlink()
    fr = sorted(set(common + extra[n]))
    for f in fr:
        inj = f"<script>history.replaceState(null,'',location.pathname+'?frame={f}')</script>"
        s = re.sub(r'(<head[^>]*>)', r'\1' + inj, src, count=1)
        (d / f'p{f:04d}.html').write_text(s, encoding='utf-8')
    print(n, len(fr), 'frames')
