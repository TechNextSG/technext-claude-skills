# 2x stills of chosen frames per card, cropped to the overlap zones, one sheet per card
import sys, os, subprocess, pathlib
from PIL import Image, ImageDraw
root = pathlib.Path.home() / 'ClaudeWork/carousel-2026-10-16-designs'
n = sys.argv[1]; port = sys.argv[2]; frames = [int(x) for x in sys.argv[3].split(',')]
zones = [tuple(int(v) for v in z.split(':')) for z in sys.argv[4].split(',')]  # x0:y0:x1:y1 in 1080 coords
d = root / f'd{n}'; out = d / 'qa' / 'zoom'; out.mkdir(parents=True, exist_ok=True)
tiles = []
for f in frames:
    p = out / f'f{f:04d}@2x.png'
    subprocess.run([sys.executable, str(root / 'framerender.py'), f'p{n}.html', '--still', str(f), str(p), '--port', port, '--scale', '2'], cwd=d, check=True, capture_output=True)
    im = Image.open(p)
    for z in zones:
        c = im.crop(tuple(v * 2 for v in z)); c.thumbnail((640, 640))
        dr = ImageDraw.Draw(c); dr.rectangle([0, 0, 150, 26], fill='black'); dr.text((6, 6), f'f{f} {z}', fill='white')
        tiles.append(c)
W = 640; cols = len(zones); rows = len(frames)
sheet = Image.new('RGB', (W * cols, max(t.height for t in tiles) * rows), 'white')
h = max(t.height for t in tiles)
for k, t in enumerate(tiles): sheet.paste(t, ((k % cols) * W, (k // cols) * h))
sheet.save(out / f'zoom-{n}.jpg', quality=88); print(out / f'zoom-{n}.jpg', sheet.size)
