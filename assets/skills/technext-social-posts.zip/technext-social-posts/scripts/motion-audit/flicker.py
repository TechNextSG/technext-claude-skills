# Flicker map for a rendered card: pixels that are static most of the time but jump between consecutive frames
# (e.g. a tilted device edge re-rasterised differently per capture). usage: python flicker.py <mp4> <out.png> [from] [to]
import sys, subprocess, numpy as np
from PIL import Image
FF = r'C:\Users\leuss\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.1.2-full_build\bin\ffmpeg.exe'
mp4, out = sys.argv[1], sys.argv[2]; a = int(sys.argv[3]) if len(sys.argv) > 3 else 150; b = int(sys.argv[4]) if len(sys.argv) > 4 else 599
W, H = 1080, 1350
p = subprocess.Popen([FF, '-loglevel', 'error', '-i', mp4, '-f', 'rawvideo', '-pix_fmt', 'gray', '-'], stdout=subprocess.PIPE)
prev = None; spikes = np.zeros((H, W), np.uint16); calm = np.zeros((H, W), np.uint16); n = 0; i = 0
while True:
    buf = p.stdout.read(W * H)
    if len(buf) < W * H: break
    f = np.frombuffer(buf, np.uint8).reshape(H, W).astype(np.int16)
    if prev is not None and a <= i <= b:
        d = np.abs(f - prev); spikes += (d >= 10); calm += (d <= 2); n += 1
    prev = f; i += 1
# flicker = mostly calm (>= 70 % of steps) but spikes in >= 4 % of steps
fl = (calm >= .70 * n) & (spikes >= .04 * n)
ys, xs = np.nonzero(fl)
print(f'{mp4.split("/")[-1]}: {fl.sum()} flicker px over {n} steps')
img = Image.open(subprocess.run([FF, '-loglevel', 'error', '-ss', '8', '-i', mp4, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'], capture_output=True).stdout and __import__('io').BytesIO(subprocess.run([FF, '-loglevel', 'error', '-ss', '8', '-i', mp4, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'], capture_output=True).stdout)).convert('RGB')
arr = np.array(img); arr = (arr * .45 + 140).astype(np.uint8); arr[fl] = [255, 0, 0]
# grow red dots so they are visible
from PIL import ImageFilter
m = Image.fromarray((fl * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(5)); arr[np.array(m) > 0] = [255, 0, 0]
Image.fromarray(arr).save(out)
if len(xs):
    # coarse clusters on a 40 px grid
    g = {}
    for x, y in zip(xs, ys): g[(x // 40, y // 40)] = g.get((x // 40, y // 40), 0) + 1
    top = sorted(g.items(), key=lambda kv: -kv[1])[:12]
    print('  hot cells (x,y ~px: count):', ', '.join(f'({k[0]*40},{k[1]*40}):{v}' for k, v in top))
