# -*- coding: utf-8 -*-
"""DEEP AUDIT of finished post pages - the blocking QA gate before render and delivery (owner, 2026-10-09: "properly audit
all images, theres alot of overflowing text and some not properly alligned content"; 2026-10-10: "do audit all images,
always check if the text are too small to read, overflowing text, layering, etc..").

Works on both page kinds: TN.boot social posts (kit.js; poster time + reel motion frames) and technext-site-posts pages
(`.f` frame, static). For every post/format it checks, with audit.js in the page:
  READABILITY  text size measured ON SCREEN after transforms/3D/zoom (< 15 px = error, sentences < 18 px = warning),
               CONTRAST of every text against the pixels really behind it (screenshot; error < 2.2:1 small / 1.8:1 big)
  OVERFLOW     text spilling its pill/plate/box, clipped by a container, cut by the frame, hugging the edge
  LAYERING     text covered by art/cards/Nexi, text-on-text collisions, devices/windows covering another one's
               controls, cards on Nexi's face, plate-less text on busy art, pointer-events:none hiding text
  CANVAS       fillText/strokeText is hooked before the page loads: canvas labels get the same size/frame/cover rules
  LAYOUT       near-miss alignment, brand margin, objects cut by the frame, TN.qa safe zones
Writes:
    <out>/report.md + report.json        one section per post, errors first
    <out>/NN-<fmt>-audit.png             screenshot with numbered red (error) / orange (warning) boxes
    <out>/audit-sheet.jpg                contact sheet of every flagged screenshot
usage: python audit.py <page.html | folder> [...] [--f 34,reel] [--port 9495] [--out qa/audit] [--errors-only] [--no-contrast]
Exit code 1 when any ERROR remains - delivery is blocked until it is 0 (warnings need a look, not always a fix)."""
import argparse, base64, io, json, pathlib, re, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import _cdp

ap = argparse.ArgumentParser()
ap.add_argument('pages', nargs='+'); ap.add_argument('--f', default='34,reel'); ap.add_argument('--port', type=int, default=9495)
ap.add_argument('--out', default='qa/audit'); ap.add_argument('--errors-only', action='store_true'); ap.add_argument('--no-contrast', action='store_true')
a = ap.parse_args()
JS = (pathlib.Path(__file__).resolve().parent / 'audit.js').read_text(encoding='utf-8')
out = pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)
for old in out.glob('*-audit.png'): old.unlink()

# canvas text hook, installed before any page script runs (records on-screen box, size, colour, stroke/fill)
HOOK = r"""(function(){
  window.__cvText = []; window.__pageErrs = [];
  window.addEventListener('error', function (e) { window.__pageErrs.push((e.message || '') + ' line ' + e.lineno); });
  var P = CanvasRenderingContext2D.prototype;
  ['fillText', 'strokeText'].forEach(function (fn) { var orig = P[fn];
    P[fn] = function (t, x, y, mw) { try { if (this.canvas && String(t).trim()) {
      var cv = this.canvas, host = cv;
      if (!cv.isConnected) { host = [].filter.call(document.querySelectorAll('canvas'), function (k) { return k.isConnected && k.width === cv.width && k.height === cv.height; })[0]; }
      if (host) {
        var m = this.measureText(t), w = (mw && m.width > mw) ? mw : m.width, al = this.textAlign, x0 = x;
        if (al === 'center') x0 = x - w / 2; else if (al === 'right' || al === 'end') x0 = x - w;
        var asc = m.actualBoundingBoxAscent || 0, des = m.actualBoundingBoxDescent || 0, T = this.getTransform();
        var cr = host.getBoundingClientRect(), k = cr.width / host.width;   // canvas px -> CSS px
        var pts = [[x0, y - asc], [x0 + w, y - asc], [x0, y + des], [x0 + w, y + des]].map(function (q) { return [T.a * q[0] + T.c * q[1] + T.e, T.b * q[0] + T.d * q[1] + T.f]; });
        var xs = pts.map(function (q) { return q[0]; }), ys = pts.map(function (q) { return q[1]; });
        var px = parseFloat((this.font.match(/([\d.]+)px/) || [0, 10])[1]);
        window.__cvText.push({ t: String(t).slice(0, 60), stroke: fn === 'strokeText', col: typeof this.fillStyle === 'string' ? this.fillStyle : '',
          fs: px * Math.hypot(T.a, T.b) * k, r: [cr.left + Math.min.apply(0, xs) * k, cr.top + Math.min.apply(0, ys) * k, cr.left + Math.max.apply(0, xs) * k, cr.top + Math.max.apply(0, ys) * k] });
      } } } catch (e) {} return orig.apply(this, arguments); }; });
})();"""

pages = []
for p in a.pages:
    p = pathlib.Path(p)
    pages += sorted(p.glob('p[0-9]*.html')) + sorted(p.glob('ad[0-9]*.html')) if p.is_dir() else [p]
jobs = []
for pg in pages:
    s = pg.read_text(encoding='utf-8')
    tn = re.findall(r"slugs:\s*\{\s*(\d+):\s*'([^']+)'", s)
    if tn:
        for n, slug in tn:
            t = (re.findall(r"poster:\s*\{\s*%s:\s*([\d.]+)" % n, s) or ['0'])[0]
            fm = [f for f in a.f.split(',')]
            # paid ads (adN.html pages, posts 91-93 of 2026-10-09) are 4:5; ordinary posts keep 3:4 at any number (87-122+)
            if pg.name.startswith('ad'): fm = ['45' if f == '34' else f for f in fm]
            for f in fm: jobs.append((pg, int(n), slug, float(t), f, 'tn'))
    else:   # technext-site-posts page: .f frame 1080x1440, static, number from pNN, slug from <title>
        m = re.search(r'p(\d+)', pg.stem); ttl = re.search(r'<title>([^<]+)</title>', s)
        jobs.append((pg, int(m.group(1)) if m else 0, (ttl.group(1) if ttl else pg.stem).strip(), 0.0, '34', 'site'))

POST = "(document.querySelector('.post.on') || document.querySelector('.post') || document.querySelector('.f') || document.body)"


def lum(c):
    c = [v / 255 for v in c]; c = [v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4 for v in c]
    return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]


def parse_col(s):
    s = (s or '').strip()
    if s.startswith('#'):
        h = s[1:]; h = ''.join(ch * 2 for ch in h) if len(h) in (3, 4) else h
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = re.match(r'rgba?\(([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)', s)
    return tuple(int(float(v)) for v in m.groups()) if m else None


def contrast_items(png, texts):
    """Pixel contrast: text colour vs the median colour of the non-text pixels in (and just around) its box."""
    import numpy as np
    from PIL import Image
    im = np.asarray(Image.open(io.BytesIO(png)).convert('RGB')).astype(np.int16); S = im.shape[1] / 1080.0; res = []
    for t in texts:
        col = parse_col(t['c'])
        if not col or t['halo'] or t['fs'] < 6: continue
        x, y, w, h = [v * S for v in t['r']]
        y0, y1 = int(y + h * .2), int(y + h * .8); x0, x1 = int(x), int(x + w)
        if x1 - x0 < 4 or y1 - y0 < 3: continue
        reg = im[max(0, y0):max(0, y1), max(0, x0):max(0, x1)].reshape(-1, 3)
        if reg.size == 0: continue
        d = np.abs(reg - np.array(col)).sum(1)
        if (d < 60).mean() < .02: continue                    # the text colour is not there (covered / tinted) - other checks handle it
        bg = reg[d > 110]
        if len(bg) < max(20, .12 * len(reg)):                  # tight pill: sample a ring just outside the box
            pad = int(6 * S); ring = im[max(0, int(y) - pad):int(y + h) + pad, max(0, int(x) - pad):int(x + w) + pad].reshape(-1, 3)
            bg = ring[np.abs(ring - np.array(col)).sum(1) > 110]
        if len(bg) < 20: continue
        b = tuple(int(v) for v in np.median(bg, 0)); l1, l2 = lum(col), lum(b); cr = (max(l1, l2) + .05) / (min(l1, l2) + .05)
        big = t['fs'] >= 28
        lim_e, lim_w = (1.8, 2.6) if big else (2.2, 3.0)
        if cr < lim_w:
            res.append({'lvl': 'err' if cr < lim_e else 'warn', 'kind': 'contrast', 'msg': f'low contrast {cr:.1f}:1 (text rgb{col} on rgb{b}): "{t["t"]}"',
                        'r': [round(v) for v in t['r']]})
    return res


def seethrough(png, x):
    """[covered] check: are the text's glyph strokes still visible at the covered sample points? A pixel counts as a stroke
    when it stands out from the local background (> 60) AND sits at least halfway from that background towards the text
    colour - so a white gloss or glass that only lightens the text passes, an opaque card or heavy tint does not."""
    col = parse_col(x.get('tcol')); pts = x.get('pts') or []
    if not col or not pts: return False
    import numpy as np
    from PIL import Image
    im = np.asarray(Image.open(io.BytesIO(png)).convert('RGB')).astype(np.int16); S = im.shape[1] / 1080.0
    cw, ch = x.get('cell') or [8, 8]; regs = []
    for px, py_ in pts:
        x0, x1 = int((px - cw / 2) * S), int((px + cw / 2) * S); y0, y1 = int((py_ - ch / 2) * S), int((py_ + ch / 2) * S)
        reg = im[max(0, y0):max(0, y1), max(0, x0):max(0, x1)].reshape(-1, 3)
        if reg.size: regs.append(reg)
    if not regs: return False
    reg = np.concatenate(regs); tc = np.array(col); bg = np.median(reg, 0)
    dbt = np.abs(bg - tc).sum()
    if dbt < 60: return False                      # text colour ~ background: nothing to measure
    dpt = np.abs(reg - tc).sum(1); dpb = np.abs(reg - bg).sum(1)
    stroke = (dpb > 60) & ((dbt - dpt) / dbt >= .5)
    return stroke.mean() >= .04


def canvas_visible(png, x):
    """Is this canvas text really on the final image? (its colour must show inside its box; unknown colour = assume yes)"""
    col = parse_col(x.get('col'))
    if not col or not x.get('r'): return True
    import numpy as np
    from PIL import Image
    im = np.asarray(Image.open(io.BytesIO(png)).convert('RGB')).astype(np.int16); S = im.shape[1] / 1080.0
    l, tp, w, h = [v * S for v in x['r']]
    reg = im[max(0, int(tp)):max(0, int(tp + h)), max(0, int(l)):max(0, int(l + w))].reshape(-1, 3)
    return reg.size > 0 and (np.abs(reg - np.array(col)).sum(1) < 60).mean() >= .03


proc, c = _cdp.session(1080, 1920, port=a.port, profile=f'audit-{a.port}')
rep, flagged = [], []
try:
    c.call('Page.addScriptToEvaluateOnNewDocument', source=HOOK)
    for pg, n, slug, t, f, kind in jobs:
        H = {'34': 1440, 'reel': 1920, '45': 1350}[f]
        c.call('Emulation.setDeviceMetricsOverride', width=1080, height=H, deviceScaleFactor=1, mobile=False)
        if kind == 'tn':
            c.call('Page.navigate', url=f'{pg.resolve().as_uri()}?p={n}&f={f}')
            ready = False
            for _ in range(200):
                time.sleep(.2)
                if c.ev("document.documentElement.getAttribute('data-ready')") == '1': ready = True; break
            if not ready:   # a page that never booted (JS error, missing file) shows nothing - auditing it would pass falsely (74/76, 2026-10-10)
                errs = c.ev("JSON.stringify(window.__pageErrs || [])")
                rep.append({'post': n, 'slug': slug, 'fmt': f, 'page': str(pg), 'items': [{'lvl': 'err', 'kind': 'boot', 'msg': f'page never set data-ready="1" - it did not render (JS error?) {errs}', 'r': None, 't': t}]})
                print(f'{n:02d} {f:4s} {slug[:44]:44s} 1 err (page did not boot)', flush=True)
                continue
        else:
            c.call('Page.navigate', url=pg.resolve().as_uri())
            for _ in range(100):
                time.sleep(.2)
                if c.ev("document.readyState === 'complete' && document.fonts.status === 'loaded' && (window.__spReady || !window.SP) ? 1 : 0") == 1: break
            time.sleep(.8)
            pe = c.ev("JSON.stringify(window.__pageErrs || [])")
            if pe and pe != '[]':
                rep.append({'post': n, 'slug': slug, 'fmt': f, 'page': str(pg), 'items': [{'lvl': 'err', 'kind': 'boot', 'msg': f'page threw JS errors while loading: {pe}', 'r': None, 't': t}]})
                print(f'{n:02d} {f:4s} {slug[:44]:44s} 1 err (JS error)', flush=True)
                continue
        c.ev(JS + '; 0')
        found = {}
        frames = [t] + ([0, 2, 4, 6] if f == 'reel' else [])
        for tt in frames:
            if kind == 'tn':
                c.ev("(function(){var keep = window.__cvText || []; window.__cvText = []; window.R(%s); if (!window.__cvText.length) { var s = {}; window.__cvText = keep.filter(function (x) { var k = x.t + '|' + Math.round(x.r[0]) + '|' + Math.round(x.r[1]); if (s[k]) return false; s[k] = 1; return true; }); }})(); 0" % tt)
            q = "TN.qa(%s)" % POST if kind == 'tn' else "[]"
            res = c.ev("JSON.stringify({a: TN_AUDIT(%s), q: %s})" % (POST, q))
            res = json.loads(res) if isinstance(res, str) else {'a': [{'lvl': 'err', 'kind': 'js', 'msg': str(res), 'r': None}], 'q': []}
            items = res['a'] + [{'lvl': 'err', 'kind': 'qa', 'msg': x, 'r': None} for x in res['q']]
            if tt == t:   # poster frame: a clean 2x screenshot for the pixel checks
                png = base64.b64decode(c.call('Page.captureScreenshot', format='png', clip={'x': 0, 'y': 0, 'width': 1080, 'height': H, 'scale': 2})['data'])
                items = [x for x in items if not x.get('col') or canvas_visible(png, x)]   # canvas text painted over by later canvas art is not a fault
                items = [x for x in items if not (x['kind'] == 'covered' and x.get('pts') and seethrough(png, x))]   # see-through layer over readable text
                if not a.no_contrast:
                    texts = c.ev("JSON.stringify(TN_AUDIT_TEXTS(%s))" % POST)
                    try: items += contrast_items(png, json.loads(texts))
                    except Exception as e: items.append({'lvl': 'warn', 'kind': 'contrast', 'msg': f'contrast check skipped: {e}', 'r': None})
            for x in items:
                if tt != t and x['kind'] in ('tiny', 'small', 'pad', 'centre', 'vcentre', 'busy', 'align', 'cut', 'margin', 'edge', 'crossed', 'contrast', 'pe', 'layer'): continue   # motion frames: hard faults only
                if tt != t and (x['kind'] in ('covered', 'collide', 'nexi', 'face') or (x['kind'] == 'qa' and x['msg'].startswith('overlap'))): x['lvl'] = 'warn'   # things passing in front mid-motion: look, don't block
                k = x['kind'] + x['msg']
                if k not in found: x['t'] = tt; found[k] = x
        items = sorted(found.values(), key=lambda x: (x['lvl'] != 'err', x['kind']))
        if a.errors_only: items = [x for x in items if x['lvl'] == 'err']
        rep.append({'post': n, 'slug': slug, 'fmt': f, 'page': str(pg), 'items': items})
        if items:
            if kind == 'tn': c.ev(f'window.R({t}); 0')
            c.ev("TN_AUDIT_MARK(%s, %s); 0" % (POST, json.dumps([x for x in items if x.get('t') == t])))
            d = c.call('Page.captureScreenshot', format='png', clip={'x': 0, 'y': 0, 'width': 1080, 'height': H, 'scale': 1})['data']
            shot = out / f'{n:02d}-{f}-audit.png'; shot.write_bytes(base64.b64decode(d)); flagged.append(shot)
        ne = sum(x['lvl'] == 'err' for x in items); nw = len(items) - ne
        print(f'{n:02d} {f:4s} {slug[:44]:44s} {"CLEAN" if not items else f"{ne} err, {nw} warn"}', flush=True)
finally:
    proc.terminate()

md = ['# Post audit', '', f'{len(rep)} post/format runs, {sum(1 for r in rep if any(x["lvl"] == "err" for x in r["items"]))} with errors, '
      f'{sum(1 for r in rep if r["items"] and not any(x["lvl"] == "err" for x in r["items"]))} with warnings only.', '']
for r in rep:
    if not r['items']: continue
    md += [f'## {r["post"]:02d} {r["slug"]} ({r["fmt"]})', '']
    md += [f'{i + 1}. **{x["lvl"].upper()}** [{x["kind"]}] {x["msg"]}' + (f' (t={x["t"]})' if x.get('t') is not None else '') for i, x in enumerate(r['items'])] + ['']
(out / 'report.md').write_text('\n'.join(md), encoding='utf-8')
(out / 'report.json').write_text(json.dumps(rep, indent=1), encoding='utf-8')
if flagged:
    try:
        from PIL import Image
        th = [Image.open(p).convert('RGB') for p in flagged]
        W = 360; cols = 6; rows = (len(th) + cols - 1) // cols
        sheet = Image.new('RGB', (cols * (W + 8) + 8, rows * (int(W * 1920 / 1080) + 8) + 8), 'white')
        for i, im in enumerate(th):
            im = im.resize((W, int(W * im.height / im.width))); sheet.paste(im, (8 + (i % cols) * (W + 8), 8 + (i // cols) * (int(W * 1920 / 1080) + 8)))
        sheet.save(out / 'audit-sheet.jpg', quality=82)
    except Exception as e:
        print('sheet skipped:', e)
errs = sum(x['lvl'] == 'err' for r in rep for x in r['items'])
print(f'AUDIT: {errs} errors, {sum(x["lvl"] == "warn" for r in rep for x in r["items"])} warnings -> {out / "report.md"}')
sys.exit(1 if errs else 0)
