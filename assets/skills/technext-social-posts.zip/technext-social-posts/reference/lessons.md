# Lessons (read before building; add to it after every batch)

## Owner feedback
- 2026-10-06: first batch reused an old poster generator -> "don't use the previous format (Paid Ads Studio, Drip Studio),
  create a brand new design following technext.asia". Every batch is a new design; techniques may be reused.
- 2026-10-06: "more creative, not flat" -> depth (iso, glass, studio). Then "more dynamic" -> motion + energy.
- 2026-10-06: logo rule: TechNext logo fixed top-left on every post; Odoo = plain wordmark, no background, no Ready badge.
- 2026-10-06 (on post 14, the hologram): **"DONT DO THIS KIND FOR DESIGN"** - no dark sci-fi / hologram / wireframe
  dashboards crowded with small glowing info panels and labels. Prefer **light backgrounds**, few big elements, big type.
  "Experiment with the placement of text" (bottom, centred around an object, side column, inside a shape - not always
  top-left). "Occasionally showcase Nexi"; when Nexi appears with Odoo apps the background goes **playful** (sky, clouds,
  confetti, pastel shapes). "Create 3 quick designs" = simpler scenes, one hero idea each.
- 2026-10-06: "dont do flat design or workflow, it's boring ... look for more effect, design and style" -> process lives
  inside a themed scene (blueprint, globe, hologram), never as a box-arrow-box rail.

- 2026-10-07: after 15-25 (a new style AND a new camera per post) the owner said **"properly design the material, some
  inconsistenct. you can use the nexi video skill for improving the materials."** -> one house template per batch in the
  Nexi Quick Tips world (`template.md`): envkit painted sets, Odoo 17 record window with the process as its LOG, costumed
  Nexi from the current engine, Nexi caption card, same type scale and footer. Variety now lives in palette, costume,
  app and copy - not in layout, type or camera. 21-25 were redone as v2 this way.
- 2026-10-07: the one-template v2 was not it either: **"make it dynamic, cinematic, and unique in different poster/content,
  no similar design like what we do previously."** Read "inconsistency" as uneven finish, not as "make them all alike".
  Now: every poster its own film look + build + text placement + MP4 loop (`cinematic.md`); 21-25 redone as v3.
- 2026-10-07: **"for social media posting, use 4:3 ratio only. high quality image. for video format, use 9:16 format
  social media posting reels."** -> images 3:4 (1080x1440 + 2160x2880 HQ), video 9:16 reels only; enforced in
  render.py/kit.js; `formats.md`. 21-25 v3 re-rendered in both formats.
- 2026-10-07: **"remove duplicate images. compile all created image in one folder in this session"** -> one flat delivery
  folder, one file per post (final version, high-quality 3:4), reels beside them; no 2nd sizes, overview sheets, reel
  covers or v1/v2 versions. render.py now writes one image; deliver.py copies flat and skips overviews/covers.
- 2026-10-07: **"always seperate the video and image posting."** -> every delivery: `Image Posts/` + `Video Posts/`.
- 2026-10-07 batch 26-28 ("3 more design, dynamic, different camera angle"): one-point perspective piles every far object
  on the vanishing point, so labels anchored to objects stack up. Pin the labels at the rack edges (fixed slots) and
  link them with dotted leaders to small numbered badges on the objects; spread objects over left / middle / right lanes.
- A character added as a DOM image over a WebGL scene can't be occluded by 3D props: make it a textured plane in the
  scene (TextureLoader works from file:// in render.py's Chrome) and copy the camera quaternion each frame.
- Far objects in fog/haze or against a bright door vanish: shorten the set (bring the dock closer), give them strong
  colour (blue truck, blue stretch-wrap) and push the fog start back.

## Format adaptation gotchas (2026-10-07)
- Canvases with a fixed CSS height (1350px) squash taller drawings: always `height:100%`.
- `ctx.setTransform()` inside a painter wipes the scene's `translate(0, DY)`: add DY back (post 24 wing prints floated).
- A reel needs more air between the subtitle and the scene: plane 3 hit the subtitle until DY grew 150 -> 196.
- Keep the horizontal field of view fixed across formats; re-frame with view offset / a small camera solver.
- The Bash tool halves backslashes: a Python patch sent through it turned a regex word-boundary escape into a backspace
  character and a newline escape into a real line break inside a JS string (both broke kit.js). Write patches with
  the Write/Edit tools; search a file for control characters (chr(8)) after any shell-driven patch.
- Don't end a JS line with `// comment` and then append code to that line in a patch (it commented out `S.cam = cam`).

## Rendering gotchas
- A `linearGradient` with default objectBoundingBox on a perfectly straight horizontal/vertical line paints **nothing**
  (zero-height box). Use a solid stroke or `gradientUnits="userSpaceOnUse"` with real coordinates.
- A filled radial-gradient "rim light" on a sphere washed the whole globe peach. Rim light = a *stroked* circle with a
  linear gradient (+ a blurred copy).
- Absolute `top` values for stacked panels drift as text wraps -> overlaps. Stack them in a flex column and place
  anything below from the column's measured bottom.
- `<textPath>` text turns upside down where the path runs right-to-left; ring text longer than pi*r gets clipped.
- Decoration (stars, sparks, dots) must skip the text zone or it lands inside letters.
- Elements placed by guessed coordinates collide; measure with getBoundingClientRect in setup and position from that.
- A setup that loads data (world atlas) must return its promise; kit.js waits for it before data-ready.
- Saving a PNG that the app's file pane has open can fail with `OSError [Errno 22]`: just re-run that post.
- Bash heredocs containing JS quotes break ("unexpected EOF"): write patch scripts with the Write tool.
- Bash halves backslashes; Windows paths in Python strings: use forward slashes.
- Google Drive: build on local disk, copy with deliver.py (md5 check). Never write MP4/PNG straight into Drive.
- The grain overlay sits at z-index 30 (under text at 40+) so headlines stay crisp.

- Small direction triangles that are nearly equilateral read the wrong way once rotated. Use an arrow with a shaft
  (`M-8 0 H7 M1 -6 L7 0 L1 6`) or a long thin chevron, and zoom a crop of the @2x PNG to check direction.
- A circle with one diagonal bar reads as a "no entry" sign: draw dials/cranks with the handle outside the circle.
- Full-width text containers (left 0 / right 0) trip the frame QA: give text blocks real margins or inline-block.

- 2026-10-07 owner: "add more creativity on the model/design, use different camera angle, make it exaggerated" -> every post
  now picks a camera from camera.md; Nexi is re-rendered from that angle (nexi-cam), not a front-view PNG tilted.
- A camera looking straight down a row of objects stacks them; shoot 30-40 deg off-axis. A curved row hid three of six.
- Guessing label offsets wastes renders: measure the label rects (CDP eval of getBoundingClientRect) and fix in one go.

- Batch 21-25: a first camera is usually too close (objects crop at the edges): start wide, then push in.
- Tilt-shift only reads when the blur bands overlap the scene itself; bands placed over empty floor or text do nothing.
- When Nexi or a big prop fills the bottom-left, mirror the footer (`.foot{flex-direction:row-reverse}`) so the button
  stays on clear ground.
- A floating card (lead, ticket) can carry its own step number instead of a separate pill; fewer labels, fewer collisions.

- v2 template: a window placed high (y < 600) slid behind the headline; a lamp prop crowded the logo; the caption card
  overlapped the subtitle at x < 650 and hid the chef hat when Nexi was 600px tall (500-536 fits). Measure, don't guess.
- Reuse the video engine by COPYING files (envkit -> qtworld.js via make_qtworld.py; nexi-core.js into kit/nexi-cam);
  writing into ~/ClaudeWork/nexi-tutorial/web/assets breaks every film's gate fingerprint.
- The old kit/nexi-cam core (qa/nexi-ads) had no costumes; the current engine's `N.wear()` does. Hide `N.aura` for stills.

## Design notes that worked
- One clear hero object per post (tower, globe, hologram) + 3-4 supporting labels; a single Caveat note for warmth.
- Odoo app icons as physical things in the scene (stickers, tags, tiles) read better than icons in a row.
- Real Odoo vocabulary (RFQ, FEFO, progress claim, retention, session close) makes it credible; label samples.
- Dark scenes need white Odoo wordmark + white TechNext logo; light scenes the colour versions.
- What the owner asked for after rejecting 14, as built in 15-17 (awaiting review): one hero object, big type, text placed to suit the object (bottom,
  centred around it, side column), Nexi in one post of three with a playful sky.

## 2026-10-09 batch 29-46 + FB ads (hero-style request)
- "Use the design format from hero slide 1 and 2" taken literally (orbit + process board on every post) -> owner: "repetative design
  and format. looks templated", "too much orbit, card, box, make it more creative", "dont do long form. only social media format".
  Borrow the SITE'S LANGUAGE (type, blue, Odoo icons, Nexi), never one composition for a whole batch. One metaphor per post.
- "THE DESIGN ARE TO CORNERD IN LOWER PART": write a vertical budget first; 2-line headlines (~96-110 px) when a visual shares the frame.
- "add nexi model if needed to add more elements in the space" + "make nexi in dynamic posing and reaction": re-render Nexi per post
  with nexi-cam in action holds (hero, heroL, jump, gasp, celebrate, reach) + faces (star, wow, love, happy, content) + low/dutch
  cameras + costumes; animate with squash/bounce (scene.js HB.act) and add a reaction FX (burst lines, "!", hearts, sparkle pop).
- "make dinamic bacground": kit/scene.js = themed animated layers (blobs, rays, rings, clouds, birds, waves, bubbles, leaves,
  confetti, shapes incl. pill/coin/check/heart/balloon/paper/chili, gears, paper plane, light shaft + motes). Pick 3-5 per post that
  fit the metaphor; keep the text zone in `avoid`. Time the poster frame so the reaction is visible (32: after the stamp lands).
- "ALWAYS SEND HERE THE IMAGE FOR PREVIEW" + "properly name the created image": SendUserFile every preview, saved as
  preview/NN-technext-<topic>-<concept>.png (never pNN.png); SLUGS carry the same descriptive name into render.py output.
- impeccable craft floor applied: no gradient headline text (site uses solid blue .hl), no unicode/emoji glyphs as icons (drawn SVG ticks/hearts).
- Class-name clash: hero.css `.pm` (process map) restyled a postcard's `.pm` postmark -> prefix one-off classes per post.
- render.py reels: ~1.5 frames/s at 1080x1920 -> ~2.5 min per reel; run batches in the background and write captions meanwhile.

## 2026-10-09 (late) - detail pass, audit, Odoo interface batch (posts 57-76)
- "make sure the design are more detailed": flat hero objects read as unfinished. kit/detail.js (DT) gives textures laid OVER a
  shape (`DT.over(shape, 'url(#dt-grain)')`: speck, weave, grain, planks, stripe, dots, tile, grass, circuit, ripple, brick,
  hatch), bbox shading (dt-gv/gh/gr), cheap radial contact shadows (dt-sh, no blur filter) and props (tree, palm, bush, tufts,
  flowers, city, lamp, fence, gear, carton, star5, shell, potplant, cloud, screw, gloss). Aim for 8-15 small, story-true props
  per scene (pegboard + clock in a tailor's room, kerb stripes + traffic light on a course, sandcastle + lane floats on a beach).
- "properly audit all images, alot of overflowing text and not properly alligned content": TN.qa only knew HTML data-qa boxes.
  scripts/audit.py + audit.js now check every SVG and HTML text item. What it caught (all fixed): sign text wider than its board
  (size boards from `getComputedTextLength()`, never a fixed width), balloon names spilling the envelope (measure the envelope
  at that height), "PLAN"/"SUPPORT" past their plates, a racing number half under a wheel, stacked labels drifting 4-9 px because
  each had its own animation phase (aligned groups share ONE phase), a lot label MIRRORED when its tractor flipped with
  scale(-1,1) (counter-flip text), a shadow over a sign, the hovering stamp hiding a tag at t=0, a carton flap over a label,
  text 9-11 px (minimum 12 px; barcode digits are decoration -> data-audit="skip").
- Audit false positives fixed in the tool (do not reintroduce): glyph cells are taller than letters (use the ink band, fs*.74);
  a plate must hold >=60% of the word and live in the text's own group (not passing smoke or a shading patch); transparent HTML
  wrappers and an element's own ::after glare never "cover"; text hidden by an overflow container (far side of a lens) is skipped;
  in motion frames things passing in front are warnings, safe-zone/clipping stay errors.
- Hidden-but-present text still counts: a card waiting inside a machine, the clipped half of an opened doll -> set
  visibility:hidden or remove the node, don't just clip it.
- Class clashes with the shared CSS broke real layouts again: hero.css `.hd` (an absolute white card) washed out a POS header;
  also `.pl`, `.grid`, `.pg`, `.h`; kit.css `.chip`, `.sub`. Before writing page CSS run
  `grep -o "\.\(name\)[ {:.,]" hero.css kit.css` for every new class, or prefix them.
- Never append a `// comment` to a line you splice into the middle of JS: it commented out the rest of the line (a doll vanished).
- Reel right zone (140 px clear below y 1000) bites side-by-side layouts: use TN.pick for left/scale/rotation (POS printer moved in,
  phone scaled .72 and leaned the other way, draft card floats up above y 1000 in the reel only).
- After stopping a render task, kill its orphan headless Chrome (`remote-debugging-port=<port>` in the command line) before
  re-rendering on that port, or every post fails at session start.
- Odoo interface batch (67-76): crisp HTML UI beats drawn UI. Vary the device and angle per post (laptop on desk, rotated board
  with a lifted card, exploded 3D layers, phone over desktop, tilted card plane, tablet + receipt printer, two windows in depth,
  perspective Gantt, three fanned phones, sheet + dashboard). Animate the real interaction (drag to Won, count-up, scan, reconcile,
  tap, reply, reschedule, timer, drag a chart). Keep a "sample data" mark on every window and away from the data it labels.

## 2026-10-10 - brand skins, sub-lines, readable sizes (posts 77-86, 67-76 resized)
- "use the technext branding. background and color": the live site has two skins - the white paper hero (blue-050 44 px grid,
  blue aurora) and the brand-blue Nexi slide with yellow #FFD23F highlights and yellow CTA. Off-brand washes (peach, mint,
  slate, lavender) used in 67-76 read as "not TechNext". kit/brand.css + brand.js reproduce both; charts in blue tones.
- "add short sub description below, use inter as fonts": `.hw .sub` Inter 500 29 px under the 2-line headline; plan the
  vertical budget with it (scene starts ~560 in 3:4).
- "some of the content like this are too small": the UI mockups used 12-14 px labels and 15/13 px toasts - below the brand
  floor (15 px labels, 18 px reading text). Toasts now 24/18 px with a 44 px icon; all UI text lifted with scripts/upsize.py
  (12->15, 13->15, 14->16, 15->17, 16->18 ...). Bigger text grows windows: re-audit every post (frames, overlaps, reel safe zone)
  and trim content (a row, a column, a day) rather than shrinking type again. Measure row heights instead of hard-coding them.
- Class clashes keep coming (`.pn`, `.ci`): run the clash grep for every new class.
- (2026-10-10, owner screenshot) A toast sat on top of Nexi (86). Nexi must stay fully visible: audit.js now samples Nexi's
  body and flags any card, toast, window or text stacked on her (>20% = error). Fixed 86 (toast + Nexi moved) and 48 reel
  (invoice slid over him). Place Nexi in his own free zone first, then the floating UI.
- Made the mid-line `// comment` mistake again (48): it silently disabled the rest of the line. Comments go on their own line.
- (2026-10-10) "why the last batch of image background are not dynamic but technext branding?" - asked for brand colours, I
  swapped the living backgrounds for the site's flat skins. Wrong: brand colours go INTO the living background. brand.js v2
  BR.skin = site paper/blue + drifting blue aurora + grid light-sweep + blurred Odoo app icons + glossy shapes (z 5, behind
  the UI); BR.layers = pulsing rings, the TechNext paper plane with its dashed trail, rays (dark), bokeh, sparkles. A new
  rule never cancels an older standing rule unless the owner says so.
- (2026-10-10) The owner reorganised the drive while batches were still being re-delivered: Marketing\02. TechNext Folder  02. TechNext Social Media Posting Image\ with batches renumbered (07-11) and 00. All Images; images only, no Video Posts.
  My next re-delivery wrote to the old path and recreated a stray "00. TechNext Folder". Before every delivery, list the
  destination parent and match the owner's current layout; never recreate a folder the owner removed.

## 2026-10-10 (late) - 36 posts with 7 parallel helpers (87-122)
- Owner: "3 nexi introduction (nexi-explains page theme, comical) + 3 nexi introduction (technext branding) + 30 random
  collective content ... dont do comical design ... much detailed properly audited ... create alot of variation".
  What worked: ONE written brief (`~/ClaudeWork/qa/BRIEF-2026-10-10-collection.md`, copied to kit/examples) with the owner's
  words, the standing rules, facts fetched from the live blog/pages, a definition of done and a per-post concept (headline,
  sub, CTA, family, props, Nexi pose/costume), then one helper per 3-6 posts, each in its OWN work folder
  (`qa/setup_2026-10-10_collection.py` copies the kits) with its OWN ports (render/dbg/audit/nexi-cam). The lead reviews
  every render in 3-up sheets (`qa/grid3.py`) before anything is delivered.
- audit.py silently audited every post numbered >= 91 as a 4:5 ad (the 2026-10-09 ads were posts 91-93), so footers
  sat 90 px off and errors were false/missed. Fixed: only `ad*.html` pages are 4:5. Post numbers past 99 are fine
  everywhere (render.py `{p:02d}`); verify/deliver scripts must glob `[0-9]*-technext-` not `[0-9][0-9]-`.
- render.py prefixes `technext-` itself: a slug that starts with `technext-` gives `107-technext-technext-...`. Slugs never
  start with "technext".
- Facts for blog-based posts: fetch the article text first (curl with a browser UA into `qa/facts/`), put the exact
  numbers in the brief (InvoiceNow phases, country packages, Odoo Experience figures) and check sample maths on review
  (bill totals, GST 9%, reorder = on hand + RFQ = max).
- A centred/right headline triggers the audit's "[margin]" warning (logo/headline/CTA left edges); acceptable when the
  placement is deliberate for variety - every other warning gets fixed.

## 2026-10-10 (evening) - owner "fix this" on 114, FB ad 1, FB ad 3
- 114 (three phones): the middle phone overlapped both side phones and hid their buttons ("Track order", "Pay now"), and
  the poster frame froze the photo card mid-slide. Text-based audits pass that (the words themselves stayed visible).
  Rules: devices/windows never overlap another device's UI content (bezels may touch, screens may not); the poster time
  is a frame where EVERY animated element has settled (no card mid-slide, nothing half-faded) - check the PNG for it;
  phones stand on a platform, not sunk into it.
- FB ad 3: a giant close-up Nexi with the chat cards floating "around her head" put two cards on her visor. audit.js
  6b measured coverage of her whole body (16%) and stayed quiet. Added 6c [face]: dense samples on her head zone (top
  10-45%, inner 50% width); 1 in 10 covered = ERROR. Swept posts 29-122 + ads: only ad 3 had it. First fix moved Nexi
  (full-body, to the right) - owner: "the previous position of nexi is good. fix this". When the owner flags ONE fault,
  fix only that fault: keep the approved composition (giant Nexi rising from the bottom) and move the cards into the
  free band between the headline and her antenna.
- FB ad 1: the WITH ODOO half was a bare blue panel with six unlabelled floating icons - the claim ("one database") was
  only written, not shown. Rebuilt as labelled app tiles wired by flowing data lines into one glossy database placed
  BETWEEN the two rows (no wire crosses a tile or a label). Every region of the frame needs designed content.

## 2026-10-10 (night) - collection part 2 (123-172)
- pointer-events:none hides elements from elementsFromPoint, so text inside such a wrapper is never tested for being covered
  (a helper found it on 161/162; 114's phone wrapper had it). Forcing pointer-events on everything during the audit made
  decorative overlays (glass, glare, selection outlines, tints) into false errors, so audit.js now WARNS [pe] when a
  click-transparent wrapper holds readable text. Rule: pointer-events:none only on pure decoration.
- Review catches the audit cannot make, all from this batch: a sold-out croissant offered in a "coffee + croissant" combo
  (my brief's slip - read the story logic, not just the layout); a mirrored footer (CTA right) - the footer and logo row
  never move; Nexi seen straight from above reads as a cap - use a high three-quarter camera instead.
- Helpers lengthen slugs (odoo- prefix, extra concept words). Sync captions to the real out/ names before delivery
  (qa/sync_captions_2026-10-10.py) instead of trusting the brief's slugs.

## 2026-10-10 (late night) - "do audit all images ... too small to read, overflowing text, layering" - audit v2
- The old audit read computed font-size: a 15 px label inside a phone/window tilted in 3D, a scaled-down card or a zoomed
  site card passed while reading at 11-13 px. audit.js now measures ON-SCREEN size with a thin 1x100 px probe inside each
  text host (picks up every transform, perspective and zoom): < 15 px = error, sentences < 18 px = warning.
- Contrast was never checked: pale "sample" marks (#A3ABBD on white = 2.2:1), white text on gold chips (1.8:1), muted
  calendar days. audit.py now compares each text colour with the real pixels behind it in a 2x screenshot (median of the
  non-text pixels in the ink band, a ring outside tight pills). Shared fix: `.ou-smp` -> #6E7891.
- Canvas text (comic posters, scene labels) was invisible to the audit: audit.py hooks fillText/strokeText with
  Page.addScriptToEvaluateOnNewDocument (on-screen box + size + colour, offscreen sticker canvases mapped onto the
  visible canvas), clears it before the audited frame, and drops canvas items whose colour never shows in the final
  image (painted over by later canvas art). Caught: comic cast name tags at 12-13 px and one cut by the frame.
- Layering: a device/window/big card covering part of another one's controls = [layer] (114's buttons).
- Site pages (technext-site-posts, `.f` frame) are audited by the same tool. One catalogue run:
  map_sources.py (delivered image -> local render by md5 -> source page) + audit_all.py (parallel ports, SUMMARY.md).
  First run: 63 of 175 delivered posts had errors (281 tiny, 59 contrast, 19 covered, 6 collide, 1 plate) + 864 items
  incl. warnings, all from checks the old audit could not make. Fixed by 10 parallel fixers, "fix only the fault".
- deliver.py is now a gate: it re-audits every image's source page and refuses on any error, a missing page, or a page
  edited after its render. Custom delivery scripts must call audit.py the same way.
- Gotcha: audit_all ran each audit in its page folder with a relative --out -> reports landed in the work folders.
  Paths handed to subprocesses that change cwd must be absolute.
- Reel 52 (2026-10-10) showed a TechNext landing-page web form from t>0: two sessions rendered on the same CDP port (9421);
  the second Chrome could not bind, `_cdp.session` attached to the OTHER Chrome's tab and both drove it. `_cdp.session` now
  refuses a busy port. Always give every parallel render/dbg/audit its own port.
- Reels brief 2 (2026-10-10): owner "why some extension on space are forced? fix this" on brief-1 reels (ad2 had a second
  sketch sheet + props pasted under the CTA, ad1 stray shapes on an empty blue band). "Extended elements" means the main scene
  grows and its own surface continues; it never means a second picture, a props floor or floating icons in the caption band.
  UI posts cannot grow much (the 240-1440 safe zone is already full) - the living brand skin carries the bottom band instead.
  Review every reel on one contact sheet (qa/reel_review_2026-10-10.py: ffprobe + 3.5 s frames) before compiling.
- Seasonal batch 2026-10-10 (posts 173-188, folder 15.): owner wanted per season (Halloween, Christmas, year-end countdown,
  New Year) 1 pure GREETING (no Odoo wordmark/icons/CTA/claims - TechNext logo + "From all of us at TechNext" sign-off; the
  expected [margin] warning from the hidden footer is fine) + 3 Odoo/TechNext posts where the season is the scene. Brief:
  ~/ClaudeWork/qa/BRIEF-2026-10-10-seasonal.md. Owner: "always send a preview" - when builders run in the background,
  watch their qa/ and out/ folders (Monitor) and SendUserFile each draft/render as it lands.
- deliver.py with a RELATIVE out dir fails its audit gate (FileNotFoundError on pNN.html after its cwd change) and reports
  "refused (audit gate)". Always pass absolute paths.
- Post 189 draft (2026-10-10): ~100 px empty band between the sub-line and the sticker sheet -> owner "lower the gap, apply
  this to newer images". Rule in brand.md: visual starts ~32-40 px under the sub-line.
- FB ads r1-r3 (2026-10-11): audit.py said CLEAN on all 9, owner: "properly audit the images, theres alot of layering and
  overflow text" + "make sure factual to design workstation of odoo". The lead found orbs/rings/icons peeking behind
  monitors and TVs, Nexi's hand and a plant cut by the frame, props under the CTA, hearts on Nexi's head, a cursor on
  "Approve", a chart bar out of its card, the navbar badge/avatar pushed off the screen, a detached Nexi hand over the
  Inventory list, laptops touching, pins on sticky-note letters, footer text on the rug weave, and invented Odoo labels.
  Why the audit missed them: workspace props sit in `data-audit="skip"` SVG layers and deco/cursors carry
  pointer-events:none (invisible to elementsFromPoint and vis()); scene sparkles are canvas shapes; [face] only counted
  [data-qa] cards in a fixed zone; [covered] needs > 18 % of a word; [layer] only boxes >= 60k px2. audit.js v3 adds
  [deco] [edge-cut] [face] [cursor] [contain] [float] [stack] [line] + the [odoo-facts] lint (SKILL.md "Audit").
  Rules for builders: brand deco only in empty background, 24 px clear of devices/props/Nexi/text/CTA; objects 24 px
  inside the frame and clear of the CTA; nothing on Nexi's head; cursor tip on the button's lower-right corner; same-kind
  devices keep a gap; Odoo screens follow reference/odoo-ui-facts.md. The pink knob on top of Nexi's helmet is part of
  her PNG (antenna), not a foreign dot - the audit does not flag it.
- Audit test bench: frozen faulty ads in ~/ClaudeWork/qa/audit-v3-testcases/r1-r3 (ad1-9, --f 45) must keep reporting
  their faults; known-good p77/p78 (brand-ui), p181/p182 (seasonal-s3), p190 (nexi-companion) at --f 34 must stay at 0
  errors. Re-run both after ANY change to audit.js/audit.py (runners in ~/ClaudeWork/qa/audit-v3-work/). Never loosen
  a check to pass a page.
- deliver.py skipped `211-technext-magazine-cover-2027.png` silently: its filter dropped any name containing "-cover" (meant
  for reel cover PNGs). Now only names ending in "-cover.png/.jpg" are skipped. Always compare the delivered count with the
  number of posts in the batch.
- Owner 2026-10-11 rules (put in every brief): (1) show the ODOO side - real, factual Odoo screens, but (2) every poster its
  OWN composition (no repeated desk + monitor; workflows as staircase/conveyor/funnel/orbit/map...), (3) ~10% of each batch
  gets a background colour shifted 10-20% off the brand skins, (4) detailed + informative down to tiny details - each Odoo
  post teaches one real Odoo fact through its details. Briefs: ~/ClaudeWork/qa/BRIEF-2026-10-11-janfeb-2027-v2-dynamic.md,
  BRIEF-2026-10-11-valentines-2027.md.
- Colour-variation pass 2026-10-11: overriding HB.bg colours on 204/228 rendered ONLY background + text + CTA - the whole scene
  vanished, yet audit.py passed (it checks text/layering, not "is the scene there"). After any background change compare the new
  PNG with the old one (everything but the background must match) and LOOK at it at full size before reporting.
- v3 rebuild 2026-10-11 (owner: "make the poster as dynamic as possible, similar to previous designs" = the scheduled posts
  29-191): RESUMED builders with saturated context kept re-rendering their old layouts or only stripped texture. Fresh builders
  with a CONCRETE named world per post (brief qa/BRIEF-2026-10-11-v3-worlds.md) got it right first time. When the look must
  change, start fresh agents in new folders and name the world for every post. Owner also: NO texture overlays; content must
  be factual and match the caption (qa/V3-FACTS-NOTE.md).

## 2026-10-15 - 4:5 video carousel cards (website showcase)
- Owner asked for FB carousel VIDEO cards: 4:5 (1080x1350) is allowed for carousel ads on request (carousels take only 1:1 or 4:5; never 9:16/3:4).
- Website scroll videos: record real scroll frames with CDP (pre-scroll the page once to fire lazy images + reveal animations, set scroll-behavior auto, smootherstep ease, hold 1 s top / 1.5 s bottom), desktop 1280x872 + phone 390x844, then composite in Pillow into Chrome-rendered layers (bg / phone / top). Route: ~/ClaudeWork/carousel-2026-10-15-websites (capture.py, layers.py, compose.py, build.py).
- Check the client page for live bugs in every frame before using it in an ad (Immaculate had a duplicated "Special offers" heading + stray "amp; China," text - hidden in the capture only, reported to the owner).
- Blurred aurora DIVs trip audit [edge-cut]; paint the aurora as background radial-gradients on the frame instead.
- technext.asia blocks HeadlessChrome ("Automated access not permitted"): set a normal desktop/mobile UA with Emulation.setUserAgentOverride (capture.py does). Decline its cookie notice before recording (privacy: never Accept).
- technext.asia's hero is a timed slider: settle 4 s after scroll-to-top (SETTLE=4) and check the first 60 phone frames for a blank mid-swap frame (stddev check) before compositing.
- Card scripts are env-driven: URL, CAP (capture dir), PAGE, PFX (layer prefix), OUT.
- Cookie buttons may be uppercase via text (Casa Escondida 'DECLINE'): match the Decline button case-insensitively.
- Owner 2026-10-16: "DONT DO FASTFORWARD, DO NORMAL SPEED" + "different content wording, idea the same". Website scroll cards = rec.py: real-time CDP screencast (~40-58 fps) of an in-page rAF scroller at ~210 CSS px/s, resampled to 30 fps, 20 s, top part of the site only. Never step-scroll with screenshots (page animations crawl, scroll races). Every carousel card gets its own chip/headline/sub/bold line/Odoo label/CTA/footer (gen_pages.py). Screencast stops emitting when the page is still: guard ws.recv with a timeout.
- Owner 2026-10-16: "theres no content about free website and branding + odoo?" - offer ads must state the offer outright: yellow FREE badge (FREE + "website + branding with your Odoo", varied per card) above the headline and the word "free" in the sub-line. Word play alone ("comes with your Odoo", "on us") is not enough. Odoo itself is never called free.
- Website-scroll design cards: framerender.py (examples/2026-10-16-carousel-website-designs) renders a page frame-by-frame via window.setFrame(i) (img src = recording frame i, all motion from t, no CSS animations); a lead SPEC with 5 distinct concepts + 5 sonnet designers gave 0-error cards in ~15-25 min each. Client footage may show the client's own prices (HB S$88, Immaculate tour prices) - not our copy, but tell the owner.
- Owner 2026-10-16: "properly audit the layering design". A one-frame audit (frame 240) passed all 5 animated cards, but auditing 12-26 frames per card (entrances, swing extremes, every flight/landing frame, idle, end) found 46 errors: a fly card landing ON TOP of a kanban card before the column opened, rolling counter digits not clipped (drawn behind a window / under a stamp), a "+1" bubble over a sentence, wobbling chips touching, cards pushed out clipped by the window edge. A 2x close-up pass of every overlap zone found what no audit flags: Nexi half-behind a laptop deck (pierced look), a torso-cropped Nexi PNG faded into the floor, a sticker covering the site's text in a phone, a pen sliding under a sticky note, Nexi sitting on the CTA. RULE for any animated card/reel: run scripts/motion-audit/layer_audit.sh (per-frame copies via ?frame=) + zoom.py close-ups BEFORE delivery; choreograph landings so the slot opens first and the swap is same-frame; clip rolling digits; never put Nexi part-behind a prop with her lower body showing; use full-body Nexi PNGs only (check alpha reaches her base).
- Owner/reviewer 2026-10-17 on card 10: "a bit of disconnect between the bg visuals and the message" + "dont block the website too much". Fix that worked: every claim in the copy points at a visible object (checklist rows numbered 1-4, the SAME numbered chip pinned on the Odoo app sheet / the browser / a brand board / Nexi "We're your team"; row + object chips turn green together and KEEP their numbers). Remove props that illustrate nothing (sticky note, coffee). The showcased website stays fully visible - props sit beside it, never over its nav or screen. Check badges sit on a chip rim, never over the digit.
