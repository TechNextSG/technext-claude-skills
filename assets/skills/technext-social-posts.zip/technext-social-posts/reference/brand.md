# Brand frame (fixed - creativity goes into the scene, not here)

Source of truth: the live site technext.asia (v2 `site.css`). The hidden "Branding" tab in Marketing_Main.xlsx is stale
(Montserrat / #2563EB): ignore it.

## Canvas
**Owner rule 2026-10-07: images 3:4 only, video 9:16 Reels only** (details + safe zones in `formats.md`).
| Format | Size | URL / class | Notes |
|---|---|---|---|
| Image post (FB/IG/LinkedIn) | 1080 x 1440 (3:4) + HQ 2160 x 2880 | `?f=34` -> `.post.f-34` (default) | shows ~400 px wide on a phone |
| Reel (video) | 1080 x 1920 (9:16) | `?f=reel` -> `.post.f-reel` | text in the reel safe zone: below 190, above bottom 420, right 140 clear below y 1000 |
| legacy 4:5 | 1080 x 1350 | `?f=45` | only to re-render pre-rule examples |
Safe frame for images: nothing readable within 36 px of an edge (QA checks it). Side gutters 72 px.
Reel logo row: top 196; words top 316; footer bottom 430 (kit.css `.f-reel` rules).

## The brand row (user rule, 2026-10-06)
- `.brand` = left 72 / right 72 / top 64 / height 72, flex space-between, on **every** post. Never move the logos to a
  footer or a bar, never resize them per post.
- TechNext: `assets/logo/technext-horizontal-blue.svg`, height 44. On dark backgrounds the section has class `dark` and the
  kit turns it white (`filter: brightness(0) invert(1)`).
- Odoo: **plain wordmark** `assets/logo/odoo-logo.png` (purple o + grey doo) on light, `odoo-logo-white.png` on dark,
  height 42, **no card, no background, never the "Odoo Ready Partner" badge image**. ("Odoo Ready Partner" as words in
  copy is fine.) Source of the wordmark: `~/ClaudeWork/nexi-tutorial/web/assets/odoo-logo.png` (copy it, never edit that
  folder: the Nexi video gate fingerprints it).

## Type
- Display: Plus Jakarta Sans 800, h1 ~94 px / .98, letter-spacing -.045em, two lines: line 1 ink (or white), line 2
  `.l2` blue gradient (light gradient on dark). End lines with a period or comma like the site.
- Body: Inter. Subtitle 28 px / 1.42, max 2 lines, `text-wrap: balance`, key phrase in `<b>`.
- Hand notes: Caveat 700 (the site's `.hand` accent) for one human touch per post at most.
- Chip (eyebrow): pill with an Odoo app icon + "Odoo for <industry> · <b>angle</b>".
- Minimum readable size at 1080 wide: 15 px for labels, 18+ for anything that must be read.

## Colour
Brand blue `#3167CA`; deep `#1E4691` / `#173A7C`; light `#6FA0F5`, `#A9C6FF`, `#DDE7F8`, `#EAF0FB`; ink `#1F1F3D`;
body `#4C4C63`; muted `#6A6A84`; success `#137A4A` / `#22A55B`; alert `#D9363E`; Odoo purple `#714B67` (for Odoo UI bits).
Scenes may add an accent that suits the industry (amber construction tape, sunset rim on a globe, hologram cyan, receipt
paper) as long as blue stays the dominant brand colour.

## Footer
`.foot` bottom 58: left a pill CTA (`.btn`, white on dark posts) naming the page it opens ("See Odoo for clinics"); right
`.site` = **technext.asia** + one short line ("Odoo, set up by TechNext"). It may be restyled to suit the scene (the
blueprint post used a drawing title block) but must keep both parts.

## Assets in kit/assets
- `odoo/*.svg` - 52 official Odoo app icons (same files as technext.asia). Names: `sale`, `crm`, `stock` (Inventory),
  `purchase`, `account` (Invoicing), `accountant` (Accounting), `mrp`, `point_of_sale`, `pos_restaurant`, `project`,
  `hr_timesheet`, `helpdesk`, `documents`, `knowledge`, `ai_app`, `im_livechat`, `mail` (Discuss), `appointment`,
  `quality_control`, `maintenance`, `iot`, `website`, `website_sale` (eCommerce), `spreadsheet_dashboard`, `sign`, ...
- `nexi/*.png` - Nexi the 3D robot mascot, trimmed poses 760 px tall: hello, present, point-left, point-right, think, wow,
  love, clap, celebrate. Tint/hologram him with CSS filters; never redraw him.
- `logo/logo-plane.png` - the TechNext paper-plane mark (avatars, watermarks).

## Headline block -> visual gap (owner 2026-10-10: "lower the gap, apply this to newer images")
The main visual starts ~32-40 px below the sub-line's last line (1080-wide coordinates). No dead band of sparkles between
the headline block and the visual: grow the visual upward instead. Measure with dbg.py (`.sub` rect bottom vs the visual's
top) before rendering.
