# Captions

Write `out/captions.md`: a header, then per post: files, title, subtitle, caption. Facebook unless told otherwise.
Each platform gets its own text (owner rule from the Buffer batches): never paste the same caption everywhere.

## Facebook (default): hook + checklist + link
```
<Hook: one line, a real moment from the industry, 1 emoji max> 

<One sentence: what changes with Odoo.>
✔ <Odoo step 1 in plain words (App)>
✔ <step 2>
✔ <step 3>
✔ <step 4>

<One line on TechNext: who sets it up / for whom.>

👉 <CTA verb>: https://technext.asia/<path>

#Odoo #<Industry> #<Topic> #TechNext #<Country/Odoo app>
```
3-5 hashtags. Mention the sample nature only if a number could be mistaken for a client's real result.

## Instagram
Punchy: 2-4 short lines, the link as "link in bio", up to ~20 relevant hashtags in a block at the end.

## LinkedIn
Long-form (900-1,300 characters): a business problem, how the Odoo process solves it, one concrete detail from the image,
what TechNext does, a question to invite comments, 3 hashtags. No emoji walls.

## Formats in captions.md
Per post list its files: the image `NN-technext-<slug>.png` (3:4, 2160x2880) and, if made, the reel `-reel.mp4`.
One caption block per post, final version only (no superseded sections). The header says where files are:
`Image Posts/` and `Video Posts/`.

## Reels (9:16 video)
- Caption: hook line (what happens in the video) + 2-3 short lines + CTA + 3-8 hashtags; the link goes in bio/comments on IG.
- First 3 words matter: the video loops (8 s), so the hook names the moment ("We froze the dinner rush mid-toss").
- The MP4 is silent on purpose: add trending/licensed music in the Instagram/Facebook editor when posting
  (never bake unlicensed music in). Pick the cover frame in the app (or render `--cover` if asked).
- Same reel can go to Facebook Reels and Instagram Reels; LinkedIn takes it as a native vertical video.
