# House template: the Nexi video world (ONLY when the owner asks for a matching series)

> 2026-10-07 later: the owner rejected one-template batches ("unique in different poster ... no similar design").
> Default is now `cinematic.md`. Keep this for a series the owner explicitly wants to match.

Owner, after batches 15-25 (each post a different style and camera): **"properly design the material, some inconsistency.
you can use the nexi video skill for improving the materials."** So a batch is now ONE template, and it is the same world
as the Nexi Quick Tips videos (rule P26 in the nexi-video skill). A viewer who knows the videos should recognise the posts.
Creative one-off styles (`style-library.md`, `camera.md`) are for when the owner asks for "something different", never
mixed inside one batch.

Working file: `kit/template-nexi-world.html` (= posts 21-25 v2; copy it to `batch.html` and edit the `POSTS` table).
Look reference: `reference/qt-look-ref.jpg` (frames from Quick Tips 27 and 29).

## The grid (same on every post, 1080x1350)
| Layer | Where | Fixed values |
|---|---|---|
| Painted set | full canvas, drawn at 2x | wall to floorY 1086, window `[806,606,216,250]` with skyline + mullions + rays, baseboard, floor, window light pool, bunting at y 1110, motes, bokeh, vignette |
| Brand row | kit.css | TechNext top-left, plain Odoo wordmark top-right (unchanged) |
| Words | `.words{top:172px}` left column | chip with app icon, h1 84px two lines (`.l2` blue), sub 27px max 560px |
| Odoo window | `.stage{left:52px;top:572px}` | 660px wide, `rotateY(11deg) rotateX(2deg)`, Odoo 17 chrome: url pill `yourcompany.odoo.com/odoo/<slug>`, app + menus, **"Sample data" chip**, crumb, title, chevron statusbar (last step active), LOG rows |
| The process | the window's LOG | 4 rows = 4 steps: app icon tile with step number, title 21px, detail 17px, time, green check; last row tinted green (`.end`) |
| Nexi (optional) | right of the window, feet at y 1112, centre x 884 | costume render 500-536px tall, the same hero camera for every post |
| Caption card | `.cap` at about (652, 456-462) | Nexi avatar + "Nexi" + one line in Nexi's voice, `<em>` in blue; sits under the subtitle, above Nexi's hat |
| No-Nexi posts | right of the window | one supporting object in the same flat-soft style (membership card `.mcard` on 23) or props (plant, clock) |
| Footer | kit.css | unchanged |

## The set recipe (`paintSet`, needs `qtworld.js`)
`qtworld.js` = the videos' `envkit.js` copied verbatim + a shim (`make_qtworld.py` rebuilds it from
`~/ClaudeWork/nexi-tutorial/web/films/inc/envkit.js`; read-only, never write into nexi-tutorial). API on `window.QW`:
envWall(g, x, floorY, c1, c2, pattern: bricks|stripes|dots|panels), envGround(g, floorY, c1, c2, wood|carpet|tiles),
envWindow, envSkyline, envRays, envBaseboard, envBunting, envTufts, envShadow, envMotes, envBokeh, envVignette, plus
props plant(g, x, y, s, pot, leaf), clock(g, x, y, r), frame, shelf, lamp, tone(hex, k).
Per post only the palette changes: `wall: [c1, c2, pattern]`, `floor: [c1, c2, kind]`, `base`, props, tufts, shadows.
One pastel family per industry (peach bricks F&B, mint stripes service, lavender dots wellness, blue panels HR/office,
cream dots web/marketing). No ink outlines on scenery (nexi-video rule P21). No dark sets.

## Nexi in costume (`kit/nexi-cam`, v2)
`kit/nexi-cam` now runs the CURRENT video engine core (wear system). Render:
`python nexi_cam.py chef '{"hold":"pointL","face":"happy","wear":"chef","cam":{"pos":[1.4,-3.4,17],"look":[0,0.4,0],"fov":40},"w":3000,"h":3000,"size":2200}'`
- Costumes (`kit/assets/nexi/costumes/_wear_sheet.jpg`): hardhat conductor pilot glasses strawhat beret chef cap knight
  bowtie goggles bellhop beanie tophat boppers helmet astro. Pick the one the industry wears (chef F&B, bellhop service,
  beret design, hardhat construction, pilot travel, conductor logistics...).
- Holds: idle hi present point pointL celebrate gasp think cute clap knock kiss shrug jump reach; faces idle happy star wow
  content love. Point toward the window (pointL) or present it.
- Ready renders: `kit/assets/nexi/costumes/nexi-chef.png` (pointL), `nexi-bellhop.png` (hi), `nexi-beret.png` (present).
- Keep the camera above for every post in a batch; size with `nexiAt(post, 884, 1112, h, w/h)` using the PNG's real ratio.

## Filling a post (the `POSTS` table)
```
NN: { set: {wall, floor, base, win, props, tufts, shadows},
      win: {app, menus[2], slug, crumb, rec, title, status[2-3], rows: [[icon, title, detail, time] x4]},
      nexi: [cx, footY, h, ratio], cap: [x, y] }        // omit nexi/cap for a no-Nexi post
```
- Rows tell the process in plain words ("Ticket sent to the kitchen", "Recipe used the stock"), real Odoo app icons
  (`assets/odoo/<module>.svg`), plausible times. Names and money are samples: the window already says "Sample data".
- Nexi on about half the posts of a batch (3 of 5), never all.
- Headline: two short lines, the second blue. Subtitle: 2 lines at 560px. Caption card: one line, under 60 characters.

## QA specific to the template
- Caption card must not cover the subtitle or Nexi's hat: measure, then nudge `cap` or Nexi's height (500-536).
- Window must not pass behind the headline (window top 606 is below the sub).
- Same scale everywhere: if one post needs smaller type, the copy is too long; rewrite instead of shrinking.
- Overview sheet of the batch side by side must read as one family before delivery.
