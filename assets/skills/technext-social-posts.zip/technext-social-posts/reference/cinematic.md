# Cinematic posters (default since 2026-10-07)

Owner, after the one-template v2 batch: **"make it dynamic, cinematic, and unique in different poster/content, no similar
design like what we do previously."** So every poster in a batch is its own small film: its own genre look, its own
build technique, its own text placement, and its 9:16 reel (8 s loop) next to the 3:4 image. What stays the same is only the brand frame
(logo row, type family, footer) and the finish quality. Never reuse a look from `style-library.md`'s used table.

Working files: `kit/examples/2026-10-07-posts-21-25-v3-cinematic/p21..p25.html` (one HTML per post, format-aware:
`?f=34` image and `?f=reel` reel - see `formats.md`). Every poster ships as a 3:4 image and a 9:16 reel.

## The recipe for one poster
1. **A film idea, not a diagram.** One frozen moment or one place: a wok toss in bullet time, a lighthouse at blue hour,
   a spa pool at sunrise, paper planes into the sun, a station board. The Odoo process lives inside it as 4 objects
   (ticket -> wok -> food -> coins; boats; lotus lanterns; planes; board rows).
2. **A light plan.** Name the time of day and the key light (tungsten kitchen, blue hour + lantern, morning haze, golden
   hour backlight, shafts in a hall). Vary it across the batch; keep most posts light/warm (owner prefers light), at most
   one or two dusk scenes, never sci-fi dark.
3. **Three cinematic devices minimum**: depth of field (blurred background/foreground layers), volumetric light (beams,
   shafts, god rays), bloom/glow, lens flare (anamorphic streak + ghosts), film grain, colour grade, vignette, haze layers,
   motion streaks / long exposure, reflections, caustics.
4. **Different text placement per poster** (bottom billing block, top-left over sky, centred top, centred big, top-left
   on a dark vault). Labels in a style that suits the scene (freeze-frame tags, captions by boats, leaf cards, contrail
   pills, the board itself) - never the same label style twice in a batch.
5. **Motion**: `render(t)` draws any moment; every time input is an integer multiple of `th = 2*PI*t/LOOP` (or `frac()`
   of t/LOOP), so the 8 s loop is seamless. Poster time = the most readable frame.

## Techniques used in v3 (copy from the example files)
| Post | Look | Built with | Key tricks |
|---|---|---|---|
| 21 F&B | Bullet time over a wok toss, warm kitchen, movie billing block | three.js r128 (`three.min.js`) | PMREM env scene for metals; 3 scenes (bg / fg / near) rendered by one renderer and composited on a 2D canvas with `ctx.filter = blur()` = depth of field; `cam.setViewOffset` lifts the subject above the text; sprite flames (normal blending so they stay orange on a light set); CanvasTexture for the printed ticket/receipt; tags placed from `Vector3.project()` anchors |
| 22 Helpdesk | Lighthouse at blue hour, Nexi keeper (pilot cap) | painted 2D canvas, two canvases sandwich the Nexi PNG (railing in front) | volumetric beam = 3 blurred radial-gradient wedges with `lighter`; lantern bloom; water glints where the beam lands; boats with the app icon on the sail; dark class |
| 23 Wellness | Spa plunge pool at sunrise | raw WebGL fragment shader | ray-plane camera; refraction to a tiled floor; Fresnel sky; sun glints; Voronoi F2-F1 caustics with integer time speeds (loops); lotus shadows from uniforms; same projection in JS for the 2D lotus overlay |
| 24 Payroll | Golden-hour paper planes into the sun, anamorphic flare | own 3D maths on 2D canvas | Catmull-Rom flight path; **bank each plane toward the camera** (`roll += atan2(v.-right, v.up) * .72`) or it goes edge-on; app icon printed on the wing via an affine `setTransform`; pastel paper per lead plane; flock behind the leads; bay with a sun glitter path |
| 25 Websites | Station hall, split-flap ARRIVALS board, Nexi station master | 2D canvas + CSS 3D on the board canvas | flap = top/bottom half clips + a folding half (scaleY); only a few flaps flip per loop so the poster frame stays readable; long-exposure crowd (blurred streak + soft body); shafts from the side away from the words |

## Gotchas met on v3
- Never name your elements `.l1/.l2/...`: kit.css `.l2` is the h1's second line, so `querySelector('.l2')` grabbed the
  headline. Prefix per post (`.lf1`, `.t1`, `.c1`).
- Headless Chrome renders WebGL from `file://` fine (render.py starts Chrome with `--allow-file-access-from-files`);
  local SVGs can be drawn into a CanvasTexture. Use `preserveDrawingBuffer: true`.
- render.py uses one Chrome profile per work folder: run posts of the same folder one after another, not in parallel.
- An object flying straight away from the camera collapses to a sliver: turn it across the frame or bank it.
- Additive glow on a lit object washes out the icon printed on it: keep glow alpha low on objects that carry content.
- A bright window or beam behind white words kills contrast: move light sources to the side away from the text.
- Scrambling every flap at the poster time made rows unreadable: the poster frame must be settled.
- Measure, don't guess: `python <skill>/scripts/dbg.py page.html N [t]` prints the page's `window.__dbg` anchors and every
  `data-qa` rect at time t.
