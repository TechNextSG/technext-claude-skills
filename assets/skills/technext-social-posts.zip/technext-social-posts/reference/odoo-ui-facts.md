# Odoo UI facts (Odoo 17/18 web client, which Odoo 20 keeps)

Owner 2026-10-11: "make sure factual to design workstation of odoo". Every Odoo screen drawn with `odoo-ui.js` (or by hand)
must look like real Odoo. `audit.py` lints the most common inventions as **[odoo-facts] warnings** (table `ODOO_MENUS` and
`ODOO_BTN` in `scripts/audit.js` - keep both in sync with this file). A warning still needs a fix or a written reason.

## Navbar
- Left to right: app-switcher grid, app icon + app name, then that app's REAL top menus. Right side: activity (clock) and
  chat icons with their counter badge, company switcher (optional), user avatar. Nothing else.
- No invented pills, labels or slogans in the navbar ("One database", "Live", "AI on"): annotate outside the screen.
- The navbar must fit its screen: the badge, icons and avatar stay visible (audit [contain] errors when they run off).
- A subset of the real menus is fine; an invented menu is not.

| App | Top menus |
|---|---|
| Sales | Orders · To Invoice · Products · Reporting · Configuration |
| CRM | Sales · Leads · Reporting · Configuration |
| Inventory | Overview · Operations · Products · Reporting · Configuration |
| Accounting | Dashboard · Customers · Vendors · Accounting · Reporting · Configuration |
| Invoicing | Dashboard · Customers · Vendors · Reporting · Configuration |
| Purchase | Orders · Products · Reporting · Configuration |
| Manufacturing | Overview · Operations · Planning · Products · Reporting · Configuration |
| Project | Projects · My Tasks · All Tasks · Reporting · Configuration |
| Helpdesk | Overview · Tickets · Reporting · Configuration |
| Dashboards | Dashboards · Configuration |
| Apps | Apps · Updates · Update Apps List |
| Settings | General Settings · Users & Companies · Translations · Technical |
| Point of Sale | Dashboard · Orders · Products · Reporting · Configuration |
| Website | Site · eCommerce · Reporting · Configuration |
| Employees | Employees · Departments · Reporting · Configuration |
| Timesheets | Timesheets · Reporting · Configuration |
| Time Off | My Time · Overview · Management · Reporting · Configuration |
| Expenses | My Expenses · Reporting · Configuration (Odoo 20: no Expense Reports menu - approved expenses become draft bills in the expense journal) |
| Email Marketing | Mailings · Mailing Lists · Reporting · Configuration |

Brief section B (FIX-BRIEF-2026-10-11) supplies Sales, Inventory, Accounting, Project, Helpdesk, Dashboards and Apps. The
other rows follow the standard Odoo 17/18 menus. Check an unfamiliar app on a live database before drawing it.

## Control panel
- Breadcrumb (`Projects / Discovery map`, `Quotations / S00412`, `Orders / S00042`), the purple **New** button (#714B67) on
  list/kanban views, gear (actions) icon, search bar with facets (`My team`, `This year`), view switcher
  (kanban / list / graph / pivot / calendar...).
- No action buttons next to the breadcrumb that Odoo does not have there (e.g. a header "Validate" in bank reconciliation).

## Forms
- Action buttons on the LEFT of the status-bar row; statusbar ARROWS on the RIGHT, current stage highlighted.
  Sales: Quotation > Quotation Sent > Sales Order (current = Quotation for a draft).
- Smart buttons top-right of the sheet (`Delivery 1`, `Invoice 1`). Chatter on the right: Send message · Log note ·
  Activities, then the log entries.
- Lines: Product · Quantity · Unit Price · Taxes · Amount. Totals: Untaxed Amount, the tax line (`GST 9%` / `9%`), Total.
  Numbers add up (GST 9 %). Mark data as sample.

## Real button labels (and the inventions the audit flags)
| Screen | Real | Never |
|---|---|---|
| Sales quotation | Send by Email · Confirm · Preview · Cancel | Approve (there is no Approve in Sales: an AI-drafted quote is CONFIRMED) |
| Bank reconciliation (17+) | statement lines list left, matching panel right with **Validate** | Reconcile |
| Inventory transfer | Validate | Done / Ship |
| Apps app cards | Activate (not installed) · Module Info (installed state) | Install / Update / Installed pills |

Approve does exist elsewhere (Purchase with 2-step approval, Expenses, Time Off), so the lint only fires in a Sales or
quotation context.

## Kanban cards
- Title, tags, priority star(s), activity clock, assignee avatar. Helpdesk tickets also `#<number>` and the customer;
  Helpdesk stages: New / In Progress / Solved.

## Views that exist (draw these, never invent one)
- Sales > Reporting > Sales Analysis (graph/pivot, Measures, facet "This year"). There is **no** "Sales > Dashboard" with KPI tiles.
- Inventory > Overview (operation-type cards: Receipts "5 To Process", Delivery Orders "8 To Process") or
  Inventory > Reporting > Stock (list: Product, On Hand, Forecasted, Unit). No "Low stock" KPI tile in Stock on hand.
- Dashboards app (left panel of dashboard groups such as Sales, Inventory, Accounting + KPI cards + charts).
- Project kanban, Helpdesk kanban, Accounting bank reconciliation, Settings, Apps.
- Official app icons only (`kit/assets/odoo/*.svg`).

## Odoo 20 changes that affect posters (from technext.asia app pages, 2026-10-12; full list ~/ClaudeWork/qa/audit-all/ODOO20-CHANGES.md)
- VoIP app is now called **Phone**. Field Service is discontinued: on-site jobs, map, worksheets run in **Planning**.
- Rental: rental products on an ordinary **sales order** with a rental period; one pricelist engine for sales/rental/subscriptions.
- Expenses: approved expenses become **draft bills**; no separate Employee Expenses / Expense Reports menu.
- Documents: **folders** (workspaces went in Odoo 18); payslips get their own folder.
- Inventory: return wizard gone (simpler returns flow); stock ageing report; reordering rules suggest min/max.
- Project: profitability report replaced by **budget and margin** reports; projects from opportunities.
- Planning -> Payroll link removed. AI "topics" are now **skills**. Remote Work is part of Employees.
- Sales: dashboard above the quotation list; quotations can be saved as templates. CRM: Dun & Bradstreet (not Clearbit).
- Never draw: Meta's WhatsApp logo (use the Odoo WhatsApp app icon), TechNext marks inside Odoo screens, empty navbar circles.
