# Content rules (what a TechNext post may say)

Facts come from the live technext.asia pages (re-check when a claim matters). Odoo facts must describe real Odoo
behaviour - if unsure, say less.

## Company
- Partner wording: **"Odoo Ready Partner"** - never "Certified", never "Gold/Silver".
- Approved figures only: clients in **10+ countries**, **11+ enterprise clients**, **4 AI disciplines**, offices
  **Singapore (HQ), Taguig City (Philippines), Ho Chi Minh City (Vietnam)**. No founding year, no project counts,
  no ISO claims (ISO 27001 is not certified), no invented awards or client logos.
- Four practices: **ERP** (Odoo), **AI Solution** (assistants, Odoo + AI, workflow automation, chatbots),
  **Marketing** (websites, social, brand assets), **Technology** (IoT, apps, networks).
- **Never mention Cyber Security** as a TechNext service (owner rule; ACRA SSIC excludes it, CSA licence needed).
- How TechNext works: Discovery -> Training -> Integration -> Support; starts with Accounting, Sales, Inventory.
- AI copy: "people approve; the AI prepares" - AI drafts, a person approves posting/sending.

## Data in images
- Invented numbers, documents, names and companies are **samples**: show "sample" / "sample data" on the image.
  Use clearly fictional names (Apex Supplies, Harbour Trading, Lintel & Co., Bayside F&B, Harbour Tower).
- Numbers must add up (a journal entry balances, a margin is computed right, SG GST is 9%).
- No real client names or data without the owner's say-so. No other brands' logos (generic "spreadsheet", "email" only).

## Calls to action (verified 200 on 2026-10-06; re-check before delivery)
| Topic | URL |
|---|---|
| Quote | technext.asia/quotation |
| Odoo ERP / setup | /solutions/odoo-erp, /odoo/erp-system, /odoo/discovery, /odoo/apps, /odoo/training, /odoo/integration, /odoo/support |
| AI | /solutions/ai, /solutions/ai-chatbots, /solutions/ai-automation, /solutions/ai-knowledge, /odoo/ai-integration, /nexi |
| Marketing | /solutions/marketing, /solutions/website, /solutions/social-media, /solutions/brand-assets |
| Technology | /solutions/technology, /solutions/iot, /solutions/app-development, /solutions/networks |
| Industries | /industries/construction, /travel, /medical, /retail, /ecommerce, /fnb, /manufacturing, /health-wellness |
`technext.asia/lp/` redirects home - never use it.

## Publishing
Deliver files only. Posting, scheduling (Buffer), boosting or sending is the owner's decision every time.
