# Camera: exaggerated angles (owner, 2026-10-07: "use different camera angle, make it exaggerated")

Every post picks one camera on purpose. A straight-on, eye-level view is the default to avoid. Two tools give real
perspective: `kit/cam.js` (`TN.Cam`, for any scene you build in 3D) and `kit/nexi-cam/` (re-renders Nexi himself
from any angle with the real 3D model).

> Since 2026-10-07 the house template (`template.md`) uses ONE steady hero camera for Nexi across a batch. Use the
> exaggerated angles below only for a one-off creative batch the owner asks for, and then one angle family per batch.

## Angle library
| Angle | What it says | cam.js recipe | Nexi recipe (nexi_cam.py) | Used |
|---|---|---|---|---|
| **Worm's-eye** (look up) | heroic, giant, "big help" | camera z ~1.5, target 30+ units up, fov 90-100; towers lean in to a point above | `pos [1.5,-8.8,5.5], look [0,3.2,0], fov 90, roll .13`, pose celebrate: huge body + thruster ring, tiny head | 18 |
| **Bird's-eye / drone** (look straight down) | overview, "track everything" | camera z 300+, target almost below, fov 75-85, roll .15-.25: verticals splay outwards | `pos [0,14,9], look [0,-1,0], fov 60`: big head, small body | 19 |
| **Low dutch angle, off-axis** | action, momentum, chain reactions | camera near table height, 30-40 deg off the line of objects, roll -.15 to -.25, fov 50-60 | add `roll` to any shot | 20 |
| **Macro foreground** | detail, craft, "this one thing" | one hero object 2-3x nearer than the rest, `focus` on the hero, `aperture` 3-6 (or CSS-3D card + `filter: blur(9px)` on the background layer) | camera 4-6 units from Nexi, fov 70+ | 23 |
| **Over-the-shoulder** | "you, using it" | camera just behind a big foreground prop (screen, desk edge) looking at the scene | `pos [4.5,3.2,-12], look [-1,1.2,6], fov 46`, no `look` (ready: assets/nexi/nexi-back-over-shoulder.png) | 25 |
| **Fisheye / ultra-wide** | playful, energetic | fov 110-125 with the subject close: edges stretch; pair with a "tiny planet" (a big circle horizon, buildings rotated radially) | `pos [0.5,2.2,4.3], look [0,0.9,0], fov 118, roll -.1`, pose hi (ready: assets/nexi/nexi-fisheye-selfie-hi.png). Closer than ~4 units puts the lens inside his head | 22 |
| **Top-down flat-lay** | tidy, organised (desk, kit) | camera straight above, fov 35-45 (little distortion); a high wide angle (`pos [60,-420,760]`, fov 58) keeps the depth | - | 21 |
| **Floor-level one-point + dolly zoom** | depth, flow toward you, "Vertigo" | three.js: camera y ~.5, ultra-wide; reel pulls the camera back while narrowing fov so the hero keeps its size (`tanX = k * d0 / d`) | Nexi as a camera-facing textured plane in the scene (not a DOM overlay: the parcels must cover him) | 26 |
| **Inside-out** (from inside a machine) | "we see how it works from the inside" | painted 2D: dark machine interior frames a bright opening; big out-of-focus foreground part (fan) + light pouring in | - | 27 |
| **Tabletop ant's-eye** | intimate, everyday moment | horizon low on the table, a towering near prop (cup) softly blurred, the hero object lying flat via CSS `rotateX(60-66deg)` | - | 28 |
| **Tilt-shift miniature** | "your whole team, at a glance" | high angle, narrow fov 30-36 from far away, saturated colours, a blurred copy (`<use>` + blur) masked to top and bottom bands that sit ON the scene | - | 24 |

## Rules of thumb (learned on 18-20)
- Exaggeration comes from **wide lens + near camera**, not from tilting a flat picture. Keep the hero big and close,
  the rest small and far: a 2-3x size ratio between nearest and farthest reads as depth instantly.
- Looking straight down a line of objects stacks them on top of each other. Shoot the line **30-40 deg off its axis**
  so every object shows its face (the domino chain needed this).
- Give the whole scene the **same roll** (the Nexi render and the cam.js towers both used roll .13 in 18).
- Busy top-down scenes need a **soft white fade under the brand row** and a solid panel (a "bottom sheet") for the words.
- Depth of field: blur the nearest object 1-2 px at most; a blurred icon stops being an Odoo icon.
- Labels for objects at many depths: put them in **staggered rows with dashed leader lines** to each object, not on
  top of the objects.
- Perspective sells best with a reference grid: floor tiles, a tablecloth, streets, window rows on towers.

## cam.js in 30 seconds
```js
var cam = TN.Cam({ pos: [-215, -235, 96], target: [10, 230, 26], fov: 54, roll: -.19, cx: 520, cy: 860, focus: 470, aperture: 4 });
var faces = []; boxes.forEach(function (b) { faces = faces.concat(cam.faces(b)); });   // b = {x (centre), y (front), z, w, d, h, rz, rx}
cam.draw(g, faces, function (fc, poly) {                                                // far -> near, back faces culled
  poly.setAttribute('fill', TN.shade('#3167CA', fc.lit * .35));                         // lit = facing the light
  if (fc.key === 'front') el('image', { href: 'assets/odoo/sale.svg', x: 18, y: 16, width: 64, height: 64 },
    el('g', { transform: cam.quad(fc, 100, 100 * b.h / b.w) }, g));                      // icons/text mapped onto a face
});
var s = cam.p([x, y, z]);   // {x, y, d, s}: place HTML pins/labels at s.x/s.y, scale sizes with s.s, blur with cam.dof(s.d)
```
World is z-up (ground z 0). Keep one unit scale per scene. Paint the ground/grid first, then shadows, then boxes.

## Nexi from any angle
```bash
cd <work>/nexi-cam   # copy of kit/nexi-cam into the work folder
python nexi_cam.py hero '{"hold":"celebrate","face":"star","look":"cam","w":3600,"h":3600,"size":2500,"cam":{"pos":[1.5,-8.8,5.5],"look":[0,3.2,0],"fov":90,"roll":0.13}}'
```
-> `out/nexi-hero.png` (transparent, trimmed). Holds: idle, hi, present, point, pointL, celebrate, gasp, think, cute,
clap, knock, kiss, shrug, jump, reach. Faces: idle, happy, star, wow, content, love. `look:"cam"` makes him look into
the lens wherever it is. World: Nexi ~8 units tall at the origin (feet ~ y -4); default camera (0,0,24) fov 30.
Use big `w/h/size` for wide lenses (he gets small in frame). A ready worm's-eye render is in
`kit/assets/nexi/nexi-worms-eye-celebrate.png`.
