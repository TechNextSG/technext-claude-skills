# Formats: 3:4 images and 9:16 reels (owner rule, 2026-10-07)

Owner: **"for social media posting, use 4:3 ratio only. high quality image. for video format, use 9:16 format social
media posting reels."** "4:3" is read as **3:4 portrait** (1080x1440, the Instagram/Facebook portrait feed size the AI
marketing team's planner already uses). If the owner ever means landscape 4:3, only `TN.FMT` and `render.py SIZE` change.
Owner, same day: **"remove duplicate images. compile all created image in one folder"** -> one flat folder, one file per
post (the high-quality image; no second size, no overview sheet, no reel cover, no superseded version).
Owner, same day: **"always seperate the video and image posting"** -> `Image Posts/` and `Video Posts/` subfolders.

| `?f=` | Use | Canvas | Rendered files |
|---|---|---|---|
| `34` (default) | every image post | 1080 x 1440 layout | ONE `NN-technext-<slug>.png` at 2160 x 2880 (drawn at 2x; high quality) |
| `reel` | every video post | 1080 x 1920 | `-reel.mp4` (H.264 crf 16, 30 fps, yuv420p, faststart, silent, 8 s loop); `--cover` adds a cover PNG only on request |
| `45` | legacy only (pre-rule examples) | 1080 x 1350 | old names; `--mp4` allowed |

## Reel safe zone - TikTok + YouTube Shorts + Instagram Reels (owner 2026-10-10; checked by kit.js QA + audit.py)
One combined zone, the strictest edge of the three apps, because every reel is posted to all three:
- Top 240 px: IG top bar/camera, TikTok Following/For You tabs, Shorts header. Logo row `.f-reel .brand{top:246px}`.
- Bottom 480 px: TikTok caption + username + sound line, Shorts title + channel, IG caption. SCENERY ONLY - and never empty:
  the main scene's OWN space runs on into it (its floor, ground, table, sea, road, sky or the living brand skin). Footer CTA `.f-reel .foot{bottom:490px}`
  (CTA bottom at y 1430).
- Right 150 px from y 760 down: like / comment / share / sound column on all three apps. `.f-reel .foot{right:150px}`;
  technext.asia must end before x 930. Above y 760 the right margin is the normal 36 px (Odoo wordmark at right 72 is fine).
- Left 60 px.
## Extended elements (owner 2026-10-10: "add extended element on the video if theres alot of space in 9x16 ratio")
A reel is not the 3:4 poster on a tall strip: grow the main scene into the frame and let its own world continue (its floor/sea/road/
paper/sky, light, Nexi's ground shadow) - see NOT FORCED below - with gentle looping motion, while the 3:4 image stays
pixel-identical (reel-only TN.pick / DY / `.f-reel` code). Check with `sheet.py <reel.mp4> --frames 0.1,2,4,6,7.9`.
NOT FORCED (owner, same day, on the first pass: "why some extension on space are forced? fix this"): never paste a second
picture under the CTA (a second sheet, a row of copies of the hero object, a props conveyor/floor the scene does not stand
on, floating icons/shapes on a blank band). Grow the main scene into the frame (scale 1.1-1.35x, lower, more air) and let
only its OWN space continue to the bottom edge (its floor, ground, table, paper, sea, road, sky, or the living brand skin).
UI posts: bigger windows, brand background below - no props floor. Good examples: 26, 40, 46, 47, 49, 52-54, 56, 60, 61. Lead's final check: a scattered-object scene (29's app icons)
keeps ONE pile on the scene's floor above the CTA - a second, bigger field of the same objects under the CTA is filler.
If a cover is asked for (`--cover`), it is the poster time; Instagram crops the cover to 3:4 in the profile grid, so keep the
title in the middle band (y ~320-1300) and it survives the crop.

## Making one page serve both formats
kit.js reads `?f=` before the page script runs and exposes:
- `TN.F` ('34' | 'reel' | '45'), `TN.W` (1080), `TN.H` (1440 | 1920 | 1350), `TN.SAFE` [top, right, bottom, left],
- `TN.pick({34: a, reel: b})` for per-format values; the post gets class `f-34` / `f-reel` (CSS: `.pNN.f-reel .words{...}`).

Recipe used for all five v3 posts:
1. `var H = TN.H` (never a hard-coded 1350/1440). Canvases in CSS: `width:1080px; height:100%` (a fixed CSS height
   squashes the taller drawing - that bug made the first reel render look shrunk).
2. **Design the scene once** (it was designed on 1350) and **slide it down** with `DY = TN.pick({34: 60, reel: 150-200})`:
   `g.translate(0, DY)` before painting; paint sky/vault from `-DY` and floor/sea/ledge down to `H`; add DY to every DOM
   piece placed from scene coordinates (labels, Nexi, the board's QA box, CSS transform-origin).
   `ctx.setTransform()` inside a painter ignores that translate - add DY back there (the wing prints on post 24 floated
   off their planes until fixed).
3. **3D / shader cameras keep the same horizontal field of view** in every format: `fovY = 2*atan(tanHalfX * H / W)`;
   frame the subject with `camera.setViewOffset(W, H, 0, H/2 - targetY, W, H)` (three.js) or solve camera height + tilt
   so the key lines land where you want (post 23 solves for the pool's far edge and near coping).
4. Words: 3:4 keeps the layout of the design (top 176 or bottom-anchored); reels move them to `top: 316px` (or, for a
   bottom stack, `bottom: 556px`) so the stack ends above the footer at 430.
5. Overlays (vignette, bottom darkening) are drawn in screen space after resetting the transform.
6. `dbg.py page NN --f reel --shot qa/x.png` for each format before rendering; `render.py` then refuses wrong sizes.
