# Engine: page contract, kit API, rendering

## Formats
See `formats.md`: `?f=34` (3:4 image, default) / `?f=reel` (9:16 video); `TN.F`, `TN.H`, `TN.SAFE`, `TN.pick({...})`.

## Page contract (what scripts/render.py expects)
- One HTML page per batch, `<section class="post [dark] [grain] [sq|story]" data-p="N">` per post; `?p=N` shows one.
- Link `kit.css` + `kit.js`; finish with `TN.boot({...})`. Boot waits for fonts, images, `waitFor` promises and a setup
  that returns a promise, then runs QA and sets `<html data-ready="1">`.
- `window.SLUGS = {N: 'slug'}` names the files: `NN-technext-<slug>.png`.
- `window.__layout` = list of QA problems (empty = clean). Mark readable things `data-qa="text"`, big visuals
  `data-qa="block"`; pieces that may overlap on purpose share a `data-qa-group`.
- Motion: give `render: {N: function (t) {...}}`, `poster: {N: seconds}`, `loop: 8`. `window.R(t)` must draw any moment
  deterministically (no Date.now, no random without `TN.rand(seed)`) so frames are exact. `&play` in the URL loops it live.

## kit.js helpers (`TN.*`)
| Helper | Use |
|---|---|
| `el(tag, attrs, parent)` / `html(parent, str)` | create SVG / HTML |
| `seg(t,a,b)`, `eo`, `ei`, `eio`, `back`, `frac`, `cl` | timeline maths (ease-out, ease-in, in-out, overshoot) |
| `rand(seed)` | repeatable random (stars, windows, particles) |
| `iso(o,x,y,z)`, `pts(o,arr)` | isometric projection; `o = {x, y, k}` screen origin + scale |
| `box(g,o,x,y,z,w,d,h,{top,left,right,stroke,sw,dash})` | iso box; returns its three polygons |
| `face(g,o,z)` | group lying flat at height z (draw rects/circles/images/patterns on a floor or slab) |
| `wallX(g,o,x)`, `wallY(g,o,y)` | groups on the right / left walls (local y = height, so text would be mirrored: shapes only) |
| `filters(svg)` | defs: `blur3/6/12/24`, `glow`, `ink` (rough stamp edges + speckle) |
CSS helpers in kit.css: `.grain` (noise overlay under the text), `.vignette`, `.scanlines`, `.glass`, `.t3d` (3D app tile),
`.hand`, `.ai` (icon tile), `.okd` (green tick).

## cam.js (perspective camera) and nexi-cam
`kit/cam.js` adds `TN.Cam` (real perspective, roll, painter's sort, back-face culling, shading, face mapping, depth of
field) - see `reference/camera.md`. `kit/nexi-cam/nexi_cam.py` renders Nexi from any camera position with the real
3D model (a patched COPY of qa/nexi-ads/web; never touch nexi-tutorial/web/assets).

## qtworld.js + the house template
`kit/qtworld.js` exposes the Nexi videos' set painters as `window.QW` (see `template.md`); include it after kit.js.
Rebuild it with `python kit/make_qtworld.py` when the video engine's envkit changes (it only reads nexi-tutorial).
`template-nexi-world.html` adds `odooWin(o)`, `paintSet(post, set)`, `nexiAt(post, cx, footY, h, ratio)` and a `POSTS`
table; `TN.boot({slugs, setup})` as usual. kit/nexi-cam v2 = current engine core + `wear` option (three r128).

## Commands
```bash
python ~/.claude/skills/technext-social-posts/scripts/render.py p21.html --posts 21               # 3:4 image: one NN-technext-<slug>.png, 2160x2880
python ~/.claude/skills/technext-social-posts/scripts/render.py p21.html --posts 21 --fmt reel    # 9:16 reel: -reel.mp4 (--cover adds a cover)
python ~/.claude/skills/technext-social-posts/scripts/dbg.py p21.html 21 --f reel --t 1.2 --shot qa/x.png   # measure + screenshot
python ~/.claude/skills/technext-social-posts/scripts/sheet.py "out/1[234]-technext-*.png" --out out/00-overview.jpg
python ~/.claude/skills/technext-social-posts/scripts/sheet.py out/15-technext-x.mp4 --frames 0.4,1,2,4,7.8 --out qa/15.jpg
python ~/.claude/skills/technext-social-posts/scripts/deliver.py out "G:/Shared drives/Marketing/02. TechNext Folder/02. TechNext Social Media Posting Image/<folder>" --source batch.html kit.css kit.js
```
- render.py draws at 2x and downscales (crisp text), uses its own Chrome profile per work folder, exits 1 on QA issues.
  Two renders at once need different `--port` values.
- Fonts come from Google Fonts and libraries from jsdelivr (d3@7, topojson-client@3, world-atlas@2): render needs network.
- MP4: H.264 yuv420p crf 17, 30 fps, silent; FB autoplays muted. ffmpeg comes from WinGet (`yt-dlp.FFmpeg`).

## Live preview
Open the page in the Browser pane (`file:///C:/Users/<you>/ClaudeWork/social-.../batch.html?p=12`) to inspect; add
`&play` for motion. The PNG from render.py is the truth (fonts, DPR, timing).
