# Style library

Each style = a look + a way to carry an Odoo process without flat boxes. Pick a different one per post; remix rather than
repeat. Working code for every "used" style is in `kit/examples/` (open the file, search the post class, e.g. `.p13`).

## Used so far (update after every batch)
| # | Date | Style | Industry / service | Process carried by | Example file |
|---|---|---|---|---|---|
| 01-05 | 2026-10-06 | Clean site UI (cards, stage windows) | ERP, AI chatbot, AI bills, IoT, implementation | card rails | 2026-10-06-posts-01-05-clean.html |
| 06 | 2026-10-06 | Isometric conveyor diorama | Order to cash | stations on a belt, parcels, coins | ...-06-08-depth.html |
| 07 | 2026-10-06 | Exploded glass stack | The 4 practices | stacked layers + light beam | ...-06-08-depth.html |
| 08 | 2026-10-06 | 3D studio: Nexi on podium, tilted card, 3D tiles | Odoo AI integration | chat Q/A card | ...-06-08-depth.html |
| 09 | 2026-10-06 | Radial burst from a big button (motion) | One sales order, 5 apps | trails to app cards | ...-09-11-motion.html |
| 10 | 2026-10-06 | Chaos -> device (motion) | Replace patchwork tools | items fly into app icons | ...-09-11-motion.html |
| 11 | 2026-10-06 | Receipt ribbon on a swoosh (motion) | POS -> Accounting | textPath ribbon into a journal entry | ...-09-11-motion.html |
| 12 | 2026-10-06 | Architectural blueprint | Construction job costing | cost tags pinned to floors of a tower | 2026-10-06-posts-12-14-industries.html |
| 13 | 2026-10-06 | Night globe + passport stamps + boarding pass | Travel margin | ink stamps 1-4 = CRM/Sales/Purchase/Invoicing | ...-12-14-industries.html |
| 14 | 2026-10-06 | **REJECTED by owner**: hologram stockroom (dark sci-fi, many small panels) | Clinics lot & expiry | holo shelves, lot tags, reorder panel | ...-12-14-industries.html |
| 15 | 2026-10-06 | Playful sky + rollercoaster, **Nexi** in the front car (text at the bottom) | Lead to cash (ERP) | 5 app cars in process order on a coaster | 2026-10-06-posts-15-17-playful.html |
| 16 | 2026-10-06 | Giant 3D numeral "0" (centred, words around it) | One database / typed twice: 0 | apps ride the ring of the zero, clockwise arrows | ...-15-17-playful.html |
| 17 | 2026-10-06 | Gumball machine of app balls (text column left) | Start with 3 apps | the core three dispensed, numbered 1-2-3 | ...-15-17-playful.html |
| 18 | 2026-10-07 | **Worm's-eye**: Nexi towering overhead (re-rendered low + wide), towers leaning in, sun burst | Odoo AI integration | 4 app tiles tumbling past the lens, near = big | 2026-10-07-posts-18-20-camera.html |
| 19 | 2026-10-07 | **Drone bird's-eye**: pastel city, buildings splaying out, map-app bottom sheet for the words | eCommerce fulfilment | route on the streets, 4 app pins | ...-18-20-camera.html |
| 20 | 2026-10-07 | **Low dutch angle, off-axis**: domino chain on a tiled table | Manufacturing MTO | 6 dominoes (app icon + pips = step), staggered labels | ...-18-20-camera.html |
| 21 | 2026-10-07 | **High-angle wide top-down** over a kitchen pass, words on a paper placemat (bottom-centre) | F&B | ticket rail, POS tablet, recipe tray, session receipt | 2026-10-07-posts-21-25-five-cameras.html |
| 22 | 2026-10-07 | **Fisheye selfie**: Nexi at the lens on a tiny planet, orbiting tickets (top-centre words) | Helpdesk + AI | 4 ticket cards on an orbit ring | ...-21-25-five-cameras.html |
| 23 | 2026-10-07 | **Macro foreground**: membership card at the lens, studio blurred behind (words right column) | Health & wellness | booking board, punch card, POS slip, renewal mail | ...-21-25-five-cameras.html |
| 24 | 2026-10-07 | **Tilt-shift miniature** office (words bottom-left) | HR & Payroll | badges over zones: time off, timesheets, payslips, posted | ...-21-25-five-cameras.html |
| 25 | 2026-10-07 | **Over-the-shoulder**: Nexi from behind at a giant website (words top-right, footer mirrored) | Websites + CRM | visitor, chat, lead card popping out, quote | ...-21-25-five-cameras.html |
| 21-25 v2 | 2026-10-07 | **HOUSE TEMPLATE, Nexi video world** (`template.md`): painted set, Odoo record window, costumed Nexi (chef, bellhop, beret) on 21/22/25, caption card | F&B, Helpdesk+AI, wellness, payroll, websites | the record's 4-row LOG | 2026-10-07-posts-21-25-v2-nexi-world.html |
| 21-25 v3 | 2026-10-07 | **CINEMATIC, each unique** (`cinematic.md`): bullet-time wok toss (three.js), blue-hour lighthouse + Nexi keeper, sunrise spa pool (water shader), golden-hour paper planes, station split-flap board + Nexi station master; all with MP4 loops | F&B, Helpdesk+AI, wellness, payroll, websites | 4 scene objects per post | 2026-10-07-posts-21-25-v3-cinematic/ |
| 26 | 2026-10-07 | **Floor-level one-point aisle + Vertigo dolly zoom** (three.js): racking races to the dock, Nexi (hard hat) rides a pallet jack at the lens | Inventory / barcode | depth = time: truck at the dock, forklift lifting a wrapped pallet, picking cart, Nexi shipping; rack-edge location labels + numbered badges | 2026-10-07-posts-26-28-angles/p26.html |
| 27 | 2026-10-07 | **Inside-out**: camera inside an air-con unit looking out through the open service panel; fan blade + copper pipes frame it, daylight pours in | Field service app + Odoo Field Service | service stickers round the opening; the technician's field app on a tablet | .../p27.html |
| 28 | 2026-10-07 | **Tabletop ant's-eye**: lens on a cafe table, towering latte, phone lying flat (CSS 3D), notifications popping out | Sales + Sign + Invoicing | iOS-style notification banners rising from the phone; the signature writes itself | .../p28.html |
| (rejected) 29-46 v1 | 2026-10-09 | **REJECTED as templated**: technext.asia hero slide 1/2 language reused on every post (app orbit around a card, swimlane process board, toasts) | - | - | old-hero/ in the work folder |
| NXE S1EP00 | 2026-10-06 | **Comic-book cover** (Nexi Explains promo, skill nexi-explains-posters): low-angle night city, the pilot's Spreadsheet Monster (film painter copied), caped Nexi charging her fist, 4 power orbs | Nexi Explains EP00 premiere | 4 orbs = Odoo ERP / AI / Marketing / Technology | ~/.claude/skills/nexi-explains-posters/examples/s1ep00-v2 |
| 29-46 + FB ads 1-3 | 2026-10-09 | **CREATIVE METAPHOR BATCH + LIVING BACKGROUNDS** (after the owner rejected the hero-slide orbit/board template as "templated"): 29 kinetic 3D "ONE" + app heap; 30 metro map on blue; 31 hot-air balloons; 32 rubber stamp still life; 33 treasure map; 34 paper-cut hills hike; 35 claymation devices + cloud; 36 3-panel comic; 37 megaphone to funnel; 38 tear-off calendar; 39 tape measure on blueprint blue; 40 vintage postcard; 41 medicine expiry queue; 42 barcode skyline at night; 43 jack-in-the-box parcel; 44 recipe card + laksa bowl; 45 exploded office chair; 46 zen cairn; ads: before/after split, magnifier over a messy sketch, giant Nexi close-up | ERP, AI, marketing, tech, 8 industries | each its own metaphor; scene.js themed animated layers; Nexi action renders (hero, jump, gasp, celebrate) with reactions | kit/examples/2026-10-09-creative-29-46/ |
| 47-56 | 2026-10-09 | **INDUSTRY BATCH B** (new industries, richer illustrated settings): 47 wholesale warehouse Tetris (perspective racking, skylights); 48 professional services art-deco hourglass, hours -> coins -> invoice, magician Nexi; 49 property dollhouse block at golden hour; 50 education chalkboard + grad caps; 51 car workshop racing pit stop, job card as pit board; 52 logistics dusk city light trails; 53 events concert stage + QR tickets; 54 equipment rental boomerang loop; 55 subscriptions DJ turntable (months = grooves); 56 food production patchwork farm, lot traced field to shelf | wholesale, services, property, education, auto, logistics, events, rental, subscriptions, food | one metaphor each + scene.js + nexi-cam costumes | kit/examples/2026-10-09-industries-b/ |
Nexi Explains episode posters have their own register (nexi-explains-posters `reference/register.json`); don't reuse those looks here either.
v1 (cameras) and v2 (one template) of 21-25 are superseded by v3. New batches: the cinematic route; never reuse a look above.
The owner called 01-05 "flat ... boring": don't use the clean card style as the main idea again.
The owner rejected 14 ("don't do this kind"): no dark hologram/wireframe dashboards with many small glowing panels. Lean light, bold, playful.

## How the used styles are built (reuse the technique, not the layout)
- **Isometric scene** - `TN.box`, `TN.face` (draw flat on a floor), `TN.wallX/wallY` (windows on walls), `o.k` to scale.
  Paint back-to-front. Billboards (upright cards) for app icons; blurred ellipses for contact shadows.
- **Exploded layers** - same iso slabs with big gaps (gap >= 55% of slab height or layers clutter), content on a fixed
  grid scaled onto the face, a light beam between centres, dashed guide lines at the corners.
- **3D studio** - CSS `perspective` + `rotateY/rotateX` on a card, stacked box-shadows for thickness, a podium (ellipse
  lid + gradient side), `.t3d` tiles at several depths with blur for depth of field, halo rings, perspective grid floor.
- **Burst / trails** - conic-gradient rays, flattened ellipse shock rings, quadratic paths with `userSpaceOnUse`
  gradients, glowing heads moved with `getPointAtLength`.
- **Chaos -> screen** - rotated paper/sticky/inbox props with drop shadows, speed lines converging on real icons inside a
  CSS-3D tablet (targets measured with getBoundingClientRect after the transform).
- **Ribbon** - one SVG path stroked 3 times (shadow blur, edge, paper) + `<textPath>` + a mask with the same dash reveal.
  Path must run left-to-right or the text turns upside down.
- **Blueprint** - blue radial base, 2-scale white grid, paper folds (thin light+dark gradient lines), grain, drawing frame,
  white line art, lit windows (warm fill + blur), amber "work in progress" accents, dimension lines with ticks and
  rotated labels, taped white cost tags, red Caveat markup, title block as the footer.
- **Globe** - d3 `geoOrthographic` + world-atlas 110m from jsdelivr; ocean radial gradient, dot-matrix land (`<pattern>`),
  graticule, shading overlay, rim light as a *stroked* circle with a linear gradient (a filled radial rim washes the
  globe), great-circle arcs lifted off the surface (`p' = c + (p-c)(1 + h sin(pi t))`), city pills, stars kept out of
  the text zone.
- **Ink stamps** - SVG groups with `filter:url(#ink)` from `TN.filters` (displacement + speckle), double borders,
  ring text on an arc (`textPath`; text length <= pi r), tilted, overlapping a paper texture (repeating radial gradients).
- **Hologram** - dark teal radial, CSS-3D grid floor, iso wireframe with glow filter, translucent cyan fills, light cone
  (screen blend), particles, scanline overlay masked to the scene, chromatic aberration (two coloured drop-shadows),
  amber/red for the items that need attention, Nexi tinted with `grayscale sepia hue-rotate saturate` + stripe mask.

- **Playful sky (Nexi posts)** - sky gradient to warm white, sun disc + soft rays, white cloud blobs with a blurred
  shadow, pastel hills, seeded confetti (rects + dots in brand/app colours) kept out of the words; Nexi as the big
  character, a white speech bubble with a blue border. Track = one path stroked 3x (dashed ties, thick blue, white core).
- **Giant numeral** - two stacked text layers: back one solid with stepped text-shadows (extrusion), front one with a
  gradient fill + a diagonal shine layer; glyph box from canvas `measureText` so objects can sit on the stroke.
- **Gumball machine** - glass circle (radial gradient + blurred highlight arc), balls packed row by row inside a
  clipPath, each ball = colour + white disc + Odoo icon + highlight overlay; a crank, not a diagonal bar (reads as "no").

## Not used yet (good next picks)
- **Metro map**: the Odoo process as subway lines with interchange stations (apps), on a city-map texture. Any industry.
- **Claymorphism miniature**: soft clay kitchen/shop/warehouse diorama, warm light, tilt-shift blur. F&B, retail.
- **Paper-cut layers**: stacked cut-paper planes with drop shadows and light from above. Wellness, services.
- **Kinetic type poster**: one huge word ("RECONCILED.") built from tiny invoice/receipt elements. Accounting.
- **Product packaging hero**: an exploded 3D box/parcel with labels = Odoo steps, confetti. eCommerce.
- **Machine X-ray**: a machine drawn in cutaway with glowing parts = MRP work centres, sensors = IoT. Manufacturing.
- **Magazine / editorial cover**: big photo-like gradient mesh, masthead, cover lines = Odoo benefits. Company/brand.
- **Board game**: a path of squares (lead -> paid) with a pawn, dice and cards = apps. Sales/CRM.
- **Neon night storefront**: glowing signs, reflections on wet ground, an Odoo POS screen in the window. Retail/F&B.
- **Before/after split with a light leak**: chaotic desk vs calm Odoo screen, diagonal split, film grain. Any.

## 2026-10-09 Odoo services 57-66 (detailed metaphors, delivered to 12.)
| # | Service | Look |
|---|---|---|
| 57 | Discovery | tailor's atelier: dress form with app pins, tape with numbers, pegboard, wall clock, floor props |
| 58 | Customisation | toy-brick tower on a baseplate, golden custom brick, blueprint, curtained window, build booklet |
| 59 | Integration | Odoo power strip on brand blue, tube cables with current pulses, circuit traces, floor socket |
| 60 | Training | figure-8 driving course with kerbs + chequered line, training house, traffic light, sized signboards |
| 61 | Support | beach lifeguard tower (ON DUTY), ring buoy ticket, island + sailboat, lane floats, sandcastle, palm |
| 62 | Data migration | moving van from XLS house (#REF!, v3_FINAL) to Odoo house, skyline, balloons, crosswalk |
| 63 | Hosting | three floating islands (cloud house, Odoo.sh lab with branch graph, server rack), rope bridge, balloon |
| 64 | Upgrade | rocket "20" lifting off, gantry + beacon, mission control dish, city horizon, moon + planet |
| 65 | AI capture | capture machine: messy paper in, scan beam marks fields, vendor-bill DRAFT out on a conveyor |
| 66 | Multi-company | painted nesting dolls with Nexi-visor faces, opened Group doll, coin hops, Group view card |

## 2026-10-09 Odoo interface 67-76 (real UI, no metaphor, delivered to 13.)
| # | App | Look |
|---|---|---|
| 67 | Home screen | laptop on a desk, 18 app tiles pop in, cursor clicks Sales, new-order toast, mug + plant |
| 68 | CRM | rotated kanban on brand blue, card lifted from Proposition to Won, WON badge, toast |
| 69 | Sales | exploded 3D dashboard layers (graph window, KPI tiles, top products, team donut), Nexi on a tile |
| 70 | Inventory | Inventory Overview window + Barcode phone (scan line, qty 12 -> 13, Receipts 12 -> 11) |
| 71 | Accounting | journal cards on a tilted plane in a wave, Reconcile 7 -> 0, Bank card turns green, deep blue |
| 72 | POS | café counter tablet (order + products + numpad), receipt printer printing the GST slip |
| 73 | Helpdesk | ticket list with live SLA badges behind ticket form (chatter reply, stage Solved, SLA met) |
| 74 | Manufacturing | perspective work-order Gantt on dark slate, rescheduled bar + ghost, MO card with components |
| 75 | Mobile | three fanned phones: Timesheets timer, Expenses receipt read, Approvals tapped |
| 76 | Spreadsheet | sheet with =ODOO.PIVOT filling in, chart dragged into a Dashboards panel with scorecards |

## 2026-10-10 Odoo interface on brand skins 77-86 (delivered to 14.)
| # | App | Skin | Look |
|---|---|---|---|
| 77 | Invoicing | dark | invoice form with 9% GST lines, Register Payment -> PAID ribbon, payment toast, coins |
| 78 | Purchase | light | Compare Product Lines: 3 vendors, Best price / Fastest, Choose -> Purchase Order |
| 79 | Project | dark | project update: milestones ticking, hours ring 74/120 h, task bar, floating task card |
| 80 | Website | light | website editor: Columns block dragged from the Blocks panel into the page, published toast |
| 81 | eCommerce | dark | phone shop page Add to cart + Sales orders list with the new paid order, stock 42 -> 41 |
| 82 | Email Marketing | light | mailing with received/opened/clicked/replied rings, email preview, top links, opened toast |
| 83 | Time Off | dark | October team calendar with leave bars, request popover approved, balances |
| 84 | Sign | light | service agreement, signature draws itself, signers + activity, fully signed |
| 85 | Appointments | dark | phone booking page slot 10:30 + Odoo calendar week where the demo call appears |
| 86 | Live Chat | light | operator console typing /lead + visitor phone chat, lead created toast |

## 2026-10-10 Nexi introduction + collection (87-122) - built by 7 parallel helpers from qa/BRIEF-2026-10-10-collection.md
| # | Topic | Family / skin | Look |
|---|---|---|---|
| 87 | Meet Nexi (comic) | Nexi Explains v4 page theme | worm's-eye daytime splash: Nexi blasts out of a laptop Odoo app grid, tiles fly out like fireworks, WHOOSH!, title on the desk edge |
| 88 | Every app, one Odoo (comic) | v4 page theme | stage magic show: top-hat Nexi pulls a scarf chain of app tiles from a giant hat, marquee title board, Bluebay cast silhouettes |
| 89 | Built by TechNext (comic) | v4 page theme | pilot Nexi rides the TechNext logo plane over a golden-hour comic SEA map, 3 office pins on a dashed route, ZOOM! |
| 90 | Say hi to Nexi | site craft, light | TechNext staff ID card on a lanyard (photo, team chips, offices, barcode, TN-0000 sample), Nexi waving, Caveat notes |
| 91 | Four practices, one guide | site craft, dark | four practice playing cards fanned over Nexi, face-down TechNext deck, Season 1 badge, yellow swash headline centred |
| 92 | Ask Nexi anything Odoo | site craft, light | big outlined phone with the Ask Nexi chat + quick replies, question bubbles floating out, headline lower third |
| 93 | Odoo 20 AI agents | M+U light | PDF intake pod -> vendor bill form filling itself with AI sparkles, Approve cursor, NEW IN ODOO 20 sticker |
| 94 | Odoo 20 offline mode | R themed warm | one-point lamp-lit basement aisle, rugged tablet "3 changes waiting", packets to a daylit dock door, Synced toast |
| 95 | Odoo 20 MCP connector | I dark | iso: 3 generic AI kiosks -> MCP gateway turnstiles (Sales/Finance open, Payroll locked) -> Odoo vault, knight Nexi |
| 96 | Field Service -> Planning | U themed map paper | Planning Gantt + docked live map with vans, card flies Field Service -> Planning tile, headline on the sea |
| 97 | Pay 6 bills, one signature | S bird's-eye oak desk | six fanned bills crossed by one ink signature, pen, calculator, laptop "Pay 6 bills", headline on a letter sheet |
| 98 | Reorder from 30 days | T data-viz light | 30 dated sales bars skyline -> glass stock cabinet gauge Min 40/Max 120, reordering-rule card, RFQ toast |
| 99 | 7 signs, spreadsheets | T checklist, blue felt desk | clipboard with 7 signs, 3 red ticks + "3 OF 7" stamp, #REF! printouts, sticky "next step" |
| 100 | Go-live gate | R airport gate | one-point boarding gate, split-flap GO-LIVE GATE 4, two lit checks, trial-balance boarding pass, staging lounge |
| 101 | Standard first | M ocean cross-section | iceberg: Build tip, Upgrade 2027-29 strata, upgrade-cost depth gauge, Standard Odoo boat |
| 102 | InvoiceNow dates | T night terminal | split-flap DEPARTURES board with the 6 IRAS phases + statuses, traveller with invoice suitcase |
| 103 | Odoo 20 country packages | S travel desk top-down | 3 open passports with SG/PH/VN report stamps, headline on a boarding pass, luggage tags with app icons |
| 104 | Accounting vs ERP | M diagonal split light | muted ledger + scattered files vs glowing one-database core with app ring and order track, split headline |
| 105 | Phase one gears | M dark blueprint | 3 glossy meshing gears (Accounting/Sales/Inventory), grey phase-two gears, GO LIVE lever |
| 106 | Odoo Experience numbers | T conference hall light | hanging stat banners, Odoo 20 keynote screen, price card, audience, Nexi taking notes |
| 107 | Three offices | I map light | iso tilted SEA tile, 3 iso buildings with plates, paper-plane routes, headline lower third + 10+ stamp |
| 108 | 2 AM chatbot | R warm night street | moonlit closed sofa shop, CLOSED sign, clock 2:00, big phone chat with Reserve chip, beanie Nexi |
| 109 | IoT freezer | M cutaway cold room | walk-in freezer with frost, sensor, live chart crossing -15C, phone alerts |
| 110 | Office Wi-Fi | I blueprint light | iso office floor, 3 APs with coverage rings, rack + patch cables, coverage legend |
| 111 | Website front door | M sunny street | browser window as a shopfront, Get a quote door, visitors -> CRM lead card, top-hat doorman Nexi |
| 112 | Social media calendar | S full-bleed cork board | pinned October card calendar, campaign string, polaroid, phone feed, reach card, headline on pinned paper |
| 113 | Brand assets | S three-quarter oak desk | Bayside F&B guidelines book, swatch fan, cards, deck tablet, tote + cup, headline top-right |
| 114 | App development | U devices dark | 3 phones fanned low angle (tracking, staff checklist, portal) on a glossy Odoo database disk |
| 115 | POS Restaurant | S bird's-eye restaurant | tables in status rings, kitchen ticket printer, POS floor-plan tablet, headline on the host counter |
| 116 | Planning shifts | T kinetic dark | puzzle-tab shift blocks falling into a week roster, red open-shift gap, split headline |
| 117 | Marketing Automation | M pegboard workshop | wooden marble run: sign-up hopper, Opened? rocker gate, offer / reminder wheel, Lead -> CRM basket |
| 118 | Documents | M iso machine light | mailroom sorter belt + pistons into Finance/HR/Legal/Projects bins, Documents window as its screen |
| 119 | Expenses | S bird's-eye cafe table | receipt (22.48 + 9% GST = 24.50), phone in scan mode with field chips, expense card To approve |
| 120 | Studio | U macro dutch light | tilted Studio editor, giant cursor drags "Delivery window" into a glowing drop zone |
| 121 | Archive tip | M lamp-lit records room | headline on a manila folder, ARCHIVED drawer, crossed-out bin, Archived filter list, Restore card |
| 122 | Four views tip | M 3D cube dark | glossy cube with Kanban/List/Graph faces + Calendar face swinging open, view switcher above |

## 2026-10-10 collection part 2 (123-172) - 8 parallel helpers, BRIEF-2026-10-10-collection2.md
| # | Topic | Family / skin | Look |
|---|---|---|---|
| 123 | Odoo 20 Website Assistant | U+M light | numbered prompt words snapping matching blocks into a bakery homepage, SEO/llms.txt chips |
| 124 | Odoo 20 Accounting Assistant | R morning desk | monitor with the assistant answer (3 late invoices = calculator total), clipboard reconciliation audit |
| 125 | bill line prediction | S macro felt mat | paper vendor bill with accepted + ghost account chips, giant Tab keycap |
| 126 | POS snooze | R cafe counter | headline chalked on the specials board, empty croissant tray, greyed POS tile with moon badge, muffin combo |
| 127 | stock aging | T dark shelving | 24 cartons coloured by age bucket (heat map), cobwebs on 90+, brass "inventory at" dial |
| 128 | BOM comparison | M blueprint | two exploded desk-lamp drawings v1/v2, red-marker circles, comparison card |
| 129 | Spreadsheet locked sheets | U light | tilted Budget 2027 sheet, bubble chart as glossy spheres, padlock + key on the tab |
| 130 | Odoo 20 mobile | U device dusk platform | hand-held phone with the swipe-down palette, bottom-sheet date picker beside it, passing train |
| 131 | bank reconciliation | M denim flat lay | brass zipper closing bank/invoice tags into matched pairs, open lines above, Nexi on the slider |
| 132 | follow-up reminders | S wall clothesline | Day 7/15/30 envelopes with wax seals then PAID receipt, calendar strip, report |
| 133 | analytic accounting | M patisserie | layered cake sliced by revenue, margin flags = report |
| 134 | asset depreciation | M highway viaduct | headline on an overhead sign, ramp = straight-line schedule, van at month 10 |
| 135 | multi-currency | S navy wall + marble | generic coin stacks into one SGD ledger, split-flap rate board, 3 clocks, globe |
| 136 | pay-online link | U light | phone email -> generic checkout -> PAID invoice in three steps |
| 137 | optional products | U dark | customer quotation page tilted, Installation ticked, total updates |
| 138 | product variants | T kinetic light | product form + 6 x 4 = 24 type, rail wall of 24 numbered tees |
| 139 | loyalty + gift cards | R cafe counter eye level | receipt with points, 8/10 stamp card, points app, gift card, chalk rewards board |
| 140 | SMS marketing | U dark | SMS composer 98/160 sending bubbles to a low-angle lock screen |
| 141 | CRM lead scoring | T light | glass heat column (thermometer) with leads hung at their probability |
| 142 | customer portal | R daylight lobby | self-service kiosk with the portal, customer tapping, oak slat wall |
| 143 | pick-pack-ship | S top-down warehouse | PICK/PACK/SHIP zones with one tote route; Nexi from a high 3/4 angle |
| 144 | dropshipping | I light | iso mini-world: ghost box at the shop, PO to vendor, van straight to the customer |
| 145 | landed costs | M dusk port cutaway | cost chips hanging from a crane into a container of 1,000 crates, unit-cost tag |
| 146 | repairs | R high-angle workshop | pegboard, wall screen repair order, cracked laptop on a cutting mat |
| 147 | quality checks | M macro light | caliper reading 25.02 mm, Quality tablet Pass, PASS/FAIL lamps, reject bin |
| 148 | maintenance | R sunlit factory | filler machine with gauges, technician cart, +30-day preventive plan, kanban |
| 149 | fleet | S dark office wall | oak key cabinet with tagged keys (odometer, due dates), Fleet tablet |
| 150 | recruitment | M light | glass elevator rising New -> Interview -> Offer -> Hired to a WELCOME door |
| 151 | appraisals | M greenhouse | goal pots growing to their progress, Nexi watering, check-in calendar |
| 152 | org chart | M white gallery | hanging mobile sculpture of avatar discs = org chart, museum wall text |
| 153 | PH payroll | S morning desk | tray of 24 payslips, BIR 1601-C/2316/1604-C folder tabs, payslip maths |
| 154 | lunch | S top-down terrazzo | 14 named lunch boxes ringing a clock at 11:30 on a lazy Susan |
| 155 | Knowledge | M daylight library | card-catalogue drawer whose cards rise into nested Knowledge pages |
| 156 | Discuss / chatter | M light split | group-chat bubbles knotted in yarn vs one strand pinned to the S00042 chatter |
| 157 | activities | S dark wall | messy sticky notes -> tidy activity list, ringing alarm clock |
| 158 | surveys | R shop exit | four-face kiosk, live results screen, QR poster, headline on a hanging sign |
| 159 | email aliases | M hallway cutaway | blue door with 3 brass mail slots, tubes into the Odoo room -> bill/ticket/lead |
| 160 | VoIP | M light | glossy retro handset whose coiled cord becomes a data line into the call log |
| 161 | tip: Favorites | U macro dark | tilted search panel, gold star clicked, ribbon on "My open quotes" |
| 162 | tip: Ctrl + K | S macro sunlit desk | perspective keyboard, glowing Ctrl/K, light rising into the palette |
| 163 | tip: mass edit | M iso light | 20 record dominoes toppling from the "20 selected" list |
| 164 | tip: Group By | M tiled pantry | marbles arcing from a bowl into stage jars 7/5/4/3, slate headline board |
| 165 | tip: import | M loading dock | spreadsheet-row crates on rollers into a shutter that opens onto Contacts |
| 166 | tip: log note vs message | M light split | chatter bar over corkboard note (team) vs envelope out of the window |
| 167 | tasks not people | M editorial office | overhead conveyor lifting repetitive task cards into an Odoo box |
| 168 | test database | R dark simulator cockpit | cockpit displays running Odoo under TEST DATABASE banners |
| 169 | fix the process first | M 3D road map | tangled detours redrawn by a highlighter into one road with app stops |
| 170 | the log is for fixing | U dark | product chatter, magnifier on the slip, undo arrow restoring the price |
| 171 | ask the policy manual | M office library | glowing handbook, answer card with citation thread to the paragraph |
| 172 | written quotation | U light | the five real quotation steps as cards feeding a printer, printed scope |
