# Fresh-eyes review (after audit.py is clean, before delivery)

audit.py catches faults a script can measure. It cannot tell you that a post is generic, that the eye lands on
decoration, or that the scene would work for any company. This review does. Adapted from oil-ui's review protocol
(github.com/oil-oil/oil-ui, MIT; read 2026-11-22, nothing installed). House rules win over anything here.

Run it once per batch (not per post) on new posts, redesigns and ad creatives. Skip it for a "fix this" change on an
approved post (change only the flagged fault).

## 1. Squint sheet (you, 2 minutes)
`python <skill>/scripts/squint.py out/*.png --out qa/squint.jpg` puts each post at feed size (270 px wide) next to a
blurred copy. Look at each pair for 3 seconds and write two sentences per post in your notes:
- "It looks like a ___ post from ___" (what kind of thing, which year). "A generic 2019 SaaS banner" = redo the scene.
- "The first thing I see is ___". It must be the hero object / Nexi's moment or the headline. A glow, a pattern, a
  card frame or the logo row first = the hierarchy is wrong.
On the blurred copy the post must still show one clear hero shape and a clear headline block. Three equal blobs = no hero.

## 2. Swap test (you, 1 minute per post)
Cover the logo row and headline. Could this exact scene advertise another ERP vendor, another Odoo app, or an unrelated
company without changing anything? If yes, the scene is generic: the named Odoo process and TechNext service must be
visible in the picture itself (its props, screen, document, Nexi's action), not only in the words. Fix the scene, not
the caption.

## 3. Copy trim (you)
Delete any line that points to no object, action or number: mood lines added to balance the layout ("Where clarity
meets growth"), design notes, "illustration", "concept". Keep the required "sample" labels (content-rules.md) - those
are facts, not filler. Headline + one sub-line is the house limit anyway.

## 4. One independent reviewer (subagent, Sonnet, one per batch)
Spawn ONE fresh agent with no build history (cheap model is fine; low tokens). Hand it ONLY:
- the rendered PNG paths (full size) and `qa/squint.jpg`;
- the brief, and per post the one-line film idea + the TechNext service + the Odoo process it must show;
- the hard rules as one line each: fixed logo row, light TechNext brand (no dark mode, no peach/mint/purple), no icon
  tiles, title max 3 rows, labels >= 15 px / sentences >= 18 px at 1080 wide, no people in ads, flat icons.
Do NOT hand it: the HTML source, your reasons for choices, audit output, or any earlier score (it must judge
independently). Ask it for, per post, in this order:
1. **Veto check** - mark the post NOT SHIPPABLE if any holds: text unreadable at 540 px wide; a glyph clipped or cut;
   the hero still looks like a placeholder or stock art; the swap test passes; in 3 seconds you can't name the hero and
   the call to action.
2. **Problems** - max 5, biggest first, each as `location: what is seen -> what fixed looks like`. If the layout
   skeleton itself is the default template, the first line is `REDO: <block> - <why>` and no patch list for that block.
3. **Keep:** one or two things the fix must not sand away (usually the most distinctive move).
4. One line: which post in the batch is strongest and why (sets the bar for the others).
It reviews only; it edits nothing.

## 5. Acting on the review (you)
- REDO first: go back to the post's concept line and rebuild the named block (new skeleton, new hero placement).
  Patching a default skeleton only makes a neater default.
- Then the problems in the order given. Turn vague notes into numbers before editing ("crowded" -> +24 px gap
  between headline and scene, label 15 -> 18 px).
- Reject, with a one-line reason in your report, anything that breaks an owner rule (logo row, brand colours, no
  people, light look) - the reviewer does not know the owner.
- Write the Keep line into the post's page header comment and check it survived after the fix.
- Re-run audit.py (0 errors) and re-render. At most two review rounds: if notes start to flip back and forth, keep the
  best version and say so.

## 6. Report
In the delivery message: "Fresh-eyes review: N posts, X vetoed and fixed, Y notes rejected (owner rules)", or
"Fresh-eyes review not run: <reason>". Never claim a visual check you did not look at.
