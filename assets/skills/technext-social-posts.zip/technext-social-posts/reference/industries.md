# Industries and services: angle, Odoo process, props

Angles are the live technext.asia claims (checked 2026-10-06). Props are ideas for the scene - pick, don't stack them all.

## Industries (/industries/<slug>)
| Industry | Angle (site) | Odoo apps | Process to show | Props / metaphors |
|---|---|---|---|---|
| construction | Every project's cost and margin while it is still running | Project, Purchase, Accounting, Timesheets, Invoicing | PO site materials, subcontractor claim, labour hours land on the job; progress claim (certified %), retention 5%; S-curve | blueprint, tower going up, crane, dimension lines, taped cost tags, hard hat, site board |
| travel | Know the margin on every booking | CRM, Sales, Purchase, Accounting/Invoicing, Website | enquiry -> quotation from supplier services (flights, hotel in IDR, transfers, guide) -> confirm -> supplier bills -> invoice in customer currency; margin per booking | globe + arcs, passport stamps, boarding pass, luggage tags, postcards |
| medical (clinics) | Stock, purchasing and books - per branch, in one system | Inventory (lots/expiry, FEFO), Purchase (reorder rules -> RFQ), Accounting (per branch), Appointments | lot and expiry tracking, FEFO picking, quarantine, reorder per branch, books per clinic | hologram stockroom, medicine shelves, lot labels, branch map |
| retail | Shared stock, promotions, daily takings posted to Accounting | Point of Sale, Inventory, Accounting, eCommerce | sale at the till -> stock moves -> session close posts takings | receipt ribbon, shop window, barcode scanner, shelf labels |
| ecommerce | Online orders, marketplace feeds and fulfilment tied to real stock, reconciled payouts | eCommerce, Inventory, Sales, Accounting | order -> pick/pack/ship -> payout reconciled | parcels, conveyor, phone checkout, delivery van |
| fnb | POS to kitchen, recipes deplete stock, outlet takings to the books | POS Restaurant, Kitchen display, Inventory (BoM recipes), Accounting | table order -> kitchen -> recipe depletes ingredients -> takings | kitchen pass, order tickets, plates, menu board |
| manufacturing | BoMs, work orders, component stock, real cost per unit | Manufacturing, Inventory, Quality, Maintenance, Purchase | MO from sales/reorder -> work orders -> quality check -> finished goods cost | factory cutaway, gears, assembly line, machine X-ray |
| health-wellness | Bookings, memberships, packages and retail on one client record | Appointments, Subscriptions, POS, CRM | booking -> visit -> package used -> renewal | calm studio, membership card, calendar, plants |

## Services
| Service | URL | Odoo / process to show |
|---|---|---|
| Odoo ERP implementation | /solutions/odoo-erp, /odoo/discovery | Discovery -> Training -> Integration -> Support; Accounting + Sales + Inventory first; one database |
| One sales order, many apps | /odoo/erp-system | confirm SO -> stock reserved, PO/MO via MTO/reorder, project tasks for services, ready to invoice |
| AI chatbots | /solutions/ai-chatbots | website chat answers from your content -> lead in CRM -> appointment |
| AI automation / Odoo AI | /solutions/ai-automation, /odoo/ai-integration | vendor bill read, matched to PO (3-way), approved by a person, posted; drafted replies; answers with source shown |
| AI knowledge | /solutions/ai-knowledge | assistant grounded in your documents and Odoo records |
| Websites / marketing | /solutions/website, /solutions/marketing | website + AI assistant (Nexi), social, brand kit |
| IoT | /solutions/iot | sensor -> network -> app alert -> Odoo Quality / Maintenance |
| App development | /solutions/app-development | field app steps fill the Odoo job (Field Service) |
| Networks | /solutions/networks | site network keeping devices and Odoo connected (no security/pentest claims) |

## Sample data that already appeared (keep consistent if reused)
Quotation S00921 SIN->DPS 5D4N 2 pax, cost S$2,560, sell S$3,140, margin 18.5%. Journal POS/2026/1042: card 21.00 =
sales 19.27 + GST 9% 1.73. Construction: PO S$18,200, subcontractor claim S$42,500, labour 320 h S$11,800, certified 40%,
retention 5%. Clinic: Saline lot 17A exp 18 Nov 2026 (FEFO first), gloves (M) 12 left vs min 20 -> RFQ P00512.
