function (o) {
  const pickHero = () => (o.sel && document.querySelector(o.sel)) ||
    document.querySelector('#hero, .hero, [class*="hero" i], [id*="hero" i]') ||
    (document.querySelector('h1') && document.querySelector('h1').closest('section, header, main > div')) ||
    document.querySelector('main section, section');
  const desc = el => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') +
    (el.classList.length ? '.' + [...el.classList].slice(0, 2).join('.') : '');
  const txt = el => (el.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 40);
  const rgb = s => { const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null;
    const p = m[1].split(/[ ,/]+/).filter(Boolean).map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; };
  const lum = c => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); };
    return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  const blend = (top, bot) => [0, 1, 2].map(i => top[i] * top[3] + bot[i] * (1 - top[3])).concat(1);
  function bgOf(el) {           // solid background under el, or null if an image/gradient is involved
    const stack = [];
    for (let e = el; e; e = e.parentElement) {
      const cs = getComputedStyle(e);
      if (cs.backgroundImage && cs.backgroundImage !== 'none') return null;
      const c = rgb(cs.backgroundColor);
      if (c && c[3] > 0) { stack.push(c); if (c[3] >= 1) break; }
    }
    let base = [255, 255, 255, 1];
    for (let i = stack.length - 1; i >= 0; i--) base = blend(stack[i], base);
    return base;
  }
  // layers positioned behind the copy (glows, photos) make the computed background unreliable
  function coveredByArt(el, hero) {
    const r = el.getBoundingClientRect();
    // soft gradient glows are fine; photos, video, canvas and url() backgrounds are not measurable
    const art = [...hero.querySelectorAll('img, video, canvas, svg, [aria-hidden="true"] *, [aria-hidden="true"]')]
      .filter(a => /^(IMG|VIDEO|CANVAS|svg)$/.test(a.tagName) || /url\(/.test(getComputedStyle(a).backgroundImage));
    return art.some(a => {
      if (a.contains(el) || el.contains(a)) return false;
      const b = a.getBoundingClientRect(); if (b.width < 40 || b.height < 40) return false;
      const ox = Math.min(r.right, b.right) - Math.max(r.left, b.left), oy = Math.min(r.bottom, b.bottom) - Math.max(r.top, b.top);
      return ox > r.width * .3 && oy > r.height * .3;
    });
  }
  const effOpacity = el => { let v = 1; for (let e = el; e; e = e.parentElement) v *= +getComputedStyle(e).opacity; return v; };
  const OK_PROPS = new Set(['transform', 'opacity', 'filter', 'offset', 'easing', 'composite', 'computedOffset',
    'translate', 'scale', 'rotate', 'clipPath', 'clip-path', 'backgroundPosition', 'background-position']);

  return {
    anims() {
      const out = [];
      for (const an of document.getAnimations()) {
        const eff = an.effect; if (!eff || !eff.getKeyframes) continue;
        for (const k of eff.getKeyframes()) for (const p in k)
          if (!OK_PROPS.has(p) && !p.startsWith('--')) out.push({ prop: p, el: eff.target ? desc(eff.target) : '?' });
      }
      const seen = new Set(); return out.filter(x => !seen.has(x.prop + x.el) && seen.add(x.prop + x.el));
    },
    focusSig() {
      const el = document.activeElement; if (!el || el === document.body) return null;
      const cs = getComputedStyle(el);
      const ring = (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0) ||
        (cs.boxShadow && cs.boxShadow !== 'none');
      return { tag: el.tagName.toLowerCase(), text: txt(el), ring };
    },
    run() {
      const E = [], W = [], vw = innerWidth, vh = innerHeight, phone = o.w < 600;
      const hero = pickHero();
      if (!hero) return { errors: ['no hero found (pass --selector)'], warnings: [] };
      const hr = hero.getBoundingClientRect();
      const h1s = document.querySelectorAll('h1');
      if (h1s.length !== 1) E.push(`page has ${h1s.length} <h1> (need exactly 1)`);
      const h1 = hero.querySelector('h1');
      if (!h1) E.push('hero has no <h1>');
      if (document.documentElement.scrollWidth > document.documentElement.clientWidth + 1)
        E.push(`horizontal overflow: page is ${document.documentElement.scrollWidth}px wide in a ${document.documentElement.clientWidth}px viewport`);

      const texts = [...hero.querySelectorAll('h1,h2,h3,p,a,button,li,span,small,strong,em,label')]
        .filter(e => e.offsetParent !== null && txt(e) && ![...e.children].some(c => /^(P|H1|H2|H3|DIV|UL)$/.test(c.tagName)));
      for (const e of texts) {
        const r = e.getBoundingClientRect(); if (r.width === 0) continue;
        if (r.left < -1 || r.right > vw + 1) E.push(`text off-screen horizontally: ${desc(e)} "${txt(e)}"`);
        const cs = getComputedStyle(e);
        if (/hidden|clip|auto|scroll/.test(cs.overflow + cs.overflowX) && (e.scrollWidth > e.clientWidth + 2))
          E.push(`text clipped inside its box: ${desc(e)} "${txt(e)}"`);
        const p = e.parentElement, pr = p.getBoundingClientRect(), pcs = getComputedStyle(p);
        if (pcs.display !== 'inline' && (r.right > pr.right + 3 || r.left < pr.left - 3) && /^(A|BUTTON)$/.test(p.tagName))
          E.push(`label spills out of ${desc(p)}: "${txt(e)}"`);
        const op = effOpacity(e);
        if (op < .9 && cs.visibility !== 'hidden')
          E.push(o.reduced ? `reduced motion: "${txt(e)}" still hidden (opacity ${op.toFixed(2)})`
                           : `"${txt(e)}" still hidden 2.5 s after load (opacity ${op.toFixed(2)})`);
      }

      const imgs = [...hero.querySelectorAll('img')];
      for (const im of imgs) {
        if (!im.getAttribute('width') || !im.getAttribute('height')) E.push(`hero <img> without width/height attributes: ${im.getAttribute('src')}`);
        if (im.loading === 'lazy') E.push(`hero <img> is loading="lazy" (hero images must load eagerly): ${im.getAttribute('src')}`);
        if (im.complete && im.naturalWidth === 0) E.push(`hero <img> failed to load: ${im.getAttribute('src')}`);
        if (!im.hasAttribute('alt')) E.push(`hero <img> has no alt: ${im.getAttribute('src')}`);
      }

      const ctas = [...hero.querySelectorAll('a[href], button')].filter(e => e.offsetParent !== null && txt(e));
      const btnLike = ctas.filter(e => { const cs = getComputedStyle(e); return (rgb(cs.backgroundColor) || [0,0,0,0])[3] > 0 ||
        parseFloat(cs.borderTopWidth) > 0 || /btn|button|cta/i.test(e.className); });
      if (!ctas.length) E.push('hero has no CTA link/button');
      if (btnLike.length > 2) W.push(`${btnLike.length} button-style CTAs in the hero (max 2)`);
      const fake = hero.querySelectorAll('[onclick]:not(a):not(button)');
      if (fake.length) E.push(`${fake.length} clickable non-link/button element(s) in hero`);
      for (const b of btnLike) {
        const r = b.getBoundingClientRect();
        if (phone && r.height < 44) E.push(`CTA "${txt(b)}" is ${Math.round(r.height)}px tall on phone (min 44)`);
      }
      if (btnLike[0]) {
        const r = btnLike[0].getBoundingClientRect();
        if (r.bottom + scrollY > vh) (o.view === 'laptop' || phone ? E : W).push(`primary CTA "${txt(btnLike[0])}" is below the fold (bottom ${Math.round(r.bottom)}px, viewport ${vh}px)`);
      }

      const checkC = (el, min, label) => {
        if (!el) return;
        const fg = rgb(getComputedStyle(el).color), bg = bgOf(el);
        if (!fg) return;
        if (!bg || coveredByArt(el, hero)) { W.push(`${label} sits on image/gradient art - contrast not measurable, check the PNG`); return; }
        const cr = ratio(blend(fg, bg), bg);
        if (cr < min) E.push(`${label} contrast ${cr.toFixed(2)}:1 (need ${min}:1)`);
      };
      checkC(h1, 3, 'h1');
      const sub = h1 && [...hero.querySelectorAll('p')].find(p => p.compareDocumentPosition(h1) & Node.DOCUMENT_POSITION_PRECEDING && txt(p).length > 30);
      checkC(sub, 4.5, 'sub-line');
      if (btnLike[0]) checkC(btnLike[0], 4.5, 'primary CTA label');

      if (h1) {
        const words = txt(h1) ? h1.innerText.trim().split(/\s+/).length : 0;
        if (words > 12) W.push(`h1 has ${words} words (aim <= 9)`);
        const fam = getComputedStyle(h1).fontFamily.split(',')[0].replace(/["']/g, '').trim();
        if (/^(Montserrat|Poppins|Roboto|Open Sans|Lato|Raleway)$/i.test(fam)) W.push(`h1 font is ${fam} - generic unless it is the brand font (fonts.md)`);
        const lh = parseFloat(getComputedStyle(h1).lineHeight) || parseFloat(getComputedStyle(h1).fontSize) * 1.2;
        const lines = Math.round(h1.getBoundingClientRect().height / lh);
        if (phone && lines > 5) W.push(`h1 wraps to ${lines} lines on phone (aim <= 4)`);
        if (!phone && lines > 3) W.push(`h1 wraps to ${lines} lines on ${o.view}`);
        if (getComputedStyle(h1).textWrap && !/balance|pretty/.test(getComputedStyle(h1).textWrap)) W.push('h1 has no text-wrap: balance');
      }
      if (sub && !phone) {
        const lh = parseFloat(getComputedStyle(sub).lineHeight) || 24;
        const lines = Math.round(sub.getBoundingClientRect().height / lh);
        if (lines > 3) W.push(`sub-line wraps to ${lines} lines on ${o.view} (aim <= 2-3)`);
      }
      const fams = new Set(texts.map(e => getComputedStyle(e).fontFamily.split(',')[0].replace(/["']/g, '').trim()));
      if (fams.size > 2) W.push(`${fams.size} font families in hero: ${[...fams].join(', ')}`);
      if (!document.querySelector('meta[name="viewport"]')) E.push('no <meta name="viewport">');
      if (/user-scalable\s*=\s*no|maximum-scale\s*=\s*1(\.0)?\b/.test((document.querySelector('meta[name="viewport"]') || {}).content || ''))
        E.push('viewport meta disables zoom');
      if (hr.height > vh * 1.15 && !phone) W.push(`hero is ${Math.round(hr.height)}px tall in a ${vh}px viewport`);
      return { errors: E, warnings: W };
    }
  };
}
