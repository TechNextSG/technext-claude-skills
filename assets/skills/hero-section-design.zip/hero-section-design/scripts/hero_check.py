# -*- coding: utf-8 -*-
"""Hero section gate: renders a page in headless Chrome at desktop / tablet / phone / phone+reduced-motion, saves
screenshots and runs the automated checks from references/checklist.md (Vercel Web Interface Guidelines subset).

usage: python hero_check.py <file.html | http(s)://url> [--out DIR] [--selector CSS] [--port 9431]
exit 0 = 0 errors. Needs: pip install websocket-client. Chrome path: env CHROME_PATH or the default install.
"""
import argparse, json, os, pathlib, shutil, socket, subprocess, sys, tempfile, time, urllib.request
import websocket

CHROME = os.environ.get('CHROME_PATH', r'C:\Program Files\Google\Chrome\Application\chrome.exe')
VIEWS = [  # name, w, h, mobile, reduced-motion
    ('desktop', 1440, 900, False, False),
    ('laptop', 1366, 768, False, False),
    ('tablet', 834, 1112, True, False),
    ('phone', 390, 844, True, False),
    ('phone-reduced', 390, 844, True, True),
]
CHECK_JS = (pathlib.Path(__file__).with_name('hero_check.js')).read_text(encoding='utf-8')


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, max_size=None, timeout=60, suppress_origin=True)
        self.i, self.events = 0, []

    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({'id': self.i, 'method': method, 'params': params}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get('id') == self.i:
                if 'error' in m:
                    raise RuntimeError(m['error'])
                return m.get('result', {})
            if 'method' in m:
                self.events.append(m)

    def ev(self, js):
        r = self.call('Runtime.evaluate', expression=js, returnByValue=True, awaitPromise=True)
        if r.get('exceptionDetails'):
            raise RuntimeError(r['exceptionDetails'].get('exception', {}).get('description', str(r['exceptionDetails'])))
        return r.get('result', {}).get('value')

    def wait(self, ms):
        end = time.time() + ms / 1000
        self.ws.settimeout(0.05)
        while time.time() < end:
            try:
                m = json.loads(self.ws.recv())
                if 'method' in m:
                    self.events.append(m)
            except (websocket.WebSocketTimeoutException, TimeoutError):
                pass
        self.ws.settimeout(60)


def free_port(start):
    for p in range(start, start + 50):
        with socket.socket() as s:
            if s.connect_ex(('127.0.0.1', p)) != 0:
                return p
    raise RuntimeError('no free port')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('target')
    ap.add_argument('--out')
    ap.add_argument('--selector', default='')
    ap.add_argument('--port', type=int, default=9431)
    a = ap.parse_args()

    url = a.target if a.target.startswith(('http://', 'https://', 'file:')) else pathlib.Path(a.target).resolve().as_uri()
    out = pathlib.Path(a.out or (pathlib.Path(a.target).resolve().parent / 'hero-check' if not a.target.startswith('http')
                                 else pathlib.Path.cwd() / 'hero-check'))
    out.mkdir(parents=True, exist_ok=True)
    port = free_port(a.port)
    prof = pathlib.Path(tempfile.mkdtemp(prefix='hero-check-'))
    proc = subprocess.Popen([CHROME, '--headless=new', f'--remote-debugging-port={port}', f'--user-data-dir={prof}',
                             '--hide-scrollbars', '--no-first-run', '--allow-file-access-from-files',
                             f'--remote-allow-origins=http://127.0.0.1:{port}', 'about:blank'],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    errors, warnings = [], []
    try:
        ws = None
        for _ in range(100):
            try:
                ws = [t for t in json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/json'))
                      if t['type'] == 'page'][0]['webSocketDebuggerUrl']
                break
            except Exception:
                time.sleep(.15)
        if not ws:
            raise RuntimeError('Chrome did not start')
        c = CDP(ws)
        for d in ('Page', 'Runtime', 'Log', 'Network'):
            c.call(d + '.enable')
        for name, w, h, mobile, reduced in VIEWS:
            c.events.clear()
            c.call('Emulation.setDeviceMetricsOverride', width=w, height=h, deviceScaleFactor=1, mobile=mobile)
            c.call('Emulation.setEmulatedMedia', features=[
                {'name': 'prefers-reduced-motion', 'value': 'reduce' if reduced else 'no-preference'},
                {'name': 'prefers-color-scheme', 'value': 'light'}])
            c.call('Network.setCacheDisabled', cacheDisabled=False)
            c.call('Page.navigate', url=url)
            for _ in range(200):
                c.wait(50)
                if c.ev('document.readyState') == 'complete':
                    break
            c.ev('document.fonts.ready.then(()=>1)')
            c.wait(250)
            anims = c.ev('(%s)(%s).anims()' % (CHECK_JS, json.dumps({'sel': a.selector})))
            c.wait(600 if reduced else 2300)
            r = c.ev('(%s)(%s).run()' % (CHECK_JS, json.dumps({'sel': a.selector, 'view': name, 'w': w, 'h': h,
                                                                   'reduced': reduced})))
            if name == 'desktop':
                before = c.ev('(%s)({}).focusSig()' % CHECK_JS)
                c.call('Input.dispatchKeyEvent', type='keyDown', key='Tab', code='Tab', windowsVirtualKeyCode=9)
                c.call('Input.dispatchKeyEvent', type='keyUp', key='Tab', code='Tab', windowsVirtualKeyCode=9)
                c.wait(150)
                after = c.ev('(%s)({}).focusSig()' % CHECK_JS)
                if not after or not after.get('tag'):
                    r['errors'].append('keyboard: Tab focused nothing')
                elif not after.get('ring'):
                    r['errors'].append('keyboard: first Tab stop <%s> "%s" shows no visible focus ring'
                                       % (after['tag'], after.get('text', '')))
                c.call('Input.dispatchKeyEvent', type='keyDown', key='Escape', code='Escape', windowsVirtualKeyCode=27)
                c.ev('document.activeElement && document.activeElement.blur(), window.scrollTo(0,0), 1')
                c.wait(100)
            for p in (anims or []):
                r['warnings'].append('animation on non-composited property "%s" (%s)' % (p['prop'], p['el']))
            shot = c.call('Page.captureScreenshot', format='png')['data']
            import base64
            f = out / f'hero-{name}.png'
            f.write_bytes(base64.b64decode(shot))
            for e in c.events:
                m, p = e['method'], e.get('params', {})
                if m == 'Runtime.exceptionThrown':
                    r['errors'].append('JS exception: ' + p['exceptionDetails'].get('exception', {}).get(
                        'description', p['exceptionDetails'].get('text', ''))[:200])
                elif m == 'Runtime.consoleAPICalled' and p.get('type') == 'error':
                    r['errors'].append('console.error: ' + ' '.join(str(x.get('value', x.get('description', '')))
                                                                    for x in p.get('args', []))[:200])
                elif m == 'Log.entryAdded' and p['entry'].get('level') == 'error':
                    r['errors'].append('log error: %s %s' % (p['entry'].get('text', '')[:160], p['entry'].get('url', '')))
                elif m == 'Network.loadingFailed' and not p.get('canceled'):
                    r['errors'].append('request failed: %s' % p.get('errorText'))
            errs = sorted(set(r['errors']))
            warns = sorted(set(r['warnings']))
            errors += ['[%s] %s' % (name, x) for x in errs]
            warnings += ['[%s] %s' % (name, x) for x in warns]
            print('%-14s %s  %d error(s), %d warning(s)' % (name, f, len(errs), len(warns)))
        c.ws.close()
    finally:
        proc.terminate()
        try:
            proc.wait(5)
        except Exception:
            proc.kill()
        shutil.rmtree(prof, ignore_errors=True)

    # same fault at several widths -> report once per message, list widths
    def fold(items):
        d = {}
        for x in items:
            v, msg = x[1:].split('] ', 1)
            d.setdefault(msg, []).append(v)
        return ['%s  [%s]' % (m, ','.join(v)) for m, v in d.items()]
    print()
    for x in fold(errors):
        print('ERROR  ', x)
    for x in fold(warnings):
        print('warn   ', x)
    print('\nHERO CHECK: %d error(s), %d warning(s)  -> %s' % (len(fold(errors)), len(fold(warnings)), out))
    print('Now LOOK at each PNG and answer the review questions in references/checklist.md.')
    sys.exit(1 if errors else 0)


if __name__ == '__main__':
    main()
