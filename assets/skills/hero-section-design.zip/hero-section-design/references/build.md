# Build - hero skeleton and rules

```html
<a class="skip" href="#main">Skip to content</a>
<header class="site-header">...nav...</header>
<main id="main">
<section class="hero" id="hero" aria-labelledby="hero-title">
  <div class="hero__bg" aria-hidden="true"><!-- glow, grain, shapes --></div>
  <div class="hero__copy">
    <p class="eyebrow" data-in>Odoo partner &middot; Singapore &amp; Philippines</p>
    <h1 id="hero-title" data-in>One promise in nine words or&nbsp;fewer</h1>
    <p class="sub" data-in>Who it is for and the concrete result, in two short lines.</p>
    <div class="ctas" data-in>
      <a class="btn btn--primary" href="/get-started">Book a free consult</a>
      <a class="btn btn--ghost" href="#how">See how it works</a>
    </div>
    <p class="proof" data-in>Trusted by ... / one real fact</p>
  </div>
  <figure class="hero__visual" data-in-visual>
    <img src="hero.webp" width="1200" height="900" alt="What the screenshot shows" fetchpriority="high" decoding="async">
  </figure>
</section>
</main>
```

```css
.hero{position:relative;display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,1fr);gap:clamp(24px,4vw,64px);
  align-items:center;min-height:min(100svh,920px);
  padding:clamp(96px,12vh,140px) max(clamp(20px,5vw,80px),env(safe-area-inset-right)) clamp(48px,8vh,96px)
          max(clamp(20px,5vw,80px),env(safe-area-inset-left));overflow:clip}
.hero h1{font-size:clamp(2.6rem,6vw,5.5rem);line-height:1;letter-spacing:-.03em;text-wrap:balance;max-width:14ch}
.hero .sub{font-size:clamp(1.05rem,1.4vw,1.3rem);line-height:1.5;max-width:46ch;text-wrap:pretty}
.btn{display:inline-flex;align-items:center;min-height:48px;padding:0 22px;border-radius:999px;touch-action:manipulation}
.btn:focus-visible{outline:3px solid var(--accent);outline-offset:3px}
.hero__visual img{width:100%;height:auto;display:block}
@media (max-width:820px){.hero{grid-template-columns:1fr;min-height:auto}.hero__visual{order:2}}
```

## Rules
- One `<h1>` per page and it is the hero headline. Eyebrow is a `<p>`, not an h-tag.
- CTAs are `<a>` (navigation) or `<button>` (action) - never a clickable div. Primary first, max two.
- Hero image: explicit `width`/`height`, `fetchpriority="high"`, never `loading="lazy"`; WebP/AVIF <= 250 KB; meaningful `alt`
  (or `alt=""` if decorative). Background art in `aria-hidden` layers or CSS.
- `overflow: clip` (not hidden) on the hero so sticky headers elsewhere keep working.
- Phone: keep a visual (cropped or smaller), don't just delete it; CTA visible without scrolling at 390x844.
- Text on images: scrim (`linear-gradient`) + check contrast; never rely on the photo being dark.
- `<meta name="theme-color">` = hero/page background. Light-only sites: `<meta name="color-scheme" content="light">`.
