# Font swaps for hero headlines (all on Google Fonts)

Rule 1: a brand site keeps its brand fonts - read its CSS (`font-family`, `--font-*`) before choosing anything.
Rule 2: free choice -> one display face for the h1 (+ eyebrow optionally) and one text face for everything else.

## Swap table - "stop using X, try Y"
| Overused | Why it reads generic | Try instead (pick by mood) |
|---|---|---|
| Montserrat | wide geometric default of every template | **Outfit** (friendly geometric), **Sora** (tech), **Plus Jakarta Sans** (corporate warm), **Unbounded** (bold launch) |
| Poppins | round, toy-like at display sizes | **Manrope**, **Urbanist**, **Lexend** |
| Inter (as headline) | fine for UI, flat as a hero | **Inter Tight** (tighter), **Geist** (Vercel), **Schibsted Grotesk**, **Hanken Grotesk** |
| Roboto / Open Sans | system default feel | **DM Sans**, **Figtree**, **Onest** |
| Playfair Display | the default "luxury" serif | **Fraunces** (soft, variable), **Instrument Serif** (editorial), **DM Serif Display**, **Newsreader** |
| Bebas Neue | overused poster caps | **Anton** sparingly, **Big Shoulders Display**, **Archivo** (wide/condensed axes) |
| Lato / Raleway | 2015 web | **Bricolage Grotesque** (characterful), **Space Grotesk** (techy), **Syne** (art/creative) |

## Pairings that work
| Mood | Display (h1) | Text |
|---|---|---|
| Premium B2B / ERP | Plus Jakarta Sans 700-800 | Inter / DM Sans |
| Tech / AI | Sora 600 or Geist 600 | Geist / Inter |
| Editorial / luxury / wellness | Instrument Serif or Fraunces | Manrope / DM Sans |
| Bold launch | Unbounded 700 or Bricolage Grotesque 800 | Figtree |
| Creative / studio | Syne 700 | Hanken Grotesk |

## Loading (no flash, no layout shift)
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@600&family=Inter:wght@400;500&display=swap" rel="stylesheet">
```
Request only the weights used. Give the h1 a fallback with similar metrics (`font-family: Sora, "Segoe UI", system-ui, sans-serif`).
Display faces at 5rem need negative tracking (-.02 to -.04em); serifs often need none.
