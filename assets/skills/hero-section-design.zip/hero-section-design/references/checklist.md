# Hero checklist (Vercel Web Interface Guidelines, hero subset) + screenshot review

Source: github.com/vercel-labs/web-interface-guidelines (checked 2026-10-16). `[auto]` = hero_check.py tests it.

## Automated - errors (gate = 0)
- [auto] Exactly one `<h1>`, inside the hero.
- [auto] No horizontal page overflow at any width (scrollWidth > clientWidth).
- [auto] No hero text spilling out of its parent box or clipped (scrollWidth/Height > client + 2px).
- [auto] Hero `<img>` has width + height attributes (reserve space, no CLS) and is not `loading="lazy"`.
- [auto] Primary CTA exists (`a`/`button` in hero) and is >= 44 px tall on phone.
- [auto] Text contrast (WCAG ratio on the computed background): h1 >= 3:1, sub/CTA label >= 4.5:1. Skipped (warning)
  when text sits on an image/gradient - then check the PNG by eye.
- [auto] Reduced motion: every hero text element is visible (opacity > .9) 600 ms after load with reduce on.
- [auto] All hero text visible 2.5 s after load with motion on (nothing stuck hidden).
- [auto] No JS console errors / failed requests for the page.
- [auto] Keyboard: first Tab reaches a visible focus ring (outline or box-shadow changes).

## Automated - warnings
- h1 longer than 12 words / wider than ~16ch per line on desktop; sub-line longer than 3 lines on desktop.
- More than 2 CTAs; more than 2 font families in the hero; CTA below the fold at 1366x768-equivalent (desktop shot).
- Headline font is Montserrat / Poppins / Roboto / Open Sans (see fonts.md - fine if it is the brand font).
- Animations on non-composited properties (checked via getAnimations(): only transform/opacity/filter allowed).

## Manual (Vercel rules the script can't judge)
- Every element aligns with something on purpose; tidy rag, no orphan word on the h1's last line.
- Curly quotes, real ellipsis, non-breaking space in "Odoo&nbsp;17", units and names.
- Hover/active/focus states have MORE contrast than rest.
- Shadows: two layers; borders/shadows tinted to the background hue; no banding on dark fades.
- Animation only where it clarifies or adds deliberate delight; motion starts where the object "physically" comes from.
- Labels clear and specific, verb-first ("Book a free consult", not "Submit" / "Learn more").

## Screenshot review questions (answer for each PNG)
1. Squint test: what do you see first? It must be the headline or the visual - then the CTA.
2. Does the primary CTA win over everything else in colour/weight? Is there only one accent?
3. Phone: headline <= 4 lines, CTA above the fold, visual still present, nothing crammed to the edge (>= 16 px gutter).
4. Tablet (834): no awkward half-split - either a real two-column or a clean stack.
5. Does it match the brief's archetype and dials? Would it pass the anti-slop list in taste.md?
6. Reduced-motion shot: identical layout, all content visible.
7. Thumbnail + blur test (desktop PNG at 480 px wide, then blurred:
   `python ~/.claude/skills/technext-social-posts/scripts/squint.py <shots>/desktop.png --w 480 --out <shots>/squint.jpg`).
   In 3 seconds write two sentences: "it looks like a ___ site from ___" and "the first thing I see is ___". A
   recognisable template ("2019 SaaS starter") or decoration first = back to Pass 1. Blurred, there is ONE hero shape.
8. Brand-swap test: put a different company's name and logo on it in your head. If the hero still stands unchanged, it
   is generic - the visual must carry something only this offer has (the real Odoo screen of this process, the real
   venue/person, the actual document). Not for exact rebuilds of a given reference.
9. Left edges: count the distinct left x-positions of headline, sub, CTA row and proof. An ordered hero uses 2-3; more
   than that = name the blocks that are off and align them.
10. New heroes and redesigns (not "fix this"): one fresh-eyes subagent with no build history gets ONLY the desktop +
    phone PNGs, the 4-line brief, the archetype/dials line and the hard rules (light only, no icon tiles, title <= 3
    rows, brand fonts) - never the HTML or your reasons. It returns: veto (unreadable text at real size, placeholder-
    looking visual, brand-swap passes, no clear CTA in 3 s), max 5 problems biggest first as `where: seen -> fixed`,
    `REDO: <block>` first if the skeleton is the default template, and a `Keep:` line. Fix REDO first, turn vague notes
    into numbers (px, weight, size), reject notes that break brand/owner rules with a one-line reason, max two rounds.
