# Motion recipes (motion.dev, vanilla JS, no bundler)

Pinned UMD build (exposes global `Motion`; 12.23.12 verified 2026-10-16 to export animate, stagger, inView, scroll, spring):
```html
<script src="https://cdn.jsdelivr.net/npm/motion@12.23.12/dist/motion.js" defer></script>
```
Don't use `@latest` - pin. Bump only after testing.

## 1. Staggered entrance (the default)
```html
<section class="hero" id="hero">
  <p class="eyebrow" data-in>...</p>
  <h1 data-in>...</h1>
  <p class="sub" data-in>...</p>
  <div class="ctas" data-in>...</div>
  <figure class="visual" data-in-visual>...</figure>
</section>
<style>
  /* start states only when JS is running AND motion is allowed */
  .js-anim [data-in] { opacity: 0; transform: translateY(18px); }
  .js-anim [data-in-visual] { opacity: 0; transform: translateY(40px) scale(.97); }
</style>
<script defer>
addEventListener('DOMContentLoaded', () => {
  if (!window.Motion || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const { animate, stagger } = Motion;
  document.documentElement.classList.add('js-anim');
  animate('[data-in]', { opacity: 1, transform: 'translateY(0)' },
          { delay: stagger(0.08), duration: 0.6, ease: [0.22, 1, 0.36, 1] });
  animate('[data-in-visual]', { opacity: 1, transform: 'translateY(0) scale(1)' },
          { delay: 0.3, type: 'spring', bounce: 0.15, duration: 0.9 });
});
</script>
```
Safety: if Motion fails to load, `js-anim` is never added, so nothing stays hidden.
Headline must start moving within 150 ms; whole entrance done by ~1.2 s.

## 2. Headline word reveal (mask)
Wrap words: `<span class="w"><span>word</span></span>` with `.w{display:inline-block;overflow:clip}`; animate the inner
spans from `translateY(100%)` with `stagger(0.04)`. Keep real text in the h1 (screen readers read it once) - don't split
into letters with aria-label hacks.

## 3. Ambient loop (one, in the background)
```js
animate('.glow', { transform: ['translate(-4%,0) scale(1)', 'translate(4%,-3%) scale(1.08)'] },
        { duration: 8, repeat: Infinity, repeatType: 'mirror', ease: 'easeInOut' });
```
Max one loop behind content. Pause it off-screen with `inView`.

## 4. Scroll-linked visual tilt (MOTION dial >= 6)
```js
const { scroll, animate } = Motion;
scroll(animate('.visual', { transform: ['perspective(1200px) rotateX(14deg)', 'perspective(1200px) rotateX(0deg)'] }),
       { target: document.querySelector('.hero'), offset: ['start start', 'end start'] });
```

## 5. Pointer parallax (desktop only, MOTION >= 7)
Gate with `matchMedia('(hover: hover) and (pointer: fine)')`. Move layers <= 12 px, spring-smoothed; never move text.

## Rules (Vercel guidelines + Emil Kowalski)
- Only `transform`, `opacity` (and a small `filter: blur(<=8px)` on entrance). Never width/height/top/left/margin.
- Ease-out for entrances, ease-in-out for loops; no linear except progress. No bounce > 0.25 on business sites.
- Anything that moves can be interrupted; nothing blocks clicking the CTA.
- Reduced motion: return early (content already visible) - verified by hero_check.py's reduced-motion shot.
- CSS-only is fine for simple fades (`@keyframes` + `animation-delay`) when M <= 3 - no library needed.
