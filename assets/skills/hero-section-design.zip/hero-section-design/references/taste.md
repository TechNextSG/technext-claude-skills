# Taste references - hero archetypes, dials, anti-slop

## The three dials (idea from Leonxlnx/taste-skill)
| Dial | 1-3 | 4-6 | 7-10 |
|---|---|---|---|
| VARIANCE | centred stack, symmetric | split 55/45, offset visual | broken grid, overlapping layers, oversize type bleeding off the edge |
| MOTION | hover states only | staggered entrance + 1 ambient loop | scroll-linked scene, pointer parallax, choreographed sequence |
| DENSITY | one line + CTA, huge whitespace | headline, sub, 2 CTAs, proof row | product UI, stats, logos, tabs above the fold |

B2B / Odoo / services usually sit around V5 M4 D5. Luxury / wellness / events: V4 M3 D2. Product launch / AI: V7 M7 D5.

## Archetypes
| # | Archetype | Looks like | Good for | Real references to study |
|---|---|---|---|---|
| A1 | Editorial statement | giant serif/grotesk headline, tiny sub, lots of air, one thin rule | agencies, premium services | Pentagram, Locomotive, Stripe Press |
| A2 | Split promise + product | text left, real screenshot right tilted 6-12deg on a soft glow | SaaS, Odoo apps | Linear, Attio, Notion |
| A3 | Product stage | centred headline, big UI screenshot rising from below the fold | software, dashboards | Vercel, Raycast, Framer |
| A4 | Full-bleed photo/video | edge-to-edge imagery, text on a scrim, short line | hospitality, events, travel, wellness | Aman, Airbnb Luxe, Apple event pages |
| A5 | Bento hero | headline + 3-6 tiles each proving one thing | multi-service companies | Apple feature pages, Arc |
| A6 | Character / mascot scene | illustrated or 3D figure acting out the promise | brands with a mascot (Nexi) | Duolingo, Mailchimp (old), Headspace |
| A7 | Kinetic type | words cycle / mask-reveal / scale on scroll, little else | launches, bold brands | Basement Studio, Resend |
| A8 | Interactive object | one 3D or canvas object the pointer can move | AI, tech, hardware | Spline community, Stripe globe |
| A9 | Number-led | one huge stat as the headline ("47% faster close") with source | results-driven offers | Ramp, Mercury |
| A10 | Before / after | the messy way vs the clean way side by side or as a slider | process / ERP / migration | Superhuman, Cron |
| A11 | Collage / scrapbook | cut-out photos, stickers, handwritten notes, layered | creators, community, education | Figma Config, Gumroad |
| A12 | Quiet form | headline + inline input/CTA as the hero itself | lead gen, waitlists | Loom, Cal.com |

Pick by the promise, not by what was used last. Across one site, don't repeat the same archetype on every page hero.

## Borrow, don't copy
Write "from X I borrow <one device>": the tilt, the glow, the grain, the type scale, the scrim, the tile rhythm.
Never copy a layout 1:1, a competitor's copy or their assets.

## Anti-slop list (a hero with any of these fails review)
- Purple-to-blue gradient blob background with no reason; generic "glassmorphism" cards floating for nothing.
- Headline "Unlock / Elevate / Supercharge / Revolutionize your ..." or "The future of X". Say the concrete promise.
- Centred everything + three identical feature cards directly under it (the default template look).
- Emoji as icons; stock "people pointing at laptop" photos; fake UI with lorem/placeholder numbers.
- More than 2 typefaces, more than 1 accent colour, more than 2 CTAs.
- Gradient text on the whole headline (one highlighted word max).
- Hero taller than the screen with the CTA below the fold on a 1366x768 laptop.
- Motion that bounces every element, loops forever in the foreground, or delays the headline > 400 ms.
- Text over a busy image without a scrim/contrast check.
