---
name: hero-section-design
description: Design, redesign, critique or polish the HERO SECTION of a website or landing page (the first screen - headline, sub-line, CTA, hero visual, background, entrance motion) so it looks premium instead of AI-generic. Works in five passes - pick taste references (an archetype + three dials), swap generic fonts, build in plain HTML/CSS, add Motion (motion.dev, vanilla JS, no bundler) entrance animation, then a Vercel Web Interface Guidelines check and a headless-Chrome screenshot self-review at desktop/tablet/phone + reduced-motion, fixing until scripts/hero_check.py reports 0 errors. Use whenever the user asks for a hero, hero section, above-the-fold, first screen, banner section, landing-page top, "make the hero look better / less generic / more premium", or hero animation - on technext.asia, a client site, or any HTML page - even if they don't say "skill".
---

# Hero section design

Why AI heroes look generic: not bad code - **no taste references, no rules, and nobody looks at the result.**
This skill fixes all three. (Sources: Lindsay.ai's 5-plugin reel - Taste Skill, Vercel Web Interface Guidelines,
Playwright screenshots; Felix Bravo - Motion.dev, 21st.dev; "Stop using Montserrat" font swaps. Owner asked for it 2026-10-16.)

Work the five passes in order. Do not skip pass 5 - a hero is not done until you have looked at it.

## Pipeline
1. **Brief and taste.** Four-line brief, one archetype from taste.md, three dials, 2-3 named references.
2. **Type and colour.** Brand fonts kept; otherwise a swap from fonts.md, one accent only on the CTA.
3. **Build.** Plain HTML/CSS from build.md: one h1, real links, sized eager hero image, 44 px CTAs.
4. **Motion.** Motion 12 staggered entrance, transform/opacity only, reduced motion respected.
5. **Check and look.** hero_check.py to 0 errors, then read every screenshot and fix what the eye finds.

Worked example: `examples/a2-odoo-split/` (A2, V6 M5 D4) passes with 0 errors / 0 warnings. `examples/_bad-hero-test.html`
is the gate's self-test and must FAIL (20 errors) - re-run both after editing the script.

## Pass 1 - Brief + taste references (before any code)
1. Write a 4-line brief: **who** lands here, the **one promise** (headline), the **one action** (primary CTA), the
   **proof** (one fact, logo row, number, screenshot). If you can't fill a line, ask or read the site - never invent facts.
2. Open [references/taste.md](references/taste.md). Pick ONE archetype (A1-A12) that suits the promise, and set the
   three dials (1-10): **VARIANCE** (centred -> asymmetric/broken grid), **MOTION** (static -> choreographed),
   **DENSITY** (airy luxury -> dense product UI). Write them down: `A4 Product stage - V6 M5 D4`.
3. Name 2-3 real-world references in that archetype (from taste.md's list or ones the user gave) and the ONE thing you are
   borrowing from each (e.g. "Linear: dark product screenshot tilting in on a glow"). Borrow ideas, never copy layouts.
4. Check the anti-slop list in taste.md - your plan must not trip any of it.

## Pass 2 - Type + colour
- Fonts: [references/fonts.md](references/fonts.md). Brand sites keep their brand fonts (technext.asia, HB, BHD, TRE,
  clients - read the site's CSS first). Free choice -> never default to Montserrat / Inter / Poppins / Roboto for the
  headline; use the swap table and one pairing.
- Headline: 1 idea, <= 9 words, sentence case, `text-wrap: balance`, size with `clamp()` (e.g. `clamp(2.6rem, 6vw, 5.5rem)`),
  line-height .95-1.05, tight tracking (-.02 to -.04em) at large sizes. Sub-line <= 2 lines on desktop, `text-wrap: pretty`.
- Colour: one dominant, one accent used ONLY on the CTA + one highlight. Tint shadows/borders toward the background hue;
  shadows = two layers (ambient + direct). Light-only for TechNext and clients (owner: no dark mode) unless asked.

## Pass 3 - Build (plain HTML/CSS, no framework needed)
Skeleton and rules in [references/build.md](references/build.md): semantic `<header>`/`<section>`, one `<h1>`, real `<a>`
CTAs, hero image with width/height + `fetchpriority="high"` (never lazy), decorative layers `aria-hidden`, `min-height:
min(100svh, 920px)`, safe-area padding, CTA >= 44 px tall, visible `:focus-visible` ring. Need a component idea? Look at
21st.dev "hero" category for layout inspiration only (React code - port the idea to plain HTML).

## Pass 4 - Motion (optional by the MOTION dial)
Recipes in [references/motion.md](references/motion.md) - Motion 12 UMD global `Motion` from jsDelivr, pinned version.
- Entrance: eyebrow -> headline lines -> sub -> CTAs -> visual, `stagger(0.08)`, spring or ease-out, total <= 1.2 s.
- Only `transform` / `opacity` / `filter: blur` (small). No layout properties.
- Content must be visible WITHOUT JS (start states set by a `.js-anim` class added in script, never in plain CSS).
- `prefers-reduced-motion: reduce` -> no movement, at most a fade. Looping visuals = `<video autoplay muted loop
  playsinline>` with a poster, gated on reduced motion.

## Pass 5 - Vercel check + screenshot self-review (the gate)
```
python ~/.claude/skills/hero-section-design/scripts/hero_check.py <file.html | http(s)://url> [--out DIR] [--selector "#hero"]
```
It renders desktop 1440x900, tablet 834x1112, phone 390x844 and phone with reduced motion, saves PNGs, and runs the
automated checks from [references/checklist.md](references/checklist.md) (one h1, CTA size, image dimensions, lazy hero
image, horizontal overflow, text overflowing its box, headline width, contrast of h1/sub/CTA, reduced-motion visibility,
focus ring, console errors). **Gate: 0 errors.** Warnings need a reason.

Then LOOK at every PNG (Read tool) and answer the review questions in checklist.md ("squint test", where the eye lands
first, does the CTA win, does phone keep the visual, any orphan words, does it match the brief's archetype). Fix and
re-run until clean. Send the desktop + phone PNG to the user (SendUserFile) with the folder path.

## Delivery rules (TechNext context)
- technext.asia / client sites: follow that site's own rules and memory (push live, verify live URL, apply to all pages
  if the hero is shared, client isolation, no pricing, Odoo never "free"). This skill only designs the hero.
- Keep the approved composition when the user says "fix this" - change only the flagged fault.

## Last step: update the local repo + page
Run `python ~/ClaudeWork/technext-claude-skills/tools/build_skills.py` (add `--push` only once the owner has said skill
pushes may resume).
