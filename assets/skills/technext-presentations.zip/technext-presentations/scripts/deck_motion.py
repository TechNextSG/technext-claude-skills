# -*- coding: utf-8 -*-
"""Motion review for a deck: film strips of each slide's entrance, seeked frame by frame (motionmaxxing-style "look").

For every slide it arrives from the previous one (Deck.go), freezes every CSS transition/animation on the page with the
Web Animations API and seeks them to fixed times, so each frame is exact even on a slow machine. JS-driven motion
(orbits, counters, ctx.tween) keeps running in real time and is not seeked. It also prints, per slide, when the
entrance is finished ("built by", the latest transition end) and how many things move.

    python scripts/deck_motion.py company-profile [--slides 1,3,6] [--times 0,80,160,...] [--base http://127.0.0.1:3970/]

Writes ~/ClaudeWork/qa/decks/<deck>-motion.jpg (one strip per slide). LOOK at it: every strip should show things
arriving by moving, landing decelerated, and a finished frame by about 1.2 s.
"""
import argparse, io, pathlib, sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from _cdp import serve, Chrome  # noqa: E402
from PIL import Image, ImageDraw, ImageFont  # noqa: E402

OUT = pathlib.Path.home() / "ClaudeWork/qa/decks"
TIMES = [0, 60, 130, 220, 340, 500, 700, 950, 1300]

FREEZE = """(function(t){
  var a = document.getAnimations(), end = 0;
  a.forEach(function(x){ try { x.pause(); var tm = x.effect.getComputedTiming(); end = Math.max(end, tm.endTime === Infinity ? 0 : tm.endTime); x.currentTime = Math.min(t, tm.endTime === Infinity ? t : tm.endTime); } catch(e){} });
  return JSON.stringify({n: a.length, end: Math.round(end)});
})(%d)"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--slides", help="1-based slide numbers, comma separated (default: all)")
    ap.add_argument("--times", help="ms, comma separated")
    ap.add_argument("--base")
    a = ap.parse_args()
    times = [int(x) for x in a.times.split(",")] if a.times else TIMES
    OUT.mkdir(parents=True, exist_ok=True)
    W, H = 384, 216
    try:
        font = ImageFont.truetype("arial.ttf", 15)
    except OSError:
        font = ImageFont.load_default()
    rows, report = [], []
    with serve(base=a.base) as base, Chrome(1600, 900) as c:
        c.open(base + a.deck + ".html?nc=motion", settle=1.5)
        total = int(c.ev("Deck.slides.length"))
        want = [int(x) for x in a.slides.split(",")] if a.slides else list(range(1, total + 1))
        for n in want:
            i = n - 1
            c.ev("Deck.go(%d, -1)" % max(0, i - 1)) if i else c.ev("Deck.go(1, -1)")
            c.sleep(1.4)
            c.ev("Deck.go(%d, 0)" % i)
            c.sleep(0.09)  # two frames: .is-in lands and the transitions exist
            frames, info = [], None
            for t in times:
                r = c.ev(FREEZE % t)
                info = info or r
                png = OUT / "_mx.png"
                c.shot(str(png))
                im = Image.open(png).convert("RGB").resize((W, H), Image.LANCZOS)
                d = ImageDraw.Draw(im)
                d.rectangle([0, 0, 64, 20], fill=(15, 35, 80))
                d.text((5, 2), "%d ms" % t, fill="white", font=font)
                frames.append(im)
            c.ev("document.getAnimations().forEach(function(x){try{x.finish()}catch(e){}})")
            title = c.ev("Deck.slides[%d].dataset.title || Deck.slides[%d].id" % (i, i))
            report.append((n, title, info))
            row = Image.new("RGB", (W * len(frames) + 220, H), (245, 244, 248))
            d = ImageDraw.Draw(row)
            d.text((10, 10), "%02d" % n, fill=(49, 103, 202), font=ImageFont.truetype("arial.ttf", 40) if font != ImageFont.load_default() else font)
            d.text((10, 64), str(title)[:26], fill=(31, 31, 61), font=font)
            d.text((10, 90), str(info), fill=(100, 100, 120), font=font)
            for k, f in enumerate(frames):
                row.paste(f, (220 + k * W, 0))
            rows.append(row)
    sheet = Image.new("RGB", (rows[0].width, sum(r.height + 6 for r in rows)), (255, 255, 255))
    y = 0
    for r in rows:
        sheet.paste(r, (0, y)); y += r.height + 6
    path = OUT / ("%s-motion.jpg" % a.deck)
    sheet.save(path, quality=86)
    (OUT / "_mx.png").unlink(missing_ok=True)
    for n, title, info in report:
        print("  %02d  %-34s %s" % (n, title, info))
    print("strips:", path)


if __name__ == "__main__":
    main()
