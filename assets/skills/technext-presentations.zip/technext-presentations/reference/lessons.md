# Lessons log

Add a dated entry after every presentation job, with the newest at the bottom and one bullet per lesson. Quote the user verbatim when they set a rule. When a lesson becomes a rule, add it to `content-rules.md`, `engine.md` or the SKILL.md Non-negotiables table.

## 2026-09-27/28 · First three decks and the launcher (f86021b)
- **User:** "create a powerpoint presentation html base on technext website branding… highly interactive and animated… different html file". The first decks were the company profile, the service showcase, and What is Odoo with a lead-to-cash walkthrough.
- **The engine was built once and shared:** a 1600x900 stage, builds, overview, notes, kiosk and print. Each deck has its own CSS and JS. Pages deploy via Actions, because the legacy Pages builder wedges.

## 2026-09-28 · Leaving a deck glitched (dda7122)
- Esc opened the overview, and in full screen the browser also uses Esc to exit, so the two fought. **Esc now only closes things.**
- Opening the overview, or going Home, flew every slide across the stage. **The stage now fades out, swaps, and fades back in** (`is-fading` + `no-anim`).
- Hover lifts on cards shook when the pointer rested on an edge. **No hover lifts.**

## 2026-09-28 · More decks: tiers, portfolio, showcase; phones; print (12bdd0f, cfe0f3e)
- **User:** "add more presentation". Added the ERP and Marketing tier lists, the Portfolio (from the Drive client folders, repos and sessions) and the Marketing Showcase (every live site and mockup).
- **User:** phones must auto-rotate. The whole deck turns 90° when held upright. Every position read had to go through `Deck.rect`/`Deck.point`, or drags and hovers missed by 90°.
- **User:** PDFs must show every slide finished. **Print never plays a slide**: `settleAll` paints every build and runs every `settle` hook. Six slides printed half-done until they got settle hooks: the engagement steps, the CRM board, the customisation answer, the integration counters, the tier finder and the plan builder. The overview reuses the same hooks.
- **Site captures:** keep the real viewport height and use `captureBeyondViewport`, because resizing to the page height stretched 100vh heroes. Skip intros, and seek paused poster-less videos.
- **Print ignores CSS `filter`,** so dark slides need the white logo PNG. `h0` dots vanish in PDF, so use `h.01`.

## 2026-09-28 · Share links and the launcher card row (79093a1, ff87a2a)
- **The need:** send one deck without the way to the others. Each deck builds as `s-<token>.html`: no Home button, `data-internal` links stripped, and the build exits if a leak remains.
- **User:** the card actions go on ONE row of small buttons (13px, 33px tall, nowrap). A size container hides the icons, then "loop", then padding as the card narrows.

## 2026-09-28 · Sales proposals: Hitachi Elevator Philippines (725c1fd, 017a416, 4ec5532)
- **User:** "create a sales proposal category base on client requirements… highly animated workflow, chart". It was built from the pre-discovery analysis, using only HEP's public facts. The pains are hypotheses and every demo is labelled sample data.
- **The user set the phases;** PH2 is "to confirm" because it depends on GERP. Inventory and AI were dropped. The Hitachi logo sits beside TechNext's (`data-cobrand`).
- **Chart gridlines drawn with `repeating-linear-gradient` printed as striped bars.** They are now real 1px elements (`.px-gl`).
- **SVG hover:** `Deck.lbox` is HTML-only and gives NaN on SVG, so use `PX.svgAt` (getScreenCTM).
- **The cover connector** started 70px below the labels and the Makati shaft touched the top edge. Measure after every layout change.

## 2026-09-28 · Odoo 20 everywhere (017a416)
- **User:** "technext presentation also need to be fully updated… mention about odoo 20". Added the "Odoo 20, in six changes" slide. The catalogue now says Field Service runs in Planning and VoIP is Phone, and the kickers say "odoo 20". Facts come only from the release notes.

## 2026-09-30 · Removals the user asked for (d5937c1, 65562c3, 3328e3a)
- **Portfolio:** the clients x services matrix is gone. Client lists are plain bullets with NO dates. The "Proposals, concepts and paused work" slide is gone.
- **Hitachi:** slide 3 lost the parts point and the Inventory and Purchase cards ("Five places…"). The parts slide and the "Five questions" slide were removed (16 → 14 slides).
- **After a removal:** re-sequence the entrance timings, reprint the PDF, recapture the hover thumbnail if its page number moved, and bump ASSET_V.

## 2026-09-30 · Office roles (4f6d41d)
- **Per Pia Cachola:** the Philippines (Taguig City) is the main development and consulting hub, and Vietnam (Ho Chi Minh City) is AI engineering. This touched the office cards, map labels, notes, the who-we-are lead, the engagement slide and the service showcase Build phase.
- **One fact, many places.** Grep every deck, note and README rule.

## 2026-09-30 · Tier decks to three tiers (afc611d)
- **User:** three tiers only. Starter folded into Essentials (ERP) and Launch (marketing). Enterprise and Brand are "customisation", and add-ons are the customisation layer.
- **Every price is TechNext's service fee.** Say so on the slide. The code follows the tier count.

## 2026-09-30 · Smooth on TVs, then a Display option (e7ed568, d5eed94)
- **At 4K the decks stuttered.** Causes: about 30 loops on hidden slides kept ticking; 90px blur glows; backdrop blur. Fixes: pause every animation off the current slide, use radial-gradient glows, drop backdrop blur, and promote scroll pictures to a GPU layer only on screen. The company profile at 4K with a 4x CPU throttle went from 63 to 121 fps.
- **The Display menu:** `T` cycles HDMI (full), Wi-Fi/casting (less motion) and Auto. **Any new decorative loop must join the `.is-tv` stop list.**

## 2026-10-02 · Present anywhere (7891853, c421adf)
- **An audit of real set-ups:** cable, casting, screen share, the TV's own browser, a Bluetooth clicker, no internet. It added:
  - the presenter view (`P`, BroadcastChannel sync);
  - clicker keys: B and `.` black, W and `,` white, F5 for full screen;
  - Wake Lock, and a hidden cursor;
  - `sw.js` offline copies (live https only);
  - self-hosted fonts;
  - `inset` spelled out for 2020–21 TV browsers.

## 2026-10-02 · Showcase refresh; the Odoo app series (9987823, 428c0c8)
- **Showcase:** five sites were recaptured after their redesigns. **User:** remove Blue Moon and Tri-Comp. The wall picks a column count so every row is full. Pictures carry `?v=`, so offline copies refresh. `sites_images.py` now merges, so a partial recapture keeps the rest.
- **A parallel session** built the Accounting, Sales and CRM decks with the impeccable and web-design-engineer skills. The structure is one live Odoo window held across seven cut slides (`data-group`). One sample company, Kestrel & Pine, runs through all three. Labels follow the 20.0 docs. DESIGN.md and PRODUCT.md came from that work.
- **A capture can open a hover menu** (HummingBeing's Services). Force dropdowns hidden while capturing.

## 2026-10-03 · TRE in Singapore's live domain (c428d9f)
- The Showcase and the Portfolio still showed the old test address after the site moved to `tre-in-singapore.com`. **When a client site changes its domain, grep the decks.**

## 2026-10-04 · This skill
- **User:** "check the skils in the presentation https://technextsg.github.io/technext-presentations/, later on i will edit all the presentation. make sure the capture the skills for this".
- **The skill captures** the engine, the build, the 11 decks, the content rules, the design system (condensed from the untracked DESIGN.md) and this history. Four tools came with it: `deck_check.py` (QA gate), `deck_pdf.py`, `thumbs.py` and `drive_sync.py`. The thumbnail and Drive scripts used to live only in an old scratchpad.
- **Baseline QA:** 0 errors and 16 warnings across 11 decks. The list is in `decks.md` ("Baseline QA"). `deck_check` first called an ellipsis a "cut", so it now reports `text-overflow: ellipsis` as "text truncated" by name. The checker was proven on planted defects (off-stage text, overlap, tiny text, a broken image), and `thumbs.py` reproduced the committed thumbnails (mean pixel difference under 1).
- **The gap to close in the next edit:** technext.asia added a fourth practice, Technology (IoT · Apps · Networks), on 2026-10-03. The decks still show three practices and "fourteen services".

## 2026-10-06 · JR-Tech Solution client deck (5d80e2e)
- **User:** "create Presentation JR Tech https://technextsg.github.io/technext-presentations/ use this material, question at the back", then attached `JRTech-Accounting-and-Billing-Questions.pdf`: "add this", "at the end of presentation". So "question at the back" meant the client's discovery questions as the last part of the deck, before the close. When a short instruction is ambiguous, wait a moment for the rest; this user often sends the material in a second message.
- **A 100 MB PDF** can't be read by the Read tool (limit 100 MB): extract text with `pymupdf` (`page.get_text()`) and render 48 dpi contact sheets of four pages to look at the design.
- **Make the material work, don't transcribe it:** each static slide got one interaction that proves its point (drag the cut-off into mid-month and it turns red; the migration lines travel the way they really move; a go / no-go gate that only goes green with five checks; the questions as live tick buttons with counters on the part-04 tiles and a copyable follow-up list).
- **`data-step` is the engine's build attribute.** A jump button marked `data-step="1"` would have become a hidden build. Jumps to a build use `data-go` + `data-at` (handled in `jrtech.js`).
- **Text beside a `<b>` inside a flex button splits into two columns** (the text node becomes its own flex item). Wrap the label in one `<span>`; caught on the contact sheet, not by `deck_check`.
- **Per-card vignettes align only if everything under them has a fixed height** (the benefit pill went to 52px). Check the bottoms of a card row on the sheet.
- **Hidden preview panes throttle requestAnimationFrame:** a `ctx.tween` or `ctx.count` checked from `javascript_tool` while the pane is hidden can read mid-way. Read the value again later, or rely on `deck_check` (headless, visible).
- **Clipboard:** `navigator.clipboard` can be refused (no focus, file:// Drive copies). Fall back to `execCommand('copy')`, then to a visible textarea with the text selected.
- **Build after printing:** the launcher's PDF button only appears if `pdf/<name>` exists at build time, so build once more after `deck_pdf.py`.

## 2026-10-06 · A video in the JR-Tech deck (9b93fbd)
- **User:** "add this video after page 15" (a WhatsApp MP4, 3:21, narrated: part 3 of TechNext's Odoo 20 accounting video series for JR-Tech). Page 15 was the risk register in both the source PDF and the deck, so it became slide 16.
- **Read the video before placing it:** `ffprobe` (size, codec), a 14-frame contact sheet, `faster-whisper` on 40 s to learn it is narrated (so it plays with sound), and caption-badge crops at 1 fps to find the chapter times.
- **The engine's offline copies could not seek video:** `sw.js` cached everything and had no answer for `Range` requests. It now cuts 206 slices from the saved file. Tested live: offline, with the network cut, chapters jump and play.
- **Local tests mislead for video:** SimpleHTTP ignores ranges (seeks snap to 0), and a hidden preview pane or a background CDP tab defers playback. Test on the live site, each page in its own window.
- **Presenter view needed its own sync** for media: the deck's BroadcastChannel only moves slides.

## 2026-10-06 · The video zooms and comes back (d2a0ab2, afec470)
- **User:** "make the video can zoom properly and exit seemless bck to presentation". The browser's video full screen was the problem: leaving it also left the deck's full screen.
- **Built:** the deck's own zoom (FLIP from the slide to the whole stage; document full screen only if needed; Esc held by the Keyboard Lock API so it only shrinks the video) and a TechNext control bar, because `controlslist="nofullscreen"` still drew a greyed full-screen button that did nothing.
- **Tested with real input events** in headless Chrome (`Input.dispatchMouseEvent` / `dispatchKeyEvent`, so full screen counts as a user gesture): zoom by button, Z and double-click; back by Esc, Z, double-click and the Back button; deck already in full screen stays there; PageDown comes back and moves on; presenter view mirrors the zoom. Click a faded control without moving the mouse first and the click goes to the video: move the mouse in tests.
- **A real bug the zoom work surfaced:** chapter jumps failed with a media error once the offline copy had saved the video (pieces from the network and from the cache in one stream). `sw.js` is now network-first for ranges, and the player reloads and resumes after any media error. Test chapter jumps both before and after the background save.
- **The Bash tool halves backslashes** inside heredocs: a `split('\n')` in a JS string broke a test. Write such scripts with the Write tool.

## 2026-10-06 · Faster-hiding video controls (f12a5b9)
- **User:** "when not active, hide floating ui in the video much faster". Idle 2.6 s -> 1.1 s, fade out 0.2 s, instant on mouseleave; kept while hovered, seeking or paused; 2.6 s after a touch tap. Measured with real mouse events (`qa/jrtech-deck/idle_test.py`) locally and live.

## 2026-10-06 · Chapters that land properly; question 1.2 (34ba43a)
- **User (screenshot of the chapter list):** "some of this not properly jump to selected video, fix this". Cause 1: the chapter times came from the caption badge changing, but the narration starts 1-3 s earlier (Reminders: first word 112.6 s, chapter was 114 s, so it opened mid-sentence). Fixed from word timestamps. Cause 2: the media-error recovery resumed at the position before the click; it now resumes at the jump's target. Cause 3 (likely in the user's browser): an older offline worker still mixing sources; deck.js now asks for the newest `sw.js` on every visit.
- **Proof:** `qa/jrtech-deck/live_chapters.py` clicks every chapter in a mixed order before and after the offline save, checks time, playing and the lit row, then fakes a media error mid-jump: 0 failures.
- **User:** question 1.2 reworded ("How many companies or databases do you keep in SQL Account today, and should they run as separate companies or as branches of one company in Odoo?"). Engine change → `deck_check` on all 12 decks: 0 errors, the 16 known baseline warnings.

## 2026-10-06 · BHD Asia · HummingBeing implementation scope (ea36df5)
- **User:** "create a technext presentation here's the scope." with `BHDAsia-Implementation-Scope.pdf`, an internal "for team review" document. Built an 18-slide client-facing deck (share `s-4sg4p5j`, ASSET_V 24) and left the internal remarks out (who asked how often, who resents what, a staff name, a dormant entity, a price rise). Reported what was left out and offered a team-only version.
- **The Read tool returned no PDF content** (no pdftoppm): `pypdf` text works, but print with `PYTHONIOENCODING=utf-8` or the console codepage crashes on the minus sign.
- **Port 3970 was held by another chat's preview**: added `technext-decks-2` on 3988 to the Marketing launch.json rather than stopping theirs.
- **`.illus` overlapped the slide number** on every workflow slide (deck.css puts it at bottom 30). `deck_check` passed with 0 warnings; caught on the shots. Lift it to bottom 66–70.
- **6- and 7-step slides left the lower third empty** next to a 9-step slide: fixed-height body + `space-between` steps + the scene card stretched with its content centred.
- **TRE™ applies to speaker notes too**: a regex `\bTRE(?!™)\b` sweep found three bare "TRE" in notes.
- **Bash heredocs broke a Python patch** (quotes and backslashes): write patch scripts with the Write tool and run them.
- **Every control verified by script in the preview** (toggle, Play, slot, Approve, joins, accountant view, module light-up, switches, currency lock, open-item marks, copy fallback panel, slider) and the "contraindication" path by real clicks; `deck_check --shots` and `--phone`: 0 errors, 0 warnings.

## 2026-10-06 · BHD Asia scope, revision 2 (a3815b7)
- **User:** "update the scope", with the same PDF re-exported (20.5 KB, 16:56). Diffed it against the first version's text: three changes (workflow 2 rebuilt as "screened once, then frictionless" with a "why before payment" paragraph; currency settled on SGD; back-office access decided as full admin). The rest was identical, and the report says so.
- **The "why" became its own slide** (07 frontdoor) rather than a crowded callout: two lanes, the order we avoid (pay, wait, decline, refund) and the one we build.
- **Settled decisions move, they don't vanish:** the currency slide changed from a choose-and-lock demo to "settled" with a pricelist switch; the open list went from 8 to 7 plus a "Settled on 6 October" card; the decided slide got a sixth card.
- **Chips in a 590px column wrap at 13.5px:** a returning-client chain of four chips only fitted after shortening the long label and moving the full question into the caption.
- **Still kept the back-office person unnamed** in the deck (the PDF names him); his access decision is in the notes for the presenter.

## 2026-10-06 · BHD Asia logo fix (748451e, b105345)
- **User:** "fix the logo." The BHD mark has navy H-bars and transparent gaps between its letters: on navy slides both vanished and it read as "1D". It was also 19px tall in the slide header (deck.css `.s-co` is sized for wide wordmarks such as Hitachi's).
- **Fix:** dark slides get the official mark untouched on a white rounded tile (`bhdasia-white.png`); never recolour a client's logo. The header uses `.s-co{height:34px}` (40px for the tile) in the deck's own CSS. The closing lockup needed `.hx-lock--sm .ec-bhd--sm` to beat proposal.css's `.hx-lock--sm .hx-co{height:28px}`.
- **`assets/img/clients/*.png` is not versioned by the build** (only sites and thumbs get `?v=`): when a client logo changes under the same name, add `?v={{v}}` to its `src` and to `data-cobrand`, or browsers and offline copies keep the old file.
- **Check every client logo on BOTH a light and a dark slide** at its real size before shipping; the QA sheet is too small to show it, so crop the chrome and lockups at 2x.

## 2026-10-06 · BHD Asia workflow 3 questionnaire (9b00cb4)
- **User:** "there's no survey between 4 and 5?", then a screenshot of the WORKFLOW 2 slide with "fix this part: 4. review and approve 5. questionnaire (survey module) 6. meeting lands on you[r calendar]". The wording was workflow 3's (its steps 4 and 5), and putting it on workflow 2 would have removed payment and contradicted the "front door" slide. Asked with two previewed options; the user chose workflow 3. When a screenshot and the words point at different slides, ask with previews rather than guess.
- **The deck now differs from the scope PDF on purpose** (the questionnaire step in workflow 3 is the user's addition). Note such edits in decks.md so a later "update the scope" doesn't silently undo them.

## 2026-10-07 · HST Medical website review deck (66b8e24)
- **User:** "in technext presentation, create deck for hst. we already have website, webook, research and stuff. add this as reference. build a good presentation. properly showcase the logo", with a screenshot of Pia's agenda (1 website & product catalogue: review feedback, discuss revisions; 2 AI for the website) and her question to Sky: "for our initial scope for HST (purely website), okay to do 1500-3000 USD pricing?". "webook" = the flip-book.
- **Find the client's material first:** `00. Client Folder\28. HST Medical Website (prototype)`, `30. … Product Sheets (flipbook)`, `31. … Brand Strategy`, plus `~/ClaudeWork/hst-wp` (the WordPress build with the performance report, Theme Check and editor guide) and `Downloads\hstwebRFP.docx` (the RFP). An Explore agent summarised the three Drive folders while the engine docs were read.
- **"Properly showcase the logo":** the official colour lock-up (with "Kowa Subsidiary") on a big white card on the cover that builds itself (four clip-path layers of ONE image: the roundel spins in, HST and MEDICAL wipe, the Kowa line rises, a masked sheen); a no-tagline crop for the 36px header (the Kowa line sat right of the roundel, so it was cleared by region, nothing recoloured); the same on a white tile for dark slides. Header crops checked on light and dark.
- **Real product answers, not invented ones:** the Ask HST slides use the prototype's actual replies, probed in headless Chrome through `window.HSTChat.reply()` (scratchpad `chatprobe.py`). The probe also found the gaps the AI slide shows (a Chinese question falls back to the help menu; a blood-thinner question shows the caution AND the product to buy). The "With AI" side is labelled illustrative and quotes only label statements.
- **Catalogue fixes marked on the real pages:** the flip-book repo's `book/words/NNN.json` holds word boxes in 1/10000 of the page, so each print issue (CATALOGUE-QA.md) is boxed exactly; a lens zooms on it.
- **Facts checked live on 7 Oct:** "HST = Higher, Stronger, Together", 1930 Heng Say Tong, 1994, Kowa from 29 May 2026 (hstmedical.com/about and the Kowa announcement). The live site uses ® on HST Medical, Heritage and Rheuma-Salve, not on Zoo-Vite. Awards wording and the 5.0 rating are unconfirmed by HST, so they stay off the brand slide.
- **The first shots caught:** a 3-line cover headline (h-xl + `text-wrap:balance` in a 720px column: keep cover headlines to about 20 characters a line), a seg pressed state with magenta text on blue (unreadable), a product card under the slide number, a 7-item list running into the footer, a price overflowing its card at 50px.
- **A shared preview pane is shared:** during scripted tests the deck jumped slides and question marks changed by themselves; event logging on a re-run showed nothing from the deck. Someone was clicking in the pane. Re-run a test before "fixing" such a bug.
- **Price on a public page:** the USD 1,500–3,000 range comes from Pia's question to Sky, not answered in the screenshot. It is on one slide (14) and its notes, and flagged in the report.

## 2026-10-07 · HST Medical deck, revision 2 (b3d77a7)
- **User:** "Redo last slides, change to explain why TechNext is the best company to implement: 1. We move fast, really really fast, we recognise time as money... 2. TechNext have an ERP implementation division... data migration, APIs, connectors and implementing an integrated solution 3. AI competency very high. Implementating futureproof technologies. ensure light theme only. Slide 5: we could build your brief, slide 6 we could propose ideas after understanding your direction (AI enabled, e-commerce store that converts, support branding strategy). Remove any mention of pricing in the any part of the slides. How we get there? We do and show rather than traditional way of wireframing. Garunteed satisfaction".
- **"Light theme only":** the cover, the AI-search slide and the close lost `.dark`. On a light cover/close the lockup needs the colour logos and a `var(--line)` divider, the agenda/piece buttons need light styles, and deck.css `.ct-links a` is white (built for navy): override it, or the email and site links vanish (caught on the shots).
- **"Remove any mention of pricing" was taken literally:** the price slide, quotation wording, "running cost", "quoted separately", AND HST's own product prices in the Ask HST / rules-vs-AI demos and the JSON-LD excerpt. The "add 2 balms" conversation (all prices) was swapped for Ask HST's real store-finder answer. A regex sweep (`S\$\d|USD|quot(e|ation)|pric(e|ing)|fee|cost`) over the deck HTML + JS proved zero left, and the live share copy was grepped too.
- **Speed proven with the client's own timeline:** git first commits gave the dates (prototype 2 Oct, flip-book 5 Oct, brand pack 6 Oct; the WordPress build's report 2–3 Oct). The usual-vs-ours route shows no durations, only where the launch lands, so nothing is invented.
- **Why-TechNext slides use only approved company facts:** Odoo Ready Partner, 11+ enterprise clients, 10+ countries, four AI disciplines (the company profile's own names), HCMC = AI engineering. A 01/02/03 switcher (`.ky-nav`, `data-go`) ties the three reasons together.
- **"Satisfaction guaranteed"** is the user's own promise; worded as "we refine on the live test link until you are happy; nothing launches without your sign-off", no number of rounds.
- **The preview server from the morning had stopped** (new session): `deck_check --base http://127.0.0.1:3970/` failed with "Deck is not defined". Without `--base` the scripts serve the repo themselves.


## 2026-10-07 · Presenter scripts page (`presenter-guide.html`)
- User: "create another webpage and push online, webpage should be an internal sales guide for presenter. It should show exactly what to say for each slides. It should also contain additional add on jokes to entertain" (JR-Tech + HST Medical).
- Built as a HAND-WRITTEN root file (`presenter-guide.html`, not under `_src/decks`, not in `DECKS`, so the launcher doesn't list it; `noindex`). The build never touches it (it only writes `_src/decks/*` and retires `s-*.html`). Data lives in the `DECKS` object in its own script: per slide `t, who, min, say[], do[], watch?, joke, next`. Slide order must match the deck: a new or moved slide in either deck means updating this page too.
- Scripts are rewritten from each slide's speaker notes in spoken first person; "Never say" panels repeat the content rules (HST: no pricing at all, AI answers illustrative/sample; JR: SST+MyInvois inside Accounting, sample data). Jokes are clean, self-deprecating, never about the client's staff, money or anyone's health; HST slide 10 (the 995 emergency answer) carries a "no jokes after this click" warning.
- Rehearse mode loads the live deck in an iframe and moves it by setting the iframe's `location.hash` (deck.js listens to `hashchange`); timer per slide against `min`.
- Totals: JR-Tech 51 min, HST 42 min of scripted time.
- `git push` and the contents API both returned HTTP 500 for a while on 7 Oct (githubstatus said all operational): retried in a background loop rather than changing anything.

## 2026-10-08 · JR-Tech: Maintenance is not for customers' units (51898f4)
- **User:** "removal of this. Maintenance is not for external clients. It is for maintaining your own equipment that you use." Slide 04 (big idea) dropped the "Service maintains it / Preventive visits planned" step; the combi oven now goes through four apps (Sales, Inventory, Field Service, Accounting). Odoo Maintenance stays where it is about JR-Tech's own hire fleet (phase 2 card, the AI slide's rental units).

## 2026-10-08 · JR-Tech: no presenter names on the part dividers (78274bf)
- **User:** "remove the presentor name apply to related pages" then "this is jr tech only". The "Presents Jett & Phillip / AJ / Sky" chips came off slides 03, 09 and 18. The part-04 chip (`jd-who`, "28 questions · 0 answered") reuses the same class: a regex on `jd-who` removed it too and it had to be restored; match on the content, not the class. The team chips on the close and the speaker notes still name the team (not asked).

## 2026-10-11 · Launcher redesign: find a deck (3c22368, ASSET_V 32)
- User: "revise the design of this. make this the design will be properly arrange all additional presentation / filtering." The launcher had grown to 14 decks in five stacked groups with a big hero and no way to filter.
- Built: a sticky find bar (search, group tabs with counts, Topic and Length chips, Sort, grid/list), filter state in the hash, a compact hero with totals, and a folded "How to present" section. "Sales proposals" became "Client decks" (it holds the HST review too).
- **Arrangement:** groups of 2 in a 3-column grid left an empty column on every small group. Now groups flow on a 4-column grid, each spanning its deck count, so small groups pair up. A new deck needs `tags=` and a group that exists in `GROUPS`, or the build fails with a KeyError.
- Headless Chrome `--window-size=390` doesn't give a real 390px viewport (the page looked clipped). Check phone width in the browser pane with the mobile preset and measure `scrollWidth` instead.
- The in-app pane screenshot timed out while the window was in the background. Use headless shots (`~/ClaudeWork/qa/ix-shots.py`, which deletes its profile) to check the layout.
- **Follow-up (6c584fe, ASSET_V 33):** user: "make it smoother, it's glitching when selecting a deck". Cause: the card description un-clamped on hover, so the card grew and the whole grid row jumped; the thumbnail also zoomed and the lazy hover slide popped in late. Fix: no size change on hover (rule: **a hover must never change a card's size**), no zoom, preload `.ix-thumb-2` after load, and filter/sort/view changes run inside `document.startViewTransition` (each card has `view-transition-name: ix-c<i>`; the bar is `ix-bar`; reduced motion = instant).
- **Follow-up (7c22c25, ASSET_V 34):** user: "make this html smoother, its having a framedrop". Measured with `~/ClaudeWork/tn-perf-tools/ixperf.py` (rAF intervals during scroll, a hover sweep and 9 filter clicks; `CPU=4` throttles; named CSS ablations). The View Transitions added in 6c584fe cost a 50-83 ms frame per filter click (it snapshots every card); big 50-60px-blur shadows added scroll/hover blips. Fix: FLIP with WAAPI on on-screen cards only (transform/opacity), small shadows, hover changes the border only, `.ix-thumb-2` on its own layer, `content-visibility:auto` on the guide. Result at 4x CPU: filter 0% dropped (was 3.6%, max 83 ms). **Rules: no View Transitions on the launcher; no animated or 50px+ shadows; never `decoding="async"` on the visible thumbnail (it painted blank first).**

## 2026-10-12 · Industry case study: F&B (259ce67, ASSET_V 35)
- **User:** "create case study presentation, make it detailed i limited slides. complicated problem of client, how solve problem using odoo", then mid-build "do specific industry, focus first in fnb". Chosen in the question: anonymised composite, 8 slides. "Named" was read as a named SAMPLE company (Saltfern Kitchens, web-searched 2026-10-12: no real business by that name), labelled "illustrative composite" on every slide.
- **New launcher group "Case studies"** (`GROUPS` key `cases`); later industries go there as `case-study-<industry>` with `assets/case-study.css|js` (prefix `fb-` for F&B; pick a new prefix per industry or generalise).
- **Shape that fits 8 slides:** cover, the client's tools (click each: knows / can't see / re-keyed), the complicated problem as a cascade on → with a live loss counter, four flows Before/With Odoo toggle, apps grouped by place, one step-played workflow, one calculator workflow, rollout phases + booking QR on the last slide (no separate close).
- **Shots caught:** the Odoo icon sat on top of the link label in the With Odoo state (deck_check can't see it; labels lift 30px in that mode); first layout left ~100px dead at the bottom of five slides: size rows to fill to ~800px.
- **No results figures for a composite:** outcomes are qualitative before → after pairs; durations left out ("depends on recipe and supplier data").

## 2026-10-12 · Seven more industry case studies (4d9cc91, 5c7349d, ASSET_V 36)
- **User** (screenshot of technext.asia's Industries grid): "add case study for all industry that technext listed on website, make sure they have different content ad different complicated problem." The eight site industries: Medical, Travel, Retail, Ecommerce, Construction, F&B, Manufacturing, Health & Wellness.
- **Built in parallel by 7 subagents** from one brief (`~/ClaudeWork/qa/case-study-brief.md`): each owns only `_src/decks/case-study-<slug>.html` + `assets/case-study-<slug>.css|js` with its own prefix (mdc- trv- rtl- ecm- cst- mfg- hw-). The lead registered all 7 in `DECKS` with placeholder text and ran one build FIRST (share tokens + placeholder sources), so agents could build and `deck_check` without touching build.py; the lead then filled desc/alt, README rows, thumbs HOVER and the launcher meta. F&B's script became `case-study-fnb.js` (case-study.css stays the shared base).
- **Variety rule in the brief worked:** max 2 F&B slide patterns per deck, own problem visual each (recall trace, FX/pax P&L, size x store heat-grid, 11.11 oversell sim, S-curve overrun, work-centre Gantt cascade, credit ledger + room grid).
- **Agents verified Odoo facts in docs/source** and wrote honest limits into notes (not an EMR / GDS; no native retention; no class-credit object, eWallet used; connectors sync at intervals; no "finite capacity" wording). One first-choice sample name (Corbelstone) was a real US firm and was replaced: always WebSearch sample names.
- **Commit `_src/share.json`** with new decks (it was missed in the first commit and needed a follow-up).

## 2026-10-13 · Combined case study: Retail & Ecommerce (4375901, ASSET_V 37)
- **User** (screenshot of the Case studies group): "Can we have a combined deck that covers both Retail and E-commerce? In APAC, retail and e-commerce operations now overlap. This would cover Odoo's strong selling points, POS, e-commerce, inventory, accounting and CRM run in one system." Built as a NEW deck (the two single decks stay), 9 slides, 20 min, one new sample company so the figures don't clash with Weftwood or Kelpmere.
- **Odoo 20 facts checked in the 20.0 docs** before writing: eCommerce Click & Collect (Website ‣ Settings; provider "Pick up in store"; Stores tab = warehouses; a location selector on the product page; Show Available Qty shows stock per warehouse; can't pick an out-of-stock store unless Continue selling; payment method "Pay on Site" enabled by default). Loyalty programmes can be limited per Website / Point of Sale (blank = all), so one card works in both. POS "Quotations/Orders" loads sales orders (docs page for 20.0 not found; 16.0 page + forum; flagged in notes as confirmed in discovery).
- **Shots caught:** a `grid-row` span without `grid-column` auto-placed the counters into column 1 (always pair them); `data-in` entrances override `transform`, so absolutely placed buttons must be positioned by top-left, never `translate(-50%,-50%)`; a "five records" headline beside counts that summed to 7 (renamed "five strangers", counts dropped); cover link lines pointing at the wrong app; dead bands at the bottom of slides 2, 7, 8 (stretch the cards).
- **ASSET_V bump rebuilds every deck** (all `?v=` change): stage the modified root `*.html` and `s-*.html` too, or the live decks keep old asset versions.

## 2026-10-14 · Motion kit from motionmaxxing; company profile first (b1c170c, ASSET_V 38)
- **User:** "IN TECHNEXT PRESENTATION, USE THIS SKILLS https://github.com/Tejashmakwana/motionmaxxing, START WITH COMPANY PROFILE.. IMPROVE THE ANIMATION AND PRESENTATION". Cloned to `~/ClaudeWork/ext/motionmaxxing` (read SKILL.md, references/motion.md, transitions.md; eases from runtime/motion.js).
- **motionmaxxing is a FILM skill.** Its "never ship" list bans deck furniture (kickers, headline blocks, tracked caps, counters), and those are house rules here. What was taken is the measured CRAFT: the 12 eases, ~0.4 s median moves, opacity as a 0.2 s helper, land decelerates / leave accelerates, 1-3 frame uneven sibling gaps, words at speech rhythm, arrival from oversize, one visible spring, camera push on proof, cut on motion. Content and layout rules stay.
- **Built as an opt-in kit**, not an engine change: `assets/motion.css|js` + `<body data-motion="mx">`. Other decks are byte-identical in behaviour until they opt in.
- **Use the individual `scale` / `translate` CSS properties** for entrance motion on anything a script moves every frame (FX.orbit, FX.along, parallax set `transform` inline): they compose without fighting.
- **Word masks: `clip-path`, never `overflow:hidden`** on the inline-block word: overflow moves an inline-block's baseline to its bottom edge (looked like a marker shift; compared with the live deck before blaming the marker).
- **Review with seeked strips, not screenshots:** a background preview pane throttles rAF, so `.is-in` never lands and the shot shows a half-faded slide. New `scripts/deck_motion.py` pauses every CSS transition with the Web Animations API and seeks fixed times. The first strip showed the push still read as a cross-fade (accelExit barely moves before the fade); fixed by a 0.2 s gentle-in exit and an incoming slide visible from frame 0.
- **`Deck.on(id)` REPLACES hooks**: a second `Deck.on('offices', {settle})` would have wiped the first. Fold extra hooks into the one call.
- **The Bash heredoc broke on a long CSS append** (quote count): use Edit/Write for CSS.

## 2026-10-14 · Motion kit on every deck except the four client decks (842f766, ASSET_V 39)
- **User:** "apply to all deck", then mid-run: "remember don bother editing hitachi, bhdasia, hst medical, jrtech slides. dont". Reverted their opt-in AND restored their rebuilt root html + share copies (`git checkout --`) so nothing of theirs changed, not even `?v=`. They keep loading ?v=38 assets, which is fine because none of their assets changed.
- **18 decks opted in by a script** (`~/ClaudeWork/qa/mx_optin.py`: motion.css after `{{head}}`, `data-motion="mx"` on body, motion.js after deck.js). motion.css loads BEFORE the deck's own CSS so deck rules like `.lw [data-in]` (opacity-only inside the Odoo window) still win.
- **The kit had to respect two engine exceptions**: `.deck.is-cut .slide[data-group]` (the Odoo series' live window must CUT) and `data-transition=fade` (What is Odoo walkthrough). Same specificity + later file would have overridden them; added explicit rules. Strips confirmed: moves hold the window, the walkthrough fades.
- **Closing QR cards** (`.ct-qr[data-in]`) get `data-fx=land` from motion.js in every deck.
- deck_check on all 23: 0 errors, the 16 baseline warnings. Motion strips for every deck: built by ~1.6 s (tiers and What is Odoo 04/05 have longer inner loops). PDFs unchanged (print never plays motion; sampled odoo-accounting + portfolio).

## 2026-10-15 · Brand kits reuse this engine (separate repo)
- Built TechNextSG/brand-presentations (brand kit compilations for TechNext, HummingBeing, BHD Asia, TRE SG) on a copy of deck.js/deck.css. The skill's scripts work on any repo with `TN_DECKS=<path>` (needs a README.md and `_src/build.py` DECKS with `pdf=`).
- Owner direction mid-job: "only brandkit compilation", "not for showcasing", "MAKE IT CLEAN, THE PRESENTATION SHOULD BE TECHNEXT BRANDING": the deck is always TechNext-branded; a client brand appears only as content (swatches, specimens, files), never as the deck theme.
- Pages: a manual workflow_dispatch right after the first push collides ("in progress deployment"); dispatch again once the first run finishes.

## 2026-10-15 · Immaculate Connections website walkthrough (ab04b2a, ASSET_V 40)
- **User:** "please create new technext presentation about website, i will showcase the website to all client's college about the https://www.immaculateconnectionsph.com/". "college" read as colleagues; the same day the agency issued Travelpreneur partner codes, so the audience is the agency's team AND its partner network: the deck shows the site, never internal open items (no reviews/DOT numbers/"what we still need" slide) and never a partner code (`contact?partner=YOUR-CODE` only).
- **The client's site changed under us:** a parallel session replaced all packages with 14 Vietnam programmes from Manila mid-job (f69c1b4). The first capture and data probe were stale; check `git log origin/main` of the client's repo before capturing, and re-probe after any deploy.
- **Real data from the live site, not the repo:** headless Chrome (`~/ClaudeWork/qa/ic-deck/capture.py`, `probe2.py`): `IC.tours` for the finder, `IC.chat.answer(q)` for the assistant's real replies, section offsets for the package-page scroller, every page's title/description/LD types for the Google mock. Captures: animations must FINISH (getAnimations().finish()), not pause, or the hero print was caught mid-blur.
- **`chat_test.B` imports the client repo's tools/build.py, which changes cwd:** a relative output path wrote `tours.json` INTO the client repo. Always write absolute paths from those helpers. A failed `[IO.File]::ReadAllText('README.md')` in PowerShell (cwd reset to Marketing) then created an empty `G:\Shared drives\Marketing\README.md`: use full paths with .NET file calls.
- **Logo:** the agency has no lock-up file, so it was rendered from its own live header (mark + its own fonts) at 4x with a transparent background (`qa/ic-deck/logo.py`): `ic.png` navy text, `ic-white.png`, `ic-mark.png`.
- **WebP in a deck prints as lossless PNG:** Chrome's PDF re-encoded every .webp photo as PNG (20 MB PDF vs ~5 MB). Deck photos are JPEG; the PDF dropped to 4.9 MB.
- **Shots caught:** 7 list rows of 58px ran into the URL line (54px rows, 414px box); stacked figcaptions overlap (hide on all but the top print); dead bands under the service document and package details (added a carry-over strip and a share note).

## 2026-10-15 · Presenter scripts for the Immaculate Connections deck (d91f9c0)
- Added `immaculate` to `presenter-guide.html` `DECKS`: 13 slides, say / do / watch / bridge / joke from the speaker notes; Never say = no partner code (not even a sample), prices and dates as of 15 Oct 2026 and the package list changes often, no rankings on the Google slide, service documents and quotations are samples, "Ask us" is not AI.
- Spoken numbers only where the slide shows them; no package prices read out (they change), the script says "the live page has the latest".
- The in-app browser refuses localhost, so the check was the live page: 200, 3 tabs, 13 TOC entries, 5 rules, no console errors.
- Same day, f30e668: deck went to 16 slides (bd9ad2b, ASSET_V 41: 35 packages, 45 sitemap pages, part 05 working together). Script updated in place (slides 1, 2, 5, 6, 9, 11 + new 13 journey, 14 together, 15 roles; Close is 16; parts gain 13:"Part 05"). Added a sixth rule: no promised reply or turnaround times (the 15 Oct one-day timeline is what happened, not a promise). Gotchas: a Bash heredoc with many quotes broke, so write the edit script with Write and run it from PowerShell; `innerText` sees the CSS-uppercased part labels, so check them with `textContent`.

## 2026-10-15 · Immaculate Connections deck, revision 2 (bd9ad2b, ASSET_V 41)
- **User:** "update the presentation base on the current website, and how we will gona work with clients." Asked whose process; answer "Both": the agency with its travellers and partners, and TechNext with the agency.
- **The site had grown to 35 packages in an afternoon** (17 China + 4 Vietnam from Cebu; posters first on package pages). Re-probed `IC.tours`, chat answers, page metas, sitemap (45 URLs / 13 videos) and package-page offsets; recaptured all pages. Prices now mix ₱ and US$: no price sort; the finder sorts by departure count and shows 13 + "+N more".
- **New part 05 "working together"** (3 slides): journey (six stages x traveller / website / team lanes, traveller or partner toggle, only what the site already says: no reply-time promises), together (poster to package card, the day's commit times as proof), roles (your team / TechNext / both filter).
- **{{icon:*}} is inlined SVG with no name**: a script can't find an icon by name in the page; give the slide a hidden `<div hidden>` set of `<span data-k>{{icon:x}}</span>` and read it in init.
- **PowerShell array gotcha**: `@('a', 'b'+"`n"+'c')` split into three elements and corrupted a CSS rule in the earlier pass; do multi-line replacements in Python.

## 2026-10-19 · St. Clare College proposal (2756e17, 085f652, ASSET_V 43)
- **User:** "crete a technext presentation for this client https://stclareonline.com/vms, scope will be. timekeeping, attendance and payroll. do create phase 3 detailed per phase on how we gonna help them. we will offer free website design". "phase 3" read as three phases, one per scope item, each with a detail slide (what we do x6, a live demo, you give us / you get / done when).
- **The client's public site gave the hook:** the IMS page links three Google Forms for faculty attendance, one per division. The understand slide plays them as three separate response lists; pains stay hypotheses.
- **Odoo 20 PH payroll facts come from the release notes** (fetched 19 Oct): basic package, 1601-C, 2316, 1604-C, Alphalist, SSS/Pag-IBIG loan deductions. Contribution rates and tax are NOT claimed: the payslip demo shows sample figures labelled "not St. Clare's".
- **"Free website" follows the offer rule:** our design work is free; the site runs on the client's Odoo subscription (never "free Odoo").
- **Motion-kit bug found and fixed:** `[data-motion] [data-step]{transform:translateY(22px)}` has the same specificity as deck.css `[data-step].is-shown` and loads later, so every plain step build stayed 22px low (seen as the right column sitting lower than the left on the pains slide). Added `[data-motion] [data-step].is-shown{transform:none}`. Affected What is Odoo and the F&B / retail case studies too.
- **The hands-off client decks slipped into the commit:** `git checkout --` ran before a later build/tool step re-versioned them again (?v=38 -> 43). Fixed in a follow-up commit (restored from HEAD~1). Rule: run the `git checkout --` of the four client decks as the LAST step before `git add`, and check `git diff --cached --stat` for them before committing.
- **Missing Odoo icon:** `hr_attendance` was not in `assets/img/odoo/`; fetched from `odoo/odoo` master `addons/hr_attendance/static/description/icon.svg`.

## 2026-10-20 · Adviser voice across the TechNext decks (67852ef, ASSET_V 44)
- **User:** "update the voice branding of technext website, persentation, branding, we are solution provider/expert adviser." Then: "Leave the website to the other session. Here, take its solution provider / expert adviser wording and apply it to the presentations (not the client decks) and the brand kit."
- **One voice guide, shared with the parallel website session** (it was already building technext.asia/advisers in worktree tn-advisors): written once (`~/ClaudeWork/qa/voice/technext-voice-adviser.md`), sent by SendMessage, the site adopted it. Check `list_sessions` before a cross-surface brand change: another chat may own one surface.
- **Changed:** company profile (cover, who we are, offices, practices, partnership, engagement, "how we advise", close), service showcase (cover, map, close: "What we solve", fourteen solutions), Odoo series + What is Odoo ("The same advisers, three offices", call with an adviser), portfolio close, tier leads, nine case-study CTAs, launcher group "What we solve". Thumbs for company-profile + service-showcase reshot.
- **"Not the client decks" = six decks now:** the four hands-off ones PLUS immaculate-connections-website and stclare-odoo-hr (and their shares s-trd6yng, s-m7a9zai), all restored with `git checkout --` before staging.
- **Gotchas:** `thumbs.py` takes ONE deck per call. PowerShell splits a `git commit -m` here-string with inner double quotes into pathspecs: commit with `-F <file>`. `python -c` with nested quotes fails from PowerShell: write the patch to a .py file.

## 2026-10-20 · New deck: Our talent (technext-talent, 9 slides, a46a073, ASSET_V 45)
- Owner: "create a technext presentation, showcase the talent of technext to client." The People/CV deck is still waiting on CVs, so this one is built only from live technext.asia/advisers + /life text: six adviser roles (lead, advises-on, first-call question), demo-vs-adviser questions, office talent (Taguig City = "Odoo developers, consultants and architects, with finance, HR, sales and marketing"), Listen · Advise · Implement · Stay, four rules. No names, years, photos or credentials.
- Offices map and step track are copied (CSS extracted by selector prefix .of-/.en-) from company-profile into technext-talent.css/js, not shared: keep the two in step if one changes.
- The 5 preview slots were all held by other chats: QA ran on deck_check --shots --phone + deck_pdf --look + the live site in the browser pane.
- MISTAKE: a PowerShell `[IO.File]::WriteAllText("README.md", ...)` with a RELATIVE path resolved against .NET's current dir (G:\Shared drives\Marketing), not Set-Location, and wrote an empty README.md into the Drive root. Always pass absolute paths to [IO.File] calls.
- When CVs arrive: add a "Meet the advisers" slide after `roles` (named cards, office, focus keys) here and in /advisers ADVISORS.

## 2026-10-20 · Our talent: 3 profile placeholders (b1e4178, ASSET_V 46, 10 slides)
- Owner: "create atlases 3 place holder best employee profile". New slide 5 `people` "Meet some of our best": 3 flip cards (featured adviser SG / lead Odoo consultant PH / AI engineer VN). Front: photo slot, name, role, office, years, apps, 3 strength chips, quote; back: known for, credentials, industries, languages. Every unconfirmed field carries `data-ph` (muted + dashed underline); fill from the CVs and drop `data-ph` and the `.ta-pp-note` line when done.
- deck_check reports 7 "text overlaps" on this slide: front vs back faces of the flip cards (backface hidden). Expected, not a bug.

## 2026-10-20 · Our talent: "Trusted. Reliable. Expert." (29a8b8e, ASSET_V 47, 11 slides)
- Owner: "showcase in presentation as technext will be trusted advisor, reliable, and experts". New slide 2 `pillars`: three cards, each word backed by technext.asia/advisers commitments + approved figures; builds 1-3 bring one card forward (data-hi set in step, cleared in settle so print shows all three equal). Cover lead now names all three.
- The literal phrase "trusted advisor" stays OUT (content-rules Words ban). The single words Trusted / Reliable / Expert are fine. If the owner insists on the phrase verbatim, confirm, then update content-rules.
- thumbs HOVER for technext-talent is now 5 (roles moved).

## 2026-10-21 · Moneybees CAS proposal (e25d19b, ASSET_V 50, 13 slides)
- **User:** "createa presentation base on the client's requirements." with the pasted RFQ thread. Built straight from the email: one slide per requested piece, the client's condition quoted, and their three asks (fees, timeline, experience) each answered on its own slide.
- **Prices and weeks the client asked for are not ours to invent:** the quote slide shows the five lines they named with "In the quotation" (a `PRICES` object fills figures + total later); the timeline shows the order of work on milestones, labelled "bar lengths are indicative, not durations". Flag both to the user as the open items before the deck is sent.
- **BIR facts via a research subagent with sources:** RMC 5-2021 + RMO 9-2021 (AC replaced PTU, no demo, AC within 3 working days, Annex B checked at post-evaluation); EOPT: invoice is primary, AR is supplementary proof of payment (RMC 77-2024); Odoo 20 release notes add a Book of Accounts for CAS/CBA (docs silent on format). Reprint "REPRINT/COPY" marking had no BIR source: never state it as a rule.
- **Owner rules that bite here:** no WhatsApp number on client decks either (21 Oct site rule), never "BIR-accredited/compliant", no CAS-experience counts.
- **A real downloadable file in a deck** (assets/docs/*.xlsx via `download`) works on Pages and offline; generate it with openpyxl and keep it in step with the slide's sample rows.
- Shots caught: an 8-row timeline running into the key strip (rows 44 -> 48 px once the headline fit one line), an empty band in the printed document (added qty/unit columns, VAT summary, signature line).

## 2026-10-22 · Company profile: ERP experience slide removed (b43d26d, ASSET_V 51)
- **User:** "remove this part in company profile" (screenshot of slide 9b `experience`, "Odoo projects, industry by industry"). Removed the section, its `.xp-*` CSS in company-profile.css, the launcher desc phrase and the README count (12 -> 11). Deck is 11 slides.
- deck_pdf.py rebuilds every deck too: restore the four client decks + share copies AGAIN after the PDF step, right before `git add`.

## 2026-10-22 · People deck + five real profiles in the talent deck (ASSET_V 55)
- **Brief (from the owner via a parent session):** use only the five profiles in `advisors.py`. Fill the talent slide `people`, fill the company-profile consultant and skills boxes, build a new "People" deck (intro, one profile per person, "Book a discovery call" close). Rules: initials avatar with a photo slot, no contact details, no client or company names, nothing invented, no pronouns for people.
- **The company-profile boxes no longer existed:** the owner had deleted that slide ("ERP experience by industry", b43d26d, 09:03 the same morning), so task 2 was NOT done. Re-adding a slide the owner just removed would reverse a decision, so it went back to the parent session in the report. Check `git log -5` before filling a placeholder: it may have been deleted since the brief was written.
- **One data module, four tokens** (`people_data.py` + `people_render.py`, like portfolio_data and `pf`): the talent cards and the People cover, roster and five profile slides all come from it, so figures can never disagree between decks. A shared `assets/people.css` holds the avatar.
- **Layout traps found on the first shots:**
  - a skills panel with 66 chips overflowed; `column-count:2` with a FIXED height adds a third column off the panel, so build the two columns explicitly and split them by estimated height from real Inter glyph widths;
  - `flex:1 1 auto` rows spread 4 groups over 600px nicely, but 22 chips overflowed, so density modes follow the chip count;
  - a stat tile "1,000+" at 38px overflowed its tile (tiles are now `flex:1 1 auto` at 34px);
  - the card band shrank (flex-shrink) when a bio ran to 4 lines and the avatar rode up over the office pill (band `flex:none`, one-line bio at 3 lines);
  - `<em>` inside a block span inherited the 22px body line-height, so back-of-card lines sat 33px apart: set font-size and line-height on the row.
- **Chrome's PDF ignores `backface-visibility`:** the flip cards printed with mirrored backs over the fronts. Fix: `@media print{.ta-pc-b{display:none}}`. Always open the PDF page of a flip-card slide.
- **The in-app browser refused localhost** (navigate denied): QA used headless Chrome through the skill's `_cdp.py` (shots, real mouse events for the click tests, a measure script). One build exceeded the 120 s shell timeout while other jobs ran: run it in the background if it hangs.
- **Pronoun check:** meta descriptions and notes count ("each with their skills" became "with every skill grouped"). Regex the built HTML for he|she|they|their|them|his|her.
- **Open for the owner:** Clement's "Network security" and "Cybersecurity and data protection certification" are personal skills from the owner's own text, but they sit near the "never add Cyber Security" service rule. The company-profile slide the brief wanted filled is gone.

## 2026-10-22 later · A sixth person (Astroneil Matan) and warmer bios (ASSET_V 56)
- **Request (peer session, for the owner):** add Astroneil Matan, Senior Functional Lead, to both decks, in the site order; then "warmer, more human bios", copied as-is. A usage limit hit in between: the half-done tree (six people in data, five-column layout) was left UNCOMMITTED with a hand-over note in the shared notes folder, which is the right way to stop.
- **The source can change under you:** regenerating from `advisors.py` also changed Clement's bio and his third stat label and all six bios. Always diff `people_data.py` after a regenerate.
- **Six cards across:** the talent grid went to six slim cards (215px): one stat on the front, all stats as rows on the back, 3 groups on the back. The roster's office boxes were tightened (PH holds 5). Names at 20px just fit "Jeric Bulayungan".
- **Density by estimate, not by count:** Astroneil (38 chips) has long credentials, so the 15px two-column layout overflowed by 110px while RJ (also 38) fitted. The renderer now estimates the taller column and drops to 13.5px past 600px. A chip wider than its column is counted as two lines.
- **Count words come from the data:** `{{people:Count}}` / `{{people:count}}` (Six / six) replace hard-coded "Five" in titles, notes and meta; the launcher description and README still need a manual edit.
- **A headless-Chrome QA run died with a WinError 10053 (connection aborted):** not a deck fault; re-run it.

## 2026-10-22 later · Team photos (b7fcb62, ASSET_V 57)
- **Request (peer session):** put five photos on both decks; Clement has none; ignore the directory-only extras (Pia, Jett, Rico, Sky) in the same folder.
- **JPEG, not WebP:** the crops arrived as 600x600 WebP; converted to JPEG q88 (40-66 KB each) because Chrome's PDF re-encodes WebP as lossless PNG. The existing `.pp-av` photo path just worked (solid ring, camera badge hidden, `?v=` on the src).
- **Look at the cover on the dark slide too:** the `.dark .pp-av::before` rule keeps a light ring on the navy cover.
- A change that only swaps assets still means: reshoot the cover thumbnail, bump ASSET_V, reprint both PDFs (PDF grows by about 150 KB), restore the four client decks before `git add`.

## 2026-10-22 later · Clement's photo (0ef5ac5, ASSET_V 58)
- A correction from the peer session: the file named SKY in the owner's folder is Clement Kho. Same recipe as the five (WebP crop -> JPEG q88, regenerate people_data.py, thumbs, PDFs, QA, push); only `photo` changed in the data. All six people now have photos.

## 2026-10-22 later · Eight people: Pia Cachola and Rico Duque (6589d43, ASSET_V 59)
- **Request (peer, owner approved):** Pia (General Manager, no office, no credentials, a very different skill list) and Rico (Marketing Officer) join; order Clement, Pia, Astroneil, RJ, Philip, AJ, Jeric, Rico.
- **Eight cards do not fit as slim columns:** 8 x 160px was too narrow, so both the talent slide and the team slide became 4 x 2 landscape cards (photo left, name/role/office right). The office boxes on the team slide went; the office is a pill and `→` dims the cards of the other office.
- **Data without an office or credentials:** `office=None` and `creds` missing must be tolerated by the generator and the renderers (`office_of(p)`, `a.get("creds") or []`), and Pia's profile shows no office anywhere.
- **Long group names break pill math:** "Corporate development & organisational design" is wider than a card, so `group_pills` counts a long pill as wrapped rows and folds "+N" into it. Check every card's pills row on the shot.
- **Estimated column heights drift:** Rico (32 chips) overflowed at 15px, so the 13.5px switch moved from 600px to 570px. Re-run `people_measure.py` for every new person.
- Photos: the owner's WebP crops (600x600) became JPEG q88 as before.

## 2026-10-22 later · Nine people: Jett Balanza (f908bba, ASSET_V 61)
- Nine does not fit 4 x 2: the grids became flex rows with a column count computed from the number of people (5 + 4 centred for nine), set as `--cols` / `data-cols` through a `{{people:cols}}` token, so the tenth person (5 + 5) and beyond (6 per row from eleven) need no CSS work. Look at the 5-column cards' BACKS (the longest back overflowed by a line and needed tighter spacing).
- A fast succession of "one more person" requests from a peer session: each time regenerate from advisors.py, diff, check the new person's profile with `people_measure.py` and the long group names on the cards, then the whole pipeline. Batch if another person is announced while one is in flight.
