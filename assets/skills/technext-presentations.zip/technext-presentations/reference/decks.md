# The decks, one by one (state on 2026-10-07, ASSET_V 29, last commit b3d77a7)

Slide maps are `number · id · title`. **dark** marks a navy slide. Each deck lists its sources, data and special rules. When a deck changes, update its section here.

Every deck shares the same shape:
- **Cover** (`cover`): dark, `data-chrome="none"`, with a logo, a kicker, a `.h-xl` headline with one `.hl`, a lead, tags and a hint saying "→ or click to begin · O all slides".
- **Closing slide** (`contact` or `next`): dark, `data-chrome="foot"`, the booking CTA with `{{qr:meet}}`.

## About TechNext

### Company profile: `company-profile` (11 slides, about 10 min, share `s-4zprjc7`)
Files: `_src/decks/company-profile.html`, `assets/company-profile.css|js`, `ai-demos.*`, `fx.js`, `{{include:ai-templates}}`, `window.APPS`.

01 cover (plane and orbit art) · 02 who (who we are, stats) · 03 offices (SEA dot map and office cards, `data-steps="3"`) · 04 practices (ERP, AI and marketing) · 05 partner **dark** (Odoo Ready Partner orbit) · 06 engagement (five steps, `data-steps="4"`) · 07 ai (four disciplines, live AI demos) · 08 industries · 09 rules **dark** (a few rules we keep) · 10 details (company record, click to copy) · 11 contact **dark**

- Office cards and map labels carry the office roles (see content-rules).
- **Motion kit on (2026-10-14):** cover core lands from 2.3x, rings ripple, apps spring in (`--od` cascade); who counters drive their pips; offices camera push (`ofCamera`, reset in settle); engagement/industries panels push by direction (`swap()`); details rows cascade; QR `data-fx=land`.
- The `practices` slide lists three practices. Technology (IoT · Apps · Networks) is pending (see content-rules).

### Portfolio: `portfolio` (10 slides, share `s-77yjkef`)
Files: `_src/decks/portfolio.html`, `assets/showcase.css`, `showcase.js`, `portfolio.js`, and data in `_src/portfolio_data.py` (CLIENTS, SERVICES, STATUS, PINS with label side r/l/t/b).

01 cover (client-name marquee) · 02 map (world dot map, pins) · 03 clients (directory: filter and detail panel, cycles until clicked) · 04 story-casa · 05 story-tre · 06 story-niv · 07 story-jrt · 08 story-imc · 09 enterprise **dark** (NDA work as counts) · 10 contact **dark**

- Stories are plain bullets (`.st-list`), with no dates anywhere.
- The matrix slide and the proposals/paused slide are removed for good.

- 2026-10-22: slide 9b `experience` (ERP experience by industry) REMOVED at the owner's request; don't reintroduce it.

## What we build

### Service showcase: `service-showcase` (15 slides, share `s-pamt7t8`)
Files: `_src/decks/service-showcase.html`, `assets/service-showcase.css|js`, `ai-demos.*`, `fx.js`.

01 cover · 02 map (the service map) · 03 erp (Odoo 20 implementation plan, a Gantt you can drag: `.gt-body[data-drag]`) · 04 crm (live pipeline board, add a lead, assignment rules) · 05 group (multi-company) · 06 custom (customisation Q&A) · 07 integrate (integrations with outages, counters, MCP line) · 08 care (training and support) · 09 ai · 10 rag · 11 aiodoo · 12 agents · 13 marketing (websites, social, brand) · 14 pricing (how engagements are priced; Light User line, no figures) · 15 contact **dark**

- "All fourteen services". When a service is added (the Technology practice), the map, the count, the launcher description and a slide all change.

### Marketing showcase: `marketing-showcase` (15 slides, share `s-p98b5ej`)
Files: `_src/decks/marketing-showcase.html` (mostly `{{sc:*}}` tokens), `assets/showcase.css|js`, and data in `_src/showcase_data.py` (LIVE 7, CONCEPTS 3 featured, MORE, PITCH 10, five to a row) + `_src/sites_meta.json` + `assets/img/sites/`.

01 cover (scrolling site wall) · 02 gallery (the wall of 29 tiles, filter All/Live/Concepts/Pitch; columns chosen so every row is full) · 03–09 one slide per LIVE site (Casa Escondida, BHD Asia, HummingBeing, nivellipso, JR-Tech, TRE in Singapore, technext.asia) · 10–12 featured concepts (Immaculate Connections, Auntie Gaik Lean's, TRE Worldwide Conference) · 13 more (more concepts) · 14 pitch (pitch microsites) · 15 contact **dark**

- A site slide (`sc_feature` in build.py) has the copy on the left, and a browser frame plus a phone on the right, each scrolling the full page.
- Adding a site: an entry in `showcase_data.py`, a capture, `sites_images.py`, `build.py --prune` (see recipes).
- Blue Moon and Tri-Comp are removed. The last recapture was 2026-10-02 (BHD, HummingBeing, TRE SG, technext.asia, Immaculate Connections).

## Odoo

### What is Odoo: `what-is-odoo` (17 slides, share `s-4xgby3f`)
Files: `_src/decks/what-is-odoo.html`, `assets/what-is-odoo.css|js`, `fx.js`, `{{include:walkthrough}}` (the walkthrough screens in `_src/partials/walkthrough.html`).

01 cover · 02 problem (`data-steps="1"`) · 03 what · 04 new20 ("Odoo 20, in six changes", filter All/New/Check before upgrading) · 05 apps (catalogue from `{{apps_json}}`) · 06 onedb **dark** (one database) · 07 walk (index of the walkthrough, `data-go` jumps) · 08–13 w1–w6 (CRM, Sales, Inventory, Invoicing, Accounting, Reporting; `data-transition="fade"`, one build each, a stepper on top) · 14 editions (Community and Enterprise) · 15 hosting (where Odoo runs) · 16 implement (how TechNext implements Odoo) · 17 contact **dark**

- The walkthrough follows one order (S00042, Lumen Trading Pte Ltd, office chairs) from lead to cash. Keep its figures consistent across w1–w6.

### The Odoo app series: `odoo-accounting`, `odoo-sales`, `odoo-crm` (13 slides each; shares `s-myi79wm`, `s-tig4yfh`, `s-njrgnhn`)
Built 2026-10-02 by a parallel session with the impeccable and web-design-engineer skills. The user chose the structure "one live Odoo screen". It is reviewed against `DESIGN.md`.

01 cover **dark** (`oa-cover`, an Odoo window already working) · 02 replaces (what it replaces, one build: a counter and a meter) · 03–09 mv1–mv7 (the seven moves: `class="oa-mv"`, `data-group="live"`, `data-steps="1"`) · 10 new20 (each item has a "seen in Move n" jump) · 11 local (Singapore, the Philippines and Vietnam side by side, beside a dot map; a pin only highlights its column, so print carries all three) · 12 setup (phases light in turn) · 13 contact **dark**

- **Shared layer:** `assets/odoo-app.css|js` (`OA`): the window `.lw`, the move column, the session log `.mv-log`, and the replaces, new20, local and setup slides. Each deck adds its views in `assets/odoo-<app>.css|js` and its navbar in `_src/partials/<acc|sale|crm>-nav.html` (Sales also uses `pico-chair` and `pico-desk`).
- **A move script:**
  ```js
  OA.start({ cover: fn, coverSettle: fn, moves: [
    { id: 'mv1', name: 'Bank feed', result: '14 transactions in',
      reset(s),                       // back to the start, no transitions (wrapped in snap)
      intro(ctx, s, ready, quick),    // set the scene; call ready() to light the Odoo button
      act(ctx, s, done),              // perform the task; call done() to tick the log
      final(s),                       // the finished state, for print and the overview
      init(s) /* optional */ }, ... ] });
  ```
  Step 0 readies the highlighted `[data-act]` Odoo button. Step 1, or a click on that button, performs the move. Inside the window, keep Odoo's grammar: a plum primary button, teal links, a chevron status bar, the official app icons. Outside it, TechNext blue leads ("Two Palettes Rule", DESIGN.md).
- **The sample company:** Kestrel & Pine Pte Ltd (Singapore). Every window carries a "Sample" chip. The figures must agree:
  - **CRM:** two leads merged, Lead Sourcing (10 companies found), assignment by rotation, a planned next step, predictive scoring (41.2% → 63.0%; prorated S$7,416 → S$11,340), the Sunbird Clinics quotation, then Won (S$18,000 expected; October forecast S$55,840 → S$62,500).
  - **Sales:** S00057 for Sunbird Clinics: S$18,220.44 with installation at a 30% margin, S$18,318.54 at 35%, a S$5,000.00 deposit, S$13,318.54 still due. Then Shopee, Lazada and TikTok Shop orders, and commissions on paid sales.
  - **Accounting:** the bank feed (14 transactions; GL S$110,382.30 → S$130,407.90), 13 matched by rule plus Lumen Trading by suggestion, a bill read from its PDF, reminders, a batch payment, the GST return (Review, Submit, Pay, Validate), the month locked.
- **Odoo 20 claim limits:** see content-rules ("Do not claim").

## Client decks (sales proposals)

### Hitachi Elevator Philippines: `hitachi-elevator-ph` (14 slides, share `s-vwagibj`, which is WITH THE CLIENT; never change the token)
Files: `_src/decks/hitachi-elevator-ph.html`, `assets/proposal.css|js` (the shared kit), `assets/hitachi.js`, `fx.js`; body `data-cobrand="assets/img/clients/hitachi.png"` (+ `-white`).

01 cover **dark** (TechNext | Hitachi lockup `.hx-lock`; connector and service desk right under the branch labels) · 02 understand (PH dot map, NSCR stations) · 03 pressure ("Five places where Odoo takes the load") · 04 arch **dark** (a service layer beside GERP) · 05 breakdown (a call from ring to signed report: 3 scenarios, 3 branches, SLA clock, route; it takes about 14 s to finish) · 06 dispatch · 07 worksheet · 08 contract (handover to renewal) · 09 radar (contracts ending this year) · 10 projects (NSCR-scale installs) · 11 dashboard (the 24/7 promise, with a number) · 12 scope (the client's phases) · 13 roadmap (pilot first) · 14 contact **dark**

- **Phases (user):**
  - PH1: Helpdesk, Planning (field service), Sign, Documents, Project.
  - PH2: Subscriptions, Sales, CRM, Purchase, marked TO CONFIRM (it depends on what GERP covers).
  - PH3: Dashboards.
  - No Inventory and no AI tile.
- **Removed (don't bring back):** the parts pressure point, the Inventory and Purchase cards on slide 3, the "Parts confirmed before the van leaves" slide and the "Five questions" slide.
- **Public facts used** (hitachi-elevator.com.ph and hitachi.com):
  - 1971 Hi-Eles; a subsidiary since 2011;
  - Makati, Cebu (Mandaue) and Cagayan de Oro;
  - 24/7 service with "readily available maintenance parts";
  - NSCR 67 units (21 elevators and 46 escalators) across 7 stations, contracts CP01 Taisei-DMCI and CP02 Sumitomo Mitsui;
  - body cams and QR codes (22 Nov 2025).
- **Odoo's place:** the service layer beside GERP, never a replacement.

### JR-Tech Solution: `jrtech-odoo-erp` (25 slides, about 50 min, share `s-mm4jk7b`)
Built 2026-10-06 from two PDFs the user supplied: `Downloads\JRTech-Odoo-ERP-Presentation.pptx (1).pdf` (19 pages, TechNext's own presentation to JR-Tech) and `Downloads\JRTech-Accounting-and-Billing-Questions.pdf` (28 discovery questions + "please bring or send ahead"). User: "use this material", "question at the back", "at the end of presentation".
Files: `_src/decks/jrtech-odoo-erp.html`, `assets/jrtech.css|js` (every class starts with `j`), `proposal.css|js` for the lockup and `PX` chart helpers; body `data-cobrand="assets/img/clients/jrtech.png"` (the light logo JR-Tech's own deck uses on white) + `jrtech-white.png` (the official `JR-Tech-Logo_Final-white.png` from the client site repo, cropped).

01 cover **dark** (agenda buttons jump to the four parts; "one database, eleven applications" ring with numbered phase badges) · 02 solution (Migration → P1 → P2 → P3 → Go-live → Support, AI Blueprint band, "runs through every phase" strip; click a stage, "Go to it") · 03 s1 **dark** (part 01, Jett & Phillip; "in this part" jump list) · 04 bigidea (one combi oven record written by five apps, 5 builds) · 05 roadmap (11 apps, phase filter, counter) · 06 phase1 · 07 phase2 (five cards each, 5 builds; every card has a live vignette that resets, plays, or shows its end) · 08 phase3 (margin drop → six jobs; AI agent proposes a bill, Confirm/Discard; 2 builds) · 09 s2 **dark** (part 02, AJ) · 10 worries (4 builds) · 11 cutoff (drag the cut-off; mid-month turns red, "Cut at the close" snaps; plays once on arrival) · 12 scope (11 lines travel SQL Account → Odoo the way they move; tax codes re-configured, prior-year stays archived) · 13 process (7 builds, step caption with when it happens) · 14 runway (6 builds, system-of-record and e-Invoice-sender bars) · 15 risks (6 risks + go / no-go gate, auto-runs once) · 16 video-ar (the narrated video "Getting paid, with less chasing", Odoo 20 Accounting part 3 of 4, 3:21, user: "add this video after page 15"; poster = its title card, chapter list 0:00/0:15/0:45/1:20/1:52/2:25/3:04, each just before its first spoken word: data-t 0, 15, 45.4, 80.6, 112, 145, 184) · 17 needs (12-item checklist, ring) · 18 s3 **dark** (part 03, Sky; jumps to builds of 19 via `data-at`) · 19 aftergolive (drag the day, 3 builds) · 20 s4 **dark** (part 04: six question groups as tiles with live answered counters) · 21 q-books (01 + 02 KEY) · 22 q-billing (03 + 04 KEY) · 23 q-cash (05 + 06) · 24 prep (8 files to send, meeting tally, "Copy the follow-up list") · 25 contact **dark** ("Let's set the cut-over date", team chips, booking QR)

- **The video** (`assets/video/jrtech-getting-paid.mp4`, 12.8 MB, remuxed with `-movflags +faststart`, + `.jpg` poster): `preload="none"`, plays with sound on click, pauses on leave. Own control bar (play, time, seek track with chapter marks, sound, Zoom/Back; fades while playing); click = play/pause, double-click or Z = zoom to the whole stage (and the screen), Esc/Z/Back = back into the slide; recovers from a media error at the same point. Presenter view: a BroadcastChannel (`jrtech-odoo-erp-video`) keeps play, pause and seek in step; the presenter window is muted. Other parts of the series (1 supplier bills, 2 bank & reconciliation, 4 MyInvois, set-up & AI) exist as videos but were not given.
- **Question 1.2 is the user's wording** (2026-10-06): "How many companies or databases do you keep in SQL Account today, and should they run as separate companies or as branches of one company in Odoo?" (the Penang fabrication plant line is gone).
- **Questions at the back:** the 28 questions are buttons: one click answered, two follow up, three clear. Marks live in `sessionStorage` (`jrtech-odoo-erp:q|files|needs`), so a reload or moving between slides keeps them; "Clear all marks" needs two clicks. The copy button writes follow-ups, not-asked questions, missing files and open checklist items; if the clipboard is refused, the text opens in a panel to copy by hand. Print shows everything unticked.
- **Fixes to the source, on purpose:** cover footer said "Casa Escondida × TechNext · Phase 1" (template leftover); close said hello@technext.asia and "Odoo Implementation Partner" → sales@technext.asia and "Odoo Ready Partner"; date set to October 2026 (the questions sheet says the presentation is October 2026). The cover agenda listed "03 AI Blueprint" but the source had no AI Blueprint slides: it stays as the band on slide 2 and a phase-3 note, and Sky's chip reads "AI blueprint & support".
- **Facts checked:** SST-02 reports and the MyInvois intermediary (Odoo S.A. on MyTax, pre-production and production) are in Odoo's Malaysia localisation docs. "SST + MyInvois" is the localisation inside Accounting, so the deck lists it but does not count it among the eleven apps. Field Service is labelled as running in Planning (Odoo 20).
- **Sample data:** deal, quote, serials, jobs, bill, units, codes, month labels: all labelled "Sample" on the slide or in its foot note.
- **Open with the user:** Jett & Phillip (part 01 chip) vs "Migui & Jett · Odoo modules" (close) both come from the source; the AI Blueprint has no slide of its own.

### BHD Asia · HummingBeing: `bhdasia-odoo-scope` (19 slides, about 30 min, share `s-4sg4p5j`)
Built 2026-10-06 from `Downloads\BHDAsia-Implementation-Scope.pdf` (5 pages, TechNext's internal "for team review" scope: workflows and modules, consolidated from the 20 Aug and 18 Sep meetings, the client's lawyer's 6 Oct questions and five demo databases). User: "create a technext presentation here's the scope." Built as a CLIENT-FACING deck to walk Isabelle through the scope; the source's internal remarks were left out (see content-rules, "Client decks from an internal document").
Files: `_src/decks/bhdasia-odoo-scope.html`, `assets/bhdasia.css|js` (every class starts with `e`), `proposal.css|js` for the lockup; body `data-cobrand="assets/img/clients/bhdasia.png"` (= `-white`: the BHD mark cropped from `09. HummingBeing (production)\01. Images\09. Event Image\ALL LOGO\4.png` without its tagline; the mark works on navy too) + `hummingbeing-white.png` (from the HB site's `logo-dark.webp`) in the cover and close lockups.

01 cover **dark** (TechNext | BHD | HummingBeing lockup; agenda jumps to scope / flows / modules / decided; "one client record" hub with seven streams, `.flow` lines, bobbing chips in the `.is-tv` stop list) · 02 scope (layer stack: custom modules / third-party apps / code crossed out, configuration + Odoo Online; click a layer; recurring / one-off / code-upkeep ledger; Zoom capture out of scope) · 03 carry (seven kinds of work, cycles every 4.6 s until clicked; "how it's sold" badge, workflow jump buttons, modules, a record-chip row) · 04 flows (six workflows x nine modules dot grid built from `data-u`; click a module to light its rows; rows jump to w1–w6) · 05 w1 ticket (9 steps) · 06 w2 paid 1:1 session, "Screened once, then frictionless." (6 steps for a new client: the site's one "Book a session" button opens the questionnaire, scored against red-flag criteria, an automation rule emails the paid link on a pass or the free Discovery Call on a fail, pick a time, pay, invoice + calendar + reminder; switch No red flags / A red flag; pick a slot; an "every booking after that" card under the steps) · 07 frontdoor (`data-steps="2"`: two lanes, "pay to book, then approve" ending in a refund vs "questionnaire first"; the lawyer's timestamped record; the paid link never on the website) · 08 w3 free booking (7: link, intake question, request, you approve, the questionnaire in Surveys (user, 2026-10-06; not in the scope PDF), meeting on your calendar, no payment/no invoice; type switch, Approve at step 3) · 09 w4 screened sale (7, All clear / A contraindication: fail strikes steps 4–7 and shows "Stops here") · 10 gate (`data-steps="1"`: the shop search types "screened service", No results) · 11 w5 waitlist (4, seats fill 9 to 12, "Someone joins") · 12 w6 money and books (4, statuses In payment / Not paid then Paid, accountant Exports / Limited login) · 13 modules (carries / replaces switch) · 14 phase2 (five switches light dashed slots, 9 to 14) · 15 decided (six cards, 3 + 3, incl. "Books in SGD"; screening jumps to workflows 2 and 4; "booking links are public once published") · 16 currency ("Books in SGD, prices in any currency.": settled 6 Oct, Singapore chart; pricelist switch SGD/USD/EUR/GBP/JPY changes the sample quote; "Try to change the company currency" is refused) · 17 bundle **dark** (provider network slider, 25 by default; "not in this scope: to discuss") · 18 open (seven open items as tick buttons with owners + a "Settled on 6 October" card: books in SGD, back-office access full admin; counters, copy list, clear) · 19 contact **dark** ("Next, the quotation, in writing.")

- **The workflow engine** (`flow(id, opt)` in `bhdasia.js`): `data-steps` = number of steps; the arrow key, a step click or Play move the build; scene parts `data-on="n"` light from step n (ghosted before), `data-t="0:text|n:text"` swaps wording; `opt.paint` adds per-slide state; settle paints the last step. Reuse it for any "process played step by step" slide.
- **Open items** keep their marks in `sessionStorage` (`bhdasia-odoo-scope:q`): one click settled, two follow up, three clear. Print shows them unmarked.
- **Revision 2 (user: "update the scope", same PDF re-exported 16:56):** workflow 2 rebuilt (screened once, then frictionless) + the "why before payment" slide; currency settled 6 Oct (SGD, Singapore chart, pricelists USD/EUR/GBP/JPY); open item 5 became the back-office access paperwork (full admin decided 6 Oct, because Odoo has no standard group that publishes events while hiding registration answers). Everything else in the PDF was word-for-word the same.
- **Facts kept from the source:** six workflows and their steps, nine modules and what each replaces, phase two list, decisions, seven open items + what was settled on 6 Oct, the provider bundle (about 25 students, TRE™ Singapore membership benefit, shared service). TRE™ everywhere, notes included (client trademark rule).
- **Left out on purpose:** that she "asked three times", the cost she "resents", the back-office person's name, the dormant Japan entity, the Simba price rise, the "internal / confidential" labels. Multi-company being on Odoo's Custom plan is in the notes only, as a presenter check.
- **Open with the user:** whether a team-only (internal) version is also wanted. The card surcharge and bank sync are the source's tested claims (bank sync is footnoted "where your bank is on Odoo's list").

### HST Medical: `hst-medical-website` (19 slides, about 40 min, share `s-9d7xqqb`)
Built 2026-10-07 from the HST material on Drive (website prototype `28.`, product-sheet flip-book `30.`, brand strategy `31.`), `~/ClaudeWork/hst-wp` (WordPress build: performance report of 3 Oct, Theme Check, editor guide) and `Downloads\hstwebRFP.docx`, to Pia's agenda (website and catalogue feedback; AI for the website). User: "properly showcase the logo". Revision 2 the same day (b3d77a7): **light theme only, no pricing anywhere**, slide 5 "we can build your brief", slide 6 "your direction", the close rebuilt as why TechNext + how we build.
Files: `_src/decks/hst-medical-website.html`, `assets/hst.css|js` (every class starts with `k`), `proposal.css` (lockup), `showcase.css|js` (browser and phone frames, lazy site pictures). Body `data-cobrand="assets/img/clients/hst-mark.png?v="` (colour, no Kowa line; `hst-white.png` is unused now that every slide is light). `assets/img/clients/hst.png` is the full official lock-up. Packshots `assets/img/hst/pNN.webp`, catalogue pages `cat-NNN.jpg` / `fix-NNN.jpg`, site pictures `assets/img/sites/hst-{home,shop,pdp,where,about,cat,bs}-*`.

01 cover (light; colour lockup; a white logo card that builds itself, "Higher · Stronger · Together"; agenda 01 website & catalogue / 02 feedback / 03 AI for the site / 04 why TechNext) · 02 brand (1930 / 1994 / 2026; four brands with packshots) · 03 built (three live test links, hover pans) · 04 site (five page tabs, desktop + phone) · 05 brief ("We can build your brief, line by line": RFP 2.1–2.6 with evidence from the staging build; 2.4 carries a mini main-paint chart) · 06 direction ("Tell us your direction, we'll bring the ideas": AI-enabled / a store that converts / brand strategy support; click a column to pick it, the others dim; picks stored in `hst-medical-website:dir` and added to the follow-up list) · 07 book (CSS 3D page turn, product card with item codes) · 08 fixes (seven print fixes boxed on the pages) · 09 feedback (live board, `hst-medical-website:fb`) · 10 askhst (four real Ask HST conversations, no prices: stiff shoulders, kid's cough, the Watsons-near-Tampines store finder, the 995 emergency) · 11 ainext (rules vs AI, illustrative AI side, no prices) · 12 aimap (five AI opportunities; no cost row) · 13 geo (light; sample AI answer; real llms.txt, a JSON-LD excerpt without prices, the HTML) · 14 fast (why TechNext 01: "We move fast. Really fast."; HST's own timeline 2 Oct prototype, 3 Oct staging build, 5 Oct flip-book, 6 Oct brand pack, today; usual vs TechNext route, launch flag and "more time selling", no durations) · 15 erp (02: "An ERP division behind your website": integration map ERP / payments / couriers / channels / email & CRM / analytics, auto-cycles until clicked; data migration, APIs, connectors; "already moved on our staging build") · 16 ai (03: "Strong in AI, built for what's next": the four AI disciplines with what each means for HST and jumps back; future-proof list) · 17 how ("We build it and show you, not wireframes": usual vs TechNext lanes, "Another round" counter, Satisfaction guaranteed seal) · 18 questions (ten; Q3 delivery and GST without amounts; copy list = questions + directions + revisions) · 19 contact (light)

- **No pricing anywhere** (user, 7 Oct): no figures, no quotation wording, no product prices in the demos. Don't bring the scope/price slide back unless asked.
- **Facts used** (hstmedical.com, checked 7 Oct 2026): HST = Higher, Stronger, Together; Heng Say Tong 1930; incorporated 1994; Kowa Pharmaceutical Asia from 29 May 2026; 51 products, 11 ranges, 58 item codes; 30 stores. ® on HST Medical, Heritage, Rheuma-Salve (as the live site), none on Zoo-Vite; Alievaid™ (pack).
- **Left out on purpose:** the brand strategy's market figures and the internal research files; the 5.0 rating and award wording (unconfirmed, question 5).

**A new proposal:** copy this deck's structure, reuse `proposal.css|js`, write `assets/<client>.js`, and add it to the "Client decks" group in `DECKS`. Content rules apply in full.

### Immaculate Connections: `immaculate-connections-website` (16 slides, about 25 min, share `s-trd6yng`, group Client decks)
Built 2026-10-15 for the agency to show its new site to its team and partners. Files: `_src/decks/immaculate-connections-website.html`, `assets/immaculate.css|js` (prefix `im-`), `proposal.css` (lockup), `showcase.css|js` (frames, `{{scroll:ic-*}}`), photos `assets/img/ic/*.jpg` (15 home prints, 13 gallery posters, 14 package images, `pkg-long.jpg`), logos `assets/img/clients/ic*.png`, QR key `icsite`. Light theme, motion kit on.
01 cover (lockup, agenda, browser + phone scroll) · 02 built (six counters that jump) · 03 site (7 page tabs, desktop + phone) · 04 prints (the 15 real group prints, click/thumbnail throws to back) · 05 tours (35 packages, country/departure city/length, ₱ and US$, top 13 + more) · 06 package (7 parts from the poster scroll the real page; details panel) · 07 services (4 documents typed live, sample) · 08 inquiry (traveller / partner flows played step by step, sample refs) · 09 ask (5 real Ask us answers) · 10 gallery (13 posters, filter) · 11 google (search mock with each page's own title/description + 6 facts) · 12 share (copy links, partner link without a code, site QR) · 13 journey (part 05 working together: six stages, traveller / website / your team lanes, traveller or partner) · 14 together (you send it, we put it live; poster to card; 15 Oct timeline) · 15 roles (who does what) · 16 contact (light, "Want a site like this?")
- Facts as of 15 Oct 2026; the package list changes often: re-probe `IC.tours` before presenting again. Never show a partner code; no internal open items on slides.

### St. Clare College: `stclare-odoo-hr` (12 slides, about 30 min, share `s-m7a9zai`, group Client decks)
Built 2026-10-19 from the user's brief: "crete a technext presentation for this client https://stclareonline.com/vms, scope will be. timekeeping, attendance and payroll. do create phase 3 detailed per phase on how we gonna help them. we will offer free website design". Read as THREE phases (timekeeping, attendance, payroll), each with its own detail slide. Files: `_src/decks/stclare-odoo-hr.html`, `assets/stclare.css|js` (prefix `sx-`), logo `assets/img/clients/stclare.png` (the school's square red "SCO ONLINE" tile from its site header, untouched; used on light AND dark, so no white variant), new Odoo icon `assets/img/odoo/hr_attendance.svg` (from odoo/odoo master). Motion kit on, light slides with dark cover and close.
Slides: cover (agenda, three divisions -> One Odoo -> three apps), understand (public facts with sources + the IMS page's three Google Forms as live columns), pains (5 hypotheses, Odoo answer per arrow press), apps (Employees, Attendances, Time Off, Payroll + Website), day (Ana Reyes, sample SHS teacher, 6 steps, Play), phases (3 cards with gates + website lane), p1 schedule builder (division x full/part-time, sample schedules), p2 kiosk slider (grace 10 min sample) + division board, p3 payslip (full-time overtime / part-time hours, sample peso figures, BIR chips), website (today's 12-item menu vs a proposed sitemap; "our design work is free, the site runs on your Odoo subscription"), 12 questions (tick buttons, sessionStorage `sx-questions`, copy list), close.
Facts used (19 Oct 2026): 36th founding anniversary 31 Aug 2021; Caloocan (Zabarte Road); Basic Ed / SHS / Tertiary with the tertiary programmes; LMS CMS IMS PMS VMS; full online or blended; IMS Faculty Corner 2026-2027 links three attendance forms. Odoo 20 release notes: basic Philippines payroll package, 1601-C items, 2316, 1604-C + Alphalist, SSS/Pag-IBIG auto loan deductions; Attendances: eSSL and Mantra devices, photo at check-in, overtime rulesets with public holiday rates. No durations, no prices.

### Moneybees Forex Corporation: `moneybees-odoo-cas` (13 slides, about 30 min, share `s-7kzr62q`, group Client decks)
Built 2026-10-21 (e25d19b, ASSET_V 50) from the RFQ email of Jane Frances Odarve (General Accountant, 20 Oct 2026): six Excel books (GL, GJ, CRJ, SJ, CDJ, PJ), printable PDF Acknowledgement Receipts and Sales Invoices with reprinting, deployment/validation/migration/go-live, recorded tutorials, BIR CAS documentation + registration assistance; condition "retain our current setup, customise only where feasible"; asked for a fee breakdown (development, registration assistance, deployment, training, recurring), timeline and CAS experience. Files: `_src/decks/moneybees-odoo-cas.html`, `assets/moneybees.css|js` (prefix `mb-`), logos `assets/img/clients/moneybees.png` (dark text) + `moneybees-white.png` (both from moneybees.ph/_nuxt/img, untouched), real sample workbook `assets/docs/moneybees-sample-cas-books.xlsx` (generator `~/ClaudeWork/qa/mb-deck/books_xlsx.py`; keep its rows equal to BOOKS in moneybees.js). Gold accent #F2AE00 from their site.
Slides: cover (hexagon hive) · heard (5 pieces + condition, jump links) · approach (keep / configure / build; Odoo Online = no custom modules; Odoo 20 release notes "Book of Accounts for CBA and CAS") · books (6 tabs, sample sheet, export, download) · print (SI/AR, Print then Reprint with stamp, reason and log) · deploy (4 builds: review, staging, validate, go live + validation checklist) · videos (mock player, 3 tutorials x 4 chapters) · register (RMC 5-2021 / RMO 9-2021 pack: system description, sample printouts, audit trail, reports specs + Annex B, sworn statement; no pre-demo; AC in 3 working days; who does what toggle) · timeline (milestones, NO week figures) · quote (five lines; `PRICES` in moneybees.js null = "In the quotation", fill to show figures and the total) · why (no CAS count claimed) · 12 questions · close (no WhatsApp).
Facts (21 Oct 2026): moneybees.ph describes OTC crypto buy/sell via BSP-licensed outlet partners; the deck says nothing about their business beyond the RFQ. Reprint marking is NOT a BIR rule found in any source: the deck presents it as our control design.

## Pricing

### ERP tier list: `erp-tiers` and Marketing tier list: `marketing-tiers` (7 slides each; shares `s-w37eiqr`, `s-f3657x2`)
Files: `_src/decks/<x>-tiers.html` (tier cards and add-ons as static HTML with data attributes; `window.TIERS` = name, subject, viz, meter, finder questions, explorer data), and the shared `assets/tiers.css|js`.

01 cover **dark** · 02 tiers (three cards; Growth is "most popular"; the last one is marked customisation) · 03 explore (what each tier covers) · 04 finder (which tier fits; the answers set a minimum tier, and `why` explains it) · 05 addons (eight customisation add-ons) · 06 plan (tier + add-ons → an email, WhatsApp or clipboard quotation request) · 07 next **dark**

- Three tiers only. The prices are TechNext's service fee and "On quotation".
- The code follows the tier count (`NAMES.length`, `--last`), so the two decks must stay in step: change both together.

## Presenter scripts: `presenter-guide.html` (internal, hand-written)
Word-for-word scripts for the JR-Tech (25), HST Medical (19) and Immaculate Connections (16, key `immaculate`, added 2026-10-15 d91f9c0, updated to 16 slides f30e668) decks: say / do / watch out / bridge / optional joke per slide, deck tabs, search, jokes and script-only toggles, rehearse mode (live slide in an iframe + timer). Not generated by the build and not in the launcher. **When a slide is added, moved or reworded in any of these decks, update this page's `DECKS` data too.** Deep link: `presenter-guide.html?deck=<key>`. Write each script from the deck's `<aside class="notes">` in spoken first person; the deck's own "never" lines (codes, as-of dates, samples, no rankings) go in `rules` and again as `watch` on the slide where they bite. The page is not built, so no ASSET_V bump; the localhost preview is blocked in the in-app browser, so verify on the live URL. Adding another deck = another key in `DECKS` with `url`, `parts` and `slides`.

## The launcher: `index.html`
Source `_src/decks/index.html` with `{{launcher}}` from `DECKS`, `assets/index.css|js`, and `sw.js`.

- **Hero:** "12 decks, made to be clicked" (12 since the JR-Tech deck).
- **Groups:** About TechNext · What we build · Odoo · Client decks · Pricing (each with a `GROUPS` key + blurb).
- **Find bar (2026-10-11, 3c22368):** sticky bar with search (`/` focuses it), group tabs with counts, Topic chips (from each deck's `tags`, AND), Length chips (≤10 · 15–25 · 30+ min), Sort, grid / list view (remembered in localStorage). No filter + "By group" = grouped; anything else = one flat sorted grid (`.ix-flat`), with the group name shown on each card. State is in the hash (`#g=odoo&t=ai&q=crm`) so a filtered view can be sent; `#guide` is left alone. Groups flow on a 4-column grid, each spanning as many columns as it has decks (`--n`), so two 2-deck groups share a row (2 cols ≤1100px, 1 col ≤680px). Hero shows decks / slides / hours (`{{slide_count}}`, `{{hours}}`); shortcuts, tips and TV set-ups sit in a folded "How to present" section (`#guide`).
- **Cards:** a thumbnail with a hover picture, then slides and minutes, the title and description, and one row of actions: Present, Kiosk loop, PDF, Share.
- **Card sizes:** `.ix-body` is a size container. At 315px or less the link icons hide; at 281px or less "Kiosk" stays without "loop"; at 254px or less the padding tightens. It was verified from 320 to 1440px.
- **Sections:** "Presenting tips" and "Presenting on a TV or projector", plus "Save every deck for offline use".
- **PRODUCT.md** describes a planned living dashboard: a team-only address, a registry, owners and statuses, freshness flags and GoatCounter views. It is NOT built: the launcher is still the site root. Don't treat it as done. Ask before building it.

## Baseline QA, 2026-10-04 (`deck_check.py` on all 11 decks, `--phone` included)

0 errors and 16 warnings. Every deck turns on a phone, and none throws in play or in `?print`. These warnings are the to-fix list for the coming edit. Each one is a call for the user: fix it, or record it as intended.

- **Text cut with "…":**
  - Hitachi 06 dispatch: the job card shows "#HD-2431 · Mand…" and "lift stopped, brake pa…". The card is too narrow; widen it or shorten the text.
  - Odoo CRM 03 mv1: the list cells "Orchard Pilates Studio" and "Tiong Bahru Bakehouse". Odoo truncates list columns the same way, so this may stay.
  - Odoo Sales 08 mv6: "Monitor riser: 46 on hand, sent…".
  - Service showcase 12 agents: "an email arrives, the order changes, a p…".
- **Text under 11px:**
  - avatar initials: service showcase 04 crm (10px) and What is Odoo 08 w1 (9.5px);
  - chips: Hitachi "phase 2" and "In progress" (10.5px), Portfolio status "Live" (10.5px);
  - What is Odoo 10 w3: "Reorder rule" (10.8px).
  - These are acceptable as captions inside a product window. On a 1080p screen they render at about 12–13px.
- **Not caught by the script, from reading the decks:** the decks show three practices and "fourteen services", while technext.asia now has a fourth practice, Technology (IoT · Apps · Networks).

## Case study · F&B (`case-study-fnb`, 8 slides, share `s-xgqnin8`, group "Case studies")
- Composite Singapore F&B group, sample company **Saltfern Kitchens** (1 central kitchen, 5 outlets, 140 menu items, 60 suppliers, 7 tools). Every figure is sample data, labelled.
- Slides: 1 cover (hub art) · 2 client (7 tools picker) · 3 ripple (chicken +12%, S$0.21/set, 9,000 sets/month, found day 38; counter to S$2,394) · 4 flows (Goods/Food/Money/People, Before/With Odoo) · 5 arch (9 apps: Manufacturing, Inventory, Quality / Point of Sale, Restaurant, Planning / Purchase, Accounting, Dashboards) · 6 w1 replenishment (6 steps, Play) · 7 w2 plate costing (BOM, chicken slider S$6-9/kg, dine-in S$7.80 vs delivery S$9.40 at 30% commission, target 32%) · 8 rollout 4 phases + QR.
- Honest limits kept in notes: delivery-app orders/payouts by connector or import, confirmed per platform; payroll stays with the client's provider.

## Case studies, seven more (2026-10-12, one per technext.asia industry; 8 slides each, sample companies)
| Deck | Sample company | Problem | Share |
|---|---|---|---|
| case-study-medical | Kinsail Medical (6 clinics) | recalled lot untraceable; panel claims unbilled | s-xgj7pps |
| case-study-travel | Wayfern Journeys | SGD price vs JPY/KRW/EUR costs, pax changes, deposits before payments | s-xhukm4h |
| case-study-retail | Weftwood (8 stores) | right stock wrong store, markdowns, loyalty per store | s-2prpj3b |
| case-study-ecommerce | Kelpmere Skin | 11.11 oversell across 4 channels, kits, payouts vs bank | s-fdfnstp |
| case-study-construction | Lattwell Fit-Out (12 projects) | green monthly, red at handover; variations, retention | s-pct2pbp |
| case-study-manufacturing | Kerrowan Precision | breakdown cascade, quotes without routing cost, old revisions | s-6eenfw6 |
| case-study-wellness | Tidemere Studios (4 studios + spa) | prepaid credits owed, failed renewals, room double-booking | s-q2wcuku |

## Case study · Retail & Ecommerce (`case-study-retail-ecommerce`, 9 slides, share `s-j7avbpv`, group "Case studies", 2026-10-13)
- The combined omnichannel deck (user: "In APAC, retail and e-commerce operations now overlap… POS, e-commerce, inventory, accounting and CRM run in one system"). Sample company **Harrowmere Living** (web-searched 2026-10-13: no business by that name): homeware, 5 stores (Katong, Bishan, Tiong Bahru + two unnamed), website shipping SG & MY, Shopee + Lazada, 860 products, 1 warehouse, 6 systems. Prefix `om-`; reuses case-study.css (`fb-agenda`, `fb-stats`, `fb-ap`, `fb-docs`, `fb-ro/ph/pd/cta`, `fb-art/core/n`).
- Slides: 1 cover (5-app hub: POS, eCommerce, Inventory, Accounting, CRM) · 2 client "One customer, five strangers" (7 moments of one customer's month; Her month / Your systems toggle; who each system thinks she is) · 3 knot "Paid online, sold at the till" (5 steps, Katong Saturday: web file says 2, collect order 10:04, till sells 2 at 11:40, 2nd order 14:15, empty shelf 17:30 → 2 customers, S$256 refunded by hand; day 4 S$18 from the drawer → S$274) · 4 five seams (Stock, Customer, Price, Returns, Money; separate / One Odoo toggle, auto-flips after 4.2 s) · 5 arch hub picker (closes-the-seam + replaces) · 6 w1 click & collect (Show Available Qty per store, Pay on Site, KAT/PICK to a collect shelf, walk-in sells the last, POS Quotations/Orders settles S10482) · 7 w2 one customer (152→280→142 points; website form → CRM lead → Won S$4,480 = 40 × S$128 at 12.5% corporate pricelist) · 8 w3 one set of books (5 sessions S$18,420 + web S$6,380 + marketplaces S$5,390 = S$30,190; margin per dinner set by channel: price S$128, cost S$46, card 1.9%, web shipping S$9 + 3.4% + S$0.50, marketplace fee slider 8–30% (default 18%) + S$5 voucher) · 9 rollout (product/stock → stores on POS → website on the same stock → CRM, Email Marketing, connectors) + QR.
- Honest limits in notes: two-step pick to a collect shelf is a route we configure; POS settle flow confirmed on the client's version; connectors are Enterprise and sync on a schedule; payouts reconciled from imported settlement reports; sample fees only.
- The single Retail and Ecommerce decks stay; this one is the pitch when a prospect does both.


## Our talent (`technext-talent`, About TechNext group, 10 slides, share s-xandk4f; slide 5 `people` = 3 PLACEHOLDER profile flip cards, data-ph fields)
cover (six adviser chips orbit the plane, SG/PH/VN inside) · asks (sales-demo questions struck, adviser questions land, 2 builds) · offices (company-profile map, talent per office) · roles (6 tabs = builds 0-5, panel per adviser from technext.asia/advisers) · team (problem chips -> advisers + crew light; demo picks month-end + stock until clicked; settle = those two) · process (Listen/Advise/Implement/Stay plane track) · crafts (3 practice cards + "Who" footers; hover/auto-walk lights the office) · rules (4 rules, dark) · contact. Hover thumb = slide 4. Source text: technext.asia/advisers, /life. Technology practice (IoT/Apps/Networks) NOT shown yet (content-rules: confirm first).
